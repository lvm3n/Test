import json, re, csv, io
s=open('/home/claude/w/kognitivni-baterie/assets/app.html',encoding='utf8').read()
def bank(n):
    i=s.index('const '+n+' = ')+len('const '+n+' = '); return json.JSONDecoder().raw_decode(s[i:])[0]
def ver(key):
    m=re.search(r"key:'"+key+r"'[^\n]{0,400}?version:'([^']+)'",s) or re.search(r"K = '"+key+r"'[\s\S]{0,20000}?version:'([^']+)'",s); return m.group(1) if m else ''
rows=[]
def val(test,it):
    if test=='adhd': return 'obrácená – před sčítáním rekódovat 4 − odpověď (ve skórech se nesčítá)' if str(it.get('code','')).startswith('REV_') else '+ (vyšší = více obtíží)'
    if test=='masking': return '+ (vyšší = více maskování); X = situace se nestává (chybějící)'
    return ''
def add(test, items, idf, textf, ansf, lvlf, extra=lambda it:''):
    for k,it in enumerate(items):
        rows.append({'test':test,'verze':ver(test),'poradi_v_bance':k+1,'id':idf(it),'zneni_popis':textf(it),'spravna_odpoved':ansf(it),'uroven_obtiznost':lvlf(it),'valence':val(test,it),'poznamka':extra(it)})
j=lambda x: ' '.join(map(str,x)) if isinstance(x,list) else str(x)
M=bank('BANK_MATICE')
add('matice',M['test'],lambda it:'matice_%s'%it['p'],lambda it:'%s | %s | %s'%(it.get('carrier',''),it.get('family',''),it.get('rule','')),lambda it:'ABCDE'[it['answer']],lambda it:'úroveň %s, b %s'%(it.get('level',''),it.get('b','')))
V=bank('BANK_VAHY')
add('vahy',V['test'],lambda it:it['id'],lambda it:it.get('popis',''),lambda it:json.dumps(it['ans'],ensure_ascii=False),lambda it:'b %s'%it.get('b',''),lambda it:it.get('faze',''))
D=bank('BANK_DED')
lab={k:v['label'] for k,v in D['vis'].items()}
add('dedukce',D['items'],lambda it:it['id'],lambda it:'síť: %d vztahů, cíl %s, odhaleno %d'%(len(it['cons']),it['target'],len(it['reveals'])),lambda it:lab[it['answer']],lambda it:'úroveň %d; technika %s; jádro sporu %s; větvení %s'%(it['tier'],'+'.join((it.get('metriky') or {}).get('used',[])),(it.get('metriky') or {}).get('refutation_core',''),(it.get('metriky') or {}).get('branching','')))
P=bank('BANK_POR')
add('por',P['forms']['A'],lambda it:it['id'],lambda it:'řada: '+', '.join(it['targets'])+' | rušivé: '+', '.join(it['lures']),lambda it:' '.join(it['targets']),lambda it:'délka %d, možností %d'%(it['K'],len(it['layout'])))
R=bank('BANK_RDS')
for f in ('A',):
    add('rds',R['forms'][f],lambda it:it['id'],lambda it:'proud: '+j(it['full']),lambda it:j(it['target']),lambda it:'K%d U%d'%(it['K'],it['U']),lambda it,f=f:'forma '+f)
add('zpetna',bank('BANK_DB'),lambda it:it['id'],lambda it:'řada: '+j(it['seq']),lambda it:j(it['target']),lambda it:it.get('uroven',''))
G=bank('BANK_GCT2')
add('gcslovni',G['slovni'],lambda it:it['id'],lambda it:it.get('q',''),lambda it:'; '.join(it.get('acc',[])),lambda it:it.get('L',''))
add('gcznalosti',G['znalosti'],lambda it:it['id'],lambda it:it.get('q',''),lambda it:'; '.join(it.get('acc',[])),lambda it:it.get('L',''))
SK=bank('BANK_SKOLA')
txt=lambda it: it.get('stem') or it.get('q') or it.get('text') or it.get('prompt') or ''
ans=lambda it: it.get('exact') or (it['opts'][it['ans']] if 'opts' in it and isinstance(it.get('ans'),int) else it.get('ans') or it.get('correct') or '')
for key,src in (('pocitani','pocitani_v2'),('ulohy','ulohy_v2'),('synonyma','synonyma'),('cteni','cteni')):
    L=SK[src]['test']; add(key,L,lambda it:it.get('id',''),txt,ans,lambda it:'b %s'%it.get('b',''))
SC=bank('BANK_SCALES')
add('adhd',SC['adhd'],lambda it:it['code'],lambda it:it.get('m',''),lambda it:'',lambda it:it.get('sub',''),lambda it:'ženský tvar: '+it.get('f','') if it.get('f')!=it.get('m') else '')
add('masking',SC['mask'],lambda it:it['code'],lambda it:it.get('m',''),lambda it:'',lambda it:it.get('sub',''))
GV=bank('BANK_GV')
add('papir',GV['papir'],lambda it:it['id'],lambda it:'přeložení: '+j(it['folds'])+' | dírek %d'%len(it['holes'])+(' | trojúhelník' if any(len(h)>2 for h in it['holes']) else ''),lambda it:json.dumps(it['answer']),lambda it:'odhad %s (pův. úroveň %s)'%(it.get('obtiznost_odhad',''),it.get('level','')))
CT=bank('BANK_CT2')
add('cteni2',CT,lambda it:it['id'],lambda it:(it.get('text') or ' … '.join(it.get('veta',[])) or '')+(' | otázka: '+it['q'] if it.get('q') else ''),lambda it:str(it.get('klic','')),lambda it:'úroveň %s, %s'%(it.get('L',''),it.get('proces','')),lambda it:it.get('f',''))
ST=bank('BANK_STAN')
add('stanoviste',ST['items'],lambda it:it['id'],lambda it:'%s, %d stanovišť | %s'%(it['topology'],it['n'],' ; '.join(r['kind']+' '+json.dumps(r['args'][0],ensure_ascii=False) for r in it['rules'])),lambda it:it['answer']+1,lambda it:'úroveň %d'%it['level'],lambda it:'pravidel %d; kritických %d'%(len(it['rules']),it['metrics']['critical_clues']))
ROT=bank('BANK_ROT')
add('rotace',ROT,lambda it:it.get('id',''),lambda it:'mentální rotace, %d možností'%len(it.get('options',[])),lambda it:' '.join(str(i+1) for i,o in enumerate(it.get('options',[])) if o.get('correct')),lambda it:it.get('level',''))
SRCE=bank('BANK_SRCE')
items=sorted(SRCE,key=lambda x:x.get('order_v2',0)) if isinstance(SRCE,list) else (SRCE.get('A') or SRCE.get('items') or [x for v in SRCE.values() if isinstance(v,list) for x in v])
add('srce',items,lambda it:it.get('id',''),lambda it:it.get('sentence') or it.get('text') or '',lambda it:it.get('side',''),lambda it:'%s slov, %s'%(it.get('words',''),it.get('family','')))
out=io.StringIO(); w=csv.DictWriter(out,fieldnames=list(rows[0].keys()),delimiter=';'); w.writeheader(); w.writerows(rows)
open('/home/claude/w/kognitivni-baterie/assets/codebook.csv','w',encoding='utf-8-sig').write(out.getvalue())
from collections import Counter
print(Counter(r['test'] for r in rows)); print('bez ID:',[ (r['test']) for r in rows if not r['id']][:5])
