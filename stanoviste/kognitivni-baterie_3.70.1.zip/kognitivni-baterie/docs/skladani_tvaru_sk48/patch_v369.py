"""3.69.0 / 1.30.0 – Skládání tvarů SK30-W1: střední část nově po principu Visual Puzzles (kategoriální distraktory), bez „porovnávání milimetrů“."""
import os, json, shutil, csv, io
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st13/BANK_SKW.json', encoding='utf8'))
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK34-v2', pickN:3,", "version:'SK30-W1', pickN:3,")
    rep(app, "['SK34-v1', 'SK34-v2']]", "['SK34-v1', 'SK34-v2'], ['SK30-W1']]")
    rep(app, "list.findIndex(x => x.id === 'SK48_04')),   // od 9 let start za úvodními položkami (6 se připíše)",
        "list.findIndex(x => x.id === 'SKW_01')),   // od 9 let start za barevnými úvodními položkami (4 se připíší)")
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']
        desc = '; '.join(x for x in (f.get('pasmo', ''), f.get('sablona', ''), ('mřížka %s, spojů %s' % (f['mrizka'], f['spoju'])) if 'mrizka' in f else '',
                                     ('distraktory: ' + f['distraktory']) if f.get('distraktory') else '') if x)
        body.append(['skladani', 'SK30-W1', k + 1, it['id'], 'vyber %d z 6 dílů; %s' % (it['pick'], desc), ' '.join(str(i + 1) for i in it['answerIdx']),
                     'nácvik' if it['level'] == 0 else 'pořadí %d' % (k - 1), '', '' if it['level'] == 0 else 'limit %d s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60)])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.68.0', '3.69.0', 2); rep(EN + 'cognitive-battery-en.php', '1.29.0', '1.30.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.68.0</div>', '>verze 3.69.0</div>'); rep(EN + 'assets/app.html', '>version 1.29.0 (EN)</div>', '>version 1.30.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('gen_wais.py', 'wais_mid.json', 'BANK_SKW.json', 'preview_skw.html'): shutil.copy('st13/' + f, dd + f)
shutil.copy('st14/patch_v369.py', dd + 'patch_v369.py')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.69.0 – Skládání tvarů SK30-W1: celý průběh podle principu Visual Puzzles
Původní sada měla ve střední části úlohy typu „porovnej proporce podobných čtyřúhelníků“ (distraktory lišící se o pár
procent) – to měří jemné vizuální rozlišování, ne skládání. Všechny takové položky vyřazeny; zůstaly jen 40 a 44
(pravoúhlé díly se zuby). Nová střední část (gen_wais.py) – díly jsou rozpoznatelné základní tvary, distraktory se liší
KATEGORIÍ (jiný tvar), výrazně VELIKOSTÍ (×0,62 / ×1,45), ZRCADLEM nebo VZOREM:
 krok 1  SK_E1–E4  barevné díly, hranice vidět, bez otáčení (beze změny)
 krok 2  SKW_01–05 jednobarevné, hranice dílů v tvaru vidět, díly otočené po 90°, distraktory jiné kategorie
 krok 3  SKW_06–11 bez hranic, dvoubarevný vzor (kruh/pruh) přes více dílů; distraktor se špatně položeným vzorem, jiná velikost
 krok 4  SKW_12–17 jednobarevné bez hranic (i kruh a oblouk), otočení po 45°; jiná velikost, zrcadlo, jiný tvar
 krok 5  strop: SKS_01–07 (zuby, čepy, výřezy) + 40, 44
Jednoznačnost u mnohoúhelníků ověřena řešičem; u vzorových a kulatých položek rozhoduje vzor/kategorie/velikost.
Start od 9 let: SKW_01 (4 úvodní položky se připíší). 30 položek, nová srovnávací skupina SK30-W1.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.30.0 – Shape Assembly SK30-W1: střední část podle principu Visual Puzzles (kategoriální distraktory) – jako česká 3.69.0.
''')
print('ok')
