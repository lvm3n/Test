"""3.68.0 / 1.29.0 – Skládání tvarů SK34-v2: u prvních položek viditelné hranice dílů (postup jako Visual Puzzles), úprava pořadí."""
import os, json, shutil
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st13/BANK_SK34.json', encoding='utf8'))
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "  function svg(paths, w, h, u, outline, W, H){", "  function svg(paths, w, h, u, outline, W, H, seams){   // seams: u prvních položek viditelné hranice dílů v tvaru")
    rep(app, """paths.forEach(p => { s += `<path d="${p.d}" fill="${p.fill}" stroke="${outline ? p.fill : '#1d232b'}" stroke-width="${outline ? (1.2 / u).toFixed(4) : sw}" stroke-linejoin="round"/>`; });""",
        """paths.forEach(p => { s += `<path d="${p.d}" fill="${p.fill}" stroke="${outline && !seams ? p.fill : '#1d232b'}" stroke-width="${outline ? (1.2 / u).toFixed(4) : sw}" stroke-linejoin="round"/>`; });""")
    rep(app, "const refRender = (it) => { const u = unit(it), t = it.target; return svg(t.paths, t.w, t.h, u, t.outline); };",
        "const refRender = (it) => { const u = unit(it), t = it.target; return svg(t.paths, t.w, t.h, u, t.outline, null, null, t.seams); };")
    rep(app, "svg(it.target.paths, it.target.w, it.target.h, u, it.target.outline) + '</div>", "svg(it.target.paths, it.target.w, it.target.h, u, it.target.outline, null, null, true) + '</div>")
    rep(app, "version:'SK34-v1', pickN:3,", "version:'SK34-v2', pickN:3,")
    rep(app, "['SK34-v1']]", "['SK34-v1', 'SK34-v2']]")
rep(CZ + 'kognitivni-baterie.php', '3.67.0', '3.68.0', 2); rep(EN + 'cognitive-battery-en.php', '1.28.0', '1.29.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.67.0</div>', '>verze 3.68.0</div>'); rep(EN + 'assets/app.html', '>version 1.28.0 (EN)</div>', '>version 1.29.0 (EN)</div>')
shutil.copy('st13/BANK_SK34.json', CZ + 'docs/skladani_tvaru_sk48/BANK_SK34.json'); shutil.copy('st14/patch_v368.py', CZ + 'docs/skladani_tvaru_sk48/patch_v368.py')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.68.0 – Skládání tvarů SK34-v2: postup obtížnosti podle principu Visual Puzzles
Obecný princip postupu (bez převzetí položek): (1) tvar ukazuje hranice dílů, díly neotočené, distraktory jiné kategorie →
(2) hranice vidět, díly otočené → (3) jen obrys, barevný vzor ještě napovídá → (4) jednobarevné tvary bez hranic, i oblé →
(5) strop: pravoúhlé díly se zuby/čepy, distraktory ze stejné „slovní zásoby“. Doplněn chybějící krok 2: nácvik, úvodní
položky SK_E1–E4 a první jednobarevné položky SK48_01, 03, 04, 08 ukazují v tvaru hranice dílů (tenká čára); SK48_08 posunuta
hned za SK48_04. Dál beze změny. Ve srovnání spojeno s SK34-v1 (stejné položky).
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.29.0 – Shape Assembly SK34-v2: viditelné hranice dílů u prvních položek, SK48_08 posunuta – jako česká 3.68.0.
''')
print('ok')
