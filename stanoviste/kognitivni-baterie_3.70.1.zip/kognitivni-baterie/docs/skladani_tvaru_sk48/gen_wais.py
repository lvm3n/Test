"""Střední část Skládání tvarů po principu Visual Puzzles: díly jsou rozpoznatelné základní tvary (čtverec, obdélník,
pravoúhlý/rovnostranný trojúhelník, lichoběžník, kosočtverec, půlkruh, výseč, L), distraktory se liší KATEGORIÍ
(jiný tvar), výrazně VELIKOSTÍ (≥ 35 %), ZRCADLEM nebo VZOREM – nikdy ne o milimetry. Úrovně:
 L2 hranice dílů vidět, jednobarevné, díly otočené;  L3 bez hranic, dvoubarevný vzor přes díly;  L4 bez hranic, jednobarevné."""
import math, random, json, itertools
from shapely.geometry import Polygon, Point, box
from shapely.ops import unary_union
from shapely import affinity
from solve import solve
S3 = math.sqrt(3)
def P(*pts): return Polygon(pts)
def sector(cx, cy, r, a0, a1, n=48):
    pts = [(cx, cy)] + [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]
    return Polygon(pts)
# --- šablony: (název, kategorie dílů, funkce rng -> seznam dílů v souřadnicích tvaru) ---
def t_rect_sq_tri(r):
    d = r.choice([0, 1]); A = box(0, 0, 1, 1)
    B, C = (P((1, 0), (2, 0), (2, 1)), P((1, 0), (2, 1), (1, 1))) if d else (P((1, 0), (2, 0), (1, 1)), P((2, 0), (2, 1), (1, 1)))
    return [A, B, C], ['čtverec', 'pravoúhlý trojúhelník', 'pravoúhlý trojúhelník']
def t_sq_rect_2tri(r):
    return [box(0, 0, 2, 1), P((0, 1), (2, 1), (0, 2)), P((2, 1), (2, 2), (0, 2))], ['obdélník', 'pravoúhlý trojúhelník', 'pravoúhlý trojúhelník']
def t_trap(r):
    return [P((0, 0), (1, 0), (1, 1)), box(1, 0, 2, 1), P((2, 0), (3, 0), (2, 1))], ['pravoúhlý trojúhelník', 'čtverec', 'pravoúhlý trojúhelník']
def t_house(r):
    return [box(0, 0, 2, 2), P((0, 2), (1, 2), (1, 3)), P((1, 2), (2, 2), (1, 3))], ['čtverec', 'pravoúhlý trojúhelník', 'pravoúhlý trojúhelník']
def t_bigtri(r):
    return [box(0, 0, 1, 1), P((1, 0), (2, 0), (1, 1)), P((0, 1), (1, 1), (0, 2))], ['čtverec', 'pravoúhlý trojúhelník', 'pravoúhlý trojúhelník']
def t_hex(r):
    h = S3 / 2
    tr = P((-0.5, h), (0, 0), (1, 0), (1.5, h))                      # dolní polovina šestiúhelníku = lichoběžník
    rh = P((-0.5, h), (0.5, h), (1, 2 * h), (0, 2 * h))               # kosočtverec
    et = P((0.5, h), (1.5, h), (1, 2 * h))                            # rovnostranný trojúhelník
    return [tr, rh, et], ['lichoběžník', 'kosočtverec', 'rovnostranný trojúhelník']
def t_circle(r):
    a = r.choice([0, 90, 180, 270])
    return [sector(0, 0, 1, a, a + 180), sector(0, 0, 1, a + 180, a + 270), sector(0, 0, 1, a + 270, a + 360)], ['půlkruh', 'čtvrtkruh', 'čtvrtkruh']
def t_parallelogram(r):
    return [P((0, 0), (1, 0), (1, 1)), box(1, 0, 2, 1), P((2, 0), (3, 1), (2, 1))], ['pravoúhlý trojúhelník', 'čtverec', 'pravoúhlý trojúhelník']
def t_L(r):
    return [box(0, 0, 1, 2), box(1, 0, 3, 1), P((0, 2), (1, 2), (0, 3))], ['obdélník', 'obdélník', 'pravoúhlý trojúhelník']
def t_semirect(r):
    # obdélník s půlkruhem nahoře: obdélník + 2 čtvrtkruhy
    return [box(0, 0, 2, 1), sector(1, 1, 1, 0, 90), sector(1, 1, 1, 90, 180)], ['obdélník', 'čtvrtkruh', 'čtvrtkruh']
def t_chevron(r):
    return [P((0, 0), (1, 0), (2, 1), (1, 1)), P((2, 1), (1, 2), (0, 2), (1, 1)), P((2, 1), (3, 1), (2, 2), (1, 2))][:2] + [P((1, 1), (2, 1), (1, 2))], ['rovnoběžník', 'rovnoběžník', 'pravoúhlý trojúhelník']
TEMPL = {'obdélník: čtverec+2△': t_rect_sq_tri, 'čtverec: obdélník+2△': t_sq_rect_2tri, 'lichoběžník: 2△+□': t_trap, 'domek': t_house,
         'velký △: □+2△': t_bigtri, 'šestiúhelník: lichoběžník+kosočtverec+△': t_hex, 'kruh: půlkruh+2 čtvrtkruhy': t_circle,
         'rovnoběžník: 2△+□': t_parallelogram, 'L s rohem': t_L, 'obdélník s obloukem': t_semirect}
# --- distraktory jiné kategorie (velikost ≈ plocha klíčového dílu) ---
CAT = {'kruh': lambda: Point(0, 0).buffer(1, 48), 'rovnostranný trojúhelník': lambda: P((0, 0), (2, 0), (1, S3)),
       'pětiúhelník': lambda: Polygon([(math.cos(math.radians(90 + 72 * i)), math.sin(math.radians(90 + 72 * i))) for i in range(5)]),
       'šestiúhelník': lambda: Polygon([(math.cos(math.radians(60 * i)), math.sin(math.radians(60 * i))) for i in range(6)]),
       'kosočtverec': lambda: P((0, 0), (1, 0.6), (2, 0), (1, -0.6)), 'L': lambda: P((0, 0), (2, 0), (2, 1), (1, 1), (1, 2), (0, 2)),
       'půlkruh': lambda: sector(0, 0, 1, 0, 180), 'lichoběžník': lambda: P((0, 0), (3, 0), (2, 1), (1, 1)), 'čtverec': lambda: box(0, 0, 1, 1),
       'obdélník': lambda: box(0, 0, 3, 1), 'pravoúhlý trojúhelník': lambda: P((0, 0), (1, 0), (0, 1)), 'čtvrtkruh': lambda: sector(0, 0, 1, 0, 90),
       'rovnoběžník': lambda: P((0, 0), (1, 0), (1.6, 1), (0.6, 1)), 'kříž': lambda: unary_union([box(1, 0, 2, 3), box(0, 1, 3, 2)]),
       'ovál': lambda: affinity.scale(Point(0, 0).buffer(1, 48), 1.6, 1)}
def scale_to(g, area): k = math.sqrt(area / g.area); return affinity.scale(g, k, k)
def norm_target(pieces):
    U = unary_union([g.buffer(1e-7, join_style=2) for g in pieces]).buffer(-1e-7, join_style=2).simplify(1e-6); k = 1 / math.sqrt(U.area); b = U.bounds
    f = lambda g: affinity.scale(affinity.translate(g, -b[0], -b[1]), k, k, origin=(0, 0))
    return f(U), [f(g) for g in pieces]
def make(name, level, rng, color, color2=None):
    for attempt in range(200):
        pieces, cats = TEMPL[name](rng)
        U, K = norm_target(pieces)
        # vzor (L3): kruh nebo pruh druhou barvou přes více dílů
        pat = None
        if level == 3:
            c = U.centroid; b = U.bounds
            pat = rng.choice(['kruh', 'pruh'])
            pat = Point(c.x + rng.uniform(-.1, .1), c.y + rng.uniform(-.1, .1)).buffer(0.32, 48) if pat == 'kruh' else \
                  affinity.rotate(box(b[0] - 1, c.y - 0.12, b[2] + 1, c.y + 0.12), rng.choice([0, 45, 90, 135]), origin=c)
            pat = pat.intersection(U)
            if sum(1 for g in K if g.intersection(pat).area > 0.01) < 2: continue
        # distraktory
        D = []
        used = set(cats)
        others = [c for c in CAT if c not in used]
        if level == 2:
            for c in rng.sample(others, 3): D.append((CAT[c](), None, 'jiný tvar: ' + c))
        else:
            # 1) výrazně jiná velikost jednoho klíčového dílu
            k = rng.randrange(3); f = rng.choice([0.62, 1.45])
            D.append((affinity.scale(K[k], f, f), 'kopie vzoru' if pat is not None else None, 'jiná velikost (×%.2f)' % f))
            # 2) u L3: díl se špatně umístěným vzorem; jinak zrcadlo chirálního dílu nebo jiný tvar
            if pat is not None:
                k2 = rng.choice([i for i in range(3) if K[i].intersection(pat).area > 0.01])
                D.append((K[k2], 'zrcadlený vzor', 'špatný vzor'))
            else:
                m = affinity.scale(K[(k + 1) % 3], -1, 1)
                if min(Kk.symmetric_difference(m).area for Kk in [affinity.rotate(K[(k + 1) % 3], a, origin='centroid') for a in range(0, 360, 5)]) > 0.02 * K[(k + 1) % 3].area:
                    D.append((m, None, 'zrcadlo'))
                else:
                    c = rng.choice(others); others.remove(c); D.append((CAT[c](), None, 'jiný tvar: ' + c))
            c = rng.choice(others); D.append((CAT[c](), None, 'jiný tvar: ' + c))
        # velikost distraktorů jiné kategorie ≈ průměrný klíčový díl
        avg = sum(g.area for g in K) / 3
        D = [(scale_to(g, avg * rng.uniform(0.85, 1.2)) if kind.startswith('jiný tvar') else g, pt, kind) for g, pt, kind in D]
        opts = [(g, 'cíl', i) for i, g in enumerate(K)] + [(g, kind, pt) for g, pt, kind in D]
        rng.shuffle(opts)
        rot = lambda: rng.choice([0, 90, 180, 270]) if level == 2 else rng.choice([0, 45, 90, 135, 180, 225, 270, 315])
        out = []
        for g, kind, extra in opts:
            a = rot(); gg = affinity.rotate(g, a, origin='centroid')
            # vzor na dílu
            paths = None
            if pat is not None and kind == 'cíl':
                frag = g.intersection(pat); paths = (g, frag)
            elif pat is not None and extra == 'kopie vzoru':
                src = K[[i for i in range(3) if K[i].area > 0][0]]; frag = None
                paths = (g, None)
            elif pat is not None and extra == 'zrcadlený vzor':
                frag = affinity.scale(g.intersection(pat), -1, 1, origin=g.centroid).intersection(g)
                if frag.area < 0.005: frag = affinity.rotate(g.intersection(pat), 180, origin=g.centroid).intersection(g)
                paths = (g, frag)
            out.append((gg, kind, a, paths, g))
        keys = [i for i, o in enumerate(out) if o[1] == 'cíl']
        # jednoznačnost (geometrie; u L3 navíc rozhoduje vzor)
        if level != 3 and 'kruh' not in name and 'oblouk' not in name:
            Gs = [o[0] for o in out]
            if solve(U, [(i, Gs[i]) for i in keys], [1.0] * 3, 2e-3) is None: continue
            if any(abs(sum(Gs[i].area for i in c) - 1) < 0.05 and solve(U, [(i, Gs[i]) for i in c], [1.0] * 3, 2e-3) is not None
                   for c in itertools.combinations(range(6), 3) if set(c) != set(keys)): continue
        else:
            if any(abs(sum(out[i][0].area for i in c) - 1) < 0.03 for c in itertools.combinations(range(6), 3) if set(c) != set(keys)) and level != 3: continue
        return U, K, pat, out, keys
    return None
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def pd(g, ox, oy):
    if g.geom_type == 'MultiPolygon': return ' '.join(pd(q, ox, oy) for q in g.geoms)
    return 'M' + ' L'.join(fmt(x - ox) + ' ' + fmt(y - oy) for x, y in list(g.exterior.coords)[:-1]) + 'Z'
def to_item(iid, name, level, res, color, color2):
    U, K, pat, out, keys = res; b = U.bounds
    tpaths = [{'d': pd(g, b[0], b[1]), 'fill': color} for g in K]
    if pat is not None and not pat.is_empty: tpaths.append({'d': pd(pat, b[0], b[1]), 'fill': color2})
    opts = []
    for gg, kind, a, paths, g in out:
        q = gg.bounds; ps = [{'d': pd(gg, q[0], q[1]), 'fill': color}]
        if paths and paths[1] is not None and not paths[1].is_empty:
            fr = affinity.rotate(paths[1], a, origin=g.centroid); ps.append({'d': pd(fr, q[0], q[1]), 'fill': color2})
        opts.append({'paths': ps, 'w': round(q[2] - q[0], 4), 'h': round(q[3] - q[1], 4), 'correct': kind == 'cíl', 'kind': kind})
    return {'id': iid, 'level': level, 'pick': 3, 'target': {'paths': tpaths, 'outline': pd(U, b[0], b[1]), 'w': round(b[2] - b[0], 4), 'h': round(b[3] - b[1], 4), 'seams': level == 2},
            'options': opts, 'answerIdx': keys, 'facety': {'pasmo': {2: 'hranice vidět', 3: 'vzor', 4: 'jednobarevné'}[level], 'dilu': 3, 'sablona': name,
                                                            'distraktory': ', '.join(o['kind'] for o in opts if not o['correct'])}}
PLAN = [  # (úroveň, šablona, barva, druhá barva)
    (2, 'obdélník: čtverec+2△', '#3D8CCD', None), (2, 'domek', '#E0574D', None), (2, 'velký △: □+2△', '#5FAF63', None),
    (2, 'lichoběžník: 2△+□', '#7C58B5', None), (2, 'čtverec: obdélník+2△', '#ED8B37', None),
    (3, 'obdélník: čtverec+2△', '#2B4586', '#E8C547'), (3, 'čtverec: obdélník+2△', '#5FAF63', '#E0574D'), (3, 'kruh: půlkruh+2 čtvrtkruhy', '#E0574D', '#E8C547'),
    (3, 'rovnoběžník: 2△+□', '#7C58B5', '#E8C547'), (3, 'šestiúhelník: lichoběžník+kosočtverec+△', '#3D8CCD', '#ED8B37'), (3, 'domek', '#2B4586', '#ED8B37'),
    (4, 'kruh: půlkruh+2 čtvrtkruhy', '#D25499', None), (4, 'šestiúhelník: lichoběžník+kosočtverec+△', '#5FAF63', None), (4, 'L s rohem', '#ED8B37', None),
    (4, 'obdélník s obloukem', '#3D8CCD', None), (4, 'rovnoběžník: 2△+□', '#E0574D', None), (4, 'velký △: □+2△', '#7C58B5', None),
]
if __name__ == '__main__':
    rng = random.Random(777); items = []
    for k, (lv, name, c1, c2) in enumerate(PLAN):
        res = make(name, lv, rng, c1, c2)
        print(lv, name, 'OK' if res else 'NE', flush=True)
        if res: items.append(to_item('SKW_%02d' % (k + 1), name, lv, res, c1, c2))
    json.dump(items, open('wais_mid.json', 'w'), ensure_ascii=False); print(len(items))
