"""3.70.1 / 1.31.1 – Skládání tvarů: jednotný limit 45 s na položku (dřív 60 s u výběru 3 dílů od úrovně 3)."""
import os
os.chdir('/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/')
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
for d in (CZ, EN):
    rep(d + 'assets/app.html', "capFor:(it) => (it.pick === 2 || (it.level || 1) <= 2) ? 45 : 60,", "capFor:() => 45,   // jednotně 45 s (WAIS VP 30 s + čas na výběr 3 dílů)")
    cb = d + 'assets/codebook.csv'; L = open(cb, encoding='utf-8-sig').read().split('\n')
    L = [l.replace('limit 60 s', 'limit 45 s') if l.startswith('skladani;') else l for l in L]
    open(cb, 'w', encoding='utf-8-sig').write('\n'.join(L))
rep(CZ + 'kognitivni-baterie.php', '3.70.0', '3.70.1', 2); rep(EN + 'cognitive-battery-en.php', '1.31.0', '1.31.1', 2)
rep(CZ + 'assets/app.html', '>verze 3.70.0</div>', '>verze 3.70.1</div>'); rep(EN + 'assets/app.html', '>version 1.31.0 (EN)</div>', '>version 1.31.1 (EN)</div>')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.70.1 – Skládání tvarů: limit 45 s na každou položku (dřív 60 s u výběru 3 dílů). Položky beze změny.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.31.1 – Shape Assembly: limit 45 s na každou položku (jako česká 3.70.1).
''')
print('ok')
