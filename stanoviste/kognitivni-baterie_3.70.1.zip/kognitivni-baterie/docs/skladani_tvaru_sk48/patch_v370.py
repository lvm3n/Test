"""3.70.0 / 1.31.0 – Skládání tvarů SK31-W2: stropová SKS_01 nahrazena ornamentovou SKO_1, před SKS_07 přidána zámková SKL_2."""
import os, json, shutil, csv, io
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st15/BANK_SK31.json', encoding='utf8'))
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK30-W1', pickN:3,", "version:'SK31-W2', pickN:3,")
    rep(app, "['SK30-W1']]", "['SK30-W1'], ['SK31-W2']]")
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']
        desc = '; '.join(x for x in (f.get('pasmo', ''), f.get('sablona', ''), f.get('ornament', ''), ('švy ' + f['svy']) if f.get('svy') else '',
                                     ('mřížka %s, spojů %s' % (f['mrizka'], f['spoju'])) if 'mrizka' in f else '',
                                     ('distraktory: ' + f['distraktory']) if f.get('distraktory') else '') if x)
        body.append(['skladani', 'SK31-W2', k + 1, it['id'], 'vyber %d z 6 dílů; %s' % (it['pick'], desc), ' '.join(str(i + 1) for i in it['answerIdx']),
                     'nácvik' if it['level'] == 0 else 'pořadí %d' % (k - 1), '', '' if it['level'] == 0 else 'limit %d s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60)])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.69.1', '3.70.0', 2); rep(EN + 'cognitive-battery-en.php', '1.30.1', '1.31.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.69.1</div>', '>verze 3.70.0</div>'); rep(EN + 'assets/app.html', '>version 1.30.1 (EN)</div>', '>version 1.31.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('gen_orn.py', 'gen_lock.py', 'BANK_SK31.json', 'orn.html', 'lock.html', 'patch_v370.py'): shutil.copy('st15/' + f, dd + f)
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.70.0 – Skládání tvarů SK31-W2: dvě nové stropové položky
 SKO_1 (místo SKS_01): kruhová deska s vyřezaným ornamentem, 3 díly. Distraktory jsou díly jiné celé desky (v každém
       dílu jiný výběžek: hrot / zub / oblouk), takže do sebe zapadají – rozhoduje shoda s ornamentem v cíli.
 SKL_2 (nová, před SKS_07): cíl je plný kruh = 2 skořepiny s výřezy + nesouměrný ornament, který do nich zapadne.
       Distraktory: zrcadlový ornament + skořepina, do které zrcadlo přesně zapadá, a skořepina s jinak vyříznutým zubem.
Jednoznačnost ověřena řešičem (všechny trojice × otočení; gen_orn.py, gen_lock.py). 31 položek, nová srovnávací skupina SK31-W2.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.31.0 – Shape Assembly SK31-W2: ornamentová SKO_1 místo SKS_01 a nová zámková SKL_2 – jako česká 3.70.0.
''')
print('ok')
