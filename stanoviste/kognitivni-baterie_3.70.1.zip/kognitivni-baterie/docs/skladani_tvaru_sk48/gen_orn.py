"""Ornamentové stropové položky: deska (kruh) s vyřezaným ornamentem uprostřed, rozřezaná na 3 díly.
Distraktory = díly JINÉ, ale celistvé sady (alternativní ornament / zrcadlová deska) – samy do sebe zapadají.
Jednoznačnost: řešič zkouší všech 20 trojic × otočení kolem středu (díl obsahuje kus obvodu => střed je daný)."""
import json, math, random, itertools
from shapely.geometry import Point, Polygon, MultiPolygon
from shapely.ops import unary_union
from shapely import affinity
from shapely.geometry.polygon import orient
R, R0 = 1.0, 0.27
def pol(r, a): a = math.radians(a); return (r * math.cos(a), -r * math.sin(a))   # y dolů (SVG), úhel proti směru hodin
def lobe(kind, a, L=0.0):
    if kind == 'oblouk': return unary_union([Point(*pol(0.43 + L, a)).buffer(0.105, 32), Polygon([pol(R0 - .05, a - 9), pol(0.43 + L, a - 9), pol(0.43 + L, a + 9), pol(R0 - .05, a + 9)])])
    if kind == 'hrot': return Polygon([pol(R0 - .05, a - 15), pol(0.64 + L, a), pol(R0 - .05, a + 15)])
    if kind == 'zub':  # obdélníkový zub
        c, s = math.cos(math.radians(a)), -math.sin(math.radians(a)); n = (-s, c); w = 0.075
        p0, p1 = (R0 - .05) , 0.56 + L
        return Polygon([(c * p0 + n[0] * w, s * p0 + n[1] * w), (c * p1 + n[0] * w, s * p1 + n[1] * w), (c * p1 - n[0] * w, s * p1 - n[1] * w), (c * p0 - n[0] * w, s * p0 - n[1] * w)])
    if kind == 'T':  # zub s příčkou (kotva)
        c, s = math.cos(math.radians(a)), -math.sin(math.radians(a)); n = (-s, c); w, W = 0.05, 0.14
        p0, p1, p2 = R0 - .05, 0.47 + L, 0.6 + L
        pt = lambda r, t: (c * r + n[0] * t, s * r + n[1] * t)
        return Polygon([pt(p0, w), pt(p1, w), pt(p1, W), pt(p2, W), pt(p2, -W), pt(p1, -W), pt(p1, -w), pt(p0, -w)])
    raise ValueError(kind)
def hole(lobes): return affinity.scale(unary_union([Point(0, 0).buffer(R0, 64)] + [lobe(k, a, L) for k, a, L in lobes]), 1.2, 1.2, origin=(0, 0))
def plate(lobes): return Point(0, 0).buffer(R, 128).difference(hole(lobes))
def wedge(a0, a1, step=None):
    """Výseč mezi švy a0→a1 (proti směru). step=(r, d): šev jde radiálně do r, pak uhne o d stupňů a pokračuje ven."""
    def seam(a):
        if not step: return [(0, 0), pol(2, a)]
        r, d = step; return [(0, 0), pol(r, a), pol(r, a + d), pol(2, a + d)]
    arc = [pol(2, a0 + (a1 - a0) * t / 40) for t in range(41)]
    s0, s1 = seam(a0), seam(a1)
    return Polygon(s0 + arc[1:-1] + s1[::-1]).buffer(0)
def cut(lobes, seams, step=None):
    P = plate(lobes); out = []
    for i in range(len(seams)):
        a0, a1 = seams[i], seams[(i + 1) % len(seams)] + (360 if i == len(seams) - 1 else 0)
        g = P.intersection(wedge(a0, a1, step))
        if isinstance(g, MultiPolygon): g = max(g.geoms, key=lambda x: x.area)
        out.append(g)
    return P, out
def mirror(g): return affinity.scale(g, -1, 1, origin=(0, 0))
def placements(piece, T, step=0.5):
    res = []; A = piece.area
    for k in range(int(360 / step)):
        q = affinity.rotate(piece, k * step, origin=(0, 0))
        if q.difference(T).area < 2e-3 * A: res.append(q)
    return res
def solve(T, opts):
    sols = []; pl = [placements(o, T) for o in opts]
    for tri in itertools.combinations(range(len(opts)), 3):
        if abs(sum(opts[i].area for i in tri) - T.area) > 4e-3 * T.area: continue
        for a in pl[tri[0]]:
            for b in pl[tri[1]]:
                if a.intersection(b).area > 2e-3 * T.area: continue
                for c in pl[tri[2]]:
                    if unary_union([a, b, c]).symmetric_difference(T).area < 4e-3 * T.area: sols.append(tri); break
                else: continue
                break
            else: continue
            break
    return sols
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.').replace('-0', '0') if abs(v) > 5e-5 else '0'
def d_of(g):
    g = orient(g, 1.0); s = ''
    for ring in [g.exterior] + list(g.interiors):
        c = list(ring.coords)[:-1]; s += 'M' + ' L'.join(fmt(x) + ' ' + fmt(y) for x, y in c) + 'Z'
    return s
def norm(g, sc, rot):
    g = affinity.scale(affinity.rotate(g, rot, origin=(0, 0)), sc, sc, origin=(0, 0)).simplify(4e-4)
    x0, y0, x1, y1 = g.bounds; g = affinity.translate(g, -x0, -y0); return g, x1 - x0, y1 - y0
def item(iid, fill, lobes, seams, alt, kinds, step=None, seed=1, fac=None):
    rng = random.Random(seed)
    T, good = cut(lobes, seams, step)
    if alt == 'mirror': bad = [mirror(g) for g in good]
    else: _, bad = cut(alt, seams, step)
    sols = solve(T, good + bad)
    assert sols == [(0, 1, 2)], (iid, sols)
    for g, b in zip(good, bad): assert g.symmetric_difference(b).area > 0.012, iid   # rozdíl nesmí být „milimetrový“
    sc = 1 / math.sqrt(T.area)
    tg, w, h = norm(T, sc, 0)
    order = list(range(6)); rng.shuffle(order)
    allp = [(g, True, 'cíl') for g in good] + [(b, False, k) for b, k in zip(bad, kinds)]
    opts = []
    for j in order:
        g, ok, k = allp[j]; og, ow, oh = norm(g, sc, rng.choice([25, 70, 115, 160, 205, 250, 295, 340]) + rng.uniform(-8, 8))
        opts.append({'paths': [{'d': d_of(og), 'fill': fill}], 'w': round(ow, 4), 'h': round(oh, 4), 'correct': ok, 'kind': k})
    return {'id': iid, 'level': 5, 'pick': 3, 'target': {'paths': [{'d': d_of(tg), 'fill': fill}], 'outline': d_of(tg), 'w': round(w, 4), 'h': round(h, 4)},
            'options': opts, 'answerIdx': [i for i, o in enumerate(opts) if o['correct']],
            'facety': dict({'pasmo': 'strop (ornament)', 'dilu': 3, 'distraktory': ', '.join(kinds), 'reseni': 'jediná trojice (řešič)'}, **(fac or {}))}

if __name__ == '__main__':
  ITEMS = []
  # O1: 3 díly ~po 120°, rovné švy; distraktory = deska s jiným ornamentem (v každém dílu jiný jeden výběžek)
  L1 = [('hrot', 30, 0), ('oblouk', 85, 0), ('zub', 150, 0), ('hrot', 205, 0), ('oblouk', 270, 0), ('zub', 320, 0)]
  A1 = [('hrot', 30, 0), ('zub', 85, 0), ('zub', 150, 0), ('oblouk', 205, 0), ('oblouk', 270, 0), ('hrot', 320, 0)]
  ITEMS.append(item('SKO_1', '#3D8CCD', L1, [0, 118, 240], A1, ['zub místo oblouku', 'oblouk místo hrotu', 'hrot místo zubu'], seed=12, fac={'svy': 'rovné', 'ornament': '6 výběžků'}))
  # O2: nestejné díly, rovné švy; distraktory = zrcadlová deska (každý díl má zrcadlový protějšek)
  L2 = [('T', 20, 0), ('hrot', 70, 0), ('oblouk', 120, 0), ('zub', 175, -.05), ('hrot', 230, .04), ('oblouk', 285, 0), ('T', 330, -.05)]
  ITEMS.append(item('SKO_2', '#7E57C2', L2, [45, 150, 255], 'mirror', ['zrcadlo', 'zrcadlo', 'zrcadlo'], seed=22, fac={'svy': 'rovné', 'ornament': '7 výběžků'}))
  # O3: švy se schodem, 7 výběžků; distraktory = jiná deska (posunutý výběžek, prohozené pořadí, jiný typ)
  L3 = [('zub', 15, 0), ('oblouk', 60, 0), ('hrot', 110, 0), ('T', 165, 0), ('oblouk', 215, 0), ('hrot', 265, 0), ('zub', 315, 0)]
  A3 = [('zub', 15, 0), ('hrot', 60, 0), ('oblouk', 110, 0), ('T', 185, 0), ('oblouk', 215, 0), ('hrot', 265, 0), ('T', 315, 0)]
  ITEMS.append(item('SKO_3', '#E07B39', L3, [38, 140, 240], A3, ['prohozené výběžky', 'výběžek posunutý', 'kotva místo zubu'], step=(0.84, 14), seed=33, fac={'svy': 'se schodem', 'ornament': '7 výběžků'}))
  json.dump({'items': ITEMS}, open('orn.json', 'w'), ensure_ascii=False)
  print([(i['id'], i['answerIdx']) for i in ITEMS])
