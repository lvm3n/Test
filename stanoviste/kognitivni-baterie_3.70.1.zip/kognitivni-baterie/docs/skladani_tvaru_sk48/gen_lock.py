"""Zámkové stropové položky (princip Visual Puzzles): cíl = plný kruh; díly = 2 skořepiny s výřezy + vnitřní ornament,
který do výřezů zapadá. Distraktory: jiný ornament O' + skořepina, která do O' přesně zapadá (smysluplný pár),
a skořepina vyříznutá pro mírně jiný ornament. Jednoznačnost: řešič přes všechny trojice a otočení."""
import json, math, random, itertools
from shapely.geometry import Point, box
from shapely.ops import unary_union
from shapely import affinity
import sys; sys.path.insert(0, '.')
from gen_orn import d_of, norm
C = 0.19
from shapely.geometry import Point as _P
DISC = _P(0, 0).buffer(1, 256)
def art(s, k):
    """ASCII ornament; řádky nad indexem k patří horní skořepině. Vrací (polygon, horní část, dolní část)."""
    rows = [r for r in s.strip('\n').split('\n')]; W = max(len(r) for r in rows)
    cells = [box((x - W / 2) * C, (y - k) * C, (x - W / 2 + 1) * C, (y - k + 1) * C) for y, r in enumerate(rows) for x, ch in enumerate(r) if ch == '#']
    g = unary_union(cells).buffer(1e-6, join_style=2).buffer(-1e-6, join_style=2)
    assert g.geom_type == 'Polygon', 'ornament není souvislý'; assert g.buffer(0.07).within(DISC), 'ornament u okraje'
    return g

TOP, BOT = box(-2, -2, 2, 0), box(-2, 0, 2, 2)
def shell(o, half): g = DISC.intersection(half).difference(o); assert g.geom_type == 'Polygon', 'skořepina se rozpadla'; return g
def rotc(g, a): return affinity.rotate(g, a, origin=(0, 0))
def fit_free(piece, region, tol):
    """Lze piece (otočením + posunem) přesně položit na region? Posun je dán těžištěm."""
    if abs(piece.area - region.area) > tol: return False
    cx, cy = region.centroid.x, region.centroid.y
    for k in range(720):
        q = affinity.rotate(piece, k * 0.5, origin='centroid'); q = affinity.translate(q, cx - q.centroid.x, cy - q.centroid.y)
        if q.symmetric_difference(region).area < tol: return True
    return False
def solve(opts, is_shell):
    A = DISC.area; tol = 3e-3 * A; sols = []
    for tri in itertools.combinations(range(len(opts)), 3):
        if abs(sum(opts[i].area for i in tri) - A) > tol: continue
        sh = [i for i in tri if is_shell[i]]; fr = [i for i in tri if not is_shell[i]]
        if len(sh) != 2: continue
        s1 = opts[sh[0]]; ok = False
        for k in range(720):   # cíl je kruh => první skořepinu lze bez újmy obecnosti nechat v 0°
            s2 = rotc(opts[sh[1]], k * 0.5)
            if s2.intersection(s1).area > tol: continue
            res = DISC.difference(s1).difference(s2)
            if fit_free(opts[fr[0]], res, tol): ok = True; break
        if ok: sols.append(tri)
    return sols
def item(iid, fill, O, k, O2, k2, Bv, kv, seed, kinds, fac):
    o, o2, bv = art(O, k), art(O2, k2), art(Bv, kv)
    pieces = [shell(o, TOP), shell(o, BOT), o, o2, shell(o2, TOP), shell(bv, BOT)]
    is_shell = [True, True, False, False, True, True]
    sols = solve(pieces, is_shell); assert sols == [(0, 1, 2)], (iid, sols)
    rng = random.Random(seed); sc = 1 / math.sqrt(DISC.area)
    tg, w, h = norm(DISC, sc, 0)
    lab = ['cíl'] * 3 + kinds; order = list(range(6)); rng.shuffle(order); opts = []
    for j in order:
        og, ow, oh = norm(pieces[j], sc, rng.choice([0, 90, 180, 270]) + rng.choice([-30, -15, 15, 30, 0]))
        opts.append({'paths': [{'d': d_of(og), 'fill': fill}], 'w': round(ow, 4), 'h': round(oh, 4), 'correct': j < 3, 'kind': lab[j]})
    return {'id': iid, 'level': 5, 'pick': 3, 'target': {'paths': [{'d': d_of(tg), 'fill': fill}], 'outline': d_of(tg), 'w': round(w, 4), 'h': round(h, 4)},
            'options': opts, 'answerIdx': [i for i, x in enumerate(opts) if x['correct']],
            'facety': dict({'pasmo': 'strop (zámek)', 'dilu': 3, 'distraktory': ', '.join(kinds), 'reseni': 'jediná trojice (řešič)'}, **fac)}
ITEMS = []
# L1: souměrný ornament (kotva), distraktor O' má jinak ukončená ramena nahoře i dole
ITEMS.append(item('SKL_1', '#D64545', '''
#....#
######
..##..
..##..
.####.
''', 2, '''
##..##
.####.
..##..
.####.
.#..#.
''', 2, '''
#....#
######
..##..
..##..
######
''', 2, 5, ['ornament jiného zámku', 'skořepina k jinému ornamentu', 'jinak vyříznutá skořepina'], {'ornament': 'souměrný'}))
# L2: nesouměrný ornament (otočením se nezmění v sebe), O' = zrcadlo O; skořepina B' má zub posunutý o 1 pole
ITEMS.append(item('SKL_2', '#2E7D6B', '''
##....
.#..##
.#####
...#..
.###..
.#....
''', 3, '''
....##
##..#.
#####.
..#...
..###.
....#.
''', 3, '''
##....
.#..##
.#####
....#.
..###.
..#...
''', 3, 7, ['zrcadlový ornament', 'skořepina k zrcadlovému', 'jinak vyříznutá skořepina'], {'ornament': 'nesouměrný'}))
# L3: větvený ornament se zobáčky, O' liší se jednou větví nahoře a jednou dole; B' = dolní část O, ale konec větve přetočený
ITEMS.append(item('SKL_3', '#5C6BC0', '''
#.#..#.
###.###
..###..
...#...
.#####.
.#...##
''', 3, '''
#...##.
###.###
..###..
...#...
.#####.
##...#.
''', 3, '''
#.#..#.
###.###
..###..
...#...
.#####.
.#..##.
''', 3, 9, ['ornament jiného zámku', 'skořepina k jinému ornamentu', 'jinak vyříznutá skořepina'], {'ornament': 'větvený, nesouměrný'}))
json.dump({'items': ITEMS}, open('lock.json', 'w'), ensure_ascii=False)
print([(i['id'], i['answerIdx']) for i in ITEMS])
