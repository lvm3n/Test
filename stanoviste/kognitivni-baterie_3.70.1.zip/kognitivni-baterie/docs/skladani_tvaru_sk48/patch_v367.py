"""3.67.0 / 1.28.0 – Skládání tvarů SK34-v1: snadný nácvik a 4 úvodní položky po vzoru WAIS (barevné díly bez otáčení, zjevné distraktory)."""
import os, json, shutil, csv, io
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st13/BANK_SK34.json', encoding='utf8'))
DEMO = {CZ: ('Dva zelené čtverce dohromady dají obdélník. Díly jsou nakreslené ve stejné velikosti jako tvar.', 'Modrý a žlutý díl dohromady dají tvar. Díly jsou nakreslené ve stejné velikosti jako tvar a mají stejnou barvu jako jeho části.'),
        EN: ('Two green squares together make the rectangle. The pieces are drawn at the same size as the shape.', 'The blue and the yellow piece together make the shape. The pieces are drawn at the same size as the shape and have the same colours as its parts.')}
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK30-v2', pickN:3,", "version:'SK34-v1', pickN:3,")
    rep(app, "['SK30-v2']]", "['SK30-v2'], ['SK34-v1']]")
    rep(app, "startFor:(list, age) => age <= 8 ? 0 : Math.max(0, list.findIndex(x => x.pick === 3)),   // od 9 let start u první položky se 3 díly",
        "startFor:(list, age) => age <= 8 ? 0 : Math.max(0, list.findIndex(x => x.id === 'SK48_04')),   // od 9 let start za úvodními položkami (6 se připíše)")
    rep(app, DEMO[d][0], DEMO[d][1])
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']; extra = '; mřížka %s, spojů %s; distraktory: %s' % (f['mrizka'], f['spoju'], f['distraktory']) if 'mrizka' in f else ''
        body.append(['skladani', 'SK34-v1', k + 1, it['id'], 'vyber %d z 6 dílů; %s%s' % (it['pick'], f['pasmo'], extra),
                     ' '.join(str(i + 1) for i in it['answerIdx']), 'nácvik' if it['level'] == 0 else 'pořadí %d; předpoklad %s' % (k - 1, f.get('predpoklad', 'snadná')),
                     '', '' if it['level'] == 0 else 'limit %d s; původní položka %s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60, f.get('puvodni', 'nová'))])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.66.0', '3.67.0', 2); rep(EN + 'cognitive-battery-en.php', '1.27.0', '1.28.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.66.0</div>', '>verze 3.67.0</div>'); rep(EN + 'assets/app.html', '>version 1.27.0 (EN)</div>', '>version 1.28.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('easy.py', 'easy.json', 'BANK_SK34.json', 'preview_easy.html'): shutil.copy('st13/' + f, dd + f)
shutil.copy('st14/patch_v367.py', dd + 'patch_v367.py')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.67.0 – Skládání tvarů SK34-v1: snadný začátek po vzoru WAIS
Nácvik byl příliš těžký (jednobarevný čtverec ze tří otočených trojúhelníků). Nově, jako u Visual Puzzles: díly mají barvu své
části tvaru, jsou ve stejné poloze jako v tvaru (bez otáčení) a distraktory jsou zjevně jiné (kruh, kosočtverec, trojúhelník,
jiná velikost). Vlastní položky (ne kopie WAIS):
- nácvik SK_N1 (2 díly: modrá a žlutá polovina obdélníku), SK_N2 (3 díly: červený a zelený čtverec, fialový pruh);
- úvodní položky SK_E1 (čtverec ze dvou barevných trojúhelníků), SK_E2 (sloupec tří barevných čtverců), SK_E3 (velký a dva malé
  čtverce), SK_E4 (pruh a dva trojúhelníky; poprvé jeden díl otočený o 90°). Pak navazuje dosavadní sada (34 položek celkem).
Start: do 8 let od SK_E1; od 9 let od SK48_04 (6 položek se připíše, při chybě v prvních dvou návrat). Nová skupina SK34-v1.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.28.0 – Shape Assembly SK34-v1: snadný nácvik a 4 úvodní položky (barevné díly bez otáčení) – jako česká 3.67.0.
''')
print('ok')
