"""Snadný nácvik a úvodní položky po vzoru WAIS: barevné díly ve stejné poloze jako v tvaru (bez otáčení),
distraktory zjevně jiné (jiný tvar nebo barva). Plocha tvaru = 1, díly ve stejném měřítku."""
import json, math
from shapely.geometry import Polygon, Point, box
from shapely.ops import unary_union
from shapely import affinity
R, B, Y, G, O, P, PK = '#E0574D', '#3D8CCD', '#E8C547', '#5FAF63', '#ED8B37', '#7C58B5', '#D25499'
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def pd(g, ox=0, oy=0, s=1):
    return 'M' + ' L'.join(fmt((x - ox) * s) + ' ' + fmt((y - oy) * s) for x, y in list(g.exterior.coords)[:-1]) + 'Z'
def tri(a, b, c): return Polygon([a, b, c])
def circle(cx, cy, r): return Point(cx, cy).buffer(r, 40)
def diamond(cx, cy, w, h): return Polygon([(cx, cy - h / 2), (cx + w / 2, cy), (cx, cy + h / 2), (cx - w / 2, cy)])
def item(iid, pieces, distract, order, level, pick, note, rot=None):
    """pieces: [(polygon v souřadnicích tvaru, barva)]; distract: [(polygon, barva, druh)]; order: pořadí 6 možností (indexy do pieces+distract)"""
    U = unary_union([p for p, _ in pieces]); s = 1 / math.sqrt(U.area); b = U.bounds
    target = {'paths': [{'d': pd(p, b[0], b[1], s), 'fill': c} for p, c in pieces], 'outline': pd(U, b[0], b[1], s),
              'w': round((b[2] - b[0]) * s, 4), 'h': round((b[3] - b[1]) * s, 4)}
    allp = [(p, c, 'cíl') for p, c in pieces] + list(distract)
    opts = []
    for j in order:
        p, c, kind = allp[j]
        if rot and j in rot: p = affinity.rotate(p, rot[j], origin='centroid')
        q = p.bounds
        opts.append({'paths': [{'d': pd(p, q[0], q[1], s), 'fill': c}], 'w': round((q[2] - q[0]) * s, 4), 'h': round((q[3] - q[1]) * s, 4),
                     'correct': kind == 'cíl', 'kind': kind})
    assert abs(sum(p.area for p, _ in pieces) - U.area) < 1e-9          # díly se nepřekrývají a vyplní tvar
    return {'id': iid, 'level': level, 'pick': pick, 'target': target, 'options': opts,
            'answerIdx': [i for i, o in enumerate(opts) if o['correct']], 'facety': {'pasmo': note, 'dilu': pick}}
practice = [
    # N1: obdélník = modrá horní a žlutá dolní polovina
    item('SK_N1', [(box(0, 0, 2, 1), B), (box(0, 1, 2, 2), Y)],
         [(circle(1, 1, 0.6), Y, 'jiný tvar'), (tri((0, 1), (1.6, 1), (0.8, 0)), B, 'jiný tvar'), (box(0, 0, 1, 1.4), R, 'jiný tvar i barva'), (diamond(1, 1, 1.2, 1.6), B, 'jiný tvar')],
         [2, 0, 4, 1, 3, 5], 0, 2, 'nácvik'),
    # N2: obdélník = červený čtverec, zelený čtverec, fialový obdélník (vše bez otáčení)
    item('SK_N2', [(box(0, 0, 1, 1), R), (box(1, 0, 2, 1), G), (box(0, 1, 2, 1.8), P)],
         [(circle(1, 1, 0.55), R, 'jiný tvar'), (tri((0, 1), (1.2, 1), (0, 0)), G, 'jiný tvar'), (diamond(1, 1, 1.1, 1.5), P, 'jiný tvar')],
         [3, 0, 4, 2, 5, 1], 0, 3, 'nácvik'),
]
intro = [
    # E1 (2 díly): čtverec = zelený a oranžový pravoúhlý trojúhelník (úhlopříčka)
    item('SK_E1', [(tri((0, 0), (1.6, 0), (0, 1.6)), G), (tri((1.6, 0), (1.6, 1.6), (0, 1.6)), O)],
         [(box(0, 0, 1.6, 1.6), G, 'celý čtverec'), (circle(0, 0, 0.9), O, 'jiný tvar'), (box(0, 0, 1.6, 0.8), O, 'jiný tvar'), (diamond(0, 0, 1.2, 1.7), G, 'jiný tvar')],
         [0, 3, 2, 5, 1, 4], 1, 2, 'úvodní (snadná)'),
    # E2 (3 díly): sloupec tří čtverců: červený, modrý, žlutý
    item('SK_E2', [(box(0, 0, 1, 1), R), (box(0, 1, 1, 2), B), (box(0, 2, 1, 3), Y)],
         [(tri((0, 0), (1.2, 0), (0.6, 1)), B, 'jiný tvar'), (circle(0, 0, 0.55), R, 'jiný tvar'), (box(0, 0, 2, 1), Y, 'jiná velikost')],
         [3, 0, 4, 1, 5, 2], 1, 3, 'úvodní (snadná)'),
    # E3 (3 díly): obdélník = velký modrý čtverec + dva malé čtverce (žlutý nad zeleným) vpravo
    item('SK_E3', [(box(0, 0, 2, 2), B), (box(2, 0, 3, 1), Y), (box(2, 1, 3, 2), G)],
         [(box(0, 0, 2, 1), B, 'jiný tvar'), (diamond(0, 0, 1, 1.4), Y, 'jiný tvar'), (circle(0, 0, 0.55), G, 'jiný tvar')],
         [0, 4, 1, 5, 2, 3], 1, 3, 'úvodní (snadná)'),
    # E4 (3 díly, poprvé otočený díl): čtverec = fialový obdélník nahoře + dva trojúhelníky dole (růžový, žlutý); jeden díl otočen o 90°
    item('SK_E4', [(box(0, 0, 2, 1), P), (tri((0, 1), (2, 1), (0, 2)), PK), (tri((2, 1), (2, 2), (0, 2)), Y)],
         [(box(0, 0, 1, 1), P, 'jiná velikost'), (tri((0, 0), (1, 0), (0.5, 0.9)), PK, 'jiný tvar'), (circle(0, 0, 0.6), Y, 'jiný tvar')],
         [3, 0, 1, 4, 5, 2], 1, 3, 'úvodní (snadná)', rot={0: 90}),
]
json.dump({'practice': practice, 'intro': intro}, open('easy.json', 'w'), ensure_ascii=False)
print('ok', [it['id'] for it in practice + intro])
