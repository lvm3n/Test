"""3.69.1 / 1.30.1 – Skládání tvarů: díly v možnostech přetékaly rámeček na mobilu (šířka SVG nepočítala s okrajem a paddingem tlačítka)."""
import os
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
for d in (CZ, EN):
    app = d + 'assets/app.html'
    rep(app, "const w = Math.floor((Math.min(innerWidth, 520) - 64) / 3); return {tw:Math.min(300, innerWidth - 48), th:170, ow:w, oh:Math.round(w * 0.82)}; };",
        "const w = Math.floor((Math.min(innerWidth, 520) - 32 - 16) / 3) - 20;   // okraj stránky 2×16, mezery 2×8, rámeček+padding tlačítka 2×3+2×6 (+2 rezerva)\n"
        "    return {tw:Math.min(300, innerWidth - 48), th:170, ow:w, oh:Math.round(w * 0.82)}; };")
    rep(app, "return Math.min(b.tw / t.w, b.th / t.h, (b.ow - 14) / mw, (b.oh - 14) / mh); };",
        "return Math.min(b.tw / t.w, b.th / t.h, (b.ow - 16) / mw, (b.oh - 16) / mh); };")
    rep(app, ".mr-opts{align-items:center}", ".mr-opts{align-items:center}\n#m-skladani .mr-opt{overflow:hidden}\n#m-skladani .mr-opt svg{display:block;max-width:100%;height:auto}")
rep(CZ + 'kognitivni-baterie.php', '3.69.0', '3.69.1', 2); rep(EN + 'cognitive-battery-en.php', '1.30.0', '1.30.1', 2)
rep(CZ + 'assets/app.html', '>verze 3.69.0</div>', '>verze 3.69.1</div>'); rep(EN + 'assets/app.html', '>version 1.30.0 (EN)</div>', '>version 1.30.1 (EN)</div>')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.69.1 – Skládání tvarů: oprava zobrazení na mobilu
Díly v možnostech A–F mohly přetékat rámeček (velikost obrázku nepočítala s okrajem a odsazením tlačítka). Opraveno,
obrázek se navíc vždy vejde do tlačítka (max-width). Položky, klíče ani skórování se nemění.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.30.1 – Shape Assembly: oprava přetékání dílů v možnostech na mobilu (jako česká 3.69.1).
''')
print('ok')
