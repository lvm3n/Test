<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    add_menu_page('Kognitivní baterie', 'Kognitivní baterie', 'edit_posts', 'kb-overview', 'kb_admin_overview', 'dashicons-chart-bar', 58);
    add_submenu_page('kb-overview', 'Nastavení', 'Nastavení', 'manage_options', 'kb-settings', 'kb_admin_settings');
});

/* export CSV (spouští se přes admin-post.php, aby se neposílala HTML hlavička) */
add_action('admin_post_kb_export', function () {
    if (!current_user_can('edit_posts')) { wp_die('Nedostatečná oprávnění.'); }
    check_admin_referer('kb_export');
    $what = isset($_GET['what']) ? sanitize_key($_GET['what']) : 'rows';
    if ($what === 'items') {
        $test = isset($_GET['test']) ? kb_clean_key(wp_unslash($_GET['test'])) : '';
        kb_export_items($test, !empty($_GET['sondy']));
        exit;
    }
    kb_export_csv($what === 'scores' ? 'scores' : 'rows');
    exit;
});

function kb_export_csv($what) {
    global $wpdb;
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=kb_' . $what . '_' . gmdate('Ymd_His') . '.csv');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");            // BOM pro Excel
    $P = kb_table('participants'); $S = kb_table('sessions');
    if ($what === 'scores') {
        $rows = $wpdb->get_results("SELECT sc.*, p.anon_id, p.code, p.demographics FROM " . kb_table('scores') . " sc JOIN $P p ON p.id = sc.participant_id ORDER BY sc.id", ARRAY_A);
        $base = array('id', 'session_id', 'anon_id', 'code', 'mode', 'age', 'test_key', 'test_version', 'raw_score', 'valid', 'created');
        $keys = array();
        foreach ($rows as $r) { $d = json_decode((string) $r['data'], true); if (is_array($d)) { foreach ($d as $k => $v) { $keys['score_' . $k] = 1; } }
                               $m = json_decode((string) $r['demographics'], true); if (is_array($m)) { foreach ($m as $k => $v) { $keys['demo_' . $k] = 1; } } }
        $cols = array_merge($base, array_keys($keys));
        fputcsv($out, $cols, ';');
        foreach ($rows as $r) {
            $line = array(); foreach ($base as $b) { $line[] = $r[$b]; }
            $d = json_decode((string) $r['data'], true); $m = json_decode((string) $r['demographics'], true);
            foreach (array_keys($keys) as $k) {
                if (strpos($k, 'score_') === 0) { $kk = substr($k, 6); $v = is_array($d) && isset($d[$kk]) ? $d[$kk] : ''; }
                else { $kk = substr($k, 5); $v = is_array($m) && isset($m[$kk]) ? $m[$kk] : ''; }
                $line[] = is_scalar($v) ? $v : wp_json_encode($v);
            }
            fputcsv($out, $line, ';');
        }
        fclose($out); return;
    }
    // řádky odpovědí: nejdřív zjistit všechny sloupce (po dávkách), pak zapsat
    $T = kb_table('rows'); $keys = array(); $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $T WHERE id > %d ORDER BY id LIMIT 2000", $last), ARRAY_A);
        foreach ($chunk as $c) { $last = $c['id']; $d = json_decode($c['data'], true); if (is_array($d)) { foreach ($d as $k => $v) { $keys[$k] = 1; } } }
    } while (count($chunk) === 2000);
    $base = array('row_id', 'session_id', 'anon_id', 'code', 'mode', 'age', 'saved');
    $cols = array_keys($keys);
    fputcsv($out, array_merge($base, $cols), ';');
    $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare(
            "SELECT r.id, r.session_id, r.created, r.data, p.anon_id, p.code, p.mode, p.age FROM $T r JOIN $S s ON s.id = r.session_id JOIN $P p ON p.id = s.participant_id WHERE r.id > %d ORDER BY r.id LIMIT 2000", $last), ARRAY_A);
        foreach ($chunk as $c) {
            $last = $c['id']; $d = json_decode($c['data'], true);
            $line = array($c['id'], $c['session_id'], $c['anon_id'], $c['code'], $c['mode'], $c['age'], $c['created']);
            foreach ($cols as $k) { $v = is_array($d) && isset($d[$k]) ? $d[$k] : ''; $line[] = is_scalar($v) ? $v : wp_json_encode($v); }
            fputcsv($out, $line, ';');
        }
    } while (count($chunk) === 2000);
    fclose($out);
}

/* Export po položkách pro jeden test (široký formát): řádek = sezení, sloupec = položka, hodnota = body (HS) za položku.
   Jen ostré položky (faze = test); nácvik vynechán; sondy volitelně jako sloupce „sonda_ID“. Nezadaná položka = prázdné pole
   (připsané položky se nevyplňují – jsou ve sloupci HS_celkem / pripsane). Hodnota: skore, jinak spravne, jinak odpoved. */
/* Klíč osoby: veřejná verze = anonymní identifikátor prohlížeče; vaše verze (admin) = zadaný kód osoby (každé sezení má nový
   identifikátor, proto se slučuje podle kódu); bez kódu = identifikátor. */
function kb_test_meta() {
    static $M = null;
    if ($M !== null) { return $M; }
    $M = array();
    $groups = array(
        'Gf – usuzování' => array('matice' => 'Matice', 'vahy' => 'Váhy', 'dedukce' => 'Tvarové klíče', 'pravidla' => 'Hledání pravidla', 'stanoviste' => 'Stanoviště', 'stroje' => 'Seřaďte stroje'),
        'Gc – znalosti' => array('gcslovni' => 'Jak se to nazývá', 'gcznalosti' => 'Všeobecné znalosti', 'synonyma' => 'Slova stejného významu', 'pojmy' => 'Pojmy', 'zasoba2' => 'Slovní zásoba (MC)', 'znalosti2' => 'Znalosti (MC)'),
        'Gv – prostorové' => array('papir' => 'Skládání papíru', 'rotace' => 'Mentální rotace', 'kostky' => 'Pohled na stavbu', 'skladani' => 'Skládání tvarů'),
        'Gwm – pracovní paměť' => array('zpetna' => 'Čísla pozpátku', 'rds' => 'Poslední čísla', 'por' => 'Pořadí obrázků'),
        'Gs – rychlost' => array('symboly' => 'Symboly a čísla', 'rady' => 'Shodné řady'),
        'Školní dovednosti' => array('pocitani' => 'Počítání', 'ulohy' => 'Slovní úlohy', 'cteni' => 'Porozumění textu (st.)', 'cteni2' => 'Porozumění textu', 'srce' => 'Efektivita čtení'),
        'Škály' => array('adhdp_nepozornost' => 'ADHD nepozornost', 'adhdp_hyperaktivita' => 'ADHD hyperaktivita', 'adhdp_impulzivita' => 'ADHD impulzivita', 'adhdp_exekutivni' => 'ADHD exekutiva', 'adhdp_emocni' => 'ADHD emoce',
                          'mask_zahlazovani' => 'Maskování: zahlazování', 'mask_potlacovani' => 'Maskování: potlačování', 'mask_predstirani' => 'Maskování: předstírání', 'mask_zatez' => 'Maskování: zátěž', 'adhd' => 'Škála ADHD', 'masking' => 'Škála maskování'));
    $r = 0;
    foreach ($groups as $g => $list) { foreach ($list as $k => $lab) { $M[$k] = array('rank' => $r++, 'group' => $g, 'label' => $lab); } }
    return $M;
}
function kb_test_rank($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['rank'] : 1000 + crc32($k) % 1000; }
function kb_test_group($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['group'] : 'Ostatní'; }
function kb_test_label($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['label'] : $k; }
/* v přehledu mezi současnými verzemi skrýt odvozené/pomocné klíče (DSM počty, staré subškály ADHD) */
function kb_test_hidden($k) { return (bool) preg_match('/^(adhd_dsm_|adhd_(nepozornost|hyperaktivita|impulzivita|exekutivni|emocni)$|gcnapis$)/', $k); }
function kb_corr_hidden($k) { return kb_test_hidden($k) || in_array($k, array('adhd', 'masking', 'stroje', 'zasoba2', 'znalosti2'), true); }

function kb_person_key($mode, $code, $anon) {
    $code = trim((string) $code);
    return ($mode === 'admin' && $code !== '') ? 'kod:' . $code : 'id:' . $anon;
}

function kb_export_items($test, $withProbes) {
    global $wpdb;
    if ($test === '') { wp_die('Chybí test.'); }
    $T = kb_table('rows'); $S = kb_table('sessions'); $P = kb_table('participants'); $SC = kb_table('scores');
    $data = array(); $meta = array(); $items = array(); $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare(
            "SELECT r.id, r.session_id, r.data, p.anon_id, p.code, p.mode, p.age, p.demographics FROM $T r JOIN $S s ON s.id = r.session_id JOIN $P p ON p.id = s.participant_id WHERE r.test_key = %s AND r.id > %d ORDER BY r.id LIMIT 2000",
            $test, $last), ARRAY_A);
        foreach ($chunk as $c) {
            $last = $c['id']; $d = json_decode($c['data'], true); if (!is_array($d)) { continue; }
            $faze = isset($d['faze']) ? $d['faze'] : '';
            if ($faze === 'sonda') { if (!$withProbes) { continue; } $pref = 'sonda_'; }
            elseif ($faze === 'test' || $faze === 'dotaznik' || $faze === '') { $pref = ''; }
            else { continue; }
            $id = isset($d['id']) && $d['id'] !== '' ? $d['id'] : (isset($d['polozka']) ? $d['polozka'] : '');
            if ($id === '' || (isset($d['typ']) && $d['typ'] === 'workspace')) { continue; }
            $v = '';
            foreach (array('skore', 'spravne', 'odpoved') as $k) { if (isset($d[$k]) && $d[$k] !== '' && is_numeric($d[$k])) { $v = $d[$k] + 0; break; } }
            $col = $pref . $id; $items[$col] = 1;
            $sid = kb_person_key($c['mode'], $c['code'], $c['anon_id']);   // jedna osoba = jeden řádek (sezení se slučují)
            if (!isset($data[$sid][$col])) { $data[$sid][$col] = $v; }       // při opakování položky platí PRVNÍ pokus
            if (!isset($meta[$sid])) {
                $m = json_decode((string) $c['demographics'], true);
                $meta[$sid] = array('anon' => $c['anon_id'], 'code' => $c['code'], 'mode' => $c['mode'], 'age' => $c['age'], 'sessions' => array(),
                    'pohlavi' => is_array($m) && isset($m['pohlavi']) ? $m['pohlavi'] : '', 'forma' => isset($d['forma']) ? $d['forma'] : '');
            }
            $meta[$sid]['sessions'][$c['session_id']] = 1;
        }
    } while (count($chunk) === 2000);
    $cols = array_keys($items); natsort($cols); $cols = array_values($cols);
    usort($cols, function ($a, $b) { $pa = strpos($a, 'sonda_') === 0; $pb = strpos($b, 'sonda_') === 0; if ($pa !== $pb) { return $pa ? 1 : -1; } return strnatcmp($a, $b); });
    $hs = array();
    foreach ($wpdb->get_results($wpdb->prepare("SELECT sc.raw_score, sc.data, p.anon_id, p.code, p.mode FROM $SC sc JOIN $P p ON p.id = sc.participant_id WHERE sc.test_key = %s ORDER BY sc.id", $test), ARRAY_A) as $r) {
        $k = kb_person_key($r['mode'], $r['code'], $r['anon_id']);
        if (isset($hs[$k])) { continue; }                                 // první dokončený výsledek osoby
        $d = json_decode((string) $r['data'], true);
        $hs[$k] = array($r['raw_score'], is_array($d) && isset($d['pripsane']) ? $d['pripsane'] : '', is_array($d) && isset($d['konec']) ? $d['konec'] : '');
    }
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=kb_polozky_' . $test . '_' . gmdate('Ymd_His') . '.csv');
    $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_merge(array('osoba', 'anon_id', 'code', 'mode', 'age', 'pohlavi', 'forma', 'sezeni', 'HS_celkem', 'pripsane', 'konec', 'zadano_polozek'), $cols), ';');
    foreach ($data as $sid => $vals) {
        $m = $meta[$sid]; $h = isset($hs[$sid]) ? $hs[$sid] : array('', '', '');
        $n = 0; foreach ($vals as $k => $v) { if (strpos($k, 'sonda_') !== 0) { $n++; } }
        $line = array($sid, $m['anon'], $m['code'], $m['mode'], $m['age'], $m['pohlavi'], $m['forma'], implode(' ', array_keys($m['sessions'])), $h[0], $h[1], $h[2], $n);
        foreach ($cols as $c) { $line[] = isset($vals[$c]) ? $vals[$c] : ''; }
        fputcsv($out, $line, ';');
    }
    fclose($out);
}


/* Přepočet Tvarových klíčů (DED-24) podle nových časových limitů po úrovních (verze DED-24-v1.3):
   1: 30 s, 2: 45 s, 3: 60 s, 4: 120 s, 5: 150 s, 6: 75 s, 7: 90 s, 8–9: 120 s.
   Položka: správně jen tehdy, když odpověď přišla do limitu své úrovně (původní hodnota zůstává ve spravne_puvodni).
   Skóre: znovu se použije ukončení po 5 chybách v řadě – co by po novém ukončení už nebylo zadáno, se nepočítá.
   Opakované spuštění nic nemění (zpracované záznamy mají příznak prepocet). */
function kb_recode_dedukce() {
    global $wpdb;
    $CAP = array(1 => 30, 2 => 45, 3 => 60, 4 => 120, 5 => 150, 6 => 75, 7 => 90, 8 => 120, 9 => 120);
    $R = kb_table('rows'); $SC = kb_table('scores');
    $scores = $wpdb->get_results("SELECT id, session_id, raw_score, data FROM $SC WHERE test_key = 'dedukce' AND test_version IN ('DED-24-v1.0','DED-24-v1.1','DED-24-v1.2')", ARRAY_A);
    $nS = 0; $nR = 0; $changed = 0;
    foreach ($scores as $sc) {
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet'])) { continue; }
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $R WHERE session_id = %d AND test_key = 'dedukce' ORDER BY client_seq, id", $sc['session_id']), ARRAY_A);
        $raw = 0; $run = 0; $stopped = false; $konec = '';
        foreach ($rows as $r) {
            $d = json_decode((string) $r['data'], true);
            if (!is_array($d) || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
            if (!preg_match('/tier=(\d+)/', isset($d['facety']) ? $d['facety'] : '', $m)) { continue; }
            $tier = intval($m[1]); $cap = isset($CAP[$tier]) ? $CAP[$tier] : 120;
            $orig = isset($d['spravne']) ? intval($d['spravne']) : 0;
            $rt = isset($d['rt_ms']) ? floatval($d['rt_ms']) : 0;
            $ok = ($orig === 1 && $rt <= $cap * 1000) ? 1 : 0;
            if (empty($d['prepocet'])) {
                $d['spravne_puvodni'] = $orig; $d['spravne'] = $ok; $d['time_limit_ms_prepocet'] = $cap * 1000;
                $d['prepocet'] = 'casove-limity-DED-24-v1.3';
                if ($ok !== $orig) { $d['po_novem_limitu'] = 1; $changed++; }
                $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
            }
            if ($stopped) { continue; }
            if ($ok) { $raw++; $run = 0; } else { $run++; if ($run >= 5) { $stopped = true; $konec = 'ukončeno po 5 chybách v řadě (přepočet)'; } }
        }
        $sd['hruby_puvodni'] = $sc['raw_score']; $sd['hruby'] = $raw; $sd['prepocet'] = 'casove-limity-DED-24-v1.3';
        if ($konec) { $sd['konec_prepocet'] = $konec; }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    return array('scores' => $nS, 'rows' => $nR, 'changed' => $changed);
}

function kb_admin_overview() {
    global $wpdb;
    if (!current_user_can('edit_posts')) { return; }
    // smazání dat účastníka (GDPR)
    if (isset($_POST['kb_delete']) && check_admin_referer('kb_delete') && current_user_can('manage_options')) {
        $anon = sanitize_text_field(wp_unslash($_POST['kb_delete']));
        $n = kb_delete_participant($anon);
        echo '<div class="notice notice-success"><p>Smazáno záznamů účastníka: ' . intval($n) . '</p></div>';
    }
    $P = kb_table('participants'); $S = kb_table('sessions'); $SC = kb_table('scores');
    $np = (int) $wpdb->get_var("SELECT COUNT(*) FROM $P");
    $ns = (int) $wpdb->get_var("SELECT COUNT(*) FROM $S");
    $nr = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . kb_table('rows'));
    if (isset($_POST['kb_dedupe']) && check_admin_referer('kb_dedupe') && current_user_can('manage_options')) {
        // smaže jen přesné duplicity: stejný test a verze ve stejném sezení (ponechá první záznam)
        $d = $wpdb->query("DELETE a FROM $SC a JOIN $SC b ON a.session_id = b.session_id AND a.test_key = b.test_key AND a.test_version = b.test_version AND a.id > b.id");
        echo '<div class="notice notice-success"><p>Odstraněno duplicitních výsledků: ' . intval($d) . '</p></div>';
    }
    $per = $wpdb->get_results("SELECT test_key, test_version, COUNT(*) n, COUNT(DISTINCT session_id) ns, COUNT(DISTINCT participant_id) np, SUM(valid) nv, AVG(raw_score) m, MAX(created) last FROM $SC GROUP BY test_key, test_version ORDER BY test_key");
    $curv = array();                                   // současná verze testu = ta, ve které přišel nejnovější výsledek
    foreach ($per as $x) { if (!isset($curv[$x->test_key]) || strcmp($x->last, $curv[$x->test_key][1]) > 0) { $curv[$x->test_key] = array($x->test_version, $x->last); } }
    $dup = (int) $wpdb->get_var("SELECT COUNT(*) FROM $SC a JOIN $SC b ON a.session_id = b.session_id AND a.test_key = b.test_key AND a.test_version = b.test_version AND a.id > b.id");
    $recent = $wpdb->get_results("SELECT s.id, s.started, s.last_seen, p.code, p.mode, p.age, LEFT(p.anon_id, 8) a FROM $S s JOIN $P p ON p.id = s.participant_id ORDER BY s.id DESC LIMIT 50");
    $exp = function ($what) { return esc_url(wp_nonce_url(admin_url('admin-post.php?action=kb_export&what=' . $what), 'kb_export')); };
    echo '<div class="wrap"><h1>Kognitivní baterie</h1>';
    if (isset($_POST['kb_recode_ded']) && check_admin_referer('kb_recode_ded') && current_user_can('manage_options')) {
        $rr = kb_recode_dedukce();
        echo '<div class="notice notice-success"><p>Tvarové klíče přepočítány podle nových časových limitů: výsledků ' . intval($rr['scores']) . ', odpovědí ' . intval($rr['rows']) . ', z toho nově za limitem ' . intval($rr['changed']) . '.</p></div>';
    }
    echo '<form method="post" style="margin:6px 0">'; wp_nonce_field('kb_recode_ded');
    echo '<button class="button" name="kb_recode_ded" value="1" onclick="return confirm(\'Přepočítat Tvarové klíče (DED-24 v1.0–v1.2) podle nových časových limitů? Původní hodnoty zůstanou uložené vedle.\')">Přepočítat Tvarové klíče podle nových limitů</button> <span class="description">Jednorázově pro data sebraná před verzí DED-24-v1.3. Opakované spuštění nic nemění.</span></form>';
    echo '<p>Účastníků: <b>' . $np . '</b> · sezení: <b>' . $ns . '</b> · uložených odpovědí: <b>' . $nr . '</b></p>';
    echo '<p><a class="button button-primary" href="' . $exp('rows') . '">Stáhnout všechny odpovědi (CSV)</a> ';
    echo '<a class="button" href="' . $exp('scores') . '">Stáhnout výsledky testů (CSV)</a></p>';
    $tests = $wpdb->get_col("SELECT DISTINCT test_key FROM " . kb_table('rows') . " ORDER BY test_key");
    echo '<form method="get" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:8px 0 16px"><input type="hidden" name="action" value="kb_export"><input type="hidden" name="what" value="items">';
    wp_nonce_field('kb_export', '_wpnonce', false);
    echo '<b>Položky po testech (HS za položku):</b> <select name="test">';
    foreach ($tests as $t) { echo '<option value="' . esc_attr($t) . '">' . esc_html($t) . '</option>'; }
    echo '</select> <label><input type="checkbox" name="sondy" value="1"> včetně sond</label> <button class="button">Stáhnout (CSV)</button>';
    echo ' <a class="button" href="' . esc_url(KB_URL . 'assets/codebook.csv') . '">Číselník položek (CSV)</a>';
    echo '<br><span class="description">Řádek = osoba (víc sezení téže osoby se sloučí; při opakování položky platí první pokus), sloupec = ID položky, hodnota = body (prázdné = nezadáno). Jen ostré položky, bez nácviku. Znění položek je v číselníku.</span></form>';
    echo '<p>Vložení na stránku: <code>[kognitivni_baterie]</code> (veřejná verze), <code>[kognitivni_baterie_admin]</code> (vaše verze, jen po přihlášení).</p>';
    echo '<h2>Výsledky podle testů</h2>';
    if ($dup > 0) {
        echo '<form method="post" style="margin:6px 0"><span style="color:#b32d2e">V databázi je ' . $dup . ' duplicitních výsledků (stejný test odeslaný v jednom sezení vícekrát – chyba odesílání do verze 3.36.0).</span> ';
        wp_nonce_field('kb_dedupe'); echo '<button class="button" name="kb_dedupe" value="1" onclick="return confirm(\'Smazat duplicitní výsledky? Ponechá se vždy první záznam.\')">Odstranit duplicity</button></form>';
    }
    echo '<p class="description">Osob = různí účastníci s dokončeným testem (výsledkem). Export po položkách obsahuje i nedokončená vyplnění, proto v něm může být osob víc.</p>';
    $head = '<table class="widefat striped"><thead><tr><th>Test</th><th>Verze</th><th>Osob</th><th>Sezení</th><th>Záznamů</th><th>Platných záznamů</th><th>Průměr</th></tr></thead><tbody>';
    $line = function ($x) { return '<tr><td>' . esc_html(kb_test_label($x->test_key)) . ' <span style="color:#888">(' . esc_html($x->test_key) . ')</span></td><td>' . esc_html($x->test_version) . '</td><td><b>' . intval($x->np) . '</b></td><td>' . intval($x->ns) . '</td><td>' . intval($x->n) . '</td><td>' . intval($x->nv) . '</td><td>' . ($x->m === null ? '–' : esc_html(round((float) $x->m, 2))) . '</td></tr>'; };
    $cur = array(); $old = array();
    foreach ($per as $x) { if (kb_test_hidden($x->test_key)) { $old[] = $x; continue; } if ($curv[$x->test_key][0] === $x->test_version) { $cur[] = $x; } else { $old[] = $x; } }
    usort($cur, function ($a, $b) { return kb_test_rank($a->test_key) - kb_test_rank($b->test_key); });
    echo '<h3>Současné verze</h3>' . $head;
    foreach ($cur as $x) { echo $line($x); }
    echo '</tbody></table>';
    echo '<details style="margin-top:10px"><summary><b>Starší verze a odvozené údaje</b> (' . count($old) . ' řádků)</summary>' . $head;
    foreach ($old as $x) { echo $line($x); }
    echo '</tbody></table></details>';
    echo '<h2>Posledních 50 sezení</h2><table class="widefat striped"><thead><tr><th>Sezení</th><th>Začátek (UTC)</th><th>Naposledy</th><th>Kód</th><th>Verze</th><th>Věk</th><th>ID</th></tr></thead><tbody>';
    foreach ($recent as $x) { echo '<tr><td>' . intval($x->id) . '</td><td>' . esc_html($x->started) . '</td><td>' . esc_html($x->last_seen) . '</td><td>' . esc_html($x->code) . '</td><td>' . esc_html($x->mode) . '</td><td>' . esc_html($x->age) . '</td><td>' . esc_html($x->a) . '…</td></tr>'; }
    echo '</tbody></table>';
    $m0 = kb_correlation_matrix(null, 10);
    // uspořádání: kognitivní testy po oblastech, pak školní dovednosti, pak škály; bez DSM počtů a starých klíčů
    $ord = array();
    foreach ($m0['keys'] as $i => $k) { if (kb_corr_hidden($k)) { continue; } $ord[] = $i; }
    usort($ord, function ($a, $b) use ($m0) { return kb_test_rank($m0['keys'][$a]) - kb_test_rank($m0['keys'][$b]); });
    $m = array('keys' => array(), 'r' => array(), 'n' => array(), 'min_n' => $m0['min_n']);
    foreach ($ord as $ii => $i) { $m['keys'][$ii] = $m0['keys'][$i]; foreach ($ord as $jj => $j) { $m['r'][$ii][$jj] = $m0['r'][$i][$j]; $m['n'][$ii][$jj] = $m0['n'][$i][$j]; } }
    echo '<h2>Korelace mezi testy</h2>';
    if (!$m['keys']) { echo '<p>Zatím málo dat (každý test potřebuje aspoň ' . intval($m['min_n']) . ' lidí).</p>'; }
    else {
        $grp = function ($k) { return kb_test_group($k); };
        echo '<table class="widefat" style="width:auto;border-collapse:collapse"><thead><tr><th></th>';
        $prev = '';
        foreach ($m['keys'] as $k) { $g = $grp($k); echo '<th style="font-size:11px;vertical-align:bottom;' . ($g !== $prev ? 'border-left:3px solid #333;' : '') . '"><span style="color:#666">' . esc_html($g !== $prev ? $g : '') . '</span><br>' . esc_html(kb_test_label($k)) . '</th>'; $prev = $g; }
        echo '</tr></thead><tbody>';
        $prevr = '';
        foreach ($m['keys'] as $i => $a) {
            $ga = $grp($a);
            echo '<tr' . ($ga !== $prevr ? ' style="border-top:3px solid #333"' : '') . '><th style="text-align:left;font-size:12px;white-space:nowrap">' . esc_html(kb_test_label($a)) . '</th>'; $prevr = $ga;
            $prevc = '';
            foreach ($m['keys'] as $j => $b) {
                $gb = $grp($b); $bl = $gb !== $prevc ? 'border-left:3px solid #333;' : ''; $prevc = $gb;
                $v = $m['r'][$i][$j];
                if ($i === $j) { echo '<td style="' . $bl . 'text-align:center;color:#bbb">—</td>'; continue; }
                if ($v === null) { echo '<td style="' . $bl . 'text-align:center;color:#999">·</td>'; continue; }
                $al = min(1, abs($v)) * 0.85 + 0.05; $bg = $v >= 0 ? "rgba(33,102,172,$al)" : "rgba(178,24,43,$al)";
                echo '<td style="' . $bl . 'text-align:center;background:' . $bg . ';color:' . (abs($v) > 0.5 ? '#fff' : '#222') . '" title="n = ' . intval($m['n'][$i][$j]) . '">' . esc_html(number_format($v, 2)) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table><p class="description">Modrá = kladný vztah, červená = opačný; sytost = síla vztahu. Počítá se z prvního platného výsledku každé osoby, všechna její sezení dohromady (vaše verze se slučuje podle kódu osoby); zobrazují se testy s aspoň ' . intval($m['min_n']) . ' lidmi (u malých čísel jsou korelace velmi nestabilní – číslo n je v bublině po najetí myší). Skryto: počty DSM symptomů a starší odvozené skóry.</p>';
    }
    if (current_user_can('manage_options')) {
        echo '<h2>Smazat data účastníka (GDPR)</h2><form method="post">';
        wp_nonce_field('kb_delete');
        echo '<input name="kb_delete" placeholder="celý identifikátor účastníka" size="40" required> <button class="button">Smazat</button></form>';
    }
    echo '</div>';
}

function kb_delete_participant($anon) {
    global $wpdb;
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('participants') . " WHERE anon_id = %s", $anon));
    if (!$pid) { return 0; }
    $sids = $wpdb->get_col($wpdb->prepare("SELECT id FROM " . kb_table('sessions') . " WHERE participant_id = %d", $pid));
    $n = 0;
    foreach ($sids as $sid) { $n += (int) $wpdb->delete(kb_table('rows'), array('session_id' => $sid)); }
    $n += (int) $wpdb->delete(kb_table('scores'), array('participant_id' => $pid));
    $n += (int) $wpdb->delete(kb_table('sessions'), array('participant_id' => $pid));
    $n += (int) $wpdb->delete(kb_table('participants'), array('id' => $pid));
    return $n;
}

function kb_admin_settings() {
    if (!current_user_can('manage_options')) { return; }
    $s = get_option('kb_settings', array());
    if (isset($_POST['kb_save']) && check_admin_referer('kb_settings')) {
        $s['notify_email']   = sanitize_email(wp_unslash($_POST['notify_email']));
        $s['notify']         = (isset($_POST['notify']) && $_POST['notify'] === 'finished') ? 'finished' : 'none';
        $s['min_n']          = max(1, intval($_POST['min_n']));
        $s['public_enabled'] = empty($_POST['public_enabled']) ? 0 : 1;
        $s['privacy_url']    = esc_url_raw(wp_unslash($_POST['privacy_url']));
        update_option('kb_settings', $s);
        echo '<div class="notice notice-success"><p>Uloženo.</p></div>';
    }
    echo '<div class="wrap"><h1>Nastavení baterie</h1><form method="post">';
    wp_nonce_field('kb_settings');
    echo '<table class="form-table">';
    echo '<tr><th>Veřejná verze zapnutá</th><td><input type="checkbox" name="public_enabled" value="1" ' . checked(!empty($s['public_enabled']), true, false) . '></td></tr>';
    echo '<tr><th>E-mail pro upozornění</th><td><input type="email" name="notify_email" value="' . esc_attr(isset($s['notify_email']) ? $s['notify_email'] : '') . '" size="40"></td></tr>';
    echo '<tr><th>Posílat e-mail</th><td><select name="notify"><option value="finished" ' . selected(isset($s['notify']) ? $s['notify'] : '', 'finished', false) . '>po každém dokončeném testu</option><option value="none" ' . selected(isset($s['notify']) ? $s['notify'] : '', 'none', false) . '>neposílat</option></select></td></tr>';
    echo '<tr><th>Odkaz na zásady ochrany osobních údajů</th><td><input type="url" name="privacy_url" value="' . esc_attr(isset($s['privacy_url']) ? $s['privacy_url'] : '') . '" size="60"><br><span class="description">Když zůstane prázdné, použije se stránka zásad nastavená ve WordPressu.</span></td></tr>';
    echo '<tr><th>Minimální počet lidí pro zobrazení rozložení</th><td><input type="number" name="min_n" min="1" value="' . esc_attr(isset($s['min_n']) ? $s['min_n'] : 30) . '"></td></tr>';
    echo '</table><p><button class="button button-primary" name="kb_save" value="1">Uložit</button></p></form>';
    echo '<p><b>Data se při aktualizaci pluginu nemažou.</b> Nová verze baterie jen přidá nové testy; stávající výsledky zůstávají.</p></div>';
}
