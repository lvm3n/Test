<?php
if (!defined('ABSPATH')) { exit; }

/* Jednorázový přepočet: průměry subškál ADHD (0–4) pro dřívější vyplnění, jen z položek, které ve škále zůstaly (ADHD-v10).
   Uloží se jako odvozené hodnoty (valid = 2, verze 'prepocet'), aby je lidé viděli ve svých výsledcích a byly ve srovnání. */
function kb_adhd_means_backfill() {
    global $wpdb;
    $map = array(
        'adhdp_nepozornost' => array('POZ_14', 'POZ_13', 'POZ_16', 'POZ_02', 'POZ_15', 'POZ_12', 'POZ_20', 'POZ_07', 'POZ_08', 'POZ_05', 'POZ_22', 'POZ_09', 'POZ_18', 'POZ_10', 'POZ_04', 'POZ_01', 'POZ_17', 'POZ_11', 'POZ_03'),
        'adhdp_hyperaktivita' => array('HYP_04', 'HYP_16', 'HYP_01', 'HYP_11', 'HYP_12', 'HYP_03', 'HYP_13', 'HYP_14', 'HYP_07', 'HYP_08', 'HYP_15', 'HYP_09', 'HYP_02', 'HYP_05', 'HYP_06', 'HYP_10'),
        'adhdp_impulzivita' => array('IMP_06', 'IMP_11', 'IMP_03', 'IMP_05', 'IMP_10', 'IMP_01', 'IMP_04', 'IMP_07'),
        'adhdp_exekutivni' => array('EXE_09', 'EXE_07', 'EXE_15', 'EXE_01', 'EXE_14', 'EXE_18', 'EXE_20', 'EXE_16', 'EXE_19', 'EXE_02', 'EXE_08', 'EXE_10', 'EXE_13', 'EXE_11', 'EXE_06', 'EXE_05', 'EXE_17', 'EXE_04', 'EXE_03'),
        'adhdp_emocni' => array('EMO_07', 'EMO_10', 'EMO_06', 'EMO_02', 'EMO_01', 'EMO_09', 'EMO_05', 'EMO_04', 'EMO_08')
    );
    $scores = $wpdb->get_results("SELECT session_id, participant_id, age, mode, test_version, created FROM " . kb_table('scores') . " WHERE test_key = 'adhd' ORDER BY id ASC");
    $done = array(); $made = 0;
    foreach ($scores as $sc) {
        if (isset($done[$sc->session_id])) { continue; }
        $done[$sc->session_id] = 1;
        $rows = $wpdb->get_col($wpdb->prepare("SELECT data FROM " . kb_table('rows') . " WHERE session_id = %d AND test_key = 'adhd' ORDER BY client_seq ASC, id ASC", $sc->session_id));
        $ans = array();
        foreach ($rows as $json) {
            $d = json_decode($json, true);
            if (!is_array($d) || empty($d['polozka']) || !isset($d['odpoved'])) { continue; }
            if (is_numeric($d['odpoved'])) { $ans[$d['polozka']] = floatval($d['odpoved']); }   // pozdější odpověď přepíše dřívější
        }
        foreach ($map as $key => $codes) {
            $v = array();
            foreach ($codes as $c) { if (isset($ans[$c])) { $v[] = $ans[$c]; } }
            if (count($v) < 3) { continue; }
            $wpdb->insert(kb_table('scores'), array(
                'session_id' => $sc->session_id, 'participant_id' => $sc->participant_id, 'test_key' => $key, 'test_version' => 'prepocet',
                'raw_score' => round(array_sum($v) / count($v), 2), 'valid' => 2, 'age' => $sc->age, 'mode' => $sc->mode, 'created' => $sc->created,
                'data' => wp_json_encode(array('z_verze' => $sc->test_version, 'polozek' => count($v)))));
            $made++;
        }
    }
    update_option('kb_adhd_means', '1');
    return $made;
}
