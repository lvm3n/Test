import json, random
from collections import Counter
B=json.load(open('/home/claude/ps3/picture_span_v3/picture_span_bank_v3.json',encoding='utf8'))
S=sorted(x[:-4] for x in __import__('os').listdir('/home/claude/ps3/picture_span_v3/svg'))
GROUPS=[{'key','lock'},{'sock','shoe'},{'car','train','bus'},{'sun','moon','star','cloud'},{'apple','pear','cherry'},{'cake','gift'},{'cat','dog'},{'boat','fish'}]
grp={x:i for i,g in enumerate(GROUPS) for x in g}
best=None
for seed in range(400):
    r=random.Random(seed); tc=Counter(); fc=Counter(); out=[]; prev=set(); ok=True
    for it in B:
        if it['phase']!='scored': out.append(it); continue
        T=it['T']; F=len(it['foils'])
        cand=[x for x in S if x not in prev]; cand.sort(key=lambda x:(tc[x], fc[x], r.random()))
        tg=[]; used_g=set()
        for x in cand:
            g=grp.get(x)
            if g is not None and g in used_g: continue
            tg.append(x); used_g.add(g) if g is not None else None
            if len(tg)==T: break
        if len(tg)<T: ok=False; break
        r.shuffle(tg)
        cf=[x for x in S if x not in prev and x not in tg]; cf.sort(key=lambda x:(fc[x], tc[x], r.random())); fo=cf[:F]
        if len(fo)<F: ok=False; break
        for _ in range(200):
            pool=tg+fo; r.shuffle(pool); pos=[pool.index(t) for t in tg]
            if T==1 or not all(pos[j+1]==pos[j]+1 for j in range(T-1)): break
        tc.update(tg); fc.update(fo); prev=set(tg)
        out.append({**it,'targets':tg,'foils':fo,'response_pool':pool})
    if not ok: continue
    sc=(max(tc.values())-min(tc[x] for x in S))*2+(max(fc.values())-min(fc[x] for x in S))
    if best is None or sc<best[0]: best=(sc,out,tc,fc)
sc,out,tc,fc=best
sco=[x for x in out if x['phase']=='scored']
print('cíle',min(tc[x] for x in S),'-',max(tc.values()),'| rušivé',min(fc[x] for x in S),'-',max(fc.values()))
print('předchozí cíle v další položce:',sum(len(set(a['targets'])&(set(b['targets'])|set(b['foils']))) for a,b in zip(sco,sco[1:])))
bad=[x['id'] for x in sco if len({grp[t] for t in x['targets'] if t in grp})<len([t for t in x['targets'] if t in grp])]
print('asociované dvojice v cílech:',bad)
json.dump(out,open('/home/claude/ps3_bank_fixed.json','w'),ensure_ascii=False,indent=1)
