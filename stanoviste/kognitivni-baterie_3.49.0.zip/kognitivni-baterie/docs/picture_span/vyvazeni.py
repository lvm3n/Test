import json, random
from collections import Counter
B=json.load(open('/home/claude/ps2/picture_span_bank/picture_span_bank.json',encoding='utf8'))
S=sorted(x[:-4] for x in __import__('os').listdir('/home/claude/ps2/picture_span_bank/svg'))
best=None
for seed in range(300):
    r=random.Random(seed); tc=Counter(); fc=Counter(); out=[]; prev=set()
    for it in B:
        if it['phase']!='scored': out.append(it); continue
        T,F=it['T'],it['F']
        cand=[x for x in S if x not in prev]
        cand.sort(key=lambda x:(tc[x], fc[x], r.random())); tg=cand[:T]; r.shuffle(tg)
        cf=[x for x in S if x not in prev and x not in tg]
        cf.sort(key=lambda x:(fc[x], tc[x], r.random())); fo=cf[:F]
        while True:
            pool=tg+fo; r.shuffle(pool); pos=[pool.index(t)+1 for t in tg]
            if T==1 or not all(pos[j+1]==pos[j]+1 for j in range(T-1)): break
        tc.update(tg); fc.update(fo); prev=set(tg)
        out.append({**it,'targets':tg,'foils':fo,'response_pool':pool,'target_positions_in_pool':pos})
    sc=max(tc.values())-min(tc[x] for x in S)+ (max(fc.values())-min(fc[x] for x in S))
    if best is None or sc<best[0]: best=(sc,out,tc,fc)
sc,out,tc,fc=best
print('rozptyl cílů',min(tc[x] for x in S),'-',max(tc.values()),'| rušivých',min(fc[x] for x in S),'-',max(fc.values()))
sco=[x for x in out if x['phase']=='scored']
print('předchozí cíle jako rušivé/cíle:',sum(len(set(a['targets'])&(set(b['foils'])|set(b['targets']))) for a,b in zip(sco,sco[1:])))
json.dump(out,open('/home/claude/ps_bank_fixed.json','w'),ensure_ascii=False,indent=1)
