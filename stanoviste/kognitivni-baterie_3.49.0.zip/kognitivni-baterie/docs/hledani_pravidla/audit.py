import json, itertools
B=json.load(open('/home/claude/hp/bank.json'))
N=[5,4,3]   # barvy, tvary, velikosti
def attr_maps(f):
    n=N[f]; M={'id':lambda v:v}
    for c in range(n): M[f'set{c}']=(lambda c: lambda v:c)(c)
    M['+1']=lambda v,n=n:min(n-1,v+1); M['-1']=lambda v:max(0,v-1)
    if f<2: M['+1c']=lambda v,n=n:(v+1)%n; M['-1c']=lambda v,n=n:(v-1)%n
    return M
HYP=[]
for combo in itertools.product(*[attr_maps(f).items() for f in range(3)]):
    HYP.append(('|'.join(n for n,_ in combo), [fn for _,fn in combo]))
def apply(h, objs): return [[h[f](o[f]) for f in range(3)] for o in objs]
for it in B['practice']+B['items']:
    fits=[(n,h) for n,h in HYP if all(len(d[0])==len(d[1]) and apply(h,d[0])==d[1] for d in it['demos'])]
    if not fits: continue
    preds={}
    for n,h in fits: preds.setdefault(json.dumps(apply(h,it['test'])),[]).append(n)
    if len(preds)>1:
        print(it['id'],it['rule']); 
        for k,v in preds.items(): print('   ',k,'←',v[:3], '(KLÍČ)' if json.loads(k)==it['answer'] else '')
