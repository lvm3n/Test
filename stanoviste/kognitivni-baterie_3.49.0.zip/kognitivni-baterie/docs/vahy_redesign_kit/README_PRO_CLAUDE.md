# Váhy – implementační balíček pro kognitivní baterii

## Cíl
Přepracovat **pouze vizuální vrstvu** subtestu Váhy v `assets/app.html`. Neměnit položkovou banku, scoring, adaptivní logiku, časování, logování ani princip interakce.

Současná verze už má správně oddělenou logiku od zobrazení: podněty se skládají přes `shapeSVG()`, celé váhy přes `scaleHTML()` a cílová váha se renderuje v `render()`. Proto není nutné měnit psychometriku ani způsob odpovídání.

## Co je potřeba změnit

### 1. Rozložení obrazovky
- zmenšit vertikální mezery v `#m-vahy #s-item .wrap`;
- horní nápovědné rovnice zvětšit cca o 20–30 %;
- cílovou kartu zvětšit z max. 600 px na cca 760 px;
- paletu umístit bezprostředně pod cílové váhy;
- odstranit těžký černý rámeček cílové karty, použít stejný jemný rámeček jako jinde v baterii;
- zachovat responzivitu.

Připravené CSS je v `code/vahy_styles.css`.

### 2. Vzhled vah
Nynější kladina + černé pruhy jsou málo podobné skutečným rovnoramenným vahám. Nová komponenta má mít:
- jasnou centrální stojku a podstavec;
- vodorovnou kladinu s čepem;
- dvě závěsné misky na šňůrách;
- při nerovnosti se naklání **celé rameno s miskami**, stojan zůstává svislý;
- dost velký prostor nad miskou pro 1–4 podněty (u cílové misky až 6 odpovědních kusů).

Komponenta je postavená v HTML/CSS, takže zůstává interaktivní a není potřeba rasterizovat celé váhy.

### 3. Stimuly
Použít ploché 2D tvary bez 3D efektu a bez facet. Zvlášť důležité je, aby `fialový šestiúhelník` vypadal jako **jednoduchý plochý šestiúhelník**, ne jako růžový mnohostěn.

Navržená sada:
- oranžovočervený kruh;
- modrý čtverec;
- žlutý trojúhelník;
- zelená hvězda;
- fialový šestiúhelník.

Klíče v bance (`červený kruh`, `modrý čtverec` atd.) **neměnit**. Mění se jen kresba.

SVG reference jsou ve složce `svg/`. Pro vlastní baterii je ale lepší nechat tvary inline přes `shapeSVG()`, protože to zachová jednoduché škálování a interaktivitu.

## Přesné místo v současném app.html
V modulu `mod_vahy(root, BANK)`:

1. současný objekt `SHAPES` a funkci `shapeSVG` nahradit variantou z `code/vahy_component.js`;
2. současnou funkci `scaleHTML(left, right, cls)` nahradit `scaleHTMLv3` (lze ji přejmenovat zpět na `scaleHTML`);
3. v `render()` nahradit ručně sestavený HTML blok `#qscale` voláním nové komponenty s `interactiveRight=true`;
4. event listener `.piece-btn` zachovat;
5. `tilt()` zachovat – CSS používá stejné `--tilt`, `tilted` a `ineq`;
6. CSS z `code/vahy_styles.css` vložit **za stávající styly vah**, aby je přepsalo.

## Co se nesmí rozbít
- klik na položku v paletě přidá tvar do pravé misky;
- klik na vložený tvar ho odebere;
- `Vrátit krok` funguje jako nyní;
- `Hotovo` se aktivuje až po vložení odpovědi;
- horní rovnice i nerovnosti se zobrazují ze stejné banky;
- `tilt()` funguje pro demonstrační a nerovnostní váhy;
- `aria-label`, čtečka a tlačítko `Přečíst` zůstávají zachovány;
- na mobilu je jedna rovnice na řádek a cílová váha se vejde na šířku.

## UX doporučení nad rámec grafiky
První nácvik už je strukturou dobrý: nejdřív totožnost se čtvercem, pak kruh = 2 čtverce. Není potřeba hned přidávat více typů tvarů. Nový šestiúhelník se může objevit až později stejně jako dnes, ale musí být vizuálně jednoduchý.

U nácviku bych navíc horní vztah označil malým textem `Příklad` / `Nápověda`, ale v ostrém testu tento štítek nezobrazovat, aby nepřidával zbytečný jazykový obsah.

## Vizuální reference
`reference/mockup_vahy.png` ukazuje zamýšlenou hierarchii, nikoli pixelově závazný design. Implementace má zachovat styl celé baterie a nemá kopírovat dekorativní kruhy v pozadí.

## Doporučený postup pro Claude
1. Udělat změny pouze v kopii pluginu.
2. Nejdřív nahradit komponentu vah a tvary.
3. Pak aplikovat layout CSS.
4. Otestovat N1, N2, jednu položku s více rovnicemi, jednu nerovnost a položku se 4 podněty na jedné misce.
5. Otestovat desktop cca 1536×864 a mobil 390×844.
6. Nezasahovat do `BANK_VAHY` ani do funkcí pro scoring/logování.
