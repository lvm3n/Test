/*
  Drop-in vizuální komponenta pro mod_vahy().
  Klíčová zásada: nemění banku, scoring, časování ani logiku odpovědi.
  Nahrazuje pouze SHAPES/shapeSVG, scaleHTML a markup qscale v render().
*/

const SHAPES_V3 = {
  'červený kruh':         {d:'M16 50a34 34 0 1 0 68 0a34 34 0 1 0 -68 0Z', fill:'#E76F00'},
  'modrý čtverec':        {d:'M18 18H82V82H18Z', fill:'#1686C9'},
  'žlutý trojúhelník':    {d:'M50 14L87 82H13Z', fill:'#F2C94C'},
  'zelená hvězda':        {d:'M50 10L61 37L90 39L67 58L74 86L50 70L26 86L33 58L10 39L39 37Z', fill:'#35A853'},
  'fialový šestiúhelník': {d:'M50 14L82 32V68L50 86L18 68V32Z', fill:'#8B5CC7'}
};

/* Ploché 2D stimuly: žádné facety, gradienty ani „mnohostěnový“ dojem. */
const shapeSVGv3 = (n) => `<svg viewBox="0 0 100 100" aria-hidden="true">
  <path d="${SHAPES_V3[n].d}" fill="${SHAPES_V3[n].fill}" stroke="#203247" stroke-width="5" stroke-linejoin="round"/>
</svg>`;

function scaleHTMLv3(left, right, cls='', interactiveRight=false){
  const fixedPiece = (n) => `<span class="piece" title="${n}">${shapeSVGv3(n)}</span>`;
  const answerPiece = (n,i) => interactiveRight
    ? `<button class="piece piece-btn" type="button" data-i="${i}" aria-label="Odebrat: ${n}">${shapeSVGv3(n)}</button>`
    : fixedPiece(n);

  return `<div class="scale scale-v2 ${cls}">
    <div class="stand-v2" aria-hidden="true"></div>
    <div class="arm">
      <div class="beam-v2" aria-hidden="true"></div>
      <div class="pivot-v2" aria-hidden="true"></div>
      <div class="pan-v2 pan-left">
        <div class="pile">${left.map(fixedPiece).join('')}</div>
        <div class="pan-bowl" aria-hidden="true"></div>
      </div>
      <div class="pan-v2 pan-right">
        <div class="pile" aria-label="Prázdná miska">${right.map(answerPiece).join('')}</div>
        <div class="pan-bowl" aria-hidden="true"></div>
      </div>
    </div>
  </div>`;
}

/*
  V existujícím kódu:

  1) nahraď shapeSVG(...) za shapeSVGv3(...), nebo původní funkci přepiš obsahem výše.
  2) nahraď scaleHTML(...) za scaleHTMLv3(...), nebo funkci přejmenuj zpět na scaleHTML.
  3) v render() nahraď ručně skládaný #qscale tímto:

     $('#qscale').innerHTML = scaleHTMLv3(left, S.placed, 'qscale', true)
       + `<span class="mark" id="qMark"></span>`;

  4) stávající listener na .piece-btn může zůstat přesně stejný.
  5) tilt(el,diff) může zůstat beze změny; .scale-v2 používá stejné --tilt a class tilted.
*/
