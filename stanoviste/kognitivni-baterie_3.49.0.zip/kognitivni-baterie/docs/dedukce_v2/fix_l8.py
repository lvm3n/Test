import json,sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from layout import layout
from iso import iso
I=json.load(open('newbank.json'))
OLD={x['id']:x for x in json.load(open('/home/claude/ded2/bank_ded.json',encoding='utf8'))['items']}
G=json.load(open('gen_l8.json'))
G=sorted(G,key=lambda g:refute_core(g['cons'],g['reveals'],g['target'])['core_max'])[:2]
SH=lambda v,k: S[(S.index(v)+k)%5]
new=[]
for g,(want,nid) in zip(G,[('A','D57'),('E','D58')]):
    k=(S.index(want)-S.index(g['answer']))%5
    rev={n:SH(v,k) for n,v in g['reveals'].items()}
    assert target_values(g['cons'],rev,g['target'])=={want}
    L=layout(g['cons'],seed=int(nid[1:]))
    new.append({'id':nid,'tier':8,'target':g['target'],'reveals':rev,'answer':want,'cap':120,'cons':g['cons'],'nc':L['nc'],'j':L['j']})
    print(nid,want,'layout',L['eval'])
d13=dict(OLD['D13']); d13['tier']=2; d13['cap']=60; d13['puvodni_tier']=OLD['D13']['tier']
out=[]
for x in I:
    if x['id']=='D09': out.append(d13)
    elif x['id']=='D50': out.append(new[0])
    elif x['id']=='D51': out.append(new[1])
    else: out.append(x)
# metriky pro všechny: jádro sporu a větvení
for x in out:
    m=metrics(x['cons'],x['reveals'],x['target']); rc=refute_core(x['cons'],x['reveals'],x['target'])
    x['metriky']={**{k:m[k] for k in ('used','entry','local','maxopen','nodes','rels','revealed')},'spor':m.get('spor'),
                  'refutation_core':rc['core_min'] if rc['zbyva']>1 else 0,'branching':rc['zbyva']}
# kontrola izomorfie v rámci úrovní
bad=[(a['id'],b['id']) for i,a in enumerate(out) for b in out[i+1:] if a['tier']==b['tier'] and iso(a,b)]
print('izomorfní dvojice:',bad)
from collections import Counter
print(Counter(x['answer'] for x in out))
for x in out:
    if x['tier']>=6: print(x['id'],x['tier'],x['metriky']['refutation_core'],x['metriky']['branching'],x['metriky']['maxopen'])
json.dump(out,open('newbank.json','w'),ensure_ascii=False)
