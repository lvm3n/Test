import json,sys,itertools
from collections import Counter
sys.path.insert(0,'/home/claude/dedv2')
from layout import layout
from solver import metrics
s=open('/home/claude/w/kognitivni-baterie/assets/app.html',encoding='utf8').read()
i=s.index('const BANK_DED = ')+len('const BANK_DED = ')
B,_=json.JSONDecoder().raw_decode(s[i:])
OLD={x['id']:x for x in B['items']}
G=json.load(open('gen.json'))
PLAN=[(1,['D01','D04'],0),(2,['D07','D09'],0),(3,['D18','D23'],0),(4,['D27'],2),(5,['D28'],2),(6,['D26'],2),(7,['D31'],2),(8,[],3),(9,['D36'],2)]
anchors=Counter(OLD[a]['answer'] for _,ids,_ in PLAN for a in ids)
# vybrat nové položky tak, aby se vyrovnaly správné odpovědi
best=None
pools=[(lvl,G['L%d'%lvl]) for lvl,_,k in PLAN if k]
need={lvl:k for lvl,_,k in PLAN if k}
for combo in itertools.product(*[list(itertools.combinations(range(len(p)),need[l])) for l,p in pools]):
    cnt=Counter(anchors)
    for (l,p),c in zip(pools,combo):
        for j in c: cnt[p[j]['answer']]+=1
    sc=max(cnt.values())-min(cnt.get(x,0) for x in 'ABCDE')
    if best is None or sc<best[0]: best=(sc,combo,cnt)
print('rozptyl odpovědí',best[0],dict(best[2]))
items=[]; nid=41
CAP={1:30,2:60,3:60,4:60,5:60,6:75,7:90,8:120,9:120}
for lvl,ids,k in PLAN:
    for a in ids:
        x=dict(OLD[a]); x['tier']=lvl; x['cap']=CAP[lvl]; x['puvodni_tier']=OLD[a]['tier']; items.append(x)
    if k:
        p=G['L%d'%lvl]; c=best[1][[l for l,_ in pools].index(lvl)]
        for j in c:
            g=p[j]; L=layout(g['cons'],seed=nid)
            items.append({'id':'D%02d'%nid,'tier':lvl,'target':g['target'],'reveals':g['reveals'],'answer':g['answer'],'cap':CAP[lvl],'cons':g['cons'],'nc':L['nc'],'j':L['j'],'nova':1})
            print('D%02d'%nid,'L%d'%lvl,'layout',L['eval']); nid+=1
# kontrola metrik všech
for x in items:
    m=metrics(x['cons'],x['reveals'],x['target']); x['metriky']={k:m[k] for k in ('used','entry','local','maxopen','nodes','rels','revealed') if k in m}; x['metriky']['spor']=m.get('spor')
json.dump(items,open('newbank.json','w'),ensure_ascii=False)
for x in items: print(x['id'],x['tier'],x['answer'],x['metriky'])
