import itertools, json, random
S='ABCDE'
R={'A':['B','C'],'B':['C','D'],'C':['D','E'],'D':['E','A'],'E':['A','B']}
def ok(p,l,r): return {l,r}==set(R[p])
def nodes_of(cons): return sorted({n for c in cons for n in c})
def all_solutions(cons, rev, limit=10**9):
    ns=nodes_of(cons); rev={n:v for n,v in rev.items() if n in ns}; order=sorted(ns,key=lambda n:(n not in rev, -sum(n in c for c in cons)))
    out=[]; a={}
    def consistent():
        for p,l,r in cons:
            if p in a and l in a and r in a and not ok(a[p],a[l],a[r]): return False
            if p in a and l in a and a[l] not in R[a[p]]: return False
            if p in a and r in a and a[r] not in R[a[p]]: return False
            if l in a and r in a and (a[l]==a[r]): return False
        return True
    def bt(k):
        if len(out)>=limit: return
        if k==len(order): out.append(dict(a)); return
        n=order[k]
        for v in ([rev[n]] if n in rev else S):
            a[n]=v
            if consistent(): bt(k+1)
            del a[n]
    bt(0); return out
def target_values(cons,rev,t):
    if not cons or t not in nodes_of(cons): return set(S)
    rev={n:v for n,v in rev.items() if n in nodes_of(cons)}
    return {x[t] for x in all_solutions(cons,rev)}
# ---- „lidský“ řešič: techniky ----
def rel_cands(c, dom, n):
    p,l,r=c; k=(p,l,r).index(n)
    return {t[k] for t in itertools.product(dom[p],dom[l],dom[r]) if ok(*t)}
def human(cons, rev, t):
    """vrací (úroveň techniky, detaily). T1 = vztah s 1 neznámou; T2 = průnik z vztahů s jen známými ostatními;
       T3 = šíření kandidátů přes neznámé uzly; T4 = hypotéza + spor."""
    ns=nodes_of(cons); dom={n:({rev[n]} if n in rev else set(S)) for n in ns}
    used=set(); t1steps=0; entry=None; maxopen=0
    def known(n): return len(dom[n])==1
    while len(dom[t])>1:
        prog=False
        for c in cons:                                   # T1
            unk=[n for n in c if not known(n)]
            if len(unk)==1:
                v=rel_cands(c,dom,unk[0])
                if len(v)==1 and v!=dom[unk[0]]:
                    dom[unk[0]]=v; used.add('T1'); t1steps+=1; prog=True
                    if entry is None: entry=True
                    break
        if prog: continue
        if entry is None: entry=False
        for n in ns:                                     # T2: průnik kandidátů z vztahů, kde jsou ostatní uzly známé
            if known(n): continue
            cs=[c for c in cons if n in c and sum(not known(m) for m in c)==2]
            if len(cs)>=2:
                inter=set(S)
                for c in cs:
                    other=[m for m in c if m!=n and not known(m)][0]
                    tmp=dict(dom); tmp[other]=set(S); inter&=rel_cands(c,tmp,n)
                if len(inter)==1 and inter!=dom[n]:
                    dom[n]=inter; used.add('T2'); prog=True; break
        if prog: continue
        changed=False                                    # T3: obecné šíření kandidátů (jedno kolo)
        for c in cons:
            for n in c:
                v=rel_cands(c,dom,n)&dom[n]
                if v!=dom[n]: dom[n]=v; changed=True
        if changed:
            used.add('T3'); maxopen=max(maxopen,sum(1 for n in ns if 1<len(dom[n])<5)); continue
        break
    if len(dom[t])==1: return dict(level=max(used) if used else 'T0', used=sorted(used), t1=t1steps, entry=entry, maxopen=maxopen, hyp=0)
    # T4: hypotéza – hloubka sporu = počet jednoznačných kroků (T1) od hypotézy ke sporu (nejkratší ze všech hypotéz)
    def contra_depth(d0):
        d=dict(d0); steps=0
        for _ in range(30):
            for c in cons:
                if any(len(rel_cands(c,d,m)&d[m])==0 for m in c): return steps
            prog=False
            for c in cons:
                unk=[m for m in c if len(d[m])>1]
                if len(unk)==1:
                    v=rel_cands(c,d,unk[0])&d[unk[0]]
                    if len(v)<len(d[unk[0]]): d[unk[0]]=v; steps+=1; prog=True; break
            if not prog:
                ch=False
                for c in cons:
                    for m in c:
                        w=rel_cands(c,d,m)&d[m]
                        if w!=d[m]: d[m]=w; ch=True
                if not ch: return None
                steps+=2
        return None
    best=None
    for n in ns:
        if len(dom[n])<2: continue
        for v in dom[n]:
            d2=dict(dom); d2[n]={v}
            k=contra_depth(d2)
            if k is not None and (best is None or k<best): best=k
    return dict(level='T4', used=sorted(used|{'T4'}), t1=t1steps, entry=entry, maxopen=maxopen, hyp=1, spor=best, zbyva=len(dom[t]))

def metrics(cons, rev, t):
    sol=all_solutions(cons,rev)
    tv={x[t] for x in sol}
    nec=all(len(target_values(cons[:j]+cons[j+1:],rev,t))!=1 for j in range(len(cons)))
    inc=[c for c in cons if t in c]
    loc=len(target_values(inc,{n:v for n,v in rev.items() if n in nodes_of(inc)},t))
    h=human(cons,rev,t)
    return dict(unique_target=len(tv)==1, full_unique=len(sol)==1, necessary=nec, local=loc, nodes=len(nodes_of(cons)), rels=len(cons), revealed=len(rev), **h)

def hyp_chain(cons, rev, t):
    """Pro položky s hypotézou: nejkratší počet jednoznačných kroků (T1) od hypotézy k rozporu,
       když se v hypotetické větvi smí jen přímo dopočítávat (žádné šíření kandidátů).
       Vrací (nejkratší řetěz, počet hypotéz vedoucích ke sporu jen přes T1, kandidáti cíle po běžném řešení)."""
    ns=nodes_of(cons); dom={n:({rev[n]} if n in rev else set(S)) for n in ns}
    # běžné řešení T1–T3 (bez hypotézy)
    while True:
        ch=False
        for c in cons:
            for m in c:
                w=rel_cands(c,dom,m)&dom[m]
                if w!=dom[m]: dom[m]=w; ch=True
        if not ch: break
    if len(dom[t])==1: return None
    best=None; nlead=0
    for n in ns:
        if len(dom[n])<2: continue
        for v in sorted(dom[n]):
            known={m:next(iter(dom[m])) for m in ns if len(dom[m])==1}; known[n]=v; steps=0; contra=False
            for _ in range(20):
                bad=False
                for p,l,r in cons:
                    if all(x in known for x in (p,l,r)) and not ok(known[p],known[l],known[r]): bad=True
                    if p in known and ((l in known and known[l] not in R[known[p]]) or (r in known and known[r] not in R[known[p]])): bad=True
                    if l in known and r in known and known[l]==known[r]: bad=True
                if bad: contra=True; break
                prog=False
                for c in cons:
                    unk=[m for m in c if m not in known]
                    if len(unk)==1:
                        tmp={m:({known[m]} if m in known else dom[m]) for m in c}
                        cand=rel_cands(c,tmp,unk[0])
                        if len(cand)==0: contra=True; break
                        if len(cand)==1: known[unk[0]]=next(iter(cand)); steps+=1; prog=True; break
                if contra or not prog: break
            if contra:
                nlead+=1
                if best is None or steps<best: best=steps
    return dict(chain=best, nlead=nlead, zbyva=len(dom[t]))

def refute_core(cons, rev, t):
    """Pro hypotézy na cíli: nejmenší počet vztahů, které spolu s odkrytými hodnotami vyvrátí danou chybnou
       hodnotu cíle. Vrací (min přes chybné kandidáty, max přes chybné kandidáty, kandidáti po běžném řešení)."""
    ns=nodes_of(cons); dom={n:({rev[n]} if n in rev else set(S)) for n in ns}
    while True:
        ch=False
        for c in cons:
            for m in c:
                w=rel_cands(c,dom,m)&dom[m]
                if w!=dom[m]: dom[m]=w; ch=True
        if not ch: break
    true=target_values(cons,rev,t)
    cores=[]
    for v in sorted(dom[t]-true):
        found=None
        for k in range(1,len(cons)+1):
            for sub in itertools.combinations(cons,k):
                sub=list(sub)
                if t not in nodes_of(sub): continue
                r2={n:x for n,x in rev.items() if n in nodes_of(sub)}; r2[t]=v
                if not all_solutions(sub,r2,limit=1): found=k; break
            if found: break
        cores.append(found or 99)
    return dict(core_min=min(cores) if cores else 0, core_max=max(cores) if cores else 0, zbyva=len(dom[t]))
