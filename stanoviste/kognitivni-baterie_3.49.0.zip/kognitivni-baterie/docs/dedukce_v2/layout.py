import math, itertools, random
import networkx as nx
def cross(a,b,c,d):
    def o(p,q,r): return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    if len({tuple(a),tuple(b),tuple(c),tuple(d)})<4: return False
    return o(c,d,a)*o(c,d,b)<0 and o(a,b,c)*o(a,b,d)<0
def dseg(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]; L=dx*dx+dy*dy
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L)) if L else 0
    return math.hypot(p[0]-(a[0]+t*dx),p[1]-(a[1]+t*dy))
def ev(cons,pts):
    nodes=[k for k in pts if not k.startswith('F')]
    J=[tuple(pts['F%d'%(i+1)]) for i in range(len(cons))]
    S=[(i,n,J[i],tuple(pts[n])) for i,c in enumerate(cons) for n in c]
    cr=sum(cross(s[2],s[3],t[2],t[3]) for s,t in itertools.combinations(S,2) if s[0]!=t[0])
    nn=min(math.dist(pts[a],pts[b]) for a,b in itertools.combinations(nodes,2))
    segc=min(dseg(pts[k],s[2],s[3]) for s in S for k in nodes if k!=s[1])
    jn=min(math.dist(j,pts[k]) for j in J for k in nodes)
    jj=min([math.dist(a,b) for a,b in itertools.combinations(J,2)] or [99])
    jseg=min([dseg(J[i],s[2],s[3]) for i in range(len(J)) for s in S if s[0]!=i] or [99])
    clear=min(nn/2.2,segc,jn,jj*1.2,jseg*1.6)
    dev=0; spread=0
    for i,(p,l,r) in enumerate(cons):
        cx=(pts[p][0]+pts[l][0]+pts[r][0])/3; cy=(pts[p][1]+pts[l][1]+pts[r][1])/3
        dev=max(dev,math.dist(J[i],(cx,cy)))
        Ls=[math.dist(J[i],pts[n]) for n in (p,l,r)]; spread=max(spread,max(Ls)/max(1,min(Ls)))
    # rodič spíš nahoře (čitelnost „jeden nahoře, dvojice dole“), mírná preference
    up=sum(max(0,pts[p][1]-min(pts[l][1],pts[r][1])+5) for p,l,r in cons)
    return cr,clear,dev,spread,up
def obj(e): return e[1]-0.35*e[2]-2.0*max(0,e[3]-2.2)-0.04*e[4]
def faces(emb):
    seen=set(); F=[]
    for u,v in emb.edges():
        if (u,v) in seen: continue
        F.append(emb.traverse_face(u,v,mark_half_edges=seen))
    return F
def tutte(G,outer):
    pos={}
    for i,n in enumerate(outer):
        a=2*math.pi*i/len(outer); pos[n]=[50+40*math.cos(a),50+40*math.sin(a)]
    inner=[n for n in G if n not in pos]
    for n in inner: pos[n]=[50,50]
    for _ in range(1500):
        for n in inner:
            nb=list(G[n]); pos[n]=[sum(pos[m][0] for m in nb)/len(nb),sum(pos[m][1] for m in nb)/len(nb)]
    return pos
def fit(pos):
    xs=[v[0] for v in pos.values()]; ys=[v[1] for v in pos.values()]
    return {k:[10+80*(v[0]-min(xs))/((max(xs)-min(xs)) or 1),10+80*(v[1]-min(ys))/((max(ys)-min(ys)) or 1)] for k,v in pos.items()}
def layout(cons, seed=0):
    G=nx.Graph()
    for i,(p,l,r) in enumerate(cons):
        for n in (p,l,r): G.add_edge('F%d'%(i+1),n)
    ok,emb=nx.check_planarity(G)
    if not ok: return None
    starts=[]
    for outer in sorted(faces(emb),key=len,reverse=True)[:4]:
        for rv in (False,True):
            starts.append(fit(tutte(G,list(reversed(outer)) if rv else outer)))
    rng=random.Random(seed)
    for t in range(25):
        pos=nx.spring_layout(G,seed=rng.randrange(10**6),iterations=200,k=rng.choice([0.5,0.8,1.1]))
        starts.append(fit({k:list(v) for k,v in pos.items()}))
    best=None
    for st in starts:
        e=ev(cons,st)
        if e[0]!=0: continue
        pts={k:v[:] for k,v in st.items()}; o=obj(e); r2=random.Random(seed+len(pts))
        for step in range(1800):
            k=r2.choice(list(pts)); old=pts[k][:]; amp=4 if step<900 else 1.5
            pts[k][0]=min(91,max(9,pts[k][0]+r2.uniform(-amp,amp))); pts[k][1]=min(91,max(9,pts[k][1]+r2.uniform(-amp,amp)))
            ne=ev(cons,pts)
            if ne[0]==0 and (ne[1]>=11 or ne[1]>e[1]) and obj(ne)>=o: o=obj(ne); e=ne
            else: pts[k]=old
        if best is None or o>best[0]: best=(o,pts,e)
        if best and best[2][1]>=14 and len([1 for _ in [0]])>0 and st is starts[-1]: break
    if not best: return None
    o,pts,e=best
    return {'nc':{k:[round(v[0],1),round(v[1],1)] for k,v in pts.items() if not k.startswith('F')},
            'j':[[round(pts['F%d'%(i+1)][0],1),round(pts['F%d'%(i+1)][1],1)] for i in range(len(cons))],'eval':[round(float(x),2) for x in e]}
