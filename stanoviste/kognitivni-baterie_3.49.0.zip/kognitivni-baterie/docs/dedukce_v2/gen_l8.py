import random, json, sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from gen import rand_net
from iso import iso
I=json.load(open('/home/claude/dedv2/newbank.json'))
keep=[x for x in I if x['id']=='D49']
rng=random.Random(int(sys.argv[1])); out=[]; tries=0
while len(out)<int(sys.argv[2]) and tries<int(sys.argv[3]):
    tries+=1
    cons,val=rand_net(rng,6,4)
    if not cons: continue
    nodes=list(val); rng.shuffle(nodes)
    rev={nodes[0]:val[nodes[0]]}; t=nodes[1]
    if len(target_values(cons,rev,t))!=1: continue
    h=human(cons,rev,t)
    if 'T4' not in h['used']: continue
    rc=refute_core(cons,rev,t)
    if rc['core_min']!=3 or rc['zbyva']!=3: continue
    x=metrics(cons,rev,t)
    if not (x['necessary'] and x['local']>=3): continue
    cand=dict(cons=cons,reveals=rev,target=t,answer=val[t])
    if any(iso(cand,k) for k in keep+out): continue
    out.append(cand); print('nalezeno',x['maxopen'],rc,flush=True)
print('pokusů',tries)
json.dump(out,open('/home/claude/dedv2/gen_l8.json','w'))
