import random, json, sys, itertools
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from gen import rand_net
from iso import iso
level=sys.argv[1]; seed=int(sys.argv[2]); k=int(sys.argv[3]); tm=int(sys.argv[4])
EX=json.load(open('/home/claude/dedv2/newbank.json'))
rng=random.Random(seed); out=[]; tries=0
def partial_min(cons,rev,t):
    m=len(cons); best=5
    for r in range(1,m):
        for sub in itertools.combinations(cons,r):
            best=min(best,len(target_values(list(sub),rev,t)))
    return best
while len(out)<k and tries<tm:
    tries+=1
    n=rng.randint(6,7); m=rng.randint(4,5)
    cons,val=rand_net(rng,n,m)
    if not cons: continue
    nodes=list(val); rng.shuffle(nodes)
    rev={nodes[0]:val[nodes[0]]}; t=nodes[1]
    if len(target_values(cons,rev,t))!=1: continue
    h=human(cons,rev,t)
    if 'T4' not in h['used']: continue
    rc=refute_core(cons,rev,t)
    if rc['zbyva']<3: continue
    if level=='L9' and rc['core_min']<4: continue
    if level=='L8' and rc['core_min']!=3: continue
    pm=partial_min(cons,rev,t)
    if pm<3: continue
    x=metrics(cons,rev,t)
    if not (x['necessary'] and x['local']>=3): continue
    cand=dict(cons=cons,reveals=rev,target=t,answer=val[t])
    if any(iso(cand,e) for e in EX)+any(iso(cand,o) for o in out): continue
    cand['metriky']=dict(refutation_core=rc['core_min'],branching=rc['zbyva'],partial_min=pm,maxopen=x['maxopen'],nodes=x['nodes'],rels=x['rels'])
    out.append(cand); print(level,'nalezeno',cand['metriky'],flush=True)
print('pokusů',tries)
try: G=json.load(open('/home/claude/dedv2/gen_b3.json'))
except Exception: G={}
G.setdefault(level,[]).extend(out); json.dump(G,open('/home/claude/dedv2/gen_b3.json','w'))
