import random, json, sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from gen import rand_net
seed=int(sys.argv[1]); k=int(sys.argv[2]); tm=int(sys.argv[3])
rng=random.Random(seed); out=[]; tries=0
while len(out)<k and tries<tm:
    tries+=1
    n=rng.randint(6,7); m=rng.randint(4,5)
    cons,val=rand_net(rng,n,m)
    if not cons: continue
    nodes=list(val); rng.shuffle(nodes)
    r=rng.randint(1,2); rev={x:val[x] for x in nodes[:r]}; t=nodes[r]
    if len(target_values(cons,rev,t))!=1: continue
    h=human(cons,rev,t)
    if 'T4' not in h['used']: continue
    rc=refute_core(cons,rev,t)
    if rc['core_min']<4 or rc['zbyva']>3: continue
    x=metrics(cons,rev,t)
    if not (x['necessary'] and x['local']>=3): continue
    out.append(dict(cons=cons,reveals=rev,target=t,answer=val[t],metrics=x,rc=rc))
    print('nalezeno',len(cons),x['nodes'],rc,'maxopen',x['maxopen'],flush=True)
print('pokusů',tries)
try: G=json.load(open('/home/claude/dedv2/gen_l9.json'))
except Exception: G=[]
G.extend(out); json.dump(G,open('/home/claude/dedv2/gen_l9.json','w'))
