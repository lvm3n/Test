import networkx as nx
def graph(it):
    G=nx.DiGraph()
    for n in {x for c in it['cons'] for x in c}:
        G.add_node(n, role='T' if n==it['target'] else ('R' if n in it['reveals'] else 'N'))
    for i,(p,l,r) in enumerate(it['cons']):
        f='F%d'%i; G.add_node(f, role='F')
        G.add_edge(f,p,kind='parent'); G.add_edge(f,l,kind='child'); G.add_edge(f,r,kind='child')
    return G
def iso(a,b):
    return nx.is_isomorphic(graph(a),graph(b),node_match=lambda x,y:x['role']==y['role'],edge_match=lambda x,y:x['kind']==y['kind'])

def iso_struct(a,b):
    """stejná síť bez ohledu na to, kde je cíl a odkryté tvary (to člověk na obrázku pozná jako „tutéž úlohu“)"""
    ga,gb=graph(a),graph(b)
    for g in (ga,gb):
        for n in g.nodes:
            if g.nodes[n]['role'] in ('T','R'): g.nodes[n]['role']='N'
    return nx.is_isomorphic(ga,gb,node_match=lambda x,y:x['role']==y['role'],edge_match=lambda x,y:x['kind']==y['kind'])
