import random, json, itertools, sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
SPEC={
 'L4':dict(n=(5,6),m=(3,4),r=(2,3),test=lambda x:'T2' in x['used'] and 'T3' not in x['used'] and 'T4' not in x['used'] and x['entry'] and x['local']>=2),
 'L5':dict(n=(5,6),m=(3,4),r=(2,3),test=lambda x:'T3' in x['used'] and 'T4' not in x['used'] and x['entry'] and x['maxopen']<=2 and x['local']>=2),
 'L6':dict(n=(5,6),m=(3,4),r=(1,2),test=lambda x:not x['entry'] and 'T3' not in x['used'] and 'T4' not in x['used'] and x['local']>=3),
 'L7':dict(n=(6,7),m=(4,5),r=(1,2),test=lambda x:not x['entry'] and 'T3' in x['used'] and 'T4' not in x['used'] and x['maxopen']<=3 and x['local']>=3),
 'L8':dict(n=(5,6),m=(4,5),r=(1,2),test=lambda x:'T4' in x['used'] and x['local']>=3 and x.get('spor') is not None and x['spor']<=2 and x.get('zbyva',0)>=2),
 'L9':dict(n=(6,7),m=(4,6),r=(1,2),test=lambda x:'T4' in x['used'] and x['local']>=3 and x.get('spor') is not None and x['spor']>=2 and x.get('zbyva',0)>=3),
}
def rand_net(rng,n,m):
    for _ in range(200):
        val={f'N{i+1}':rng.choice(S) for i in range(n)}
        cons=[]; tries=0
        while len(cons)<m and tries<200:
            tries+=1
            p=rng.choice(list(val)); a,b=R[val[p]]
            ca=[x for x in val if val[x]==a and x!=p]; cb=[x for x in val if val[x]==b and x!=p]
            if not ca or not cb: continue
            l=rng.choice(ca); r=rng.choice(cb)
            if l==r: continue
            c=[p,l,r] if rng.random()<.5 else [p,r,l]
            if any(c[0]==d[0] and {c[1],c[2]}=={d[1],d[2]} for d in cons): continue
            cons.append(c)
        if len(cons)<m: continue
        if set(nodes_of(cons))!=set(val): continue
        # souvislost
        adj={x:set() for x in val}
        for c in cons:
            for u in c:
                for v in c: adj[u].add(v)
        seen={'N1'}; st=['N1']
        while st:
            u=st.pop()
            for v in adj[u]-seen: seen.add(v); st.append(v)
        if seen==set(val): return cons,val
    return None,None
def gen(level, k, seed):
    rng=random.Random(seed); sp=SPEC[level]; out=[]; tries=0
    while len(out)<k and tries<120000:
        tries+=1
        n=rng.randint(*sp['n']); m=rng.randint(*sp['m'])
        cons,val=rand_net(rng,n,m)
        if not cons: continue
        nodes=list(val); rng.shuffle(nodes)
        r=rng.randint(*sp['r']); rev={x:val[x] for x in nodes[:r]}; t=nodes[r]
        tv=target_values(cons,rev,t)
        if len(tv)!=1: continue
        x=metrics(cons,rev,t)
        if not (x['unique_target'] and x['necessary'] and sp['test'](x)): continue
        sig=(len(cons),tuple(sorted(x['used'])),x['local'])
        out.append(dict(level=level,cons=cons,reveals=rev,target=t,answer=val[t],metrics=x))
    return out,tries
if __name__=='__main__':
    res={}
    for L,k,seed in [(a,int(b),int(c)) for a,b,c in (x.split(':') for x in sys.argv[1:])] or (('L4',3,1),('L5',4,2),('L6',4,3),('L7',4,4),('L8',4,5),('L9',4,6)):
        o,t=gen(L,k,seed); res[L]=o
        print(L,'nalezeno',len(o),'pokusů',t,[ (len(x['cons']),x['metrics']['nodes'],x['metrics']['local'],x['metrics']['maxopen'],x['metrics'].get('spor'),x['metrics']['used']) for x in o])
    old=json.load(open('/home/claude/dedv2/gen.json')) if len(sys.argv)>1 else {}
    old.update(res); json.dump(old,open('/home/claude/dedv2/gen.json','w'))
