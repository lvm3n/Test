import json,sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from layout import layout
G=json.load(open('gen_l9.json')); I=json.load(open('newbank.json'))
SH=lambda v,k: S[(S.index(v)+k)%5]
cand=sorted(G,key=lambda g:(g['rc']['zbyva'],))   # nejdřív ty s méně zbývajícími kandidáty
want=['C','E','A']; chosen=[]; used=set()
for w in want:
    for gi,g in enumerate(cand):
        if gi in used: continue
        k=(S.index(w)-S.index(g['answer']))%5
        chosen.append(dict(cons=g['cons'],reveals={n:SH(v,k) for n,v in g['reveals'].items()},target=g['target'],answer=w)); used.add(gi); break
CAP=120; new=[]; nid=54
for c in chosen:
    assert target_values(c['cons'],c['reveals'],c['target'])=={c['answer']}
    rc=refute_core(c['cons'],c['reveals'],c['target']); m=metrics(c['cons'],c['reveals'],c['target'])
    L=layout(c['cons'],seed=nid)
    new.append({'id':'D%02d'%nid,'tier':9,'target':c['target'],'reveals':c['reveals'],'answer':c['answer'],'cap':CAP,'cons':c['cons'],'nc':L['nc'],'j':L['j'],
                'metriky':{**{k:m[k] for k in ('used','entry','local','maxopen','nodes','rels','revealed')},'spor':m.get('spor'),'jadro_sporu':rc['core_min'],'zbyva':rc['zbyva']}})
    print('D%02d'%nid,c['answer'],rc,'layout',L['eval']); nid+=1
# L8: doplnit metriku jádra sporu, L9 nahradit
for x in I:
    if x['tier']==8:
        rc=refute_core(x['cons'],x['reveals'],x['target']); x['metriky']['jadro_sporu']=rc['core_min']; x['metriky']['zbyva']=rc['zbyva']
I=[x for x in I if x['tier']!=9]+new
json.dump(I,open('newbank.json','w'),ensure_ascii=False)
from collections import Counter
print(Counter(x['answer'] for x in I), len(I))
