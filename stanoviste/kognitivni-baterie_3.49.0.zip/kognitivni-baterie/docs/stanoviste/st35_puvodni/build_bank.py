"""Stanoviště – sestavení banky pro baterii (ST-35-v1.0).
Vstup: banka z pilotu (stanoviste_pilot35_zjednoduseny.html, 35 položek).
- P19, P20: oprava dvojznačnosti „přeškrtnuté vedle“ (cíl na stanovišti samotného objektu) – přesun dvou objektů.
- 3 cvičné položky (N1–N3) vygenerované a ověřené solverem.
- metriky přepočítány; kontrola jednoznačnosti při obou čteních „není vedle“ (≠1 i ≥2)."""
import json, random, itertools, copy, sys
SRC = sys.argv[1] if len(sys.argv) > 1 else 'bank.json'
B = json.load(open(SRC))
TOP = {
 'P3':  dict(edges=[[0,1],[1,2]], pos=[[14,50],[50,50],[86,50]]),
 'S4':  dict(edges=[[0,1],[1,2],[2,3],[3,0]], pos=[[24,28],[76,28],[76,72],[24,72]]),
 'HOUSE5': dict(edges=[[0,1],[1,2],[2,3],[3,0],[0,4],[1,4]], pos=[[24,48],[76,48],[76,82],[24,82],[50,12]]),
 'P5':  dict(edges=[[0,1],[1,2],[2,3],[3,4]], pos=[[10,50],[30,50],[50,50],[70,50],[90,50]]),
}
SHAPE = {'A':('blob','smooth'),'B':('leaf','smooth'),'C':('drop','smooth'),'D':('kite','sharp'),'E':('starlet','sharp'),'F':('burst','sharp')}
def dist(b):
    n=b['n']; D=[[99]*n for _ in range(n)]
    for i in range(n): D[i][i]=0
    for a,c in b['edges']: D[a][c]=D[c][a]=1
    for k in range(n):
        for i in range(n):
            for j in range(n): D[i][j]=min(D[i][j],D[i][k]+D[k][j])
    return D
def members(b,sel): return [t for t in b['fixed'] if all(b['attrs'][t][k]==v for k,v in sel.items())]
def sat(b,r,x,D,nadj='far',agg='exists'):
    k,a=r['kind'],r['args']; F=b['fixed']
    if k=='on_color': return b['colors'][x]==a[0]
    if k=='not_on_color': return b['colors'][x]!=a[0]
    if k=='same_token': return F[a[0]]==x
    if k=='not_same_token': return F[a[0]]!=x
    if k=='adj_token': return D[x][F[a[0]]]==1
    if k=='not_adj_token': return D[x][F[a[0]]]>=2 if nadj=='far' else D[x][F[a[0]]]!=1
    if k=='dist2_token': return D[x][F[a[0]]]==2
    M=[F[t] for t in members(b,a[0])]
    if k=='same_cat': return x in M
    if k=='not_same_cat': return x not in M
    ds=[D[x][m] for m in M]
    want={'adj_cat':1,'dist2_cat':2}[k]
    return (want in ds) if agg=='exists' else (min(ds)==want)
def sols(b,**kw):
    D=dist(b); return [x for x in range(b['n']) if all(sat(b,r,x,D,**kw) for r in b['rules'])]
def metrics(b):
    D=dist(b); N=range(b['n'])
    single=[sum(sat(b,r,x,D) for x in N) for r in b['rules']]
    omit=[len([x for x in N if all(sat(b,r2,x,D) for j,r2 in enumerate(b['rules']) if j!=i)]) for i in range(len(b['rules']))]
    return {'single_domains':single,'omit_one_domains':omit,'critical_clues':sum(o>1 for o in omit)}
def crit(b,nadj):
    D=dist(b); N=range(b['n'])
    return [len([x for x in N if all(sat(b,r2,x,D,nadj=nadj) for j,r2 in enumerate(b['rules']) if j!=i)])>1 for i in range(len(b['rules']))]
def check(b):
    assert len(set(b['fixed'].values()))==len(b['fixed'])==b['n'], ('obsazení',b['id'])
    s1=sols(b,nadj='far'); s2=sols(b,nadj='ne1')
    assert s1==[b['answer']]==s2, (b['id'],s1,s2,b['answer'])
    if b.get('oprava') or b['id'].startswith('N'): assert all(crit(b,'far')) and all(crit(b,'ne1')), ('nadbytečné pravidlo',b['id'])
    for r in b['rules']:
        if r['kind'].endswith('_cat'): assert 2<=len(members(b,r['args'][0]))<=4, (b['id'],r)

# --- opravy položek ---
def fix(id_, why, moves={}, colors={}):
    b=next(x for x in B if x['id']==id_)
    for t,n in moves.items(): b['fixed'][t]=n
    for n,c in colors.items(): b['colors'][n]=c
    b['oprava']=why
fix('P19','objekty D a B si vyměnily stanoviště (D 4→5, B 5→4): při čtení „není vedle“ jako ≠1 měla položka 2 řešení (uzly 3 a 5)', moves={'D':5,'B':4})
fix('P20','stanoviště 5 je zelené místo oranžového: při čtení „není vedle“ jako ≠1 měla položka 2 řešení (uzly 1 a 5)', colors={4:'green'})
# BOW6: v pilotu se dvě prostřední stanoviště (x 43 a 57, šířka 28) překrývala → roztažení (topologie beze změny)
BOW6=[[10,22],[10,78],[34,50],[66,50],[90,22],[90,78]]
for b in B:
    if b['topology']=='BOW6': b['pos']=[list(p) for p in BOW6]
for b in B:
    b['metrics']=metrics(b); check(b)
# stanoviště se nesmějí překrývat (šířka 28, výška 17)
for b in B:
    for i,j in itertools.combinations(range(b['n']),2):
        (x1,y1),(x2,y2)=b['pos'][i],b['pos'][j]
        assert abs(x1-x2)>=31 or abs(y1-y2)>=20, ('překryv',b['id'],i,j)

# --- cvičné položky ---
COLORS=['orange','blue','green','pink']
def rand_item(rng, top, n):
    T=TOP[top]; toks='ABCDEF'[:n]; nodes=list(range(n)); rng.shuffle(nodes)
    b={'id':'','level':-5,'n':n,'topology':top,'edges':T['edges'],'pos':T['pos'],
       'colors':[rng.choice(COLORS) for _ in range(n)],'fixed':{t:nodes[i] for i,t in enumerate(toks)},
       'attrs':{t:{'shape':SHAPE[t][0],'edge':SHAPE[t][1],'size':rng.choice(['small','large']),'pattern':rng.choice(['solid','striped'])} for t in toks}}
    return b
def gen(seed, top, n, kinds, extra=lambda b:True, tries=200000):
    rng=random.Random(seed)
    for _ in range(tries):
        b=rand_item(rng,top,n); toks=list(b['fixed'])
        rules=[]
        for k in kinds:
            if 'color' in k: rules.append({'kind':k,'args':[rng.choice(COLORS)]})
            elif 'token' in k: rules.append({'kind':k,'args':[rng.choice(toks)]})
            else:
                attr=rng.choice(['size','pattern']); rules.append({'kind':k,'args':[{attr:rng.choice({'size':['small','large'],'pattern':['solid','striped']}[attr])}]})
        b['rules']=rules
        s=sols(b,nadj='far')
        if len(s)!=1 or sols(b,nadj='ne1')!=s: continue
        b['answer']=s[0]; m=metrics(b)
        if any(o<2 for o in m['omit_one_domains']) and len(rules)>1: continue
        if any(r['kind'].endswith('_cat') and not 2<=len(members(b,r['args'][0]))<=3 for r in rules): continue
        if not extra(b): continue
        b['metrics']=m; return b
    raise SystemExit('nenalezeno '+str(kinds))
# N1: jen barva (jediné modré stanoviště)
n1=gen(11,'P3',3,['on_color'],lambda b:len(set(b['colors']))==3)
# N2: vedle + přeškrtnutá barva
n2=gen(12,'S4',4,['adj_token','not_on_color'],lambda b:len(set(b['colors']))>=3)
# N3: skupina „dva kroky“, kde stačí jeden člen skupiny (při čtení „nejbližší člen“ by řešení nebylo) + přeškrtnuté „spolu“
def n3x(b):
    return sols(b,agg='min')!=[b['answer']]
n3=gen(13,'HOUSE5',5,['dist2_cat','not_same_token'],n3x)
for i,b in enumerate([n1,n2,n3]): b['id']='N%d'%(i+1)
for b in [n1,n2,n3]: check(b)
out={'verze':'ST-35-v1.0','practice':[n1,n2,n3],'items':B}
json.dump(out,open('bank_st.json','w'),ensure_ascii=False,separators=(',',':'))
for b in [n1,n2,n3]+[x for x in B if x['id'] in ('P19','P20')]:
    print(b['id'],b['topology'],b['colors'],b['fixed'],{t:(a['size'],a['pattern']) for t,a in b['attrs'].items()},b['rules'],'ans',b['answer'],b['metrics'])
print('OK', len(B), 'položek ověřeno')
