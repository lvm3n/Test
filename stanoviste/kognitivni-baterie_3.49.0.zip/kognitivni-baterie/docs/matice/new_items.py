import json, copy
def rot(p): return [p[3],p[0],p[1],p[2]]          # čtvrt otáčky po směru: new[i+1]=old[i]
AND=lambda a,b:[x and y for x,y in zip(a,b)]; OR=lambda a,b:[x or y for x,y in zip(a,b)]; XOR=lambda a,b:[x!=y for x,y in zip(a,b)]
items=[]
def put(it, ans_obj, distractors, models, pos):
    opts=distractors[:]; opts.insert(pos, ans_obj); mods=models[:]; mods.insert(pos,'correct')
    it['options']=opts; it['models']=mods; it['answer']=pos; items.append(it)
# 1) Řada: zrychlující otáčení (pravidlo druhého řádu) – kroky +1,+2,+3,+4,+5 (×45°)
d=[0]; 
for k in range(1,6): d.append((d[-1]+k)%8)
cells=[{'kind':'arrow','dir':x,'mir':0,'color':1} for x in d[:5]]+[None]
ans={'kind':'arrow','dir':d[5],'mir':0,'color':1}
put({'p':51,'format':'rada','rows':1,'cols':6,'carrier':'pointer','cells':cells,'missing':5,'family':'s_second_order','level':11,
     'rule':'Šipka se otáčí po směru hodinových ručiček a každý krok je o 45° větší než předchozí (45°, 90°, 135°, 180°, …).','b':4.1},
    ans,[{'kind':'arrow','dir':(d[4]+4)%8,'mir':0,'color':1},{'kind':'arrow','dir':(d[4]+6)%8,'mir':0,'color':1},{'kind':'arrow','dir':(d[4]-5)%8,'mir':0,'color':1},{'kind':'arrow','dir':(d[4]+1)%8,'mir':0,'color':1}],
    ['constant_step','overshoot','reverse_direction','first_step'],2)
# 2) 3×3 květy: třetí = průnik (co je v obou)
rows=[([True,True,False,True],[True,False,True,True]),([False,True,True,False],[True,True,True,False]),([True,True,True,False],[True,True,False,True])]
cells=[]
for a,b in rows: cells+= [a,b,AND(a,b)]
cells=[{'p':c} for c in cells]; ans=cells[8]; cells[8]=None
a,b=rows[2]
put({'p':52,'format':'matice3','rows':3,'cols':3,'carrier':'petals','cells':cells,'missing':8,'family':'m33_and','level':11,
     'rule':'Ve třetím sloupci zůstanou jen lístky, které jsou v prvním i ve druhém květu zároveň.','b':4.15},
    ans,[{'p':OR(a,b)},{'p':XOR(a,b)},{'p':AND(rot(a),b)},{'p':[x and not y for x,y in zip(a,b)]}],['OR','XOR','rotated','difference'],0)
# 3) 3×3 květy: složení – nejdřív sjednotit, pak otočit o čtvrt kruhu
rows=[([True,False,False,False],[False,False,True,False]),([False,True,False,False],[False,True,False,True]),([True,False,False,True],[False,False,True,False])]
cells=[]
for a,b in rows: cells+=[a,b,rot(OR(a,b))]
cells=[{'p':c} for c in cells]; ans=cells[8]; cells[8]=None
a,b=rows[2]
put({'p':53,'format':'matice3','rows':3,'cols':3,'carrier':'petals','cells':cells,'missing':8,'family':'m33_or_rot','level':11,
     'rule':'Spoj lístky prvního a druhého květu a výsledek otoč o čtvrt kruhu po směru hodinových ručiček.','b':4.2},
    ans,*(lambda C:([c[0] for c in C][:4],[c[1] for c in C][:4]))([c for c in [({'p':OR(a,b)},'no_rotation'),({'p':rot(rot(rot(OR(a,b))))},'reverse_direction'),({'p':OR(rot(a),b)},'partial_rot'),({'p':rot(rot(OR(a,b)))},'half_turn'),({'p':rot(a)},'first_only'),({'p':rot(b)},'second_only')] if c[0]['p']!=rot(OR(a,b))][:0] or (lambda L:[L[i] for i in range(len(L)) if L[i][0]['p'] not in [x[0]['p'] for x in L[:i]] and L[i][0]['p']!=rot(OR(a,b))])([({'p':OR(a,b)},'no_rotation'),({'p':rot(rot(rot(OR(a,b))))},'reverse_direction'),({'p':OR(rot(a),b)},'partial_rot'),({'p':rot(rot(OR(a,b)))},'half_turn'),({'p':rot(a)},'first_only'),({'p':rot(b)},'second_only')])),3)
# 4) 3×3 hodiny: rozdíl (první minus druhá)
rows=[(6,2),(7,1),(7,2)]
cells=[]
for a,b in rows: cells+=[{'h':a},{'h':b},{'h':(a-b)%8}]
ans=cells[8]; cells[8]=None
put({'p':54,'format':'matice3','rows':3,'cols':3,'carrier':'clock','cells':cells,'missing':8,'family':'m33_rotdiff','level':11,
     'rule':'Ručička ve třetích hodinách = otočení z prvních minus otočení z druhých.','b':4.25},
    ans,[{'h':(7+2)%8},{'h':(2-7)%8},{'h':7},{'h':6}],['sum','reverse_difference','copy_first','nearest'],1)
# 5) 3×3 dvojice: podmíněná transformace – stejná barva → výměna míst + otočení, různá barva → jen otočení
def sw(c): return {'L':copy.deepcopy(c['R']),'R':copy.deepcopy(c['L'])}
def rt(c,k=2):
    c=copy.deepcopy(c)
    for s in ('L','R'):
        if 'dir' in c[s]: c[s]['dir']=(c[s]['dir']+k)%8
    return c
def same(c): return c['L']['color']==c['R']['color']
def step(c): return rt(sw(c)) if same(c) else rt(c)
r1={'L':{'t':'arrow','dir':0,'color':1},'R':{'t':'square','color':1,'size':2}}
r2={'L':{'t':'pac','dir':2,'color':0},'R':{'t':'circle','color':2,'size':2}}
r3={'L':{'t':'L','dir':6,'color':3},'R':{'t':'diamond','color':3,'size':2}}
cells=[]
for r in (r1,r2,r3): a=r; b=step(a); c=step(b); cells+=[a,b,c]
ans=cells[8]; cells[8]=None; b3=cells[7]
put({'p':55,'format':'matice3','rows':3,'cols':3,'carrier':'duo','cells':cells,'missing':8,'family':'m33_conditional','level':11,
     'rule':'Když mají oba objekty stejnou barvu, vymění si místa a směrový se otočí o 90°; když mají různou barvu, směrový se jen otočí.','b':4.3},
    ans,[rt(b3),sw(b3),rt(sw(b3),6),rt(sw(b3),4)],['wrong_condition','swap_only','reverse_direction','overshoot'],4)
# 6) 3×3 vnořené tvary: skládání z různých zdrojů – vnějšek třetího = vnitřek prvního, vnitřek třetího = vnějšek druhého
def comp(a,b): return {'outer':a['inner'],'oc':a['ic'],'inner':b['outer'],'ic':b['oc']}
R=[({'outer':'hexagon','oc':1,'inner':'circle','ic':2},{'outer':'square','oc':3,'inner':'diamond','ic':0}),
   ({'outer':'circle','oc':0,'inner':'square','ic':1},{'outer':'diamond','oc':2,'inner':'hexagon','ic':3}),
   ({'outer':'square','oc':2,'inner':'hexagon','ic':0},{'outer':'circle','oc':1,'inner':'square','ic':3})]
cells=[]
for a,b in R: cells+=[a,b,comp(a,b)]
ans=cells[8]; cells[8]=None; a,b=R[2]
put({'p':56,'format':'matice3','rows':3,'cols':3,'carrier':'nested','cells':cells,'missing':8,'family':'m33_compose','level':11,
     'rule':'Vnější tvar třetího pole je vnitřní tvar prvního (i s barvou), vnitřní tvar třetího je vnější tvar druhého (i s barvou).','b':4.35},
    ans,[comp(b,a),{'outer':b['outer'],'oc':b['oc'],'inner':a['inner'],'ic':a['ic']},{'outer':a['inner'],'oc':b['oc'],'inner':b['outer'],'ic':a['ic']},{'outer':a['inner'],'oc':a['ic'],'inner':b['inner'],'ic':b['ic']}],
    ['reversed_sources','swapped_roles','colors_swapped','wrong_part'],2)
json.dump(items,open('/home/claude/mx/new_items.json','w'),ensure_ascii=False)
for it in items: print(it['p'],it['family'],'odpověď',it['answer'])
