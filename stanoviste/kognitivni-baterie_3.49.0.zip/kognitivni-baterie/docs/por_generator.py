import json, random, itertools
from collections import Counter
B=json.load(open('por.json'))
s=open('/home/claude/w/kognitivni-baterie/assets/app.html',encoding='utf8').read()
import re
i=s.index('const POR_ICONS = {'); seg=s[i:i+120000]
ICONS=[k for k in re.findall(r'"?([a-z_]+)"?\s*:\s*[\'"`]<',seg) if k!='icon']
ICONS=list(dict.fromkeys(ICONS)); print(len(ICONS))
GRID=lambda K: 4 if K<=2 else 8 if K<=5 else 12
cand={int(k):v for k,v in B['bank'].items()}
rng=random.Random(42)
def tcounts(sel):
    c=Counter()
    for it in sel: c.update(it['targets'])
    return c
def cost(A,Bf):
    ca,cb=tcounts(A),tcounts(Bf)
    ma=sum(ca.values())/len(ICONS)
    va=sum((ca[x]-ma)**2 for x in ICONS); vb=sum((cb[x]-ma)**2 for x in ICONS)
    dab=sum((ca[x]-cb[x])**2 for x in ICONS)
    mx=max(max(ca.values()),max(cb.values()))
    return va+vb+0.5*dab+3*mx
# počáteční výběr: 4 různé kandidáty na K
choice={K:rng.sample(range(len(cand[K])),4) for K in cand}
def build(ch):
    A=[cand[K][ch[K][j]] for K in sorted(cand) for j in (0,1)]
    Bf=[cand[K][ch[K][j]] for K in sorted(cand) for j in (2,3)]
    return A,Bf
best=cost(*build(choice)); 
for step in range(60000):
    K=rng.choice(list(cand)); ch=dict((k,v[:]) for k,v in choice.items())
    if rng.random()<0.5:
        j=rng.randrange(4); new=rng.randrange(len(cand[K]))
        if new in ch[K]: continue
        ch[K][j]=new
    else:
        a,b=rng.sample(range(4),2); ch[K][a],ch[K][b]=ch[K][b],ch[K][a]
    c=cost(*build(ch))
    if c<=best: best=c; choice=ch
A,Bf=build(choice)
print('cost',round(best,1)); print('A targety',sorted(tcounts(A).values())); print('B targety',sorted(tcounts(Bf).values()))
# rušivé obrázky: vyvážené, bez cílů předchozí položky ve formě
def gen_forms(form_items, form, seed):
    r=random.Random(seed); fc=Counter(); tc=tcounts(form_items); out=[]; prev=[]
    for n,it in enumerate(form_items):
        K=it['K']; need=GRID(K)-K
        pool=[x for x in ICONS if x not in it['targets'] and x not in prev]
        pool.sort(key=lambda x:(fc[x]+0.5*tc[x], r.random()))
        L=pool[:need]; fc.update(L)
        opts=it['targets']+L
        while True:
            lay=opts[:]; r.shuffle(lay)
            # nekopírovat pořadí cílů jako souvislou řadu zleva doprava
            idx=[lay.index(t) for t in it['targets']]
            if K==1 or not all(idx[j+1]==idx[j]+1 for j in range(K-1)): break
        j=sum(1 for x in out if x['K']==K)+1
        out.append({'id':it['id'],'lab':f'K{K}-{form}{j}','form':form,'K':K,'targets':it['targets'],'lures':L,'layout':lay,'n_lures':len(L)})
        prev=it['targets']
    return out, fc
FA,fa=gen_forms(A,'A',1); FB,fb=gen_forms(Bf,'B',2)
print('A rušivé min/max',min(fa[x] for x in ICONS),max(fa.values()),'| B',min(fb[x] for x in ICONS),max(fb.values()))
print('A cíle min/max',min(tcounts(A)[x] for x in ICONS),max(tcounts(A).values()),'| B',min(tcounts(Bf)[x] for x in ICONS),max(tcounts(Bf).values()))
assert not set(x['id'] for x in FA)&set(x['id'] for x in FB)
for x in FA+FB: assert len(set(x['layout']))==GRID(x['K']) and not set(x['targets'])&set(x['lures'])
B['forms']={'A':FA,'B':FB}
json.dump(B,open('por_new.json','w'),ensure_ascii=False)
