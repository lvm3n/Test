# Audit D26–D40 — přísná verze
Nové položky byly vybírány až po propagaci **množin kandidátů** (GAC), nikoli jen po jednoduchém pravidle „dva známé uzly → dopočti třetí“.
| Položka | Tier | Správně | Vztahů | Plně vyplněné | Redundantní | Cíl jen z vlastních vztahů | Nonincident | GAC fixpoint | Hypotéza |
|---|---:|:---:|---:|---:|---:|---|---:|---|---|
| D26 | 6 | B | 4 | 0 | 0 | NE (A/B/C/D/E) | 3 | A/B/C/D/E→A/B/C/D/E→B/C/E→B | — |
| D27 | 6 | E | 4 | 0 | 0 | NE (A/E) | 3 | A/B/C/D/E→A/E→A/E→A/E→E | — |
| D28 | 6 | A | 4 | 0 | 0 | NE (A/B/C/D/E) | 3 | A/B/C/D/E→A/B/C/D/E→A/B/C/D/E→A/D/E→A | — |
| D29 | 6 | D | 4 | 0 | 0 | NE (A/B/C/D/E) | 3 | A/B/C/D/E→A/B/C/D/E→C/D→D | — |
| D30 | 6 | C | 4 | 0 | 0 | NE (A/B/C/D/E) | 3 | A/B/C/D/E→A/B/C/D/E→A/C→C→C | — |
| D31 | 7 | C | 5 | 0 | 0 | NE (A/B/C/D/E) | 4 | A/B/C/D/E→A/B/C/D/E→A/B/C/D/E→B/C→C | — |
| D32 | 7 | D | 5 | 0 | 0 | NE (A/B/C/D/E) | 4 | A/B/C/D/E→A/B/C/D/E→C/D→C/D→C/D→D | — |
| D33 | 7 | E | 5 | 0 | 0 | NE (A/B/C/D/E) | 4 | A/B/C/D/E→A/B/C/D/E→D/E→D/E→D/E→E | — |
| D34 | 7 | B | 5 | 0 | 0 | NE (B/D) | 4 | A/B/C/D/E→B/D→B/D→B/D→B/D→B | — |
| D35 | 7 | A | 5 | 0 | 0 | NE (A/B/C/D/E) | 4 | A/B/C/D/E→A/B/C/D/E→A/B/C/D/E→A/D/E→A | — |
| D36 | 8 | E | 6 | 0 | 0 | NE (A/B/C/D/E) | 5 | A/B/C/D/E→A/B/C/D/E→A/C/E | A→spor v kole 3; C→spor v kole 4 |
| D37 | 8 | A | 6 | 0 | 0 | NE (A/B/C/D/E) | 5 | A/B/C/D/E→A/B/C/D/E→A/B/C/D/E→A/B/D/E→A/B/D/E→A/D/E | D→spor v kole 2; E→spor v kole 3 |
| D38 | 8 | B | 6 | 0 | 0 | NE (A/B) | 4 | A/B/C/D/E→A/B→A/B→A/B | A→spor v kole 3 |
| D39 | 8 | C | 6 | 0 | 0 | NE (A/B/C/D/E) | 4 | A/B/C/D/E→A/B/C/D/E→A/B/C→B/C→B/C | B→spor v kole 3 |
| D40 | 8 | D | 6 | 0 | 0 | NE (A/B/C/D/E) | 5 | A/B/C/D/E→A/B/C/D/E→B/C/D/E→C/D→C/D | C→spor v kole 3 |

## Co je teď garantováno
- Žádný vztah D26–D40 není celý vyplněný.
- Odebrání **kteréhokoli** vztahu způsobí, že cílový uzel přestane být jednoznačný; minimal proof subgraph tedy používá celý zobrazený graf.
- Cíl není jednoznačný jen ze vztahů, ve kterých sám figuruje.
- Tier 6 potřebuje nejméně 2 vztahy mimo cíl; tier 7–8 nejméně 3.
- Tier 8 nelze dokončit samotnou GAC/set-propagací: po fixpointu zůstávají 2–3 kandidáti, ale globální řešení je jediné. Nesprávná hypotéza vede ke sporu až po nejméně dvou dalších kolech propagace.

## Co stále není empiricky prokázáno
- Že tier 8 skutečně diferencuje extrémně nadané dospělé.
- Že vyšší úrovně nesaturují Gwm příliš silně.
- Že cyklickou strukturu pěti pravidel lidé neodhalí a nezačnou používat jako zkratku. V pilotu proto logovat práci s klíčem a RT trend napříč položkami.
