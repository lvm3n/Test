# DEDUKCE v0.2-strict — kompletní specifikace

## Účel
Digitální Gf subtest vedle Matic a Figure Weights. Jde o úlohu inspirovanou principem WJ Analysis–Synthesis: respondent pracuje s malým, explicitně naučeným pravidlovým systémem a dedukuje nutný závěr. Nekopírují se konkrétní WJ položky, grafika ani instrukce.

## Konstrukt
Primárně **Gf – deductive / sequential reasoning**. Minimalizovat Gc, Gs, visual search a zbytečný Gwm load.

## Pravidla
Pět stabilních reverzibilních pravidel:
- A ⇄ B + C
- B ⇄ C + D
- C ⇄ D + E
- D ⇄ E + A
- E ⇄ A + B

A–E jsou interní ID; respondent vidí jen pět odlišných barevných tvarů. Spodní dvojice je bez pořadí.

Klíč je vždy viditelný jako **5 stabilních karet**, nikdy jako 5×5 tabulka.

## Banka
Zdroj pravdy: `items_40_strict.json`.
D01–D25 zachovávají lehkou až středně těžkou gradaci. D26–D40 byly kompletně přegenerovány.

### D26–D30 / Tier 6
- 4 vztahy.
- 0 plně vyplněných vztahů.
- 0 redundantních vztahů.
- Cíl není určen jen vztahy, ve kterých figuruje.
- Alespoň 2 vztahy mimo cíl jsou nutné.
- Set/GAC propagace cíl určí až nejdříve ve 3. synchronním kole.

### D31–D35 / Tier 7
- 5 vztahů.
- Všech 5 je nutných.
- Cíl není lokálně určen.
- Alespoň 3 vztahy mimo cíl jsou nutné.
- GAC cíl určí až nejdříve ve 4. kole.

### D36–D40 / Tier 8
- 6 vztahů; všech 6 je nutných.
- Po úplném GAC fixpointu zůstávají u cíle **2–3 kandidáti**.
- Přesto existuje přesně **jedno globální řešení**.
- Je tedy nutná alespoň jedna hypotéza / proof by contradiction.
- Každá chybná hypotéza, která přežije GAC fixpoint, vede ke sporu až po nejméně 2 dalších kolech propagace.
- Cíl nejde určit jen jeho vlastními vztahy.

## Důležitý audit
Před každým buildem spusť:
`python validate_items_strict.py`

Build nesmí pokračovat, pokud validátor nevrátí OK.

## Tutorial
4 kroky s feedbackem:
1. Syntéza: známá spodní dvojice → horní symbol.
2. Analýza: známý horní + jeden spodní → druhý spodní.
3. Dva navázané vztahy.
4. Explicitní demonstrace nejednoznačnosti: jedna stopa někdy nechá dva kandidáty; rozhodnou až další vztahy.

Ve skórované části žádný correctness feedback.

## UI
- Jednoduché položky lze kreslit klasickým Y vztahem.
- U tierů 6–8 používej **factor-network** z JSON: jeden fyzický symbolový uzel se nikdy neduplikuje.
- Constraint/factor uzel je malý neutrální spojovací bod; spojení k „jednomu“ uzlu je vizuálně odlišeno od dvou ramen dvojice, ale bez textu A–E/N1–N8.
- Neznámý target = `?`.
- Ostatní skryté uzly = prázdné sloty.
- Od tieru 4 dovol neutrální pracovní poznámku do skrytých netarget uzlů (tentativní symbol, kdykoli změnit/smazat, bez feedbacku).
- 5 odpovědí zůstává v pevném pořadí; správné odpovědi jsou v celé bance přesně 8× každá.

## Čas
Bounded-power, nikoli speed test. Správně v limitu = 1 bod bez time bonusu.
Pilotní caps: 20 / 30 / 35 / 45 / 60 / 75 / 90 / 120 s podle tieru.
V research mode lze timeout úplně vypnout. Countdown nezobrazovat.

## Ukončení
- **Plný psychometrický pilot:** možnost `stop=0`, tedy všech 40 položek.
- **Veřejná / předprodukční verze:** používej existující globální `S.stop`; default baterie je 5 po sobě jdoucích chyb/timeoutů.
- Stop rule je předběžná a po kalibraci se má nahradit routingem/CAT.

## Logování v existující baterii
Nevytvářej samostatný exportní systém. Modul musí používat stejné ukládání jako ostatní testy:
- `S.rows`
- `S.scores`
- `save()`
- běžnou KB server synchronizaci.

Na položku loguj minimálně:
`id, tier, answer, response, correct, rt_ms, time_limit_ms, target, n_constraints, workspace_edits, workspace_state, input_mode`.

Pracovní změny lze logovat jako samostatné řádky `typ=workspace`.

## Cyklická pravidla
Pět pravidel má rotační/cyklickou strukturu. Zatím ji **neměň**: je kompaktní a naučitelná. V pilotu ale sleduj:
- pokles RT na lookup klíče,
- zda se u velmi schopných lidí objeví prudké zrychlení,
- zda přestanou klíč vizuálně používat.
Pokud ano, další verze má použít méně pravidelný pětisymbolový systém.

## Interpretace tieru 8
Ve specifikaci ani UI jej neoznačuj jako „pro extrémně nadané“ jako empirický fakt. Je to **experimentální high-ceiling blok**. Jeho skutečná lokalizace na latentní škále musí vzniknout pilotem.

## Acceptance criteria
1. `validate_items_strict.py` = OK.
2. 40 položek, 8× každá odpověď.
3. D26–D40: 0 plně vyplněných a 0 redundantních vztahů.
4. D26–D40: incident-only cíl není jednoznačný.
5. Tier 8: GAC cíl nevyřeší; full solver ano.
6. Žádná interní ID nejsou respondentovi zobrazena.
7. Žádné time bonusy.
8. Modul ukládá data přes stávající systém baterie.
