from itertools import product
from collections import Counter
import json,sys
from pathlib import Path

P=Path(__file__).resolve().parent
d=json.loads((P/"items_40_strict.json").read_text(encoding="utf-8"))
S=list(d["rules"])
R=d["rules"]
REL=[]
for p in S:
    a,b=R[p]; REL += [(p,a,b),(p,b,a)]

def valid(p,l,r): return (p,l,r) in REL
def nodes(cons,extra=()):
    z=set(extra)
    for e in cons:z.update(e)
    return sorted(z)

def gac(cons,revs,extra=()):
    ns=nodes(cons,extra); dom={n:set(S) for n in ns}
    for n,v in revs.items():dom[n]={v}
    trace=[{n:set(v) for n,v in dom.items()}]
    while True:
        base={n:set(v) for n,v in dom.items()}; new={n:set(v) for n,v in dom.items()}
        for p,l,r in cons:
            vv=(p,l,r); ds=(base[p],base[l],base[r])
            ok=[t for t in REL if all(t[i] in ds[i] for i in range(3))]
            if not ok:return trace+[new],False
            for i,n in enumerate(vv):
                new[n]&={t[i] for t in ok}
                if not new[n]:return trace+[new],False
        if all(new[n]==dom[n] for n in ns):return trace,True
        dom=new;trace.append({n:set(v) for n,v in dom.items()})

def solve(cons,revs,extra=(),limit=100):
    ns=nodes(cons,extra);tr,ok=gac(cons,revs,extra)
    if not ok:return []
    sols=[]
    def rec(dom):
        if len(sols)>=limit:return
        if all(len(v)==1 for v in dom.values()):
            a={n:next(iter(v)) for n,v in dom.items()}
            if all(valid(a[p],a[l],a[r]) for p,l,r in cons):sols.append(a)
            return
        n=min((n for n in ns if len(dom[n])>1),key=lambda x:len(dom[x]))
        for v in sorted(dom[n]):
            rev={k:next(iter(x)) for k,x in dom.items() if len(x)==1};rev[n]=v
            tt,ok2=gac(cons,rev,ns)
            if not ok2:continue
            nd=tt[-1]
            for k in ns:nd[k]&=dom[k]
            if all(nd[k] for k in ns):rec(nd)
    rec(tr[-1]);return sols

def tvals(cons,revs,target):
    return sorted({x[target] for x in solve(cons,revs,(target,),100)})

bad=[]
for it in d["items"]:
    cons=[tuple(x) for x in it["constraints"]];rev=it["reveals"];target=it["target"];tier=it["tier"]
    sols=solve(cons,rev,(target,),100)
    if len(sols)!=1 or sorted({x[target] for x in sols}) != [it["answer"]]:
        bad.append((it["id"],"global solution"));continue
    if tier>=6:
        if any(all(n in rev for n in e) for e in cons):bad.append((it["id"],"fully filled"))
        for i in range(len(cons)):
            if tvals(cons[:i]+cons[i+1:],rev,target)==[it["answer"]]:
                bad.append((it["id"],"redundant constraint",i+1))
        inc=[e for e in cons if target in e]
        if len(tvals(inc,rev,target))<=1:bad.append((it["id"],"incident shortcut"))
        noninc=sum(target not in e for e in cons)
        if noninc < {6:2,7:3,8:3}[tier]:bad.append((it["id"],"too few nonincident"))
        tr,ok=gac(cons,rev,(target,))
        resolve=next((i for i,x in enumerate(tr) if len(x[target])==1),None)
        if tier==6 and (resolve is None or resolve<3):bad.append((it["id"],"tier6 GAC depth"))
        if tier==7 and (resolve is None or resolve<4):bad.append((it["id"],"tier7 GAC depth"))
        if tier==8:
            final=tr[-1][target]
            if resolve is not None or len(final) not in (2,3):bad.append((it["id"],"tier8 solved by GAC"))
            for cand in final:
                if cand==it["answer"]:continue
                tt,ok2=gac(cons,{**rev,target:cand},(target,))
                if ok2 or len(tt)-1<2:bad.append((it["id"],"weak wrong hypothesis",cand))

if Counter(x["answer"] for x in d["items"]) != Counter({s:8 for s in S}):
    bad.append(("BANK","answer balance"))
if bad:
    print("FAIL"); [print(x) for x in bad]; sys.exit(1)
print("OK: 40 items.")
print("D26–D30: 4/4 constraints necessary, target not incident-only, GAC depth >=3.")
print("D31–D35: 5/5 constraints necessary, target not incident-only, GAC depth >=4.")
print("D36–D40: 6/6 constraints necessary, GAC leaves 2–3 target candidates; wrong hypotheses contradict only after >=2 propagation rounds.")
