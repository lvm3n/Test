COGNITIVE BATTERY (EN) – anglická verze, plugin 1.0.0
=====================================================

Samostatný plugin vedle české „Kognitivní baterie“. Nic v české verzi nemění ani nemaže.
- Vlastní tabulky wp_kben_* (české wp_kb_* zůstávají nedotčené), vlastní REST adresa (kben/v1), vlastní
  nastavení a položka v menu „Cognitive Battery EN“. Prohlížeč účastníka ukládá data pod jinými klíči.
- Testy: Matrices (Matice v10-50c), Weights (Váhy v2-39-hard60-ui3), Shape Keys (Tvarové klíče DED-24-v1.2).
  Banky i pravidla jsou totožné s českou verzí; přeložené je celé rozhraní, instrukce, ukázky a zpětná vazba,
  předčítání je anglickým hlasem.

INSTALACE
1. Pluginy → Přidat nový → Nahrát plugin → cognitive-battery-en.zip → Aktivovat.
2. Vytvořte novou stránku (např. /reasoning-study) a vložte shortcode:  [cognitive_battery_en]
   (vaše administrátorská verze po přihlášení: [cognitive_battery_en_admin])
3. V menu Cognitive Battery EN klikněte jednou na „Načíst česká data pro srovnání“. Přenesou se dosavadní výsledky
   Matic, Vah a Tvarových klíčů z české verze (jen čtení), aby grafy a percentily měly hned srovnávací data.
   Tlačítko lze použít kdykoli znovu – načte jen nové výsledky.

DATA
- Importovaní účastníci mají mode = cz (v exportech je lze odfiltrovat nebo naopak porovnat jazyky).
- Anglicky mluvící účastníci mají mode = public (veřejná stránka) nebo admin.
- Export po položkách, číselník a korelace fungují stejně jako v české verzi.

1.0.1 – Import přeskakuje duplicitní výsledky z české databáze (stejný test a verze ve stejném sezení). Již
importované duplicity odstraníte tlačítkem „Odstranit duplicity“ v přehledu (objeví se, když nějaké jsou).

1.1.0 – Matrices rozšířeny o 6 nejtěžších položek (verze v10-56, stejně jako v české verzi 3.40.0).

1.2.0 – Přidány Paper Folding (Skládání papíru) a Mental Rotation (Mentální rotace), stejné banky a verze jako
v české verzi. Import českých dat nově přenáší i tyto dva testy (spusťte tlačítko importu znovu).

1.3.0 – Kdo už dokončil Matrices v předchozí verzi (50 položek, až do konce), může doplnit jen 6 nových úloh;
výsledek = dřívější skór + nové správné (příznak rozsireni = 1). Stejně jako česká verze 3.41.0.

1.4.0 – Nový test Rule Finder (Hledání pravidla, HP-36-v1.0), anglicky. Import českých dat zahrnuje i tento test.

1.4.1 – Rule Finder na mobilu kompaktnější (stejně jako česká 3.42.1).

1.4.2 – Opravená dvojznačná cvičná úloha 1 v Rule Finder (stejně jako česká 3.42.2).

1.5.0 – Shape Keys: nové časové limity po úrovních (DED-24-v1.3) a tlačítko „Přepočítat Tvarové klíče podle
nových limitů“ pro data sebraná dřív (stejně jako česká 3.43.0). Přepočet se týká jen výsledků s uloženými
odpověďmi; importované české výsledky (mode cz) přepočítejte v české administraci.

1.6.0 – Časové limity podle pilotu u Matrices, Weights, Paper Folding, Mental Rotation a Rule Finder (stejně jako česká 3.44.0).

1.6.1 – Nejkratší limit u Paper Folding a Weights 45 s (stejně jako česká 3.44.1).

1.7.0 – Přidány testy pracovní paměti (Running Digits, Backward Digits, Picture Sequence) s anglickými nahrávkami
číslic 1–9 a rychlosti zpracování (Symbol Coding, Matching Rows). Shape Keys mají nové úrovně 8–9 (DED-24-v2.0).
Import českých dat zahrnuje i tyto testy.

1.7.1 – Obrazovka při přehrávání čísel: „Listen.“ místo nepřeloženého „Poslouchej.“

1.7.2 – Dopřeloženo: popisek „You“ v grafu srovnání (dřív „Vy“), tlačítka „Try again“, „Got it“, „Try it“, „Start“,
popisky klávesnice a texty srovnání.

1.8.0 – Přidány školní testy: Reading Efficiency (134 anglických vět sestavených podle obrázků, 2 min, skór správně −
chybně), Arithmetic (anglický zápis čísel, klávesa „.“) a Word Problems (65 přeložených úloh, peníze v dolarech se stejnými
čísly, metrické jednotky). U Arithmetic a Word Problems tvrdý limit 90 s na položku. Tyto tři testy mají vlastní anglické
verze (SRCE-EN-v1, banka68-EN-v1, zivot65-EN-v1) a s českými daty se nespojují – jiný jazyk/měna/limit.

1.8.1 – Reading Efficiency: promíchané pořadí vět jako v české 3.46.0 (SRCE-EN-v2) – všechny typy dějů hned od začátku.

1.8.2 – Bez časového limitu na zadávání odpovědi u Running Digits, Backward Digits a Picture Sequence.

1.8.3 – Reading Efficiency: SRCE-EN-v1 a v2 se ve srovnání spojují (liší se jen pořadím vět).

1.9.0 – Nový test Stations (Stanoviště, ST-35-v1.0), anglicky, stejná banka a průběh jako česká 3.48.0. Import českých
dat zahrnuje i tento test. V administraci je test (i Rule Finder) ve skupině Gf.

1.10.0 – Stations: nový návrh ST2-36-v1.0 (stejně jako česká 3.49.0), nahrazuje ST-35.

1.11.0 – Shape Keys DED-24-v2.1 (utažené limity, nikde pod 30 s) a Stations s limity 45/60 s – stejně jako česká 3.50.0.

1.12.0 – Automatický přepočet Shape Keys DED-24-v2.x podle současných limitů (stejně jako česká 3.51.0). Import českých
dat nově aktualizuje i už importované výsledky – po přepočtu v české administraci stačí spustit import znovu.

1.13.0 – Shape Keys DED-24-v2.2: pořadí úrovní a limity podle dat (stejně jako česká 3.52.0).

1.14.0 – Weights: blok J 150 s, K 210 s (stejně jako česká 3.53.0). Word Problems: limit 90 → 105 s (zivot65-EN-v1b;
těžké úlohy b ≥ 2 utínaly 12 % správných, nově ~8 %), ve srovnání spojeno s v1. Arithmetic beze změny (90 s).

1.14.1 – Vráceno: Weights J 90 s, K 180 s (v2-39-ui3-bl); Word Problems 90 s (zivot65-EN-v1). Stejně jako česká 3.53.1.

1.15.0 – Stations ST2-44-v1.0: nové těžší úrovně 7–8 (stejně jako česká 3.54.0).

1.16.0 – Stations ST2-36-v1.1: nový horní konec S23–S36, úrovně 7–8 ze 1.15.0 vyřazeny (stejně jako česká 3.55.0).

1.17.0 – Stations ST2-34-v1.2: nahrazené položky úrovně 3–4, vyřazené S03/S04, start podle věku, výraznější cíl
(stejně jako česká 3.56.0).

1.17.1 – Stations: mírnější start podle věku (od 13 let úroveň 2, od 17 let úroveň 3), stejně jako česká 3.56.1.

1.18.0 – Paper Folding Gv-PAP-v6: 8 nových těžkých položek (úroveň 9, PAP_043–050, limit 90 s), úroveň 6 přesunuta za 7–8,
nová srovnávací skupina. Stejně jako česká 3.57.0.

1.19.0 – Paper Folding Gv-PAP-v7: 3 extrémní položky (úroveň 10, stříhání mezi přehyby, limit 120 s), stejně jako česká 3.58.0.
