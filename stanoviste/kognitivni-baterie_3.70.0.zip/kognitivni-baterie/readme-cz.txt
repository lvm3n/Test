KOGNITIVNÍ BATERIE – WordPress plugin
=====================================

INSTALACE
1. V administraci WordPressu: Pluginy → Instalace pluginů → Nahrát plugin → vyberte soubor kognitivni-baterie.zip → Instalovat → Aktivovat.
2. V menu vlevo se objeví „Kognitivní baterie“. V části Nastavení vyplňte e-mail pro upozornění a odkaz na zásady ochrany osobních údajů.
3. Vytvořte stránku (například „Test“) a vložte do ní krátký kód:
      [kognitivni_baterie]          – veřejná verze pro kohokoli
   Pro vlastní administraci vytvořte jinou (třeba soukromou) stránku s kódem:
      [kognitivni_baterie_admin]    – vaše verze s volbou kódu účastníka, věku, formy atd. (funguje jen po přihlášení)

PŘES CELOU STRÁNKU
- Krátký kód [kognitivni_baterie] teď roztáhne test přes celou šířku okna a výšku obrazovky, i když má šablona úzký obsah.
  Když byste chtěl původní užší variantu: [kognitivni_baterie sirka="obsah"].
- Úplně bez šablony webu (nejlepší na mobilu): odkaz  https://VÁŠ-WEB/?kognitivni-baterie=1
  Vaše administrátorská verze: https://VÁŠ-WEB/?kognitivni-baterie=admin  (po přihlášení).
  Odkaz můžete dát do menu webu (Vzhled → Menu → Vlastní odkaz).

DATA
- Každá odpověď se ukládá hned (včetně časů v ms) do databáze WordPressu, tabulky wp_kb_participants, wp_kb_sessions, wp_kb_rows, wp_kb_scores.
- Export: Kognitivní baterie → „Stáhnout všechny odpovědi (CSV)“ nebo „Stáhnout výsledky testů (CSV)“. Soubory se otevírají přímo v Excelu (oddělovač středník).
- IP adresy se neukládají. Veřejný účastník má jen náhodný identifikátor uložený v prohlížeči.
- Smazání dat konkrétního účastníka (GDPR): na stránce Kognitivní baterie dole zadejte jeho identifikátor (vidí ho na stránce Moje výsledky).

AKTUALIZACE A NOVÉ TESTY
- Novou verzi pluginu nahrajete stejně jako při instalaci (WordPress nabídne nahrazení). Data se při aktualizaci ani odinstalaci nemažou.
- Výsledky se ukládají podle klíče testu a jeho verze; nový test jen přibude jako nová ikonka, dosavadní výkony zůstávají.
- Rozložení výsledků se počítá zvlášť pro každou verzi testu, aby se nemíchaly nesrovnatelné výsledky.

POZNÁMKY
- Zvuky pro paměťové testy jsou ve složce assets/audio a načítají se ze stejného webu.
- Rozložení výsledků se veřejnosti ukáže až od nastaveného počtu lidí (výchozí 30).

ZMĚNY VE VERZI 3.1.0 – MATICE A ŘADY (V10-50b)
- Převzata nová barevná sada 50 položek + 3 nácvikové (řady, analogie 2×2, matice 2×3 a 3×3).
- U 19 položek od úrovně 4 upraveny distraktory tak, aby žádné pravidlo nešlo přeskočit.
- Zachovány opravy z verze 3.0.0 (Shodné řady, synonyma, znalosti, čtení).

ZMĚNY VE VERZI 3.1.1
- Shodné řady: pozice správné odpovědi je skutečně náhodná (vyvážená, nejvýš 2× stejná po sobě), už ne po čtveřicích.
- V pravém dolním rohu aplikace je vidět číslo verze.

ZMĚNY VE VERZI 3.2.0 – INSTRUKCE
- Tři typy textu před ostrým startem: úsudkové testy, rychlostní testy (s časem a cílem „co nejvíc správně“), paměťové testy.
- Rychlostní testy (Symboly a čísla, Shodné řady, Efektivita čtení) uvádějí limit a cíl už v instrukci.
- Váhy: místo tvrdého konce po 60 s jen pobídka; do dat se ukládá překročení i „správně v limitu“ (verze v2-46-soft60).
- Maskování (MASK-pilot4): podmíněná frekvence (nikdy – spíše výjimečně – asi v polovině případů – většinou – téměř pokaždé),
  „Tato situace se mi nestává“ oddělená pod škálou; obecné výroky a zátěž jako míra souhlasu, u zátěže samostatně „Netýká se mě“.
- Zpřesněné instrukce ostatních testů; u Strojů bez požadavku na co nejkratší řešení.

ZMĚNY VE VERZI 3.3.0 – SEŘAĎ STROJE: NOVÉ TYPY STROJŮ (ZKUŠEBNĚ)
- Na konec testu přidány 4 položky (41–44): 2× stroj „A ZÁROVEŇ“ (dvě podmínky najednou), 2× stroj „KDYŽ–JINAK“ (dvě cesty).
- Před první položkou každého typu se ukáže krátká ukázková karta.
- U každé položky ověřeno: jediné nejkratší řešení, žádné kratší, nový stroj je v řešení nezbytný, aspoň jedna past.
- V datech je u položky rodina (AND / IFELSE). Verze testu v3-44-rozsireni.

ZMĚNY VE VERZI 3.4.0 – SEŘAĎ STROJE: NOVÉ STROJE I V NÁCVIKU A V LEHČÍ ČÁSTI
- Stroj „dvě vlastnosti najednou“ má podmínku v jednom obrázku (např. zelená látka s pruhy, červený čtverec).
- Nácvik rozšířen o 2 položky s jedním krokem (N4 dvě vlastnosti, N5 dvě cesty), před každou ukázková karta.
- V testu 8 položek s novými stroji: lehké (1 krok) na pozicích 11–12, střední (2 kroky) 23–24, těžké 45–48. Verze v3-48-nove-stroje.

ZMĚNY VE VERZI 3.4.1 – SEŘAĎ STROJE
- Prázdné okénko se neobjeví, když už jsou použité všechny nabízené stroje.
- Měkký limit 60 s na položku: pak jen pobídka; do dat se ukládá překročení limitu a „správně v limitu“ (verze v3-48-soft60).

ZMĚNY VE VERZI 3.5.0 – SROVNÁNÍ PŘES VERZE
- Srovnání s ostatními (graf výsledků) už se nedělí při každé drobné úpravě. Verze, které se liší jen pořadím položek,
  distraktory, instrukcemi, grafikou nebo měkkým časovým limitem, tvoří jednu „skupinu srovnání“ a porovnávají se dohromady.
- Nová skupina vzniká jen při změně počtu položek nebo způsobu skórování.
- Data se nikdy nemažou: u každého záznamu zůstává přesná verze testu, takže verze jde v analýze kdykoli oddělit.
- Seřaď stroje: položky 41–48 seřazeny podle konstrukční obtížnosti (verze v3-48-soft60-poradi, stejná skupina srovnání).

ZMĚNY VE VERZI 3.6.0 – NAVÁZÁNÍ ROZPRACOVANÉHO TESTU
- U položkových testů (Matice, Stroje, Váhy, Synonyma, Co víš o světě, Porozumění textu, Počítání, Slovní úlohy,
  Skládání papíru, Mentální rotace) se po každé odpovědi uloží stav testu v tomto zařízení.
- Při dalším spuštění stejného testu se nabídne „Pokračovat“ nebo „Začít znovu“ (platí 30 dní a jen pro stejnou verzi testu).
- Ve veřejné verzi se stav váže na anonymního účastníka v prohlížeči, v administraci na kód účastníka.
- Do dat se zapíše řádek „navazani“, takže je vidět, že test pokračoval po přerušení.
- Rychlostní testy (s časovým limitem na celý test) a paměťové úlohy se nenavazují – začínají vždy znovu.

ZMĚNY VE VERZI 3.7.0 – ŠKÁLY
- Škála ADHD a Škála maskování: průběžné ukládání odpovědí a nabídka pokračovat při dalším otevření (jako u testů).
- Výsledky škál se zobrazují po vyplnění i v „Mých výsledcích“: subškály (ADHD: nepozornost, hyperaktivita, impulzivita,
  exekutivní fungování, emoční dysregulace; maskování: zahlazování, potlačování, předstírání, zátěž) se srovnáním s ostatními.
- Počty symptomů podle DSM-5 zůstávají jen v administraci. Text u výsledků upozorňuje, že nejde o diagnózu.
- Server: srovnání (distribution) zahrnuje i odvozené hodnoty škál.

ZMĚNY VE VERZI 3.8.0 – NOVÝ TEST POROZUMĚNÍ TEXTU (CT2-33)
- Nahrazuje původní Porozumění textu (40 otázek 1 ze 4; kód i data zůstávají, test je jen skrytý). Nový klíč testu: cteni2.
- 33 položek v 6 úrovních, 9 formátů: obrázek do věty, doplň slovo, na koho odkazuje, 1 ze 4, najdi nesrovnalost,
  oprav shrnutí, propoj dvě místa, vyber dvě tvrzení, důkaz a závěr. Většina odpovědí klepnutím do textu, nic se nepíše.
- Průběh: start podle věku (do 7 let úroveň 1, 8–9 let úroveň 2, jinak úroveň 3); dvě správné na začátku úrovně → skok výš
  (zbytek úrovně se připíše; neplatí pro stropovou úroveň); chyba v prvních dvou položkách startovní úrovně → jednou o úroveň níž;
  konec po 3 chybách v jedné úrovni. Jeden člověk řeší zhruba 7–19 položek.
- Před prvním výskytem každého nového formátu krátká karta s vysvětlením. Bez časového limitu; po 90 s jen pobídka
  (ukládá se čas, první akce, počet klepnutí, překročení 90 s a „správně v limitu“). U důkazu a závěru vzor E/C zvlášť.
- Navazuje po přerušení jako ostatní testy.

ZMĚNY VE VERZI 3.9.0 – POROZUMĚNÍ TEXTU CT2-50
- 50 položek v 8 úrovních. Úrovně 7–8 doplněny (strop): mimo metodologické položky také odkazy přes více vět,
  rozlišení autora a citované osoby, časový rozpor, dva zdroje s výpočtem termínu a položka, kde je správná „neopatrná“ odpověď.
- Opravy klíčů: CT43 (rozhodují věty 2 a 5), CT36 (doplněno, že léčiva jsou ve všech částech skladu),
  CT34, CT39, CT45 (jediná obhajitelná sada rozhodujících vět). Pozice správné odpovědi zamíchány.
- Propoj / důkaz a závěr mohou mít 2 nebo 3 rozhodující věty.
- Start: do 7 let úroveň 1, 8–9 let 2, 10–12 let 3, od 13 let úroveň 4. Zdatný dospělý řeší zhruba 15 položek.

ZMĚNY VE VERZI 3.10.0 – POROZUMĚNÍ TEXTU CT2-57
- Přeřazené úrovně podle obtížnosti: CT38, CT47, CT48, CT49 na úroveň 6; CT34–CT43, CT46, CT50, CT40 na úroveň 7.
- Strop (úroveň 8): CT44, CT45 + 7 nových položek – časový model bez počítání, odkaz přes více osob, dvě vícezdrojové
  integrace, kvantifikátory s výjimkou, aktualizace situace a vystižení vývoje sporu (všechny možnosti pravdivé, jen jedna přesná).
- Zdatný dospělý řeší zhruba 17 položek; úroveň 8 se řeší celá, konec po 3 chybách v úrovni.

ZMĚNY VE VERZI 3.10.1 – POROZUMĚNÍ TEXTU CT2-60
- CT51 opraven (dřív logicky neurčitý): jednoznačný řetězec Hana ven → Tomáš → Jana → Hana zpět.
- Nové stropové položky: CT58 (pravidla soutěže, datum narození, mylné tvrzení vedoucího), CT59 (limity výpůjček s výjimkou),
  CT60 (důvod návrhu v argumentaci – všechny možnosti pravdivé, jen jedna vystihuje důvod).
- Přeřazeno: CT52 na úroveň 6, CT54 a CT56 na úroveň 7. Úroveň 8: CT44, CT55, CT57, CT51, CT58, CT59, CT60, CT45, CT53.

ZMĚNY VE VERZI 3.11.0 – POČÍTÁNÍ A SLOVNÍ ÚLOHY
- Počítání: 65 položek místo 190 (jedna forma), pokročilá témata 1–2 položky, víceciferné příklady pod sebou,
  zlomky musí být zkrácené. Verze banka65-v2b.
- Slovní úlohy: 57 nových úloh z každodenního života s obrázky na začátku (mince, hodiny, teploměr, pravítko, tvary),
  geometrií v domácnosti, financemi, tarify, spotřebou, dávkováním; automatické předčítání každé úlohy. Verze zivot57-v1b.
- Oba testy: start podle věku, po dvou správných v řadě se další položka přeskočí a připíše (při chybě hned potom se zadá).
- Staré banky (banka190-rev, banka80) zůstávají v souboru i v datech.

ZMĚNY VE VERZI 3.12.0 – MATEMATIKA
- Počítání (banka68-v3): přeřazená horní třetina (obecná algebra → kvadratické → specializované učivo → calculus),
  doplněné 3 mosty, determinant zobrazený jako matice.
- Slovní úlohy (zivot65-v2): zpřesněné SU46, SU53, SU54; SU51 vyžaduje zkrácený zlomek; 8 nových stropových úloh.

ZMĚNY VE VERZI 3.13.0 – VYKÁNÍ OD 17 LET
- Od 17 let (a na úvodních stránkách, dokud není věk zadán) aplikace vyká: instrukce, úlohy, tlačítka, zpětná vazba
  i předčítaný text („Vyberte“, „zaplatíte“, „vám“…). Do 16 let zůstává tykání.
- Převod probíhá při zobrazení, texty v bankách zůstávají beze změny. Ukazovací „ti, kdo…“ v textech se nepřevádí.

ZMĚNY VE VERZI 3.13.1
- Počítání a Slovní úlohy začínají níž: 8–9 let od b −3,0, 10–11 let od −2,3, 12–15 let od −1,5, od 16 let od −0,8
  (dříve −2,5 / −1,5 / −0,5 / +0,3). Verze banka68-v3s a zivot65-v2s, ve srovnání s ostatními spojené s předchozími.

ZMĚNY VE VERZI 3.13.2
- Počítání začíná položkami, které jdou spočítat z hlavy: 8–9 let 3 × 4, 10–11 let 7 × 6, 12–15 let 61 − 34, od 16 let 1/4 + 2/4.
- 2 003 − 856 (odčítání přes nuly) posunuto za 23 × 4. V úvodu obou matematických testů zmínka, že lze použít papír a tužku.

ZMĚNY VE VERZI 3.14.0 – NOVÉ „CO VÍŠ O SVĚTĚ“ A „SLOVNÍ ZÁSOBA“
- Co víš o světě (znalosti2, ZN2-40): 40 položek v 8 úrovních; formáty obrázek, 1 ze 4 (proč a jak, praktické vědění),
  vyber dvě, klepni na mapě Česka, klepni v obrázku těla, seřaď (časová osa, velikost). Oblasti: příroda a věda, zeměpis,
  dějiny, člověk a zdraví, praktický život, ekonomika, technika, společnost.
- Slovní zásoba (zasoba2, SZ2-59): 9 obrázkových položek (slovo zazní, klepne se na obrázek) + 50 revidovaných synonym.
  Slovo i možnosti se automaticky předčítají.
- Oba testy: automatické předčítání, karta před novým formátem, jedna nácviková položka, průběh jako u Porozumění textu
  (start podle věku, skok po dvou správných, konec po 3 chybách v úrovni), navázání po přerušení.
- Obrázky: OpenMoji (openmoji.org, CC BY-SA 4.0) z cdn.jsdelivr.net; dokud se nenačtou, zobrazí se emoji zařízení.
- Původní testy Slova se stejným významem a Co víš o světě (1 ze 4) jsou skryté; kód i data zůstávají.

ZMĚNY VE VERZI 3.15.0 – REVIZE ZNALOSTÍ A SLOVNÍ ZÁSOBY
- Co víš o světě (ZN2-53): 53 položek v 10 úrovních. Opravy ZN303 (Brno–Morava–Česko–Evropa), ZN604 (tlak a rozpínání vzduchu),
  ZN602 (vázaná rotace), ZN801 (kolektivní ochrana jen u přenosných nemocí), ZN605 (nejjižnější město), ZN803 (věrohodnější distraktory).
  Přeřazeno: ledviny L4, antibiotika L5, délka dne L6, loď a Liberec L7. Nové úrovně 8–10 (13 položek): pražské jaro, tlakový hrnec,
  délka řek, český stát, úrokové sazby, modrá obloha, časová osa 1945–1993, mRNA, stav beztíže, deficit a dluh, objevy vědy,
  Golfský proud, složení atmosféry. Každá položka má v datech oblast a druh (deklarativní / porozumění – lze odvodit).
- Znalosti: zbytek úrovně se připíše jen po 3 správných směrovacích položkách ze 3 různých oblastí.
- Slovní zásoba (SZ2-69): 10 nových stropových synonym (úroveň 9), přeřazeno explicitní L6, rezolutní L7, markantní L5,
  efemérní a perfidní L8. Směrovací (první dvě) položky každé úrovně jsou její dvě nejtěžší.

ZMĚNY VE VERZI 3.16.0 – KLIKACÍ POLOŽKY VE ZNALOSTECH
- Co víš o světě (ZN3-65): 21 nových položek ZK02–ZK22 (ZK01 zatím chybí): klikání přímo v obrázku podle masky,
  dvoukrokové položky s přiblížením (0/1/2 body, druhý krok vždy nad správným výřezem a ukládá se zvlášť),
  obrázkové možnosti (gotika, renesance), časové osy (dinosauři; století → desetiletí) a periodická tabulka.
- Nahrazují starou mapu Česka s body a schéma těla (odstraněno 9 položek sdílejících stejný obrázek).
- Obrázky v assets/img/gc (WebP), masky vložené přímo v aplikaci. Maska ZK10 krok 2 doplněna (chloroplasty, jádro, vakuola).

ZMĚNY VE VERZI 3.16.1
- Vyřazeny klikací položky s nevyhovujícími obrázky: ZK09 (ucho), ZK13 (břišní orgány), ZK18 (srdce). Co víš o světě: 62 položek (ZN3-62).
- Po vyhodnocení v nácviku a v náhledu se v obrázku zobrazí správná oblast zeleně a chybná volba červeně.

ZMĚNY VE VERZI 3.17.0 – CO VÍŠ O SVĚTĚ JAKO VŠEOBECNÝ TEST (ZN4-71)
- Oblasti: příroda a věda 24 %, praktický život, kultura, dějiny, společnost a ekonomika po 13 %, zeměpis 10 %,
  člověk a zdraví 8 %, technika 7 %. Řazení nejvýš 6 položek.
- Nové položky: kultura (kytara, Babička, Švejk, impresionismus, Rusalka, sonet, baroko), společnost a právo
  (volební věk, ombudsman, dělba moci, presumpce neviny), zdraví (sacharidy, kolaps a masáž srdce, BMI),
  praktický život (hrubá mzda, spoluúčast).
- Dějiny: místo řazení letopočtů otázky na význam (Bílá hora, vznik evropského společenství); časová osa ZK20 nově bitva u Slavkova.
- Vyřazeno: řazení planet (napovídal ho obrázek planet), 6 přírodovědných položek. Pozice a délky správných odpovědí vyrovnány.
- Směrovací položky každé úrovně ze tří různých širokých oblastí.

ZMĚNY VE VERZI 3.18.0
- Slovní zásoba a Co víš o světě začínají níž: do 8 let úroveň 1, 9–12 let úroveň 2, od 13 let úroveň 3.
- Slovní zásoba (SZ3-79): nová úroveň 10 (epigonský, idiosynkratický, mizantrop, obstrukce, eufemismus, rigidní, diletant,
  kontemplace, konsekventní, sardonický).
- Co víš o světě (ZN5-80): hlubší strop – úrovně 10–11 (Máj a romantismus, izotop, placebo, trestný čin × přestupek,
  vila Tugendhat, Marshallův plán, kvantitativní uvolňování, Descartes, buddhismus).
- Korelace: počítají se jen ze současných verzí testů (a verzí ve stejné skupině srovnání); zrušené testy a starší verze
  (např. Symboly s tvary) se nezapočítávají. Server přijímá seznam povolených verzí (parametr allow).
- Menu: test, který člověk dělal ve starší verzi, nebo test, který nahradil starý (Slovní zásoba, Co víš o světě,
  Porozumění textu), je označený „Nová verze – můžete ji vyplnit“ a lze ho spustit znovu.

ZMĚNY VE VERZI 3.18.1
- Obrázky OpenMoji se přednačítají při otevření testu; během položky se už nemění emoji za obrázek (žádné blikání).
- Časové osy se na telefonu na výšku zobrazují svisle (úseky pod sebou s rozsahem let); u periodické tabulky tip otočit telefon.

ZMĚNY VE VERZI 3.19.0 – NOVÝ TEST „POJMY A FAKTA“ (PSANÁ ODPOVĚĎ, GO-40-v1)
- Skupina Gc. 40 položek v 8 úrovních po 5: definice → slovo (19) a všeobecné znalosti (21). Úroveň 1 = podlaha (předškolní),
  úroveň 8 = strop. Odpověď se píše do okénka (Enter = Hotovo), tlačítko „Nevím“. Automatické předčítání otázky.
- Start podle věku: do 5 let úroveň 1, 6–8 let 2, 9–12 let 3, od 13 let 4. Průběh jako u ostatních Gc testů (skok po dvou
  správných směrovacích, návrat o úroveň při chybě na začátku, konec po 3 chybách v úrovni). Jeden nácvik (obloha – modrá).
- Automatické skórování: bez ohledu na velká písmena, diakritiku a interpunkci; uzavřený seznam uznaných variant; jiné tvary
  téhož slova; číslice i slovy; překlep o 1 znak u slov od 6 písmen (ne u čísel a panovníků s řadovou číslovkou);
  očekávané záměny (sloupec Neuznávat) = 0 vždy přednostně; více odpovědí najednou = bod jen tehdy, když jsou všechny správné.
- Do dat se ukládá doslovná odpověď a třída (klic, varianta, tvar, cislo, preklep, vice_spravne / zamena, vice_chybne,
  blizko, nezname, nevim) ve sloupci chyby i ve facetách. Třídy „nezname“ a „blizko“ jsou určené k ruční revizi klíče.

ZMĚNY VE VERZI 3.19.1 – POJMY A FAKTA: START NÍŽ
- Do 8 let start na úrovni 1, od 9 let (i dospělí) na úrovni 2. Přeskakuje se jen podlaha (úroveň 1), která se při
  úspěchu připíše. Verze GO-40-v1s, ve srovnání s ostatními spojená s GO-40-v1 (liší se jen startem).

ZMĚNY VE VERZI 3.20.0 – POJMY A FAKTA v2: DVA INDIKÁTORY (GC2I-48-v1)
- Podle kandidátní banky „dva indikátory v3“: 24 položek slovní zásoby (definice → slovo) a 24 znalostí, každý indikátor
  seřazený zvlášť podle obtížnosti (3 položky podlahy, 2 stropové). Položky obou indikátorů se střídají.
- Vyřazeny položky blízké Informacím z WISC (Michelangelo, Sahara, tele, týden, var vody, teploměr) a překryvy s ostatními subtesty.
- Průběh ve stylu WISC: do 8 let od položky 1, od 9 let od položky 4. Když není správně některá z prvních dvou položek,
  zadávají se předchozí pozpátku do dvou správných za sebou (níž se připíše). Indikátor končí po 5 chybách za sebou.
- Skórování benevolentní: pravopis a gramatika (i/y, s/z, zdvojená písmena, koncovky, „Karla čtvrtého“), překlepy
  (1 znak od 4 písmen, 2 znaky od 9), odpověď s přidanými slovy. Očekávané záměny zůstávají 0.
- Výsledek: celkový hrubý skór + zvlášť slovní zásoba a znalosti (ukládají se i do srovnání a korelací).

ZMĚNY VE VERZI 3.21.0 – DVA SAMOSTATNÉ SUBTESTY S PSANOU ODPOVĚDÍ
- „Pojmy a fakta“ rozděleny na dva samostatné testy ve skupině Gc:
  Jak se to nazývá (gcslovni, GCS-40-v1) – 40 položek slovní zásoby,
  Všeobecné znalosti (gcznalosti, GCZ-40-v1) – 40 položek z dějin, kultury a náboženství, společnosti a ekonomiky,
  sportu, techniky, matematiky, přírody a zdraví (přírodní vědy asi čtvrtina). Rozšířený strop.
- Omezené přeskakování: do 8 let od položky 1, od 9 let od položky 4 (položky 1–3 se připíšou). Žádný zpětný chod
  ani skoky. Konec po 5 chybách za sebou. Benevolentní skórování beze změny.

ZMĚNY VE VERZI 3.21.1
- Nová úvodní stránka veřejné verze: pilotní studie škály ADHD v dospělosti a testů schopností, autor, zvýrazněné srovnání s ostatními.

ZMĚNY VE VERZI 3.21.2 – POŘADÍ OBRÁZKŮ (por-1.3)
- Ukončení: když v obou položkách jedné délky je správně méně než polovina pozic (K1–K2: 0, K3–K4: méně než 2,
  K5–K6: méně než 3, K7–K8: méně než 4, K9: méně než 5). Dříve jen při 0 bodech v obou položkách, což u delších řad skoro nenastalo.
- Hrubé skóre není srovnatelné s por-1.2 (jiné ukončení), proto nová skupina srovnání.

ZMĚNY VE VERZI 3.22.0 – VŠEOBECNÉ ZNALOSTI (GCZ-50-v1)
- 50 položek místo 40. Méně Česka: vyřazeny Sněžka, sv. Václav, Josef Čapek, Žižka, Ústavní soud, Janáček, Josef II., Václav III.;
  NATO bez české formulace. Česko je teď v 7 z 50 položek (Praha, Masaryk, Karel IV., Smetana, matrika, Mendel, Kafka).
- Nové: Koloseum, Tichý oceán, Einstein, Beethoven, van Gogh, Berlínská zeď, přistání na Měsíci 1969 a 11 stropových:
  Caesar (Rubikon), játra (žluč), HDP, Canberra, Dante, nejmenší prvočíslo, Kant, Romanovci, Eukleidés, Hérodotos, Nový Zéland (volební právo žen).

ZMĚNY VE VERZI 3.22.1 – JAK SE TO NAZÝVÁ (GCS-50-v1)
- 50 položek místo 40. Nové: entomologie, estetika, anexe a 7 stropových (oxymóron, axiom, anafora, kosmologie,
  etnocentrismus, kognitivní disonance, litotes). Strop teď tvoří asi 15 položek.

ZMĚNY VE VERZI 3.22.2 – JAK SE TO NAZÝVÁ (GCS-55-v1)
- Víc oborů: řemesla a sport (obuvník, maraton), medicína (kardiolog), matematika (poloměr), právo (alibi), technika a IT
  (prototyp, algoritmus), biologie (symbióza), ekonomika (dluhopis, deflace), hudba (crescendo), geologie (epicentrum), fyzika (sublimace).
- Vyřazeno 8 humanitních položek (rejstřík, personifikace, xenofobie, estetika, narcismus, epos, teokracie, anafora). 55 položek.

ZMĚNY VE VERZI 3.22.3 – POŘADÍ V MENU
- Škály: nejdřív Škála ADHD, pak Škála kompenzace a maskování.
- Všeobecný rozhled a jazyk: nejdřív Jak se to nazývá a Všeobecné znalosti (psaná odpověď), pod nadpisem „Doplňkové testy“
  Slovní zásoba a Co víte o světě. Pořadí se nastavuje v MENU_FIRST a MENU_EXTRA v app.html.

ZMĚNY VE VERZI 3.22.4 – MASKOVÁNÍ: SPOJENÉ SROVNÁNÍ
- MASK-pilot3 a MASK-pilot4 se ve srovnání s ostatními (celkem i subškály) a v korelacích počítají dohromady.
  V exportu dat zůstává verze u každého záznamu, takže je lze ve výzkumné analýze dál oddělit.

ZMĚNY VE VERZI 3.23.0 – ŠKÁLA ADHD: ZJEDNODUŠENÉ FORMULACE (ADHD-v6)
- 135 ze 187 výroků přeformulováno: jeden obsah na výrok, bez vedlejších vět typu „i když“, bez zbytečných zesilovačů,
  konkrétní chování; reverzní položky jsou přesná zrcadla svých párů. Průměrná délka 9,5 → 6,5 slova.
- Kódy, subškály, páry a mapování DSM beze změny. Validitní, kontrolní, kontextové, vývojové a IDA položky beze změny.
- Nová skupina srovnání (ADHD-v6 se nemíchá s ADHD-v5b).

ZMĚNY VE VERZI 3.23.1 – ŠKÁLA ADHD: ČEŠTINA (ADHD-v6b)
- Opraveny doslovné překlady a neobratné obraty u 15 výroků (např. „Do práce se dostanu…“ → „Do práce se pustím…“,
  „zamrznu“ → „zaseknu se“, „obsah o ADHD“ → „příspěvky o ADHD“). Ve srovnání spojeno s ADHD-v6.

ZMĚNY VE VERZI 3.24.0 – ŠKÁLA ADHD ZEŠTÍHLENÁ (ADHD-v7, 120 položek)
- Odstraněno: vývojový kontext (DEV), sebeidentifikace (IDA), kontext více prostředí (CTX), normativní položky (NOR),
  validita minimalizace/stereotypy/pseudosymptomy (SVT_MIN, SUP, POP), položky s časovým určením a duplicity.
- Vráceno: vnitřní neklid dospělých (HYP_02, HYP_05, HYP_06, HYP_10).
- Validita: 4 vzácné symptomy, 4 nadsazení, 2 kontrolní otázky. 8 párů pro konzistenci (index nekonzistence nyní skutečně počítán –
  dřív se kvůli chybě nepočítal). Funkční dopady: 8 položek, formulované tak, aby se týkaly každého.
- Odpovědní škála beze změny. Instrukce bez věty o dětství. Nová skupina srovnání.

ZMĚNY VE VERZI 3.24.1 – ŠKÁLA ADHD (ADHD-v8)
- Odstraněny kontrolní otázky „označte možnost 1/2“ (pozornost hlídá index nekonzistence 8 párů).
- +10 validitních položek: 5 vzácných symptomů (SVT_RAR_07–11) a 5 populárních mýtů (SVT_MYT_01–05, nový průměr myty_prumer).
- Jádro škály beze změny → ve srovnání spojeno s ADHD-v7.

ZMĚNY VE VERZI 3.24.2 – ŠKÁLA ADHD (ADHD-v9, 124 položek)
- Odstraněna senzorická citlivost (SENZ_07–10).
- 71 výroků zkráceno a formulováno aktivně (průměr 7,7 → 5,8 slova), obsah beze změny; páry zůstávají zrcadlové.
- Ve srovnání spojeno s ADHD-v7 a v8.

ZMĚNY VE VERZI 3.24.3
- Vráceny předchozí formulace POZ_14, SENZ_01, EXE_13, REV_10, FNC_HOM_01. Vyřazena SVT_MYT_04 (telefonování). 123 položek.

ZMĚNY VE VERZI 3.25.0 – ŠKÁLA ADHD (ADHD-v10)
- Mýtus „emoce druhých“ nahrazen „stálostí objektu“ (SVT_MYT_06). 123 položek.
- Odpovědní škála beze změny; u položek o četnosti (93) je zvýrazněná četnost, u ostatních souhlas (příznak fq v bance).
- Výsledky subškál jsou nyní průměry 0–4 (adhdp_*), srovnatelné napříč verzemi. Po aktualizaci pluginu server jednorázově
  přepočítá průměry i pro dřívější vyplnění ze zachovaných položek (verze „prepocet“, soubor includes/backfill.php).
  Pro další verzi škály je potřeba ji přidat do skupiny adhdp_* v CMP_GROUPS.

ZMĚNY VE VERZI 3.26.0 – ŠKÁLA ADHD (ADHD-v11)
- Odpovědní škála jen frekvenční, 5 bodů: nikdy (0) – zřídka – občas – často – velmi často (4). Instrukce upravena.
- Podle souboru ADHD_v10_polozky_frekvence: vyřazena SVT_MYT_02 (dopamin), upraveny EMO_05 a HYP_07. 122 položek.
- Kódování 0–4 zachováno, průměry subškál zůstávají ve srovnání spojené se staršími daty.

ZMĚNY VE VERZI 3.27.0 – ŠKÁLA ADHD (ADHD-v12, 118 položek)
- Doplněno podle ICD-11: riskování bez rozmyslu (IMP_12), ukvapená důležitá rozhodnutí (IMP_13), nevhodné poznámky (IMP_14),
  ztrácení věcí (POZ_23, přidáno i do DSM skupiny), netrpělivost (EMO_12), nesnášení nudy (HYP_17).
- Vyřazeny opakující se: IMP_05, REV_12 (skákání do řeči 4× → 2×), SENZ_01, SENZ_06, HYP_01, HYP_13, EXE_18, POZ_16, EXE_20, EMO_09.
- Upraveno: RSD_03, RSD_06, EXE_15, EXE_14.

ZMĚNY VE VERZI 3.27.1 – ŠKÁLA ADHD (ADHD-v13, 120 položek)
- Druhá položka pro symptomy DSM A1f (POZ_24) a A2i (IMP_15), obě doplněny do DSM skupin.
- Tři nové zrcadlové páry: HYP_09/REV_15, IMP_14/REV_16, EMO_05/REV_17 → 10 párů přes všechny hlavní oblasti.
- Vyřazeny duplicity POZ_04, HYP_05, IMP_11; HYP_15 bez příkladu se čtením.

ZMĚNY VE VERZI 3.27.2 – VEŘEJNÁ VERZE
- Seřaďte stroje, Slovní zásoba (výběr z možností) a Co víte o světě jsou ve veřejné verzi skryté v menu, ve výsledcích
  i v korelacích (seznam PUBLIC_HIDE v app.html). V místní verzi a administraci zůstávají, sebraná data se nemažou.

ZMĚNY VE VERZI 3.28.0 – NOVÝ TEST DEDUKCE (Gf, DED-40-strict-v0.2)
- Úloha inspirovaná WJ Analysis–Synthesis: 5 stálých obousměrných pravidel (jeden symbol ⇄ dvojice), 40 položek
  v 8 úrovních; úrovně 6–8 vyžadují integraci celé sítě, úroveň 8 i jednu hypotézu (ověřeno validátorem).
- Zácvik 4 položky se zpětnou vazbou (opakování do správné odpovědi); skórovaná část bez zpětné vazby.
- Skóre = počet správně. Časové limity 20–120 s podle úrovně bez viditelného odpočtu; výzkumný režim bez limitu:
  přidat k adrese stránky ?untimed=1. Ukončení podle nastavení baterie (S.stop, 0 = všech 40).
- Od úrovně 4 neutrální poznámky do prázdných koleček (klepnutí), bez vlivu na skóre; ukládají se ve facetách.
- Topologie, odhalené symboly a odpovědi beze změny. Souřadnice sítí u úrovní 6–8 přepočítány (rovinné, bez křížení,
  čáry nevedou přes cizí symboly); původní banka, validátor a použité souřadnice jsou v docs/dedukce/.

ZMĚNY VE VERZI 3.28.1 – DEDUKCE: SMĚROVÁNÍ JEN PŘES NEJLEHČÍ ÚLOHY (DED-40-strict-v0.2r)
- Od 9 let jsou D01 a D02 směrovací: obě správně → D03–D05 se připíšou (pripsane = 3) a test pokračuje úrovní 2;
  jinak se zadají i D03–D05. Žádné jiné přeskakování. Do 8 let se zadává vše od D01.
- Ve výsledku je nový údaj „smerovani“ s popisem, co se stalo. Ukončení dál podle nastavení baterie.

ZMĚNY VE VERZI 3.28.2 – DEDUKCE PRO PILOT (DED-40-pilot-v0.3)
- Směrování D01–D02 vypnuto (DED_ROUTE = false): v pilotu všichni dostanou všech 40 položek od D01.
- Ukončení po chybách v Dedukci vypnuto (DED_FULL = true), bez ohledu na globální S.stop ostatních testů.
  Instrukce říká, že poslední úlohy jsou velmi těžké a test lze kdykoli ukončit.
- Limity: úrovně 1–2 30 s; na úrovni 1 je limit jen upozornění („Čas na tuto úlohu vypršel…“), úloha pokračuje
  (sloupec po_limitu = 1). Od úrovně 2 je limit tvrdý (chyby = timeout). ?untimed=1 limity vypne.
- Nové záznamy u každé položky: ws_log (časová posloupnost poznámek: čas, uzel, z čeho, na co) a odpovedi_log
  (posloupnost výběrů odpovědi s časem). Pro produkci přepnout DED_ROUTE / DED_FULL v app.html.

ZMĚNY VE VERZI 3.29.0 – SONDY PO UKONČENÍ, LIMITY A UPOZORNĚNÍ NA ČAS
- Sondy: když test skončí pro chyby v řadě, zadají se ještě až 3 náhodné úlohy z nejtěžší třetiny banky, kam se
  člověk nedostal (když jich tam není dost, z libovolných nedosažených). Do skóre se nepočítají: řádky mají
  faze = 'sonda', ve výsledku testu jsou údaje sondy (ID) a sondy_spravne. Účastník nic zvláštního nevidí.
  Platí pro: Matice a řady, Váhy a další testy sdíleného motoru, Skládání papíru, Pohled na stavbu, Mentální rotace,
  Dedukce, Jak se to nazývá, Všeobecné znalosti (u psaných Gc zvlášť pro každý indikátor).
  Nepatří sem testy rychlosti (Gs) a rozpětí paměti (Gwm), kde se ukončení řídí délkou řady.
- Dedukce (DED-40-pilot-v0.4): ukončení po chybách podle nastavení baterie opět zapnuto, pak sondy.
  Pod obrázkem je vždy „Na úlohu je … sekund/1 minuta.“, 15 s před koncem „Zbývá 15 sekund.“ (úroveň 1 zůstává měkká).
- Váhy (v2-46-hard60): limit 60 s je nově tvrdý (úloha se uzavře jako chybná, timeout = 1). Pod zadáním
  „Na úlohu je 1 minuta.“, po 45 s „Zbývá 15 sekund.“

ZMĚNY VE VERZI 3.29.1 – OPRAVY MATIC A VAH PO REVIZI
- Matice (v10-50c): P31, P40, P42, P47, P49 měly možnosti, které se vykreslily stejně (renderer ignoruje velikost
  u směrových objektů a otočení u běžných tvarů), a u P40/P47/P49 distraktor bez směru (rotate NaN).
  Neviditelné rozdíly nahrazeny viditelnými chybami jednoho pravidla (bez výměny míst, bez otočení, jiná velikost,
  jiný typ objektu). P30: distraktor A má nově správný prstenec a chybnou tečku, takže je nutné použít obě pravidla.
  Kontrola vykreslením: žádné dvě možnosti v celé bance nejsou vizuálně totožné, nikde není NaN.
  Pozice správných odpovědí beze změny.
- Váhy (v2-46-hard60w): u V2_E2, G1, G2, I2, K6, K7, K11 upraveny skryté číselné váhy tak, aby v paletě
  neexistovala žádná další vyvažující kombinace (zobrazené váhy i odpovědi beze změny; ověřeno pro celou banku).
- Váhy: nový záznam stavba_log – každé přidání, odebrání a „Vrátit krok“ s časem.

ZMĚNY VE VERZI 3.29.2 – VÁHY SEŘAZENÉ PODLE OBTÍŽNOSTI (v2-46-hard60w-b)
- Položky seřazeny podle deklarované obtížnosti b (dřív 12 poklesů, nyní 0); číslo položky p přečíslováno, ID beze změny.
- Startovní položky podle věku zachovány (stejné úlohy na nových pozicích): 6–8 let V2_A1, 9–12 V2_C1, 13–64 V2_D3, 65+ V2_C2.
- Úvodní karta k nakloněným vahám je u první položky s nerovností (V2_D2n). Rušivé nerovnosti pro pilot ponechány.

ZMĚNY VE VERZI 3.29.3 – VÁHY BEZ NAKLONĚNÝCH VAH (v2-39-hard60)
- Vyřazeno 7 položek s nakloněnou vahou (V2_D2n, F3n, I1, I2, H2n, K5n, K12n): nerovnost v nich k odvození
  odpovědi nebyla potřeba (a u úlohy „vyrovnej váhu“ potřeba být nemůže). Zůstává 39 položek, nejtěžší V2_K15.
- Úvodní karta k nakloněným vahám odstraněna. Startovní úlohy podle věku beze změny.
- Nerovnost jako skutečná součást výpočtu vyžaduje jiný typ otázky (např. „kam se váha nakloní?“) – případný nový blok.

ZMĚNY VE VERZI 3.30.0 – DATA A KLÍČE GC PO REVIZI
- Typ vstupu: u kliknutí/klepnutí se ukládá skutečný typ ukazatele (mouse / touch / pen) místo vždy „touch“
  (Symboly a čísla, Shodné řady, SRCE, numerická klávesnice, Pořadí obrázků, Dedukce).
- Lokální dokument sezení nově obsahuje pohlaví, demografii, informace o zařízení a otisky (hashe) všech
  položkových bank; otisky bank a údaje o ukazateli jdou i na server s údaji o zařízení.
- Lokální CSV export: sloupce = pevný základ + všechny další klíče z řádků (ws_log, odpovedi_log, stavba_log …).
  (Serverový export sjednocení klíčů používal už dřív.)
- Gc (GCS-55-v2, GCZ-50-v2): z přijímaných odpovědí vyřazeny a mezi záměny přesunuty: kukátko (SZ07),
  archeologie (SZ09), kardiochirurg (SZ17), kosmogonie (SZ50), matrikář (ZN18), neolitická revoluce (ZN34).
  SZ24 přeformulována: „Jak se nazývá okolnost nebo důkaz, že podezřelý byl v době činu na jiném místě?“
  SZ35 (symbióza + mutualismus) a ZN30 (Langerhansovy ostrůvky) ponechány.

ZMĚNY VE VERZI 3.30.1
- Efektivita čtení (SRCE-v08): hrubý skór = počet správně za 120 s; „správně − chybně“ zůstává jako vedlejší
  údaj spravne_minus_chybne. Nová verze = samostatná skupina srovnání.
- Váhy: v pilotu se u každé administrace losuje (50 : 50), zda má test časový limit 60 s. Bez limitu se neukazuje
  žádná informace o čase; ve skóre bez_limitu = 1, v řádcích time_limit_ms = 0. Sloupec spravne_v_limitu
  se počítá i bez limitu (zda by odpověď stihla 60 s).
- Poslední čísla: nový sloupec target_opakovani (1 = cílová řada obsahuje opakovanou číslici).
  Pořadí U = 2/4/6 uvnitř úrovně se náhodně míchalo už dřív.

ZMĚNY VE VERZI 3.30.2 – POŘADÍ OBRÁZKŮ (por-2.0)
- Skórování jako u WISC Picture Span: 2 body = všechny obrázky ve správném pořadí, 1 bod = všechny správné
  obrázky (bez rušivých) v jiném pořadí, 0 = jinak. Max. 36 bodů. Poziční body zůstávají jako procesní údaj
  (pozicni_skore v řádku, pozicni_body ve výsledku).
- Ukončení: obě položky jedné délky za 0 bodů (dřív méně než polovina pozic).
- Rušivé obrázky: K1–2 dva, od K3 tři (dřív rostly až na 5), aby obtížnost řídila hlavně délka řady.
- Instrukce doplněna: „Když si pořadí nepamatuješ, vyber aspoň správné obrázky – i to se počítá.“

ZMĚNY VE VERZI 3.30.3 – POŘADÍ OBRÁZKŮ (por-2.1)
- Pevná velikost výběrové mřížky podle bloku délek: K1–2 = 4 obrázky, K3–5 = 8, K6–9 = 12; rušivých je
  mřížka − K (K9: 3 rušivé, K6: 6). Chybějící rušivé obrázky se doplňují deterministicky podle ID položky
  z ostatních obrázků sady, takže jsou u všech účastníků stejné. Počet možností je v řádku n_options.

ZMĚNY VE VERZI 3.30.4 – POŘADÍ OBRÁZKŮ (por-2.2)
- Vybraný obrázek v mřížce zešedne a nejde vybrat znovu; tlačítko „Zpět“ ho zase uvolní.
- Pevné rozložení mřížky: každá položka má uložené pořadí možností (layout) – stejné pro všechny účastníky;
  cílové obrázky nikdy neleží v mřížce za sebou ve správném pořadí.
- Rušivé obrázky jsou nově všechny explicitně v bance (nic se negeneruje za běhu).
- Formy A a B znovu sestaveny z 20 kandidátů na každou délku (optimalizace): každý z 28 obrázků je v každé formě
  cílem 2–4× (dřív 0–8×), rušivým 1–3×; formy mají stejnou strukturu a nesdílejí položky. Rušivé obrázky
  nepoužívají cíle bezprostředně předchozí položky. Generátor: docs/por_generator.py.

ZMĚNY VE VERZI 3.30.5 – DEDUKCE: ČASOVÝ LIMIT AŽ U NEJTĚŽŠÍCH ÚLOH (DED-40-pilot-v0.5)
- Úrovně 1–5 (D01–D25) bez časového limitu a bez informace o čase. Po 30 s (úroveň 1) / 60 s (úrovně 2–5)
  se jen jemně ukáže: „Když si nejsi jistý/á, vyber odpověď, která ti přijde nejlepší, a pokračuj.“ (po_limitu = 1).
- Úrovně 6–8 (D26–D40) tvrdý limit 75 / 90 / 120 s s informací pod obrázkem a upozorněním 15 s před koncem.
- Instrukce: „Většina úloh nemá časový limit. Jen u posledních, nejtěžších úloh je čas omezený …“

ZMĚNY VE VERZI 3.30.6 – DEDUKCE: ZÁCVIK ROZLOŽENÝ DO TESTU (DED-40-pilot-v0.6)
- Na začátku jen ukázky T1 (složení) a T2 (obrácený směr).
- T3 (dva vztahy za sebou) se ukáže těsně před první úlohou úrovně 2 (D06), T4 (je potřeba spojit víc vztahů)
  před první úlohou úrovně 6 (D26) – vždy s krátkou obrazovkou „Nový typ úlohy“. Kdo se k těmto úrovním nedostane,
  ukázku nevidí. Platí i pro sondy po ukončení (když sonda padne do úrovně 6+, předchází jí T4).
- Ukázky se zobrazují jen při zapnutém nácviku (nastavení baterie). Řádky ukázek mají faze = 'nacvik'.

ZMĚNY VE VERZI 3.31.0 – POŘADÍ OBRÁZKŮ PODLE NOVÉ BANKY (por-3.0)
- Nová sada 36 vektorových obrázků (picture_span_bank_vector_svg_v2) místo původních 28 ikon.
- Nová banka: 30 skórovaných položek T1–T10 × F1–F4 (délka × počet rušivých, v rámci délky roste F),
  2 nácvikové + 1 náhradní nácviková. Jedna forma (formy A/B zrušeny). Sloupec f = počet rušivých.
- Ve struktuře T/F beze změny, ale obsah vyvážen: každý obrázek je cílem 4–5× (v dodané bance 0–11×, 11 obrázků
  nikdy), rušivým 1–3×; cíle předchozí položky se v další položce neobjeví; cíle nikdy neleží v mřížce za sebou
  ve správném pořadí (v dodané bance I04, I05). Vyvážená banka a skript: docs/picture_span/.
- Skórování 2/1/0 ponecháno (max. 60), LCS/poziční skóre dál jako procesní proměnné.
- Ukončení: 3 položky za sebou 0 bodů.
- Technický limit 40 s na odpověď: nevyplněná místa se doplní „?“ a odpověď se vyhodnotí (timeout = 1).
- Zpětná vazba v nácviku ukazuje správné pořadí obrázky, ne slovy.

ZMĚNY VE VERZI 3.31.1 – OPRAVY ZOBRAZENÍ
- Pořadí obrázků: 4 obrázky (kniha, letadlo, ponožka, vlak) se nevykreslovaly – odkazovaly na odstraněný
  stínový filtr. Opraveno; kontrola vykreslení všech 36 obrázků proběhla bez chyby.
- Dedukce na počítači: síť se zobrazovala ve výchozí velikosti 300 px. Nově se přizpůsobí oknu (až 640 px,
  podle výšky obrazovky), větší karty pravidel a tlačítka odpovědí.
- Vykání: doplněny tvary „nevyřešíš“ a „vyzkoušej“ (v instrukci Dedukce zůstávalo tykání).

ZMĚNY VE VERZI 3.31.2 – POŘADÍ OBRÁZKŮ NA POČÍTAČI
- Na obrazovkách širších než 900 px se obrázky zvětšují podle okna: předváděný obrázek až 260 px (30 % výšky),
  okénka pořadí až 150 px, výběrová mřížka až 180 px na obrázek (4 sloupce do 8 možností, 6 sloupců nad 8),
  stránka až 1240 px široká. Na mobilu beze změny.

ZMĚNY VE VERZI 3.31.3 – DEDUKCE: ROZVRŽENÍ NA POČÍTAČI
- Na obrazovkách širších než 900 px dvousloupcové rozvržení: síť vlevo (co největší podle výšky okna),
  vpravo pravidla, odpovědi, Potvrdit, zpětná vazba a Dál – vše viditelné bez posouvání (ověřeno 1512×860,
  1280×720). Na mobilu jeden sloupec jako dřív; po zpětné vazbě se tlačítko Dál posune do zorného pole.

ZMĚNY VE VERZI 3.32.0 – NOVÝ VZHLED VAH A SROZUMITELNĚJŠÍ DEDUKCE
- Váhy (v2-39-hard60-ui3): podle vahy_redesign_kit – ploché 2D tvary (nový jednoduchý fialový šestiúhelník),
  váhy se stojanem, kladinou s čepem a miskami na závěsech (při nerovnováze se naklání rameno, stojan zůstává),
  větší horní nápovědné váhy, cílová karta až 760 px bez černého rámečku, paleta hned pod ní. V nácviku je u
  horních vah štítek „Nápověda“. Banka, skórování, časování i logování beze změny; nová verze jen kvůli vzhledu
  (kvůli srovnatelnosti). Podklady v docs/vahy_redesign_kit.
- Dedukce: pravidla v označeném panelu „Pravidla – platí oběma směry“, nad odpověďmi „Který symbol patří místo ?“,
  síť na počítači nejvýš 640 px.

ZMĚNY VE VERZI 3.32.1 – DEDUKCE: NÁZORNÝ ÚVOD PRO DĚTI I DOSPĚLÉ
- Místo dlouhé instrukce animovaná ukázka (asi 20 s, „Přehrát znovu“, tlačítko „Zkusit“ po jejím doběhnutí):
  1) pravidla – jeden tvar a jeho dvojice, 2) hvězda se rozdělí na kruh a trojúhelník, 3) kruh s trojúhelníkem
  se spojí zpátky do hvězdy, 4) prohození dvojice – na pořadí nezáleží, 5) zabliká tlustá čára – vede k tomu
  jednomu tvaru, 6) mini-úloha: zvýrazní se pravidlo a na místo otazníku „přiletí“ správný tvar.
- Slova „symbol“ a „oběma směry“ nahrazena slovy „tvar“, „rozdělit“, „spojit“; stejně i zpětná vazba v ukázkách.
- Obtížnost („poslední úlohy jsou těžké i pro dospělé“) až na obrazovce před ostrým testem; časový limit se
  oznamuje až na obrazovce „Nový typ úlohy“ před úrovní 6. Nadpis panelu jen „Pravidla“.

ZMĚNY VE VERZI 3.32.2 – DEDUKCE: POMALEJŠÍ UKÁZKA
- Úvodní animace je 2× pomalejší (asi 40 s): každý krok 5–8 s, pohyby tvarů 1,5 s, blikání tlusté čáry 5×.
  Rychlost se mění jedním číslem DEMO_TEMPO v app.html (1 = původní, 2 = současná).

ZMĚNY VE VERZI 3.33.0 – POŘADÍ OBRÁZKŮ PODLE BANKY v3 (por-4.0)
- Banka v3 (inspirovaná WISC): 35 skórovaných položek T1–T12, velikost výběru R roste s délkou až na 16
  možností (od T6 žádné úlohy typu „6 ze 7“); 2 nácvikové položky + 1 náhradní.
- Skórování: T1 = 1/0 bodů, od T2 = 2/1/0 (max. 67 bodů). Ukončení: 3 položky za sebou 0 bodů.
- Časování podle v3: obrázek 1000 ms, pak 150 ms prázdno, po posledním obrázku 250 ms. V testu se obrázek
  už nepřesouvá do okénka (okénko se jen označí jako „viděno“); animace přesunu zůstává jen v úvodní ukázce.
- Struktura položek (T, R, počet rušivých) převzata beze změny, obsazení obrázky vyváženo: každý obrázek je
  cílem 4–5× (v dodané bance 1–14×, 13 obrázků nikdy) a rušivým 3–4× (dříve 1–21×); cíle předchozí položky se
  v další neobjeví (v dodané bance 30 případů); v jedné řadě nejsou silně asociované dvojice (klíč–zámek,
  ponožka–bota, auto/autobus/vlak, slunce/měsíc/hvězda/mrak, jablko/hruška/třešně, dort–dárek, kočka–pes,
  loď–ryba). Vyvážená banka a skript: docs/picture_span/.

ZMĚNY VE VERZI 3.33.1 – POŘADÍ OBRÁZKŮ: PLYNULÝ PŘECHOD
- Předváděný obrázek se jemně objeví (120 ms) a během 150ms pauzy plynule zmizí, místo tvrdého bliknutí.
  Celkové časování (1000 ms + 150 ms) beze změny.

ZMĚNY VE VERZI 3.33.2 – POŘADÍ OBRÁZKŮ: OPRAVA PŘESKAKOVÁNÍ
- Chyba: dvojklik na „Hotovo“ (nebo klik během zpětné vazby) vyhodnotil odpověď dvakrát – v nácviku se
  přeskočila položka (i s předvedením obrázků), v testu by se položka zapsala dvakrát a jedna by se přeskočila.
- Oprava: odpověď se vyhodnotí jen jednou; během předvádění, vyhodnocení a zpětné vazby jsou výběr obrázků,
  „Zpět“, „Nevím“ i „Hotovo“ zablokované a uvolní se až na obrazovce odpovědi.

ZMĚNY VE VERZI 3.33.3 – ZVUK ČÍSLIC NA iOS (Poslední čísla, Čísla pozpátku)
- Příčina: na iPhonu/iPadu ztiší přepínač ztlumení (a režim Nerušit) zvuk přehrávaný přes Web Audio, a iOS
  navíc uspí zvukový kontext např. po přepnutí aplikace. Odemknutí zvuku také neproběhlo celé uvnitř klepnutí.
- Oprava: odemknutí probíhá synchronně v klepnutí: zvuková relace „playback“ (Safari 16.4+), smyčka tichého
  zvuku (obchází přepínač ztlumení), probuzení AudioContextu tichým vzorkem, ztlumené nabuzení souborů číslic.
  Každé další klepnutí zvuk znovu probudí; když je kontext přesto uspaný, řada se přehraje záložně přes <audio>.
  Do stavu zvuku (DIGIT_AUDIO.status()) přibyl údaj ctx a last (který způsob přehrání byl použit).

ZMĚNY VE VERZI 3.34.0 – NOVÉ BANKY POSLEDNÍ ČÍSLA A ČÍSLA POZPÁTKU
- Poslední čísla (rds-2.1): forma A nahrazena zadanou bankou (K1–K9 × 3, U = 2/4/6; všechny cíle ověřeny).
  Nově úvodní položka K1-A0 „2 1 → 1“ – vždy první, pak K1–K9 (U uvnitř úrovně náhodně jako dřív).
  Úvodní položka se počítá do skóre, ale ne do pravidla ukončení (úrovně dál po 3 položkách).
  Forma B beze změny, jen s tou samou úvodní položkou (K1-B0).
- Čísla pozpátku (db-1.1): nová banka 18 položek (K2, K3a s číslicemi 1–5, K3–K9) + na začátek „2 3 → 3 2“;
  úroveň K2 má tedy 3 pokusy. Ukončení: celá úroveň bez správné odpovědi (K2: 0/3, ostatní 0/2).

ZMĚNY VE VERZI 3.34.1 – JEDNODUŠŠÍ ZÁCVIK U ČÍSEL, UKONČENÍ POSLEDNÍCH ČÍSEL
- Čísla pozpátku (db-1.2): zácvik jen dvě dvojice „1 2 → 2 1“ a „4 6 → 6 4“ (dřív trojice), pak test.
  Chyby v zácviku test nezneplatní, jen se zapíšou (nacvik_chyby).
- Poslední čísla (rds-2.2): ukázka „5 6 7 → 6 7“; zácvik jedna krátká řada „1 2 3 → 2 3“, při chybě ještě
  „4 5 6 → 5 6“, pak test (nacvik_chyby ve skóre).
- Ukončení Posledních čísel: úroveň bez jediné zcela správné odpovědi (0/3). Zrušeno dřívější „dvě úrovně po sobě
  nejvýš 1/3“. Poziční (částečné) body se dál ukládají u každé položky.

ZMĚNY VE VERZI 3.34.2 – SLOVNÍ ÚLOHY: MÍRNĚJŠÍ NÁSTUP (zivot65-v3s)
- Start podle věku níž: 8–9 let SU05, 10–11 SU07, 12–15 SU11, 16+ SU14 (dřív SU06/SU11/SU17/SU22).
- Přeskakování (s připsáním) až po 3 správných za sebou (dřív po 2) – test neutíká tak rychle do procent a více kroků.
- Přeřazeny úlohy, jejichž odhad obtížnosti byl zjevně nízký: SU24 (jízdní řád v minutách) b −0,6 → 0,6,
  SU27 (399 × 12) −0,3 → 0,2, SU29 (tempo 5,5 min) −0,1 → 0,35, SU22 −0,8 → −0,6, SU23 −0,7 → −0,45
  (původní hodnota uložena jako b_puvodni). Nová verze = samostatná skupina srovnání.

ZMĚNY VE VERZI 3.34.3 – SKLÁDÁNÍ PAPÍRU (Gv-PAP-v5-r2)
- Oprava přeskakování nácviku: dvojklik na „Hotovo“ (nebo klik během zpětné vazby) vyhodnotil položku dvakrát
  a přeskočil další. Teď se každá položka vyhodnotí jen jednou (týká se i Pohledu na stavbu).
- Ukončení: pevně po 3 chybách za sebou (položka je správně jen při úplně správném rozmístění všech dírek),
  bez ohledu na obecné nastavení baterie. Pak ještě 3 sondy z nejtěžší třetiny (do skóre se nepočítají).
- Nové pořadí podle odhadu obtížnosti (počet přeložení, částečné přeložení, úhlopříčka, trojúhelníkový výstřih,
  počet dírek): jednoduché trojúhelníkové úlohy s jedním přeložením (PAP_031–034) jsou teď hned po úhlopříčných,
  před dvojím přeložením; nejtěžší jsou trojúhelníky s částečným dvojím přeložením. Původní pořadí v poli poradi_v1,
  odhad v obtiznost_odhad.

ZMĚNY VE VERZI 3.35.0 – EXPORT PO POLOŽKÁCH
- V administraci (Kognitivní baterie → přehled) nový řádek „Položky po testech (HS za položku)“: vyberete test
  a stáhnete CSV v širokém formátu – řádek = sezení, sloupec = položka, hodnota = body za položku
  (skore; kde není, spravne; u dotazníků odpoved). Prázdné pole = položka nebyla zadána.
- Jen ostré položky (bez nácviku); sondy po ukončení volitelně (zaškrtávátko „včetně sond“) jako sloupce sonda_ID na konci.
- Úvodní sloupce: session_id, anon_id, code, mode, age, pohlavi, forma (verze testu), HS_celkem, pripsane, konec,
  zadano_polozek. Sloupce položek seřazené podle ID (přirozené řazení).

ZMĚNY VE VERZI 3.36.0 – ID POLOŽEK, ČÍSELNÍK, SLUČOVÁNÍ PODLE OSOBY
- Každý řádek odpovědi má stabilní ID položky. Nově i Matice (dřív jen pořadové číslo): matice_1 … matice_50.
- Číselník položek: assets/codebook.csv (tlačítko „Číselník položek (CSV)“ v administraci). Pro 18 testů:
  test, verze, pořadí v bance, ID, znění/popis, správná odpověď, úroveň/obtížnost, poznámka. Generátor
  docs/codebook_generator.py (spustit znovu po změně bank).
- Export po položkách: řádek = OSOBA (všechna její sezení dohromady; veřejná verze podle anonymního
  identifikátoru, vaše verze podle kódu osoby). Při opakování položky platí první pokus; sloupec „sezeni“
  vypisuje čísla sloučených sezení. HS_celkem = první dokončený výsledek testu. Nově i dotazníky (ADHD, maskování).
- Korelační matice: počítá se po osobách (sezení sloučená, vaše verze podle kódu), u opakovaného testu
  z PRVNÍHO dokončeného výsledku (dřív posledního a vaše verze se neslučovala).
- Číselník: nový sloupec „valence“ – u ADHD položek REV_01 … REV_17 „obrácená – před sčítáním rekódovat 4 − odpověď“,
  ostatní „+“; u maskování „+“, X = chybějící. Export po položkách obsahuje surové odpovědi (nerekódované).

ZMĚNY VE VERZI 3.36.1 – DUPLICITNÍ VÝSLEDKY A POČTY V ADMINISTRACI
- Chyba: aplikace mohla stejnou dávku odeslat dvakrát současně (pomalá odpověď serveru + další uložení), takže se
  výsledky testů (hlavně ADHD s mnoha dílčími skóry) zapsaly vícekrát. Odpovědi (řádky) server duplikovat nenechal.
- Oprava v aplikaci: odesílá se vždy jen jedna dávka; odeslané položky se z fronty odebírají průběžně.
- Pojistka na serveru: druhý výsledek téhož testu a verze ve stejném sezení se ignoruje.
- Administrace: tabulka výsledků má sloupce Osob (různí účastníci s dokončeným testem), Sezení, Záznamů; při
  výskytu starých duplicit se zobrazí upozornění a tlačítko „Odstranit duplicity“ (ponechá první záznam).
- Srovnání pro účastníky (rozložení skórů) bere jednu – první – hodnotu na osobu.

ZMĚNY VE VERZI 3.36.2 – POSLEDNÍ ČÍSLA: JEDNA FORMA (rds-2.3)
- Jako u Čísel pozpátku jen jedna banka pro všechny (dřívější forma A; úvodní „2 1 → 1“ + K1–K9 × 3).
  Stará forma B (s nulami) z banky odstraněna; nastavení formy baterie na tento test už nepůsobí.

ZMĚNY VE VERZI 3.37.0 – SROVNÁNÍ NAPŘÍČ VERZEMI, PŘEHLEDNĚJŠÍ ADMINISTRACE
- Srovnání pro účastníky spojuje verze: Poslední čísla rds-2.0–2.3, Čísla pozpátku db-1.0–1.2, Dedukce (všechny
  verze DED-40), Jak se to nazývá v1+v2, Všeobecné znalosti v1+v2, Slovní úlohy v2/v2s/v3s, Matice v10-50/b/c,
  Váhy (46 položek zvlášť, 39 položek zvlášť), Skládání papíru v5/v5-r2, SRCE v06–v08 (starší verze server
  přepočítá na „počet správně“, aby se shodovaly se skórem v08). Pořadí obrázků NEspojeno – verze mají jiné
  body i jiný počet položek (1.x poziční body, 2.x 18 položek, 3.0 30 položek, 4.0 35 položek).
- Administrace: „Výsledky podle testů“ ukazují jen současné verze (verze s nejnovějším výsledkem), seřazené
  podle oblastí a s českými názvy; starší verze a odvozené údaje (DSM počty, staré subškály) jsou ve sbaleném
  oddílu „Starší verze a odvozené údaje“.
- Korelace v administraci: od 10 osob; bez počtů DSM symptomů a starých odvozených klíčů; seřazeno Gf → Gc → Gv →
  Gwm → Gs → školní dovednosti → škály, oblasti oddělené silnou čarou; české názvy.

ZMĚNY VE VERZI 3.38.0 – POSLEDNÍ ČÍSLA (UKÁZKA), EFEKTIVITA ČTENÍ, NÁZVY
- Poslední čísla: nová pomalá ukázka (asi 25 s) – nahoře řádek „Zaznělo“, dole dvě velká okénka „Pamatuji si
  poslední dvě“; nové číslo se zvýrazní, nejstarší viditelně vypadne (přeškrtnuté, zešedlé). Každý krok má větu.
- Efektivita čtení (SRCE-v09): hlavní skór opět správně − chybně. Jedna jednotná banka místo forem A/B: 134 vět
  (3 úvodní z A, 3 z B, pak proložené), seřazené tak, aby po sobě nešly věty se stejným podmětem (v rámci
  3 vět), stejným dějem (v rámci 2 vět) ani stejným typem scény a aby správná strana nebyla víc než 3× za sebou.
  Srovnání spojuje v06–v09 (v08 server přepočítá na správně − chybně).
- Názvy: Dedukce → Tvarové klíče (menu, nadpis, administrace). Matice, Shodné řady, Poslední čísla, Efektivita
  čtení beze změny.

ZMĚNY VE VERZI 3.38.1 – ZVUK ČÍSLIC: NIC „PŘES SEBE“
- Chyba z 3.33.3: při odemykání zvuku se na iOS krátce přehrály všechny číslice najednou (iOS ignoruje ztlumení
  zvukových prvků) – při spuštění testu i při „Přehrát znovu“. Nově se prvky odemykají tichým zvukem a jen jednou.
- Pojistka proti dvojímu spuštění ukázky při dvojkliku na „Zahájit subtest“ (Poslední čísla, Čísla pozpátku).

ZMĚNY VE VERZI 3.38.2
- Tichá zvuková smyčka (obchází přepínač ztlumení) běží jen na iPhonu/iPadu a jen v úlohách s čísly; po návratu
  do menu se zastaví. Na Macu se tak přestane ukazovat „přehrávání“ na Touch Baru.

ZMĚNY VE VERZI 3.39.0 – TVAROVÉ KLÍČE: NOVÁ BANKA 24 POLOŽEK (DED-24-v1.0)
- Obtížnost se nově řídí typem nutného úsudku (ne počtem vztahů), podle „lidského“ řešiče s hierarchií technik:
  T1 vztah s jedinou neznámou · T2 průnik kandidátů na jednom uzlu · T3 šíření kandidátů přes neznámé uzly ·
  T4 hypotéza a spor. Úrovně: 1 přímé použití (2) · 2 řetěz 2 kroků (2) · 3 řetěz 3 kroků (2) · 4 průnik (3) ·
  5 šíření kandidátů se vstupním bodem (3) · 6 bez vstupního bodu, průnik/rovnost (3) · 7 bez vstupního bodu,
  šíření (3) · 8 hypotéza, malá síť do 6 uzlů (3) · 9 hypotéza, po odvození zůstávají ≥3 kandidáti (3).
- Ponechány fungující položky (ID beze změny, kotvy pro propojení s pilotem): D01, D04, D07, D09, D18, D23, D27,
  D28, D26, D31, D36. Vyřazeny logické duplikáty (D02–D03, D05–D06, D08, D10–D17, D19–D22, D24–D25), chybně
  zařazené dlouhé řetězy D29 a D34 a velké sítě D30, D32–D35, D37–D40. Nové položky D41–D53 (každý vztah nutný,
  cíl jednoznačný, sítě nejvýš 7 uzlů, rozložení bez křížení). Správné odpovědi vyvážené (4–5× každý tvar).
- Zácvik začíná neotočeným pravidlem (tvar nahoře je dán, doplňuje se dvojice), pak spojení. Ukázky v testu:
  T3 (řetěz) před úrovní 2, T4 (průnik) před úrovní 4, nová T5 (stejné tvary ve dvou dvojicích) před úrovní 6.
- Časy: úrovně 1–5 bez limitu (jen pobídka), 6: 75 s, 7: 90 s, 8–9: 120 s. Nová verze = samostatná skupina
  srovnání. Řešič, generátor a podklady: docs/dedukce_v2/. (Směrování DED_ROUTE nechat vypnuté – počítalo se
  starým pořadím položek.)

ZMĚNY VE VERZI 3.39.1 – TVAROVÉ KLÍČE: ODDĚLENÍ ÚROVNÍ 8 A 9 (DED-24-v1.1)
- Úroveň 9 dřív odlišovalo hlavně víc současně rozpracovaných uzlů (spíš zátěž pracovní paměti). Nově je rozlišuje
  „jádro sporu“: nejmenší počet vztahů, které je nutné spojit, aby se vyvrátila chybná hodnota cíle.
  Úroveň 8 (D49–D51): jádro 3 vztahy, po běžném odvození zůstávají 3 kandidáti.
  Úroveň 9 (D54–D56, nové): jádro 4 vztahy – vyvrácení vyžaduje spojit celou síť –, a přitom zůstávají jen
  2 kandidáti (méně rozpracovaného než u úrovně 8); 7 uzlů, 4 vztahy. Hlubší úsudek, ne víc věcí v paměti.
- Vyřazeny D36 (8 uzlů, 7 rozpracovaných uzlů), D52, D53. Odpovědi vyvážené (A, C, D, E 5×, B 4×).

ZMĚNY VE VERZI 3.39.2 – TVAROVÉ KLÍČE: ŽÁDNÉ STRUKTURÁLNÍ KLONY (DED-24-v1.2)
- Kontrola izomorfie (stejný graf se zachováním rolí rodič/děti, cíle a odkrytých uzlů) v rámci každé úrovně.
  Nalezeny klony D49 = D50 = D51 (úroveň 8) a D07 = D09 (úroveň 2). D50 a D51 nahrazeny novými D57, D58
  (stejné parametry: jádro sporu 3, větvení 3, ale jiná struktura), D09 nahrazena původní D13 (jiná struktura
  řetězu, pilotní data). Žádné dvě položky téže úrovně nejsou izomorfní.
- U každé položky se ukládají zvlášť refutation_core (kolik vztahů musí vstoupit do vyvrácení chybné hodnoty)
  a branching (kolik kandidátů cíle zůstává po běžném odvození), plus technika a vstupní bod – v bance,
  v číselníku i ve facetách každé odpovědi, aby pilot ukázal, co obtížnost skutečně predikuje.

ZMĚNY VE VERZI 3.40.0 – MATICE: 6 NOVÝCH NEJTĚŽŠÍCH POLOŽEK (v10-56)
- Strop byl u nadprůměrných dospělých nízký (první anglická data: 5 ze 6 lidí 44–47/50). Přidány položky 51–56
  (úroveň 11), každá jiný druh relačního úsudku, ne víc prvků:
  51 řada se zrychlujícím otáčením (pravidlo druhého řádu: kroky 45°, 90°, 135°, …) · 52 průnik (co je v obou) ·
  53 složení operací (sjednotit, pak otočit) · 54 rozdíl úhlů (první minus druhá) · 55 podmíněná transformace
  (stejná barva → výměna + otočení, různá → jen otočení) · 56 skládání z různých zdrojů (vnějšek = vnitřek
  prvního, vnitřek = vnějšek druhého).
- Kontrola: žádné dvě možnosti nevypadají stejně, správná odpověď se nikde neobjevuje v zadání, distraktory jsou
  typické chyby (konstantní krok, opačný směr, jiná logická operace, záměna zdrojů…). Pozice odpovědí A–E 11–12×.
- Nová verze = samostatná skupina srovnání (maximum 56). Podklady: docs/matice/.

ZMĚNY VE VERZI 3.40.1 – SROVNÁNÍ ZAHRNUJE I ANGLICKOU VERZI
- Grafy „jak jste na tom oproti ostatním“ u Matic, Vah a Tvarových klíčů započítávají i výsledky z anglického
  pluginu (Cognitive Battery EN), pokud je na webu nainstalovaný. Čte se živě z tabulek wp_kben_*, nic se nekopíruje
  ani nemění. České výsledky importované do anglické verze se vynechávají (nikdo se nepočítá dvakrát), za každou
  osobu se bere první výsledek a platí stejné verze/skupiny verzí jako u českých dat.
- Korelace a exporty v české administraci zůstávají jen z českých dat.

ZMĚNY VE VERZI 3.40.2 – Srovnání zahrnuje anglické výsledky i u Skládání papíru a Mentální rotace.

ZMĚNY VE VERZI 3.41.0 – DOPLNĚNÍ JEN NOVÝCH ÚLOH
- Kdo ve veřejné verzi dokončil starší verzi Matic až do konce (v10-50, v10-50b, v10-50c), uvidí v menu
  „6 nových úloh – stačí doplnit je“. Po potvrzení dostane jen položky 51–56 (bez nácviku, bez vracení, s běžným
  ukončením po chybách). Výsledek = dřívější hrubý skór + správně vyřešené nové úlohy, uloží se jako verze v10-56
  s údaji rozsireni = 1, puvodni_hruby, puvodni_verze, nove_spravne (v analýze lze takové osoby odlišit).
- Kdo starší verzi nedokončil (ukončení po chybách), dostane celý test znovu – nové úlohy by pro něj byly nad stropem.
- Mechanismus je obecný (TEST_EXTENSIONS v app.html): u dalšího rozšíření jiného testu stačí doplnit jeden řádek.

ZMĚNY VE VERZI 3.42.0 – NOVÝ TEST „HLEDÁNÍ PRAVIDLA“ (Gf – indukce, HP-36-v1.0)
- Převzat z pilotní verze (36 položek, úrovně 1–5, 2 cvičné úlohy): tři příklady vstup → výstup, odpověď se
  sestaví z objektů (barva × tvar × velikost), záleží na pořadí; „Nevím, přeskočit“ = chyba.
- V baterii: menu Gf vedle Matic; instrukce s předčítáním, tykání/vykání podle věku; časový limit podle úrovně
  (45/60/90/120/150 s, posledních 20 s jemný pruh, po limitu se odevzdá rozpracovaná odpověď); ukončení po
  5 chybách v řadě, pak 3 sondy (do skóre se nepočítají); navázání rozpracovaného testu.
- Ukládá se u každé položky: odpověď i správné řešení (JSON), správně, čas, čas do první akce, počet akcí,
  přeskočeno, vypršení limitu. Číselník obsahuje pravidlo a parametry každé položky.
- Srovnání na české stránce zahrnuje i anglické výsledky. Původní prototyp: docs/hledani_pravidla/.

ZMĚNY VE VERZI 3.42.1 – Hledání pravidla na mobilu: vstup → výstup v jednom řádku, menší objekty a ovládací prvky
(celá úloha zhruba na jednu obrazovku); zpětná vazba v zácviku se sama posune do zorného pole.

ZMĚNY VE VERZI 3.42.2 – Hledání pravidla, cvičná úloha 1: příklady měly vždy střední → malý, takže pravidlo
„zmenší se o stupeň“ sedělo stejně jako „zmenší se na malý“ a pro velký trojúhelník v úkolu dávalo jinou odpověď.
Druhý příklad je nově velký → malý. Kontrola docs/hledani_pravidla/audit.py (všechny kombinace jednoduchých změn
barvy/tvaru/velikosti) jinou dvojznačnost v bance nenašla.

ZMĚNY VE VERZI 3.43.0 – TVAROVÉ KLÍČE: ČASOVÉ LIMITY PODLE PILOTU (DED-24-v1.3) A PŘEPOČET DAT
- Tvrdý limit u všech úrovní, kalibrovaný podle časů správných odpovědí v pilotu (ne mechanicky podle obtížnosti):
  úroveň 1: 30 s · 2: 45 s · 3: 60 s · 4: 120 s · 5: 150 s · 6: 75 s · 7: 90 s · 8–9: 120 s.
  (Úrovně 4–5 – průnik a šíření kandidátů – jsou časově náročnější než 6–9.) Informace o čase je v úvodu testu.
- Přepočet dosavadních dat (DED-24 v1.0–v1.2): tlačítko „Přepočítat Tvarové klíče podle nových limitů“ v přehledu
  administrace. Odpověď po novém limitu se počítá jako chybná (původní hodnota v spravne_puvodni, příznak
  po_novem_limitu); skóre se přepočítá i s ukončením po 5 chybách v řadě (původní v hruby_puvodni). Opakované
  spuštění nic nemění. V anglických datech pilotu se to týká 6 správných odpovědí (úrovně 3–5).
- Srovnání spojuje DED-24-v1.2 (přepočtenou) a v1.3.

ZMĚNY VE VERZI 3.44.0 – ČASOVÉ LIMITY PODLE PILOTU U DALŠÍCH TESTŮ
Tvrdý limit (po něm se odevzdá rozpracovaná odpověď a počítá se jako chyba; 15 s před koncem upozornění);
v datech u každé odpovědi timeout a time_limit_ms. Nastaveno tak, aby odřízlo jen málo dosavadních správných řešení.
- Matice (v10-56t): úrovně 1–8 90 s, 9–11 120 s.
- Váhy (v2-39-ui3-bl): podle bloku A–D 30 s, E–F 45 s, G 60 s, H 75 s, J 90 s, K 180 s (u K jen pojistka –
  blok K je kandidát na úpravu položek). Náhodné rameno „bez limitu“ ukončeno; text pod zadáním ukazuje skutečný limit.
- Skládání papíru (Gv-PAP-v5-r2t): úrovně 1–5 30 s, 6 90 s, 7–8 60 s.
- Mentální rotace (MR-v5-50t): úrovně 1–3 45 s, 4–7 120 s, 8 150 s (zatím málo dat – provizorní).
- Hledání pravidla (HP-36-v1.1): úroveň 4 90 s (ostatní beze změny 45/60/90/–/150 s).
- Srovnání pro účastníky spojuje starší a novou verzi každého testu (rozdíl limitů se týká jen několika procent odpovědí).
- Oprava: časovače se po opuštění testu zruší (dřív mohl doběhnout limit po návratu do menu).

ZMĚNY VE VERZI 3.44.1 – Nejkratší tvrdý limit u Skládání papíru a Vah je 45 s (dřív 30 s u lehkých úrovní/bloků):
Papír úrovně 1–5 45 s; Váhy bloky A–F 45 s, G 60 s, H 75 s, J 90 s, K 180 s.

ZMĚNY VE VERZI 3.45.0 – TVAROVÉ KLÍČE: NOVÉ ÚROVNĚ 8–9 (DED-24-v2.0)
- Úrovně 8–9 nahrazeny položkami D59–D64 (dříve experimentální X01–X06): po běžném odvození zůstávají 3–4 kandidáti
  a ani při řešení jen části sítě se cíl nezúží pod 3 (u D62 nezúží vůbec) – tipování „50:50“ zmizelo. Jádro sporu
  3 (úroveň 8) a 4 (úroveň 9), sítě 6–7 uzlů, žádné dvě strukturálně stejné sítě (kontrola i bez ohledu na barvy
  a polohu cíle). Původní D49, D54–D58 vyřazeny (jejich data zůstávají). Nová verze = samostatná skupina srovnání.
- Srovnání na české stránce zahrnuje anglické výsledky i u Posledních čísel, Čísel pozpátku, Pořadí obrázků,
  Symbolů a čísel a Shodných řad (u číselných úloh jde o jiný jazyk nahrávek – při analýze rozlišovat podle mode).

ZMĚNY VE VERZI 3.45.1 – Školní testy umí volitelný tvrdý limit na položku (capSec); v české verzi zatím nevyužito,
v anglické verzi 90 s u Arithmetic a Word Problems.

ZMĚNY VE VERZI 3.46.0 – EFEKTIVITA ČTENÍ: SKUTEČNĚ PROMÍCHANÁ BANKA (SRCE-v10)
- Dosavadní pořadí sice střídalo podměty, ale drželo původní řazení forem: děje jako hází, chytá, kope, honí, tlačí,
  táhne, pije, jí, staví se objevovaly až od 57.–127. věty, takže je za 2 minuty skoro nikdo neviděl.
- Nové pořadí (po 6 úvodních větách): pokaždé se vybere věta s dějem, který nejdéle nezazněl, a s typem scény, který
  nejdéle nebyl; dál platí: stejný podmět ne ve 3 po sobě jdoucích větách, stejný děj ne ve 4, správná strana nejvýš
  3× za sebou. Všech 24 dějů se objeví v prvních 46 větách.
- Nové pořadí mění obtížnost začátku, proto je verze v10 ve srovnání samostatně.

ZMĚNY VE VERZI 3.47.0 – Bez časového limitu na zadávání odpovědi u Posledních čísel, Čísel pozpátku (dřív technická
pojistka 20 s – nevyplněná místa se doplnila „?“) a Pořadí obrázků (dřív 40 s).

ZMĚNY VE VERZI 3.47.1 – Efektivita čtení: verze v10 (jen nové pořadí vět) se ve srovnání opět spojuje s v06–v09.

ZMĚNY VE VERZI 3.48.0 – NOVÝ TEST „STANOVIŠTĚ“ (Gf – deduktivní úsudek, ST-35-v1.0)
- Převzat ze zjednodušeného pilotu (35 položek, úrovně −4 až +4): síť barevných stanovišť spojených cestami, na každém
  jeden objekt a jedno volné místo; úkolem je najít jediné stanoviště, kam patří zlatý žeton, aby platila všechna
  obrázková pravidla (barva, spolu, vedle, dva kroky, skupina objektů, přeškrtnuté = neplatí). Menu Gf vedle Hledání pravidla.
- Úvod: text s předčítáním + 6 karet s principy (tykání/vykání podle věku); 3 cvičné úlohy se zpětnou vazbou (po druhé chybě
  se ukáže řešení s vysvětlením); N3 záměrně procvičuje „u skupiny stačí jeden objekt“, na čemž stojí 16 položek testu.
- Průběh: všech 35 položek popořadě, tvrdý limit 75 s na položku (15 s před koncem upozornění, ?untimed=1 vypne),
  ukončení po nastaveném počtu chyb v řadě (veřejná verze 5), pak 3 sondy; navázání rozpracovaného testu.
- Ukládá se: odpověď a řešení (číslo stanoviště), správně, čas, čas do první akce, počet klepnutí a změn odpovědi,
  log voleb s časy, vypršení limitu; ve facetách úroveň, počet a druhy pravidel, negace, skupiny, topologie a metriky
  banky (single/omit-one domény, kritická pravidla). Číselník obsahuje pravidla a metriky každé položky.
- Úpravy proti pilotu (podklady a ověřovací skript docs/stanoviste/):
  * P19 a P20 měly při přirozeném čtení „není vedle“ (tj. i na stanovišti samotného objektu) dvě řešení – P19: objekty D a B
    si vyměnily stanoviště, P20: stanoviště 5 je zelené. Všech 35 položek má teď jediné řešení při obou čteních.
  * Rozložení BOW6 (11 položek): dvě prostřední stanoviště se překrývala – roztaženo, propojení beze změny.
  * Skupina v pravidle ukazuje všechny své objekty (pilot ukazoval nejvýš 3, u 10 pravidel jich mají skupiny 4).
  * Barvy stanovišť bezpečné pro poruchy barvocitu (nejmenší rozdíl ΔE ≈ 27 místo ≈ 11 – oranžová a zelená byly
    pro deuteranopy téměř stejné); zlatý žeton se už nedá splést s objektem „velký pruhovaný oblázek“.
- Srovnání na české stránce zahrnuje i anglické výsledky. V administraci je test (i Hledání pravidla) ve skupině Gf.

ZMĚNY VE VERZI 3.49.0 – STANOVIŠTĚ: NOVÝ NÁVRH (ST2-36-v1.0), NAHRAZUJE ST-35
Cíl: deduktivní (sekvenční) usuzování jako Elliot, ale krátké položky, malý slovník a obtížnost ze struktury úsudku.
- Síť 4–6 barevných stanovišť; část objektů stojí pevně, ostatní se rozmisťují; na každém stanovišti nakonec právě jeden
  objekt a žádné nezůstane prázdné. Otázka vždy na JEDEN označený objekt („Kam patří …?“) – odpověď = jeho umístění.
  Ostatní objekty lze rozmístit jako pomůcku (neskórují se, ukládá se celé rozmístění a průběh tahů).
- Jen 4 druhy pravidel: vedle · není vedle · na barvě · není na barvě; pravidlo je nakreslené jako výřez mapy,
  přeškrtnutí = neplatí. Žádné další symboly během testu; nejvýš 4 pravidla v položce.
- 36 položek v 6 úrovních podle generátoru: 1–4 = hloubka odvození (1, 2, 3, 4+ kol), 5 = jedna krátká úvaha
  „co kdyby“ (vyvrácení), 6 = více nebo delších vyvrácení. Od úrovně 3 vždy 6 stanovišť a 3–4 pravidla, takže
  obtížnost nedělá počet prvků. V některých položkách o cílovém objektu žádné pravidlo nemluví (zbude na něj místo).
- Banka ověřená úplným výčtem: cíl má jediné místo, každé pravidlo je nutné, chybná stanoviště jsou „skoro správně“
  (porušují jen jedno pravidlo; u 5 položek – S20–S22, S26, S27 – je jedna chybná možnost slabší). Metriky v bance, číselníku i facetách.
- 3 cvičné úlohy (barva; vedle + není vedle; cíl bez vlastního pravidla). Limit 60 s (úrovně 1–2), 90 s (3–4),
  120 s (5–6) – provizorní, ke kalibraci po pilotu; ukončení po chybách v řadě, sondy, navázání.
- Podklady: docs/stanoviste/gen.py (generátor + solver + model řešení), přehled položek; ST-35 v st35_puvodni/.

ZMĚNY VE VERZI 3.50.0 – ČASOVÉ LIMITY: TVAROVÉ KLÍČE (DED-24-v2.1) A STANOVIŠTĚ
- Tvarové klíče: utažené limity podle prvních protokolů DED-24-v2.0 (skóry 17–24/24, retrospektivně tato varianta
  ubere v průměru ~1,3 bodu a zvýší SD z ~2,8 na ~3,9, aniž by z testu dělala rychlostní test). Žádný limit pod 30 s.
  úroveň 1: 30 s · 2: 30 s (dříve 45) · 3: 45 s (60) · 4: 100 s (120) · 5: 120 s (150) · 6: 60 s (75) · 7: 75 s (90) · 8–9: 100 s (120).
  Původní limit zůstává v bance jako cap_puvodni. Nová verze = samostatná skupina srovnání (DED-24-v2.0 zůstává zvlášť).
  Pozn.: strop testu víc než čas omezují horní položky – D27, D28, D41–D44 mají v pilotu téměř všichni správně,
  rozlišují hlavně D26 a D59–D64; další krok je zesílit horní položky, ne dál zkracovat čas.
- Stanoviště (ST2-36-v1.0): limity jako u Tvarových klíčů – úrovně 1–3 45 s, úrovně 4–6 60 s (dříve 60/90/120 s).

ZMĚNY VE VERZI 3.51.0 – TVAROVÉ KLÍČE: PŘEPOČET DOSAVADNÍCH DAT PODLE NOVÝCH LIMITŮ
- Výsledky DED-24-v2.0 (a obecně všechny DED-24-v2.x) se přepočítají podle současných limitů (DED-24-v2.1) automaticky
  při prvním otevření administrace po aktualizaci; stav a tlačítko „Přepočítat znovu“ jsou v přehledu.
  Odpověď za limitem své úrovně = chybná (spravne_puvodni, po_novem_limitu), přepočítá se skore pro export po položkách
  a ukončení po 5 chybách v řadě; původní skór v hruby_puvodni. Účastníkům se tak ve srovnání, v „Mých výsledcích“
  i v korelacích zobrazují korigované hodnoty. Srovnání spojuje DED-24-v2.0 (přepočtenou) a v2.1.
- Přepočet počítá vždy z původní správnosti: při další změně limitů stačí upravit tabulku limitů a značku
  v includes/admin.php (kb_ded_caps, KB_DED_CAPS_TAG) a data se přepočítají znovu.
- Oprava: přepočet z verze 3.43.0 (v1.3) měnil jen „spravne“, ale export po položkách bere „skore“ – srovnáno.
- Ověřeno na testovacích datech: skór, ukončení, nedotčení starších verzí, opakované spuštění, opětovný přepočet.

ZMĚNY VE VERZI 3.52.0 – TVAROVÉ KLÍČE PODLE DAT (DED-24-v2.2): POŘADÍ ÚROVNÍ A LIMITY
Podklad: 45 sezení DED-24-v1.2/v2.0 (41 z anglické verze – zájemci o kognitivní testování z Redditu, tedy nadprůměrní
dospělí; 4 české), Raschův model kvůli ukončení po chybách. Podrobně docs/dedukce/analyza_2026-10/.
- Pořadí: obtížnost úrovní není monotónní. Úroveň 6 (D26, D45, D46; b ≈ +1,2) je těžší než úroveň 7 (b ≈ −0,2),
  úrovně 3–5 a 7 jsou zhruba stejně těžké. Nové pořadí úrovní 1-2-3-4-5-7-6-(8+9), uvnitř úrovní od nejlehčí položky;
  úrovně 8 a 9 (stejný typ) jsou jeden blok seřazený podle obtížnosti. Ukázky typů úloh zůstávají na svém místě.
- Limity (správné odpovědi uťaté limitem v tomto vzorku): limity verze v2.1 brály u rozlišujících úrovní 6–9
  16–30 % správných řešení i nadprůměrným dospělým (a u úrovně 3 11 %) – to už je měření rychlosti, ne usuzování.
  Nově: 1: 30 s · 2: 30 s · 3: 60 s · 4: 100 s · 5: 100 s · 6: 90 s · 7: 90 s · 8–9: 120 s (nikde pod 30 s).
  Úrovně 4–5 jsou snadné, ale pomalé (95 % správných do ~100–110 s) – 100 s ubere ~3 % správných.
  Úrovně 6–9 měly limit vždy, jejich časy jsou useknuté (správná řešení až těsně pod limitem) – kratší limit tam nejde
  z dat obhájit. U běžné populace a dětí budou časy delší než v tomto vzorku.
- Přepočet dosavadních dat (automaticky po aktualizaci) používá limity v2.2; v2.0, v2.1 a v2.2 se ve srovnání spojují
  (liší se jen pořadím a limity, které přepočet sjednotí). Odpovědi, které ve v2.1 vypršely, zůstávají chybné.
- Pro strop pomůže víc zesílit horní položky než krátit čas: nejslabší jsou D42 (b −1,6, úroveň 4), D47 (−1,0, úr. 7)
  a D62 (−0,1, úroveň 9); nejtěžší jsou D26, D59, D64 a D60 (b +1,6 až +2,6).

ZMĚNY VE VERZI 3.53.0 – ČASOVÉ LIMITY OSTATNÍCH TESTŮ PODLE DAT
Kritérium: limit nemá utnout víc než zhruba 10 % správných odpovědí (data 2026-10, převážně nadprůměrní dospělí
z anglické verze; u běžné populace budou časy delší). Podklady: docs/casove_limity_2026-10/.
- Váhy (v2-39-ui3-bl2): blok J 90 → 150 s (utínal 17 % správných, nově ~9 %), blok K 180 → 210 s (12 % → ~8 %).
  U bloku K trvá 90 % správných řešení i bez limitu až ~5 minut – to je otázka položek, ne limitu (kandidát na úpravu).
  Ve srovnání spojeno s v2-39-ui3-bl.
- Beze změny (utínají nejvýš ~7 %): Matice, Skládání papíru, Mentální rotace, Hledání pravidla (úroveň 4 při 90 s:
  v době limitu 120 s byla nad 90 s jen 1 ze 47 správných odpovědí), ostatní bloky Vah.

ZMĚNY VE VERZI 3.53.1 – Úprava limitů Vah ze 3.53.0 vrácena: blok J 90 s, K 180 s, verze opět v2-39-ui3-bl (přísnější
limity zůstávají záměrně). Případná data verze v2-39-ui3-bl2 zůstávají a ve srovnání se spojují. Analýza limitů
všech testů zůstává v docs/casove_limity_2026-10/.

ZMĚNY VE VERZI 3.54.0 – STANOVIŠTĚ: TĚŽŠÍ HORNÍ ÚROVNĚ (ST2-44-v1.0)
- První dva lidé měli plný počet. Příčina: u nejtěžších položek (S23–S36) je jen 24 možných rozmístění a 2–4 z nich
  splňují všechna pravidla – zkusmým rozmístěním na desce se řešení najde i bez úvahy.
- Nové úrovně 7 (S37–S40: 7 stanovišť, 5 objektů = 120 rozmístění, 4 pravidla) a 8 (S41–S44: 8 stanovišť, 6 objektů
  = 720 rozmístění, 5 pravidel). Vyhovují nejvýš 1–2 rozmístění, 26–78 rozmístění porušuje jen jedno pravidlo
  („skoro řešení“), řešení vyžaduje 2–5 úvah „co kdyby“. Slovník pravidel beze změny; dva nové tvary (kříž, blesk).
  Limit 60 s jako u úrovní 4–6. Původních 36 položek beze změny. Cesty v síti se nikde nekříží (kontrola layout_check.py).
- Ověřeno nezávislým výčtem: cíl má jediné místo, každé pravidlo je nutné. Generátor: docs/stanoviste/gen_top.py.
- Nová verze = samostatná skupina srovnání (jiný počet položek).

ZMĚNY VE VERZI 3.55.0 – STANOVIŠTĚ ST2-36-v1.1: NOVÝ HORNÍ KONEC MÍSTO ÚROVNÍ 7–8 Z 3.54.0
- Zpět na 36 položek, 6 stanovišť a 6 tvarů. S01–S22 beze změny; S23–S36 nahrazeny novým návrhem horního konce.
  Položky ST2-44 (S37–S44, 7–8 stanovišť, kříž a blesk) vyřazeny.
- Princip: místo cíle vzniká až integrací celé soustavy pravidel. Výběr podle „křivky kandidátů“ – nejmenší počet
  možných míst cíle po libovolné podmnožině k pravidel (žádná malá podmnožina pravidel cíl neprozradí):
  S23–S26 (úroveň 5): 2 pevné + 4 volné, 4 pravidla, 24 rozmístění.
  S27–S30 (úroveň 6): 1 pevný + 5 volných, 4 pravidla, 120 rozmístění, jedno pravidlo samo cíli nic neubere.
  S31–S34 (úroveň 7): 1 + 5, 5 pravidel; S31 ani po libovolné dvojici pravidel nic neubere.
  S35–S36 (úroveň 8): žádný pevný objekt, 6 pravidel, 720 rozmístění; ani libovolná trojice (S36 čtveřice)
  pravidel cíli nic neubere. U položek bez pevného objektu krátká poznámka pod otázkou.
  Barvy 2+2+2, nejvýš 2× „není na barvě“ (ne u stejného objektu), cíl nejvýš v jednom pravidle,
  celé rozmístění nemusí být jednoznačné (jednoznačné je místo cíle).
- Ověřeno nezávisle (docs/stanoviste/novy_strop_S23-S36/verify_new.py): cíl jednoznačný, každé pravidlo nutné,
  křivky, počty řešení a „po odebrání jednoho pravidla“ souhlasí s návrhem; cesty se nekříží.
- Limity pro pilot: úrovně 1–3 45 s, 4–5 60 s, 6 75 s, 7–8 90 s (utahovat až podle časů správných odpovědí).
- Data: ve facetách nově křivka kandidátů, počet úplných řešení, počet rozmístění porušujících jen jedno pravidlo,
  počet pevných objektů (vedle dosavadní hloubky a úvah „co kdyby“) – pilot ukáže, co obtížnost předpovídá.
  Pozn.: metriky se u nových položek rozcházejí (např. S36: nejvyšší křivka, ale postupným odvozením bez „co kdyby“;
  S35: 8 úvah „co kdyby“).
- Nová verze = samostatná skupina srovnání.

ZMĚNY VE VERZI 3.56.0 – STANOVIŠTĚ ST2-34-v1.2: SPODNÍ A STŘEDNÍ ČÁST, START PODLE VĚKU, VÝRAZNĚJŠÍ CÍL
- Úroveň 1: S03 a S04 vyřazeny (dvě volná stanoviště = 50 % tipem); zůstávají S01, S02.
- Úroveň 3: S12, S14, S15, S16 nahrazeny (S12b, S14b, S15b, S16b) – původní měly pravidlo „na barvě“ mířící na barvu,
  kterou má jen jedno volné stanoviště (okamžitá kotva, položka lehčí, než má úroveň být).
- Úroveň 4: S20, S21, S22 nahrazeny (S20b–S22b) – cíl byl ve dvou pravidlech a jedno pravidlo mu hned ubralo
  polovinu míst. Nové: cíl nejvýš v jednom pravidle, žádné jedno pravidlo cíli nic neubere (křivka 4, 4, …),
  všechny chybné možnosti „skoro správné“, hloubka odvození 4. Nové položky mají nová ID (data se nemíchají).
- Start podle věku (při volbě „start podle věku“, ve veřejné verzi vždy): od 13 let úroveň 3 (S11), od 17 let
  úroveň 4 (S17). První dvě položky správně → nižší položky se připíšou; jinak dvě položky o úroveň níž; když ani ty,
  od začátku. Ukončení po chybách v řadě platí až v hlavní části. Ve výsledku: start, připsané, směrování.
- Cílový objekt je výraznější: velký symbol ve zlatém kroužku v otázce, větší tlačítko v řádku „K rozmístění“,
  silnější zlatý kroužek po položení na stanoviště.
- Nová verze = samostatná skupina srovnání (34 položek, start podle věku).

ZMĚNY VE VERZI 3.56.1 – Stanoviště: mírnější start podle věku – od 13 let úroveň 2 (S05), od 17 let úroveň 3 (S11)
(dříve úroveň 3 / 4). Dospělým se připisují jen úrovně 1–2 (8 položek); pravidla návratu beze změny.

ZMĚNY VE VERZI 3.57.0 – Skládání papíru Gv-PAP-v6 (nový strop)
Podnět: zpětná vazba z Redditu („42/42, posledních 15 položek je podobně těžkých“) a data: 3 z 11 dokončených
administrací měly plný počet, položky úrovní 7–8 měly úspěšnost .84, nejtěžší byla úroveň 6 (přehyb přes víc než
polovinu, p = .54, medián času 36 s).
- 8 nových položek úrovně 9 (PAP_043–050): tři přehyby s nestejným počtem vrstev pod dírkami (dvě dírky,
  každá v jiném počtu vrstev), úhlopříčka + rovný přehyb (rozházený vzor), úhlopříčka + trojúhelníkový
  výstřih, přehyb přes víc než polovinu ve třech krocích. Řešení ověřena nezávislým řešičem
  (docs/papir_v6/paper.py – souhlasí na všech 42 původních položkách); díry nikdy nevedou přes poloviční
  políčko na úhlopříčce.
- Úroveň 6 (PAP_026–030) přesunuta za úrovně 7–8, aby obtížnost šla monotónně (pravidlo 3 chyb v řadě
  dřív ukončovalo i lidi, kteří by úrovně 7–8 zvládli).
- Limit úrovně 9: 90 s (jako úroveň 6). Ostatní limity beze změny. Ukončení: 3 chyby v řadě.
- 50 položek → nová srovnávací skupina (v5 se se v6 nesčítá). Rozpracovaný test ve v5 se po aktualizaci
  nenabídne k pokračování (kontrola verze).

ZMĚNY VE VERZI 3.58.0 – Skládání papíru Gv-PAP-v7: 3 extrémní položky (úroveň 10, PAP_051–053)
- Nový typ: papír se dvakrát přeloží, vystřihne se trojúhelníček, přeloží se potřetí a vystřihne se další
  (pole „cuts“: [{po: 2, holes: [...]}]; „answer“ = sjednocení obou výstřihů). Ve všech třech je úhlopříčný
  přehyb, v PAP_053 navíc dva přehyby přes víc než polovinu. Dřívější výstřih se v dalších obrázcích kreslí
  světle (GV_DRAW.cutGhosts). Před první takovou položkou se ukáže krátká karta s vysvětlením.
- Limit 120 s (zadání 6–7 natočených trojúhelníčků zabere samo o sobě ~30 s). Ostatní beze změny.
- Řešení ověřena řešičem (docs/papir_v6/paper.py); výstřihy obou stříhání se nepřekrývají v žádném políčku.
- 53 položek → samostatná srovnávací skupina Gv-PAP-v7.

ZMĚNY VE VERZI 3.59.0 – Skládání papíru zkráceno; Počítání a Slovní úlohy: těžší strop, kratší administrace
Skládání papíru Gv-PAP-v8 (45 položek): vyřazeno 8 nejsnazších / zdvojených (PAP_004, 007, 009, 012, 015, 019,
031, 038; úspěšnost .95–1.00 nebo stejný typ jako sousední položka). Úrovně 9 (PAP_043–050) a 10 (PAP_051–053)
zůstávají.
Počítání banka69-v4 (69 položek): + 7 stropových položek C201–C207 (střídavý součet, odmocniny, řetěz logaritmů,
teleskopický součet, mocniny dvojky, poslední číslice 7^2026, ciferný součet 10^25 − 25) – řeší se úvahou, ne
dalším učivem. Vyřazeno 6 zdvojených (C106 log₂ 32, C166 sin 30°, C058, C039, C062, C071). Dospělí (16+)
začínají na C033 (b 0,0) místo C037 (b −0,8).
Slovní úlohy zivot64-v4 (64 položek): vyřazeno 8 zdlouhavých vícekrokových úloh (SU44, 45, 53, 54, 56, 57, 60, 65 –
medián 60–90 s, obtížnost hlavně z pracnosti), přidáno 7 krátkých, ale záludných (SU66–SU72: množiny, délka vlaku,
různá rychlost tam a zpět, úhel ručiček, 99 % mužů, svíčky, falešně pozitivní test). Dospělí začínají od b −1,0
(SU21) místo −1,8; přeskakuje se po 2 správných za sebou (dříve 3).
Simulace (Rasch, docs/pocty_ulohy_v4/sim.py) – administrovaných položek při θ = +2 / +3 / +4:
  Počítání 36,8 / 39,1 / 38,0 → 31,1 / 34,0 / 35,7; Slovní úlohy 34,2 / 39,6 / 42,3 → 26,5 / 31,0 / 33,4,
  zkreslení skóru vlivem připisování do ±1 položky. Nové položky mají b jen odhadnuté (3,0–4,6).
Položky s b ≥ 3 se nikdy nepřeskakují (skip.maxB = 3) – strop se musí vyřešit, ne připsat (stojí ~1 položku navíc).
Časové limity beze změny. Nové verze = nové srovnávací skupiny. Kódovník (assets/codebook.csv) aktualizován pro
papir, pocitani a ulohy.

ZMĚNY VE VERZI 3.60.0 – Počítání a Slovní úlohy: časové limity (banka69-v4t, zivot64-v4t)
- Limit na položku podle obtížnosti (po limitu se odpověď počítá jako chybná, 15 s předem upozornění):
  Počítání b < 0: 45 s, b 0–1,5: 60 s, b ≥ 1,5: 90 s; Slovní úlohy b < 0: 45 s, b 0–3: 60 s, b ≥ 3: 90 s.
  Data 2026-10 (správné odpovědi): utne se 2–6 % u lehčích, 5–10 % u středních, 0 % u nejtěžších Počítání;
  u nejtěžších dřívějších úloh (vyřazené zdlouhavé) by 90 s utnulo 20 %, nové stropové úlohy jsou krátké.
- Celkový limit testu 25 minut čistého času (součet časů na položkách; přestávka při navázání se nepočítá).
  Po vyčerpání se test ukončí po rozpracované položce (konec = „časový limit testu 25 min“); nedosažené položky
  se nepřipisují. Při běžném tempu se nedosáhne (silní řešitelé v datech 11–15 min), týká se jen velmi
  pomalých průchodů (v datech 42 a 50 min).
- Anglická verze: místo pevných 90 s stejné limity jako česká. ?untimed=1 vypíná oba limity.
- Ve srovnání spojeno s v4 / EN-v2 (liší se jen limity).

ZMĚNY VE VERZI 3.60.1 – Celkový limit testu (25 min) u Počítání a Slovních úloh vypnut: limit na celý test by
vyžadoval jiný design (skórování nedosažených položek, instrukce o tempu). Limity na položku (45 / 60 / 90 s)
zůstávají; verze banka69-v4t / zivot64-v4t beze změny. Mechanismus cfg.budgetMin v mod_school zůstává nepoužitý.

ZMĚNY VE VERZI 3.61.0 – Mentální rotace MR-v6-38t (38 položek místo 50, pořadí podle dat)
Data 2026-10 (MR-v5, 21 sezení, Rasch JML, docs/rotace_v6/): úrovně 2–3 vyřešili všichni (10 položek bez informace),
úrovně 4–8 jsou v průměru stejně těžké (průměrné b 0,4 / 0,8 / 0,9 / 1,0 / 0,8) a návrhové facety (kostky, osy, úhel,
spojitý povrch, úroveň) obtížnost nepředpovídají (r ≈ 0,05–0,2). Dokončení 45 položek trvalo 19–49 min.
- Vyřazeno 12 položek, které vyřešili všichni: MR4_005, 007, 009, 011, 012, 014, 015 (úrovně 2–3) a MR4_031, 033, 038,
  048, 050 (úrovně 6–8).
- Úvod pro děti (do 8 let): MR4_001–004, 006, 008, 010. Od 9 let se začíná za ním (7 položek se připíše, při chybě
  v prvních dvou návrat jako dřív).
- Zbylých 31 položek seřazeno podle empirické obtížnosti (b −2,5 … 3,3) místo podle úrovní – obtížnost teď stoupá,
  takže pravidlo 4 chyb v řadě ukončuje dřív a strop dává smysl. Pole b_emp v bance.
- Časové limity beze změny (podle úrovně položky 45 / 120 / 150 s; utínají 5–7 % správných u těžkých).
- Nová srovnávací skupina. Odhady b stojí na 10–21 odpovědích na položku – po nasbírání dat přepočítat.

ZMĚNY VE VERZI 3.62.0 – Mentální rotace: přísné limity MR-v6-38h
Limit podle empirické obtížnosti položky (b_emp): b < 0: 45 s, b 0–1,5: 60 s, b ≥ 1,5: 90 s (dříve podle úrovně
45 / 120 / 150 s). Záměr: jako u časovaných subtestů WAIS (kostky, skládání obrázků) – dlouhé prohlížení podnětu se
nepočítá. Odhad z dat 2026-10 (bez limitu by správně): utne ~2 % lehkých, ~31 % středních a ~25 % nejtěžších
správných odpovědí; skóre je tedy výrazně rychlostně sycené. Ve srovnání spojeno s MR-v6-38t (stejné položky).

ZMĚNY VE VERZI 3.63.0 – Časové stropy: běžné položky max 90 s, náročné bloky max 120 s; přepočet dřívějších výsledků
Záměr: zefektivnit administraci (jako časované subtesty WAIS); rychlost se tím do skóre přidá jen málo.
- Matice v10-56t90: úrovně 9–11 120 → 90 s (data 2026-10: utne 8 % správných).
- Tvarové klíče DED-24-v2.3: úrovně 4–5 100 → 90 s (utne 0 %); 8–9 zůstávají 120 s (náročný blok; 90 s by utnulo 43 %).
- Hledání pravidla HP-36-v1.2: úroveň 5 150 → 120 s (utne 15 %; 90 s by utnulo 25 %).
- Váhy v2-39-ui3-bl3: blok K 180 → 120 s (utne 23 %; 90 s by utnulo 33 %).
- Pohled na stavbu Gv-KOS-v4t a Skládání tvarů SK-v1t: nově tvrdý limit 90 s (dříve jen pobídka po 60 s).
- Beze změny: Skládání papíru (úroveň 10: 120 s), Mentální rotace (45/60/90 s), Počítání a Slovní úlohy (45–90 s),
  Stanoviště (45–90 s), testy rychlosti s pevným časem (Symboly, Shodné řady, SRCE) a testy Gc bez limitu.
Přepočet dřívějších výsledků (includes/admin.php, kb_recode_caps2 + kb_recode_dedukce_v2 se značkou limity-DED-24-v2.3):
spustí se sám při prvním otevření administrace. Správná odpověď za novým limitem = chybná; hrubý skór = skór před úpravou
− ztracené položky (bez dominového efektu pravidla ukončení; u Tvarových klíčů se ukončení přepočítává jako dřív).
Mentální rotace MR-v5-50* a MR-v6-38t se převedou na škálu MR-v6-38h (38 položek; úvod pro děti se dospělým připisuje).
Skór před úpravou je v datech jako hruby_pred_upravou a ve výsledcích se zobrazí jako druhá (přerušovaná) čára
„původně“; srovnání a korelace už počítají s upraveným skórem. Ve srovnání spojeno s předchozími verzemi (stejné položky).

ZMĚNY VERZE 3.64.0 – Skládání tvarů SK48-v1 místo Mentální rotace
Mentální rotace (MR-v6-38h) je skrytá: kód, banka, data i přepočet zůstávají, jen se nenabízí. Na jejím místě je Skládání
tvarů (obdoba Visual Puzzles z WAIS): nahoře tvar, dole 6 dílů, vybrat 2 (položky 1–3) nebo 3 díly, ze kterých se tvar
přesně složí; díly lze otáčet, ne zrcadlit.
Zdroj: sada 48 položek (skladani_tvaru_48_final). Původní kresba měla každý díl zvětšený na výšku svého políčka, takže
neseděly velikosti (u položek 4, 6, 8, 9, 15, 40, 48 byl distraktor stejného tvaru jako správný díl, lišící se jen
velikostí → dvě správné odpovědi). Skutečné měřítko v souboru nebylo, proto se dopočítalo (docs/skladani_tvaru_sk48/):
- klíč: řešič skládání (otáčení bez zrcadlení) ověřil u všech 48 položek, že se správné díly složí do tvaru, a určil
  jejich skutečnou velikost; u kulatých tvarů z délky obloukových úseků (součet ploch klíče = plocha tvaru ±0,6 %);
- distraktory: zrcadlo správného dílu = stejná velikost; díl stejného tvaru = jiná velikost (×0,78 / ×1,28); jiný tvar =
  stejná plocha jako nejpodobnější správný díl; u kulatých tvarů velikost z obloukových úseků;
- jednoznačnost: u mnohoúhelníkových tvarů řešič ověřil, že žádná jiná trojice (dvojice) dílů tvar nesloží; u kulatých
  tvarů kontrola plochy, délky oblouku a shodnosti. Upraveny 3 distraktory (pol. 12: kombinace 1-2-5 šla složit;
  pol. 11 a 41: zrcadlo téměř souměrného dílu bylo prakticky totožné se správným dílem → zmenšeno).
- kresba: všechny díly položky ve stejném měřítku jako tvar; cílový tvar bez viditelných švů mezi díly.
Administrace: 2 cvičné položky se zpětnou vazbou; od 9 let start u položky 4 (první se 3 díly, položky 1–3 se připíší,
při chybě návrat); limit 45 s (položky se 2 díly a velmi lehké), jinak 60 s; ukončení po S.stop chybách v řadě + sondy.
Skór = počet správně (všechny vybrané díly správně). Pořadí zatím podle autorských pásem obtížnosti – po sběru dat přeřadit.

ZMĚNY VERZE 3.65.0 – Skládání tvarů SK30-v1 (30 položek místo 48)
- Vyřazeny duplicitní položky (stejný tvar a téměř stejné řezy, liší se jen barvou/vzorem): 2 (= 1), 5 (= 4), 9 (= 10),
  12 (= 14), 16 (= 34), 23 (= 28), 20, 31, 36 (= 15/22); kvůli převaze čtverců (16 ze 48) a slabým distraktorům dále 6, 10,
  13, 17, 18, 19, 21, 25, 27, 30, 32, 37, 41, 42, 46, 48. Zůstává 23 položek (7 čtverců, kruhy, elipsy, šesti- a víceúhelníky).
- 7 nových stropových položek SKC_01–07 (šestiúhelník, čtverec, obdélník, pětiúhelník, sedmiúhelník, lichoběžník, L):
  3 díly z lomených řezů, jednobarevné (bez barevného vodítka), díly nesouměrné; distraktory těsně u správných dílů:
  zrcadlo mírně nesouměrného dílu, správný díl ±8 % velikosti, díl s rohem posunutým o 0,04–0,065 (≈ 5–10 % rozdílu).
  Klíč i jednoznačnost (žádná jiná trojice se nesloží, bez zrcadlení) ověřil řešič.
- Pořadí podle předpokládané obtížnosti (docs/skladani_tvaru_sk48/predict.py), ne podle autorských pásem:
  složitost správných dílů (+), blízkost nejpodobnějšího distraktoru (+), zrcadlový distraktor (+), vícebarevný tvar jako
  vodítko (−), malý díl (+), autorské pásmo jen slabě; položky se 2 díly vždy na začátku. Po sběru dat přeřadit podle Rasche.
- Start, limity a ukončení beze změny (od 9 let start u první položky se 3 díly). Nová srovnávací skupina SK30-v1.

ZMĚNY VERZE 3.66.0 – Skládání tvarů SK30-v2: strukturní strop
Stropové položky SKC_01–07 (distraktory lišící se nepatrnou odchylkou velikosti/rohu) nahrazeny 7 položkami SKS_01–07, kde
obtížnost leží ve struktuře – jako u stropu Visual Puzzles: cíl je obdélník/čtverec (mřížka 4×3 až 5×4), 3 díly do sebe
zapadají zuby a výřezy, 0–2 spoje mají půlkruhový čep a jamku. Distraktory mluví stejným „jazykem“ a jsou na pohled
věrohodné: zrcadlo nesouměrného dílu, zub na jiném místě, čep místo jamky / spoj jinde, o kostku větší díl. Díly ukázané
otočené po 90°. Přesná kontrola dlaždicovým řešičem (otáčení po 90°, bez zrcadlení, čep musí sedět do jamky): klíč se složí
a žádná jiná trojice ne (docs/skladani_tvaru_sk48/gen_struct.py). Zařazeny do horní třetiny (SKS_01–04 mezi nejtěžší původní
položky, SKS_05–07 na konec). Nová srovnávací skupina SK30-v2.

ZMĚNY VERZE 3.67.0 – Skládání tvarů SK34-v1: snadný začátek po vzoru WAIS
Nácvik byl příliš těžký (jednobarevný čtverec ze tří otočených trojúhelníků). Nově, jako u Visual Puzzles: díly mají barvu své
části tvaru, jsou ve stejné poloze jako v tvaru (bez otáčení) a distraktory jsou zjevně jiné (kruh, kosočtverec, trojúhelník,
jiná velikost). Vlastní položky (ne kopie WAIS):
- nácvik SK_N1 (2 díly: modrá a žlutá polovina obdélníku), SK_N2 (3 díly: červený a zelený čtverec, fialový pruh);
- úvodní položky SK_E1 (čtverec ze dvou barevných trojúhelníků), SK_E2 (sloupec tří barevných čtverců), SK_E3 (velký a dva malé
  čtverce), SK_E4 (pruh a dva trojúhelníky; poprvé jeden díl otočený o 90°). Pak navazuje dosavadní sada (34 položek celkem).
Start: do 8 let od SK_E1; od 9 let od SK48_04 (6 položek se připíše, při chybě v prvních dvou návrat). Nová skupina SK34-v1.

ZMĚNY VERZE 3.68.0 – Skládání tvarů SK34-v2: postup obtížnosti podle principu Visual Puzzles
Obecný princip postupu (bez převzetí položek): (1) tvar ukazuje hranice dílů, díly neotočené, distraktory jiné kategorie →
(2) hranice vidět, díly otočené → (3) jen obrys, barevný vzor ještě napovídá → (4) jednobarevné tvary bez hranic, i oblé →
(5) strop: pravoúhlé díly se zuby/čepy, distraktory ze stejné „slovní zásoby“. Doplněn chybějící krok 2: nácvik, úvodní
položky SK_E1–E4 a první jednobarevné položky SK48_01, 03, 04, 08 ukazují v tvaru hranice dílů (tenká čára); SK48_08 posunuta
hned za SK48_04. Dál beze změny. Ve srovnání spojeno s SK34-v1 (stejné položky).

ZMĚNY VERZE 3.69.0 – Skládání tvarů SK30-W1: celý průběh podle principu Visual Puzzles
Původní sada měla ve střední části úlohy typu „porovnej proporce podobných čtyřúhelníků“ (distraktory lišící se o pár
procent) – to měří jemné vizuální rozlišování, ne skládání. Všechny takové položky vyřazeny; zůstaly jen 40 a 44
(pravoúhlé díly se zuby). Nová střední část (gen_wais.py) – díly jsou rozpoznatelné základní tvary, distraktory se liší
KATEGORIÍ (jiný tvar), výrazně VELIKOSTÍ (×0,62 / ×1,45), ZRCADLEM nebo VZOREM:
 krok 1  SK_E1–E4  barevné díly, hranice vidět, bez otáčení (beze změny)
 krok 2  SKW_01–05 jednobarevné, hranice dílů v tvaru vidět, díly otočené po 90°, distraktory jiné kategorie
 krok 3  SKW_06–11 bez hranic, dvoubarevný vzor (kruh/pruh) přes více dílů; distraktor se špatně položeným vzorem, jiná velikost
 krok 4  SKW_12–17 jednobarevné bez hranic (i kruh a oblouk), otočení po 45°; jiná velikost, zrcadlo, jiný tvar
 krok 5  strop: SKS_01–07 (zuby, čepy, výřezy) + 40, 44
Jednoznačnost u mnohoúhelníků ověřena řešičem; u vzorových a kulatých položek rozhoduje vzor/kategorie/velikost.
Start od 9 let: SKW_01 (4 úvodní položky se připíší). 30 položek, nová srovnávací skupina SK30-W1.

ZMĚNY VERZE 3.69.1 – Skládání tvarů: oprava zobrazení na mobilu
Díly v možnostech A–F mohly přetékat rámeček (velikost obrázku nepočítala s okrajem a odsazením tlačítka). Opraveno,
obrázek se navíc vždy vejde do tlačítka (max-width). Položky, klíče ani skórování se nemění.

ZMĚNY VERZE 3.70.0 – Skládání tvarů SK31-W2: dvě nové stropové položky
 SKO_1 (místo SKS_01): kruhová deska s vyřezaným ornamentem, 3 díly. Distraktory jsou díly jiné celé desky (v každém
       dílu jiný výběžek: hrot / zub / oblouk), takže do sebe zapadají – rozhoduje shoda s ornamentem v cíli.
 SKL_2 (nová, před SKS_07): cíl je plný kruh = 2 skořepiny s výřezy + nesouměrný ornament, který do nich zapadne.
       Distraktory: zrcadlový ornament + skořepina, do které zrcadlo přesně zapadá, a skořepina s jinak vyříznutým zubem.
Jednoznačnost ověřena řešičem (všechny trojice × otočení; gen_orn.py, gen_lock.py). 31 položek, nová srovnávací skupina SK31-W2.
