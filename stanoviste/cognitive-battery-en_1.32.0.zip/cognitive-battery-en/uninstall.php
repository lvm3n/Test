<?php
// Při odinstalaci se data záměrně NEMAŽOU (ochrana výzkumných dat).
// Smazání tabulek je možné jen ručně v databázi (tabulky s předponou wp_kben_).
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
