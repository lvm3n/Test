<?php
/**
 * Plugin Name: Cognitive Battery (EN)
 * Description: Anglická verze (Matrices, Weights, Shape Keys). Samostatný plugin: tabulky wp_kben_*, shortcode [cognitive_battery_en]; český plugin neovlivňuje.
 * Version: 1.30.1
 * Author: (doplnit)
 * Text Domain: cognitive-battery-en
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }

define('KBEN_VERSION', '1.30.1');
define('KBEN_DB_VERSION', '1');
define('KBEN_DIR', plugin_dir_path(__FILE__));
define('KBEN_URL', plugin_dir_url(__FILE__));

require_once KBEN_DIR . 'includes/db.php';
require_once KBEN_DIR . 'includes/rest.php';
require_once KBEN_DIR . 'includes/admin.php';

register_activation_hook(__FILE__, 'kben_activate');
function kben_activate() {
    kben_install_tables();                         // tabulky se jen vytvoří / rozšíří, data se nikdy nemažou
    add_option('kben_settings', array(
        'notify_email'   => get_option('admin_email'),
        'notify'         => 'finished',          // none | finished
        'min_n'          => 30,
        'public_enabled' => 1,
    ));
}
function kben_setting($key, $default = '') {
    $s = get_option('kben_settings', array());
    return (isset($s[$key]) && $s[$key] !== '') ? $s[$key] : $default;
}
add_action('plugins_loaded', function () {
    if (get_option('kben_db_version') !== KBEN_DB_VERSION) { kben_install_tables(); }
});

/**
 * Krátké kódy:
 *   [cognitive_battery_en]            veřejná verze (souhlas, demografie, anonymní identifikátor)
 *   [cognitive_battery_en_admin]      administrátorská verze (jen pro přihlášené s oprávněním)
 */
function kben_app_params($mode, $page = '') {
    return array(
        'mode'    => $mode,
        'api'     => esc_url_raw(rest_url('kben/v1/')),
        'nonce'   => ($mode === 'admin') ? wp_create_nonce('wp_rest') : '',
        'page'    => esc_url_raw($page ? $page : home_url('/?cognitive-battery-en=1')),
        'privacy' => esc_url_raw(kben_setting('privacy_url', function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '')),
        'v'       => KBEN_VERSION,
    );
}
function kben_iframe($mode, $atts = array()) {
    $atts = shortcode_atts(array('sirka' => 'cela', 'vyska' => '100dvh'), $atts);
    $src = add_query_arg(kben_app_params($mode, get_permalink()), KBEN_URL . 'assets/app.html');
    // „cela“ = přes celou šířku okna bez ohledu na šířku obsahu v šabloně
    $wrap = ($atts['sirka'] === 'cela')
        ? 'width:100vw;max-width:100vw;position:relative;left:50%;right:50%;margin-left:-50vw;margin-right:-50vw;'
        : 'width:100%;max-width:1200px;margin:0 auto;';
    $h = preg_replace('/[^0-9a-z%.]/i', '', $atts['vyska']);
    $fid = 'kbframe' . wp_rand(1000, 9999);
    $full = home_url('/?cognitive-battery-en=' . ($mode === 'admin' ? 'admin' : '1') . '&resume=1');
    return '<div class="kb-wrap" style="' . esc_attr($wrap) . '">'
         . '<iframe id="' . esc_attr($fid) . '" src="' . esc_url($src) . '" title="Cognitive Battery" '
         . 'style="display:block;width:100%;height:' . esc_attr($h) . ';min-height:600px;border:0;background:#F3F5F7" '
         . 'allow="autoplay; fullscreen" loading="eager"></iframe>'
         . '<p style="text-align:center;font-size:14px;margin:6px 0"><a href="' . esc_url($full) . '" target="_top" onclick="var f=document.getElementById(\'' . esc_attr($fid) . '\');var r=f&&(f.requestFullscreen||f.webkitRequestFullscreen);if(r){r.call(f);return false;}">Open full screen</a></p></div>';
}
/* samostatná adresa bez šablony webu: /?cognitive-battery-en=1 (veřejná) a /?cognitive-battery-en=admin (jen po přihlášení) */
add_action('template_redirect', function () {
    if (!isset($_GET['cognitive-battery-en'])) { return; }
    $mode = ($_GET['cognitive-battery-en'] === 'admin') ? 'admin' : 'public';
    if ($mode === 'admin' && !current_user_can('edit_posts')) { auth_redirect(); exit; }
    if ($mode === 'public') { $s = get_option('kben_settings', array()); if (empty($s['public_enabled'])) { wp_die('The test is currently unavailable.'); } }
    $params = kben_app_params($mode);
    if (!empty($_GET['resume'])) { $params['resume'] = '1'; }
    wp_redirect(add_query_arg($params, KBEN_URL . 'assets/app.html'));
    exit;
});
add_shortcode('cognitive_battery_en', function ($atts) {
    $s = get_option('kben_settings', array());
    if (empty($s['public_enabled'])) { return '<p>The test is currently unavailable.</p>'; }
    return kben_iframe('public', (array) $atts);
});
add_shortcode('cognitive_battery_en_admin', function ($atts) {
    if (!current_user_can('edit_posts')) { return '<p>The administrator version is available only after logging in.</p>'; }
    return kben_iframe('admin', (array) $atts);
});
