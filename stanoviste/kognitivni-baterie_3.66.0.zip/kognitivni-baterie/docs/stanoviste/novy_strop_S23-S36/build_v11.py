import json, itertools, sys
sys.path.insert(0,'../st2'); import gen
OLD=json.load(open('../st2/bank_st2_36.json')); NEW=json.load(open('new_items.json'))
def curve(x):
    it=gen.Item(x['layout'],x['colors'],x['fixed'],x['free'],[tuple(r) for r in x['rules']],x['target'])
    P_all=[]; masks=[]
    for perm in itertools.permutations(it.empty):
        Q=dict(it.fixed); Q.update(zip(it.free,perm)); P_all.append(Q[it.target]); masks.append(sum(1<<k for k,r in enumerate(it.rules) if not gen.sat(it,r,Q)))
    R=len(it.rules)
    return it,[min(len({p for p,m in zip(P_all,masks) if m & sum(1<<k for k in S)==0}) for S in itertools.combinations(range(R),k)) for k in range(R+1)], sum(m==0 for m in masks), len(masks), sum(bin(m).count('1')==1 for m in masks)
items=[]
for x in OLD['items'][:22]+NEW:
    x=json.loads(json.dumps(x)); it,cv,full,perm,one=curve(x)
    if x['id']>='S23':
        ev=gen.evaluate(it); assert ev and ev['answer']==x['answer'], x['id']
        h=ev['human']
        x['metriky']={'hloubka':h['depth'],'co_kdyby':h['refutations'],'hloubka_sporu':h['refutation_depth'],'techniky':h['techniques'],'pravidel':len(x['rules']),
                      'near_miss':ev['near_miss'],'chybnych_moznosti':ev['n_wrong'],'reseni_celkem':ev['n_solutions'],'zdroj':'návrh S23–S36 (nový strop)'}
        x['rules']=[list(r) for r in x['rules']]
        x.pop('solution',None)
        if ev['n_solutions']==1: x['solution']={t:v for t,v in [(t,gen.all_solutions(it)[0][t]) for t in it.free]}
    x['metriky'].update({'krivka_kandidatu':cv,'rozmisteni_celkem':perm,'porusuje_jedno':one,'reseni_celkem':full})
    items.append(x)
assert [x['id'] for x in items]==['S%02d'%k for k in range(1,37)]
bank={'verze':'ST2-36-v1.1','caps':{'1':45,'2':45,'3':45,'4':60,'5':60,'6':75,'7':90,'8':90},'practice':OLD['practice'],'items':items}
json.dump(bank,open('../st2/bank_st2_v11.json','w'),ensure_ascii=False,separators=(',',':'))
with open('prehled_v11.txt','w') as f:
    for x in items:
        m=x['metriky']; f.write('%s L%d %-3s pevných %d volných %d pravidel %d | křivka %s | řešení %d/%d | hloubka %s co kdyby %s\n'%(x['id'],x['level'],x['layout'],len(x['fixed']),len(x['free']),len(x['rules']),m['krivka_kandidatu'],m['reseni_celkem'],m['rozmisteni_celkem'],m.get('hloubka'),m.get('co_kdyby')))
print(open('prehled_v11.txt').read())
