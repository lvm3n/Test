import sys, random, itertools, collections, time
sys.path.insert(0,'../st2'); import gen
SH=['hvezda','srdce','trojuhelnik','ctverec','mesic','kapka']
def curve(it, P_all, masks):
    R=len(it.rules); out=[]
    for k in range(R+1):
        best=99
        for S in itertools.combinations(range(R),k):
            m=sum(1<<i for i in S)
            c={p for p,mk in zip(P_all,masks) if mk & m == 0}
            best=min(best,len(c))
        out.append(best)
    return out
def trial(n_fixed, n_rules, thr, tries, seed, lays=('HX','G6','BW','HT','C6','TR','KT','LD')):
    rng=random.Random(seed); hits=[]; t0=time.time()
    for _ in range(tries):
        lay=rng.choice(lays); pos,edges=gen.LAYOUTS[lay]; n=len(pos)
        cols=['orange','blue','green']*2; rng.shuffle(cols)                     # barvy 2+2+2
        toks=rng.sample(SH,n); P=dict(zip(toks,rng.sample(range(n),n)))
        fx=rng.sample(toks,n_fixed); fixed={t:P[t] for t in fx}; free=[t for t in toks if t not in fixed]
        target=rng.choice(free); A=gen.adjset(edges,n); rules=[]
        while len(rules)<n_rules:
            k=rng.choices(['adj','nadj','col','ncol'],[3,3,2,1])[0]
            if k in('col','ncol'):
                t=rng.choice(free); c=cols[P[t]] if k=='col' else rng.choice([c for c in set(cols) if c!=cols[P[t]]]); r=(k,t,c)
            else:
                a,b=rng.sample(toks,2)
                if a in fixed and b in fixed: continue
                if (P[b] in A[P[a]])!=(k=='adj'): continue
                r=(k,a,b)
            if r in rules: continue
            rules.append(r)
        kinds=collections.Counter(r[0] for r in rules)
        if kinds['ncol']>2 or len(kinds)<2: continue
        if sum(it in r for r in rules for it in [target])>1: continue          # cíl nejvýš v jednom pravidle
        it=gen.Item(lay,cols,fixed,free,rules,target)
        P_all=[]; masks=[]
        for perm in itertools.permutations(it.empty):
            Q=dict(fixed); Q.update(zip(free,perm)); P_all.append(Q[target])
            masks.append(sum(1<<i for i,r in enumerate(rules) if not gen.sat(it,r,Q)))
        full=[p for p,m in zip(P_all,masks) if m==0]
        if len(set(full))!=1: continue
        cv=curve(it,P_all,masks)
        if all(cv[k]>=thr[k] for k in range(len(thr))):
            hits.append((lay,cv,len(full),len(P_all),rules,target,len([m for m in masks if bin(m).count('1')==1])))
    return hits, time.time()-t0
for name,nf,nr,thr,tries in (('S27 (1+5, 4 pravidla)',1,4,[5,5,3,2,1],20000),('S31 (1+5, 5 pravidel)',1,5,[5,5,4,3,2,1],20000),('S35 (0+6, 6 pravidel)',0,6,[6,6,5,4,3,2,1],20000)):
    h,t=trial(nf,nr,thr,tries,7)
    print('%s: požadovaná křivka %s → nalezeno %d z %d pokusů (%.0f s)'%(name,thr,len(h),tries,t))
    for x in h[:3]: print('   %s křivka %s | úplných řešení %d z %d | porušuje jen 1: %d'%(x[0],x[1],x[2],x[3],x[6]))
