import json, itertools, collections, sys
sys.path.insert(0,'../st2'); import gen, layout_check
s=open('novy_strop.html',encoding='utf8').read(); i=s.index('const ITEMS=')+12
NEW=json.JSONDecoder().raw_decode(s[i:])[0]; json.dump(NEW,open('new_items.json','w'),ensure_ascii=False)
OLD=json.load(open('../st2/bank_st2_36.json'))
def check(x):
    it=gen.Item(x['layout'],x['colors'],x['fixed'],x['free'],[tuple(r) for r in x['rules']],x['target'])
    assert it.pos==x['pos'] and [list(e) for e in it.edges]==x['edges'], 'rozvržení nesouhlasí s generátorem'
    P_all=[]; masks=[]; full=[]
    for perm in itertools.permutations(it.empty):
        Q=dict(it.fixed); Q.update(zip(it.free,perm)); P_all.append(Q[it.target])
        m=sum(1<<k for k,r in enumerate(it.rules) if not gen.sat(it,r,Q)); masks.append(m)
        if m==0: full.append(Q)
    R=len(it.rules)
    cells=sorted({Q[it.target] for Q in full})
    curve=[min(len({p for p,m in zip(P_all,masks) if m & sum(1<<k for k in S)==0}) for S in itertools.combinations(range(R),k)) for k in range(R+1)]
    drop=[len({p for p,m in zip(P_all,masks) if m & ~(1<<k) & ((1<<R)-1)==0}) for k in range(R)]
    one=sum(bin(m).count('1')==1 for m in masks)
    cols=collections.Counter(x['colors']); kinds=collections.Counter(r[0] for r in x['rules'])
    tm=sum(x['target'] in r[1:] for r in x['rules'])
    issues=[]
    if cells!=[x['answer']]: issues.append('CÍL NENÍ JEDNOZNAČNÝ %s'%cells)
    if min(drop)<2: issues.append('zbytečné pravidlo')
    if curve!=[x['metriky']['candidate_min_by_rules'][str(k)] for k in range(R+1)]: issues.append('křivka nesouhlasí s uvedenou %s'%curve)
    if drop!=x['metriky']['drop_one']: issues.append('drop_one nesouhlasí %s'%drop)
    if len(full)!=x['metriky']['full_solutions']: issues.append('počet řešení nesouhlasí %d'%len(full))
    if sorted(cols.values())!=[2,2,2]: issues.append('barvy nejsou 2+2+2 %s'%dict(cols))
    if kinds['ncol']>2: issues.append('víc než 2 ncol')
    nc=[r for r in x['rules'] if r[0]=='ncol']
    if any(a[1]==b[1] for a,b in itertools.combinations(nc,2)): issues.append('dvě ncol u stejného objektu')
    if len(kinds)<2: issues.append('jen jeden druh pravidla')
    if tm>1: issues.append('cíl ve více pravidlech')
    for r in x['rules']:                       # tautologie: pravidlo, které samo nic nevylučuje
        if len({p for p,m,Q in zip(P_all,masks,range(len(masks)))})==0: pass
    tauto=[k for k in range(R) if all(not (m>>k)&1 for m in masks)]
    if tauto: issues.append('pravidlo nikdy neporušené %s'%tauto)
    P=x['pos']
    if any(len({*e,*f})==4 and layout_check.inter(P[e[0]],P[e[1]],P[f[0]],P[f[1]]) for e,f in itertools.combinations(x['edges'],2)): issues.append('křížení cest')
    if set(x['solution'][t] for t in x['free'])|set(x['fixed'].values())!=set(range(x['n'])): issues.append('řešení neplné')
    if any(not gen.sat(it,tuple(r),x['solution']) for r in x['rules']): issues.append('uvedené řešení porušuje pravidlo')
    return dict(id=x['id'],lvl=x['level'],fixed=len(x['fixed']),free=len(x['free']),R=R,curve=curve,full=len(full),perm=len(masks),one=one,tm=tm,kinds=dict(kinds),issues=issues)
bad=0
for x in NEW:
    r=check(x); bad+=bool(r['issues'])
    print('%s L%d  %d+%d  pravidel %d  křivka %s  řešení %d/%d  porušuje 1: %3d  cíl v pravidlech %d  %s'%(r['id'],r['lvl'],r['fixed'],r['free'],r['R'],r['curve'],r['full'],r['perm'],r['one'],r['tm'],'; '.join(r['issues']) or 'OK'))
print('položek s problémem:',bad)
# shodné ID / kolize se starou bankou, duplicity
print('ID:',[x['id'] for x in NEW]==['S%02d'%k for k in range(23,37)], '| S01–S22 v bance:', [x['id'] for x in OLD['items'][:22]]==['S%02d'%k for k in range(1,23)])
