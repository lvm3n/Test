"""ST2-34-v1.2: náhrada S12, S14–S16 (úroveň 3) a S20–S22 (úroveň 4); vyřazení S03, S04.
Kritéria: žádné pravidlo „na barvě“ nemíří na barvu, kterou má jen jedno volné stanoviště; cíl nejvýš v jednom pravidle;
úroveň 4: jedno pravidlo samo cíli nic neubere (křivka 4, 4, …); všechny chybné možnosti „skoro správné“;
jediné úplné rozmístění; hloubka odvození 3 (úroveň 3) / 4 (úroveň 4); stejné rozvržení sítě jako původní položka."""
import sys, json, random, itertools, collections
sys.path.insert(0, '../st2'); import gen
B = json.load(open('../st2/bank_st2_v11.json'))
def curve(it):
    P_all = []; masks = []
    for perm in itertools.permutations(it.empty):
        Q = dict(it.fixed); Q.update(zip(it.free, perm)); P_all.append(Q[it.target])
        masks.append(sum(1 << k for k, r in enumerate(it.rules) if not gen.sat(it, r, Q)))
    R = len(it.rules)
    return [min(len({p for p, m in zip(P_all, masks) if m & sum(1 << k for k in S) == 0}) for S in itertools.combinations(range(R), k)) for k in range(R + 1)], sum(bin(m).count('1') == 1 for m in masks)
def uniq_anchor(it):
    ec = collections.Counter(it.colors[v] for v in it.empty)
    return any(r[0] == 'col' and ec[r[2]] == 1 for r in it.rules)
REPL = {'S12': 3, 'S14': 3, 'S15': 3, 'S16': 3, 'S20': 4, 'S21': 4, 'S22': 4}
rng = random.Random(2026); new = {}; seen = set()
for x in B['items']:
    if x['id'] not in REPL: continue
    lvl = REPL[x['id']]; tries = 0
    while True:
        tries += 1
        it = gen.random_item(rng, x['layout'], 2, rng.choice([3] if lvl == 3 else [3, 4]), [3, 2, 2, 1])
        if not it or uniq_anchor(it): continue
        if sum(it.target in r[1:] for r in it.rules) > 1: continue
        kinds = collections.Counter(r[0] for r in it.rules)
        if max(kinds.values()) > 2 or len(kinds) < 2 or kinds['ncol'] > 1: continue
        ev = gen.evaluate(it)
        if not ev or ev['n_solutions'] != 1 or ev['human']['depth'] != lvl or ev['near_miss'] != ev['n_wrong']: continue
        cv, one = curve(it)
        if lvl == 4 and cv[1] != 4: continue
        if lvl == 3 and cv[1] < 3: continue
        c = gen.canon(it)
        if c in seen: continue
        seen.add(c)
        y = gen.to_json(it, ev, x['id'] + 'b'); y['level'] = lvl
        y['metriky'].update({'krivka_kandidatu': cv, 'porusuje_jedno': one, 'rozmisteni_celkem': 24, 'nahrazuje': x['id']})
        new[x['id']] = y
        print(y['id'], 'L%d' % lvl, x['layout'], 'pravidel', len(it.rules), 'křivka', cv, 'hloubka', ev['human']['depth'], 'nm %d/%d' % (ev['near_miss'], ev['n_wrong']), [r[0] for r in it.rules], 'cíl v pravidlech', sum(it.target in r[1:] for r in it.rules), 'pokusů', tries)
        break
items = []
for x in B['items']:
    if x['id'] in ('S03', 'S04'): continue
    items.append(new.get(x['id'], x))
bank = dict(B); bank['items'] = items; bank['verze'] = 'ST2-34-v1.2'
json.dump(bank, open('../st2/bank_st2_v12.json', 'w'), ensure_ascii=False, separators=(',', ':'))
print(len(items), [x['id'] for x in items])
