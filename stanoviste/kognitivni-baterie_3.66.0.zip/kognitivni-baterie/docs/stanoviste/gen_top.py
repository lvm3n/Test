"""ST2 – horní úrovně 7–8 (strop): víc stanovišť a objektů, jediné celé rozmístění, nutné opakované úvahy „co kdyby“,
mnoho rozmístění porušujících jen jedno pravidlo (zkoušení na desce nestačí). Stávajících 36 položek se nemění."""
import json, random, itertools, collections, sys
import gen
gen.SHAPES = ['hvezda', 'srdce', 'trojuhelnik', 'ctverec', 'mesic', 'kapka', 'kriz', 'blesk']
import math
def ring(n, r=42, cx=50, cy=51, rot=-90):
    return [[round(cx + r * math.cos(math.radians(rot + 360 * k / n)), 1), round(cy + r * math.sin(math.radians(rot + 360 * k / n)), 1)] for k in range(n)]
gen.LAYOUTS.update({
 'HX7': ([[50,8],[86,30],[86,72],[50,94],[14,72],[14,30],[50,51]], [(0,1),(1,2),(2,3),(3,4),(4,5),(5,0),(6,0),(6,2),(6,4)]),
 'G7':  ([[10,28],[40,28],[70,28],[10,76],[40,76],[70,76],[94,52]], [(0,1),(1,2),(3,4),(4,5),(0,3),(1,4),(2,6),(5,6)]),
 'T7':  ([[50,8],[24,40],[76,40],[8,84],[36,84],[64,84],[92,84]], [(0,1),(0,2),(1,3),(1,4),(2,5),(2,6),(4,5)]),
 'C7':  (ring(7), [(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,0),(0,3)]),
 'G8':  ([[8,28],[36,28],[64,28],[92,28],[8,76],[36,76],[64,76],[92,76]], [(0,1),(1,2),(2,3),(4,5),(5,6),(6,7),(0,4),(2,6),(3,7),(1,5)]),
 'C8':  (ring(8), [(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,0),(0,3),(4,7)]),
 'H8':  ([[24,44],[64,44],[64,80],[24,80],[44,10],[92,62],[94,22],[6,98]], [(0,1),(1,2),(2,3),(3,0),(0,4),(1,4),(2,5),(1,6),(3,7)]),
})
for k in ('HX7','G7','T7','C7','G8','C8','H8'):                      # stanoviště se nesmějí překrývat
    P=gen.LAYOUTS[k][0]
    assert all(math.dist(a,b) >= 24 for a,b in itertools.combinations(P,2)), k
def onev(it):
    n = 0
    for perm in itertools.permutations(it.empty):
        P = dict(it.fixed); P.update(zip(it.free, perm))
        n += sum(not gen.sat(it, r, P) for r in it.rules) == 1
    return n
SPEC = [  # úroveň, počet, rozvržení, pevných, pravidel, kritérium
    (7, 4, ['HX7','G7','T7','C7'], 2, [4], lambda ev, h: h['refutations'] >= 2 and ev['n_solutions'] <= 2),
    (8, 4, ['G8','C8','H8'], 2, [5], lambda ev, h: h['refutations'] >= 2 and h['refutation_depth'] >= 2 and ev['n_solutions'] <= 3),
]
def build(seed=41):
    rng = random.Random(seed); out = []; seen = set()
    for lvl, cnt, lays, nf, nrs, crit in SPEC:
        got = []; used = collections.Counter(); tries = 0
        while len(got) < cnt and tries < 500000:
            tries += 1
            lay = min(lays, key=lambda l: (used[l], rng.random()))
            it = gen.random_item(rng, lay, nf, rng.choice(nrs), [3, 2, 2, 1])
            if not it: continue
            ev = gen.evaluate(it)
            if not ev or ev['human']['depth'] is not None: continue
            if not crit(ev, ev['human']): continue
            if ev['near_miss'] < ev['n_wrong'] - 1: continue
            kinds = collections.Counter(r[0] for r in it.rules)
            if max(kinds.values()) > 2: continue
            c = gen.canon(it)
            if c in seen: continue
            ov = onev(it)
            if ov < (15 if lvl == 7 else 40): continue                  # hodně „skoro řešení“ → zkoušení nestačí
            seen.add(c); used[lay] += 1; ev['level'] = lvl; ev['one_violation'] = ov; got.append((it, ev))
        print('úroveň', lvl, 'nalezeno', len(got), 'pokusů', tries, file=sys.stderr)
        out += got
    return out
if __name__ == '__main__':
    bank = json.load(open('bank_st2_36.json'))
    assert len(bank['items']) == 36
    top = build()
    base = len(bank['items'])
    for k, (it, ev) in enumerate(top):
        x = gen.to_json(it, ev, 'S%02d' % (base + k + 1)); x['metriky']['porusuje_jedno'] = ev['one_violation']
        x['metriky']['rozmisteni_celkem'] = math.factorial(len(it.free)); bank['items'].append(x)
    bank['verze'] = 'ST2-44-v1.0'; bank['caps'].update({'7': 60, '8': 60})
    json.dump(bank, open('bank_st2_44.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    for x in bank['items'][36:]:
        m = x['metriky']; print(x['id'], 'L%d' % x['level'], x['layout'], 'pravidel', m['pravidel'], 'co kdyby', m['co_kdyby'], 'spor', m['hloubka_sporu'], 'nm %d/%d' % (m['near_miss'], m['chybnych_moznosti']), 'rozmístění', m['rozmisteni_celkem'], 'porušuje jedno', m['porusuje_jedno'], [r[0] for r in x['rules']], 'cíl v pravidlech' if any(x['target'] in r for r in x['rules']) else 'cíl bez pravidla')
