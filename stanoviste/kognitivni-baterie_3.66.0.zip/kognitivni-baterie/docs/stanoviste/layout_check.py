import itertools, math, sys
import gen_top, gen
def inter(p1,p2,p3,p4):
    d=lambda a,b,c:(c[0]-a[0])*(b[1]-a[1])-(b[0]-a[0])*(c[1]-a[1])
    d1,d2,d3,d4=d(p3,p4,p1),d(p3,p4,p2),d(p1,p2,p3),d(p1,p2,p4)
    return ((d1>0)!=(d2>0)) and ((d3>0)!=(d4>0))
def segdist(p,a,b):
    ax,ay=a; bx,by=b; t=max(0,min(1,((p[0]-ax)*(bx-ax)+(p[1]-ay)*(by-ay))/((bx-ax)**2+(by-ay)**2))); return math.dist(p,(ax+t*(bx-ax),ay+t*(by-ay)))
bad=0
for k,(P,E) in gen.LAYOUTS.items():
    for e,f in itertools.combinations(E,2):
        if len({*e,*f})==4 and inter(P[e[0]],P[e[1]],P[f[0]],P[f[1]]): print('KŘÍŽENÍ',k,e,f); bad+=1
    for e in E:
        for v in range(len(P)):
            if v not in e and segdist(P[v],P[e[0]],P[e[1]])<13: print('BLÍZKO',k,'cesta',e,'stanoviště',v,round(segdist(P[v],P[e[0]],P[e[1]]),1)); bad+=1
print('problémů:',bad)
