"""Nové stropové položky Počítání (C201–C207) a Slovních úloh (SU66–SU72); vyřazené zdlouhavé úlohy."""
from fractions import Fraction as F
import math
# --- kontrola výpočtů ---
assert sum((-1) ** (k + 1) * k for k in range(1, 101)) == -50
assert round((math.sqrt(12) + math.sqrt(27)) ** 2, 9) == 75
assert round(math.log(3, 2) * math.log(8, 3), 9) == 3
assert sum(F(1, k * (k + 1)) for k in range(1, 10)) == F(9, 10)
assert 2 ** 10 - sum(2 ** k for k in range(1, 10)) == 2
assert pow(7, 2026, 10) == 9
assert sum(map(int, str(10 ** 25 - 25))) == 219
m, h = 40 * 6, 3 * 30 + 40 * 0.5; assert min(abs(m - h), 360 - abs(m - h)) == 130
assert (200 + 1000) / (72 / 3.6) == 60
assert 3 / (1 / 3 + 1 / 6) == 6
assert 60 + 50 - (100 - 20) == 30
assert (1 / 0.02) == 50 and 100 - (1 / 0.02) == 50          # 1 žena = 2 % → 50 lidí → odejde 50 mužů
t = F(1) / (F(1, 4) - F(1, 6) * 2 + F(1, 6))                # 1 − t/6 = 2(1 − t/4)  →  t = 3 h
assert 1 - F(3, 6) == 2 * (1 - F(3, 4)); 
assert round(100 * 0.01 * 0.9 / (0.01 * 0.9 + 0.99 * 0.09)) == 9
POC = [  # id, b, stem CZ, stem EN, exact, show, rtype, scaf
    ('C201', 3.30, '1 − 2 + 3 − 4 + … + 99 − 100 =', None, '-50', '−50', 'integer', 'single_numeric'),
    ('C202', 3.45, '(√12 + √27)² =', None, '75', '75', 'integer', 'single_numeric'),
    ('C203', 3.60, 'log₂ 3 · log₃ 8 =', None, '3', '3', 'integer', 'single_numeric'),
    ('C204', 3.85, '1/(1·2) + 1/(2·3) + 1/(3·4) + … + 1/(9·10) =', None, '9/10', '9/10', 'fraction', 'fraction_or_decimal'),
    ('C205', 4.00, '2^10 − 2^9 − 2^8 − … − 2^2 − 2^1 =', None, '2', '2', 'integer', 'single_numeric'),
    ('C206', 4.15, 'poslední číslice čísla 7^2026 =', 'last digit of 7^2026 =', '9', '9', 'integer', 'single_numeric'),
    ('C207', 4.30, 'ciferný součet čísla 10^25 − 25 =', 'digit sum of 10^25 − 25 =', '219', '219', 'integer', 'single_numeric'),
]
UL = [  # id, b, struct, CZ, exact CZ, EN, exact EN
    ('SU66', 3.0, 'množiny, procenta (oba zároveň)',
     'Ve třídě má 60 % dětí doma psa, 50 % kočku a 20 % nemá ani jedno. Kolik procent dětí má psa i kočku?', '30 %',
     'In a class, 60 % of the children have a dog at home, 50 % have a cat and 20 % have neither. What percentage of the children have both a dog and a cat?', '30 %'),
    ('SU67', 3.2, 'pohyb, délka vlaku (past)',
     'Vlak dlouhý 200 m jede stálou rychlostí 72 km/h tunelem dlouhým 1 km. Kolik sekund uplyne od chvíle, kdy do tunelu vjede lokomotiva, do chvíle, kdy z něj vyjede poslední vagon?', '60 s',
     'A 200 m long train travels at a constant 72 km/h through a 1 km long tunnel. How many seconds pass from the moment the engine enters the tunnel until the last carriage leaves it?', '60 s'),
    ('SU68', 3.5, 'pohyb, rovnice (různá rychlost tam a zpět)',
     'Na kopec jdeš rychlostí 3 km/h a stejnou cestou zpátky dolů rychlostí 6 km/h. Celá cesta tam a zpět trvala 3 hodiny. Kolik kilometrů je to ze startu na vrchol?', '6 km',
     'You walk up a hill at 3 km/h and come back down the same way at 6 km/h. The whole trip up and back took 3 hours. How many kilometres is it from the start to the top?', '6 km'),
    ('SU69', 3.7, 'úhel ručiček (hodinová se posouvá)',
     'Jaký úhel ve stupních svírají hodinová a minutová ručička ve 3:40? Uveď menší z obou úhlů.', '130 °',
     'What angle in degrees is there between the hour hand and the minute hand at 3:40? Give the smaller of the two angles.', '130 °'),
    ('SU70', 4.0, 'poměr, neintuitivní procenta',
     'V sále je 100 lidí a 99 % z nich jsou muži. Kolik mužů musí odejít, aby muži tvořili 98 % lidí v sále?', '50',
     'There are 100 people in a hall and 99 % of them are men. How many men must leave so that men make up 98 % of the people in the hall?', '50'),
    ('SU71', 4.3, 'rovnoměrné ubývání, rovnice',
     'Dvě stejně dlouhé svíčky zapálíš najednou. První by celá shořela za 6 hodin, druhá za 4 hodiny. Za kolik minut bude první svíčka dvakrát delší než druhá?', '180 min',
     'You light two candles of the same length at the same time. The first would burn down completely in 6 hours, the second in 4 hours. After how many minutes will the first candle be twice as long as the second?', '180 min'),
    ('SU72', 4.6, 'podmíněná pravděpodobnost (falešně pozitivní test)',
     'Nemoc má 1 % lidí. Test ji u nemocného odhalí v 90 % případů, ale u zdravého člověka vyjde chybně pozitivní v 9 % případů. Tvůj test vyšel pozitivní. Jaká je pravděpodobnost, že nemoc opravdu máš? Odpověz v procentech a zaokrouhli na celá procenta.', '9 %',
     '1 % of people have a disease. The test detects it in 90 % of sick people, but in healthy people it is falsely positive in 9 % of cases. Your test came back positive. What is the probability that you really have the disease? Answer in percent, rounded to whole percent.', '9 %'),
]
DROP_UL = ['SU44', 'SU45', 'SU53', 'SU54', 'SU56', 'SU57', 'SU60', 'SU65']   # zdlouhavé vícekrokové počty (medián 60–90 s), obtížnost hlavně z pracnosti
DROP_POC = ['C106', 'C166', 'C058', 'C039', 'C062', 'C071']   # duplicitní typy (log₂ 32 ~ C112/C203, sin 30° ~ C169, desetinná čísla, zlomky, procenta, záporná)
DROP_PAP = ['PAP_004', 'PAP_007', 'PAP_009', 'PAP_012', 'PAP_015', 'PAP_019', 'PAP_031', 'PAP_038']   # p ≥ .95 nebo zdvojené typy
def build(poc, ul, en):
    poc = [dict(x) for x in poc if x['id'] not in DROP_POC]
    for i, b, cz, e, ex, sh, rt, sc in POC:
        poc.append({'id': i, 'b': b, 'stem': (e or cz) if en else cz, 'exact': ex, 'show': sh, 'rtype': rt, 'scaf': sc, 'tpl': '[   ]', 'n': 1})
    poc.sort(key=lambda x: x['b'])
    for k, x in enumerate(poc): x['poradi'] = k + 1
    ul = [dict(x) for x in ul if x['id'] not in DROP_UL]
    for i, b, st, cz, ecz, enS, een in UL:
        ul.append({'id': i, 'b': b, 'stem': enS if en else cz, 'exact': een if en else ecz, 'struct': st})
    ul.sort(key=lambda x: x['b'])
    return poc, ul
