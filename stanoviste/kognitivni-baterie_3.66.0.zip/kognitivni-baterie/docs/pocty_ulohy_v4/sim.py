"""Simulace adaptivní administrace (kopie recordTest) – Rasch s b z banky."""
import json, math, random, statistics as st
def run(bs, start, skip, theta, stop=4, rng=random, maxb=99):
    n = len(bs); a = dict(start=start, dir='fwd', fwdNext=start, fwdCount=0, reversed=start == 0, revConsec=0, consecErr=0, basal=None, done={}, skipped={}, runOk=0)
    i = start
    def p(j): return 1 / (1 + math.exp(-(theta - bs[j])))
    while True:
        ok = rng.random() < p(i); a['done'][i] = ok
        if a['dir'] == 'fwd':
            a['fwdCount'] += 1; a['consecErr'] = 0 if ok else a['consecErr'] + 1; a['runOk'] = a['runOk'] + 1 if ok else 0
            if not ok and a['skipped'].get(i - 1) and (i - 1) not in a['done']: del a['skipped'][i - 1]; i = i - 1; continue
            if not a['reversed'] and not ok and a['fwdCount'] <= 2:
                a['reversed'] = True; a['dir'] = 'rev'; a['fwdNext'] = i + 1; a['revConsec'] = 0
                if start - 1 >= 0: i = start - 1; continue
                a['dir'] = 'fwd'
            if a['consecErr'] >= stop: break
            j = max(i + 1, a['fwdNext'])
            while j < n and (j in a['done'] or a['skipped'].get(j)): j += 1
            if skip and ok and a['runOk'] >= skip[0] and j < n - 1:
                for _ in range(skip[1]):
                    if j < n - 1 and bs[j] < maxb: a['skipped'][j] = True; j += 1
                a['runOk'] = 0
                while j < n and j in a['done']: j += 1
            if j >= n: break
            a['fwdNext'] = j + 1; i = j; continue
        a['revConsec'] = a['revConsec'] + 1 if ok else 0
        if a['revConsec'] >= 2: a['basal'] = i; a['dir'] = 'fwd'
        elif i - 1 >= 0: i -= 1; continue
        else: a['basal'] = 0; a['dir'] = 'fwd'
        j = a['fwdNext']
        while j < n and j in a['done']: j += 1
        if a['consecErr'] >= stop: break
        if j >= n: break
        a['fwdNext'] = j + 1; i = j
    corr = sum(1 for v in a['done'].values() if v); cred = 0
    for k in range(n):
        if k in a['done']: continue
        if a['skipped'].get(k): cred += 1
        elif (k < a['basal']) if a['basal'] is not None else (start > 0 and not a['reversed'] and k < start and a['fwdCount'] >= 2): cred += 1
    return len(a['done']), corr + cred, sum(1 / (1 + math.exp(-(theta - b))) for b in bs)
def report(name, bs, start, skip, thetas=(-1, 0, 1, 2, 3, 4), R=400, maxb=99):
    random.seed(1); out = []
    for th in thetas:
        r = [run(bs, start, skip, th, maxb=maxb) for _ in range(R)]
        n = st.mean(x[0] for x in r); err = st.mean(x[1] - x[2] for x in r); sd = st.pstdev(x[1] - x[2] for x in r)
        out.append('θ=%+d: %4.1f pol., bias %+.1f, sd %.1f' % (th, n, err, sd))
    print('%-34s' % name, ' | '.join(out))
if __name__ == '__main__':
    for nm in ('pocitani_v2', 'ulohy_v2'):
        T = json.load(open(nm + '.json'))['test']; bs = [x['b'] for x in T]
        first = lambda t: next(k for k, b in enumerate(bs) if b >= t)
        cur = (2, 1) if nm[0] == 'p' else (3, 1); s0 = first(-0.8) if nm[0] == 'p' else first(-1.8)
        print('==', nm)
        report('současnost start %d skip %s' % (s0, cur), bs, s0, cur)
        for t in (0.0, 0.3):
            for sk in ((2, 1), (2, 2), (1, 1)):
                report('start b≥%.1f (%d) skip %s' % (t, first(t), sk), bs, first(t), sk)
