import csv, io, collections, json, statistics as stt
U='/root/.claude/uploads/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/'
D=[]
for f,lab in (('46c379cc-kb_rows_20261002_192427.csv','CZ'),('f92f1e9e-kben_rows_20261002_192417.csv','EN')):
    for r in csv.DictReader(io.StringIO(open(U+f,encoding='utf-8-sig').read()),delimiter=';'):
        if r['test'] in ('papir','pocitani','ulohy') and r.get('faze')=='test':
            r['src']=lab; D.append(r)
json.dump(D,open('st10/raw.json','w'))
print(D[0].keys())
for t in ('papir','pocitani','ulohy'):
    x=[r for r in D if r['test']==t]
    print('\n==',t,len(x),'sezení',len({r['sezeni'] for r in x}), collections.Counter(r['forma'] for r in x))
    g=collections.defaultdict(list)
    for r in x: g[r['polozka']].append(r)
    for k in sorted(g, key=lambda k:int(g[k][0]['poradi'] or 0)):
        y=g[k]; ok=[float(r['rt_ms'])/1000 for r in y if r['spravne']=='1']
        print(k, y[0]['poradi'], y[0].get('b_prior'), y[0].get('typ'), 'n=%d p=%.2f'%(len(y),sum(r['spravne']=='1' for r in y)/len(y)), 'rt_ok_med=%s'%(round(stt.median(ok),1) if ok else '-'))
