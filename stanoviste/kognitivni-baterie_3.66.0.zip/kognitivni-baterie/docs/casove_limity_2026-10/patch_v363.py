"""3.63.0 / 1.24.0 – časové stropy: běžné položky max 90 s, náročné bloky max 120 s; přepočet dřívějších výsledků + druhá čára."""
import os, json, shutil
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
# --- data pro převod rotace (pořadí v6, empirické b, úvod pro děti) ---
s = open(CZ + 'assets/app.html', encoding='utf8').read(); i = s.index('const BANK_ROT = ') + 17
ROT = [x for x in json.JSONDecoder().raw_decode(s[i:])[0] if not x.get('practice')]
ROTD = {'order': [x['id'] for x in ROT], 'b': {x['id']: x['b_emp'] for x in ROT if 'b_emp' in x},
        'kids': ['MR4_001', 'MR4_002', 'MR4_003', 'MR4_004', 'MR4_006', 'MR4_008', 'MR4_010']}
assert len(ROTD['order']) == 38
TPL = open('st12/recode.php.tpl', encoding='utf8').read().replace('ROTJSON', json.dumps(ROTD, separators=(',', ':')))
for d, pfx, PFXU in ((CZ, 'kb', 'KB'), (EN, 'kben', 'KBEN')):
    app = d + 'assets/app.html'; adm = d + 'includes/admin.php'; rst = d + 'includes/rest.php'
    # --- server: přepočet ---
    rep(adm, "function %s_ded_caps() { return array(1 => 30, 2 => 30, 3 => 60, 4 => 100, 5 => 100, 6 => 90, 7 => 90, 8 => 120, 9 => 120); }" % pfx,
        "function %s_ded_caps() { return array(1 => 30, 2 => 30, 3 => 60, 4 => 90, 5 => 90, 6 => 90, 7 => 90, 8 => 120, 9 => 120); }" % pfx)
    rep(adm, "define('%s_DED_CAPS_TAG', 'limity-DED-24-v2.2');" % PFXU, "define('%s_DED_CAPS_TAG', 'limity-DED-24-v2.3');" % PFXU)
    rep(adm, "\nfunction %s_admin_overview() {" % pfx, TPL.replace('PFXU_', PFXU + '_').replace('PFX_', pfx + '_') + "\nfunction %s_admin_overview() {" % pfx)
    # --- server: průběh vrací i skór před úpravou (druhá čára) ---
    rep(rst, "'valid' => (int) $x->valid, 'date' => $x->created, 'konec' => is_array($d) && isset($d['konec']) ? (string) $d['konec'] : '');",
        "'valid' => (int) $x->valid, 'date' => $x->created, 'konec' => is_array($d) && isset($d['konec']) ? (string) $d['konec'] : '');\n"
        "        if (is_array($d) && (isset($d['hruby_pred_upravou']) || isset($d['hruby_puvodni'])) && (isset($d['prepocet_limity']) || isset($d['prepocet']))) {   // přepočet podle časových limitů\n"
        "            $pred = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : $d['hruby_puvodni'];\n"
        "            if (is_numeric($pred) && $x->raw_score !== null && floatval($pred) != floatval($x->raw_score)) { $out[$x->test_key]['raw_pred'] = floatval($pred); }\n        }")
    # --- aplikace: limity ---
    rep(app, "      S.mxCap = (it.level || 1) >= 9 ? 120 : 90;", "      S.mxCap = 90;   // od v10-56t90 všechny úrovně 90 s (dříve 9–11: 120 s)")
    rep(app, "version:'v10-56t', bank:BANK,", "version:'v10-56t90', bank:BANK,")
    rep(app, "['v10-56', 'v10-56t']],", "['v10-56', 'v10-56t', 'v10-56t90']],")
    i = app; t = open(app, encoding='utf8').read(); k = t.index('const BANK_DED = ') + 17; D, e = json.JSONDecoder().raw_decode(t[k:]); n = 0
    for it in D['items']:
        if it['tier'] in (4, 5): assert it['cap'] == 100; it['cap'] = 90; n += 1
    assert n == 6; t = t[:k] + json.dumps(D, ensure_ascii=False, separators=(',', ':')) + t[k + e:]
    k = t.index('const BANK_VAHY = ') + 18; V, e = json.JSONDecoder().raw_decode(t[k:]); n = 0
    for it in V['test']:
        if it['id'].startswith('V2_K'): assert it['time_limit_ms'] == 180000; it['time_limit_ms'] = 120000; n += 1
    assert n == 15; t = t[:k] + json.dumps(V, ensure_ascii=False, separators=(',', ':')) + t[k + e:]
    open(app, 'w', encoding='utf8').write(t)
    rep(app, '"limits":{"1":45,"2":60,"3":90,"4":90,"5":150}', '"limits":{"1":45,"2":60,"3":90,"4":90,"5":120}')
    rep(app, "VERSION = 'HP-36-v1.1'", "VERSION = 'HP-36-v1.2'"); rep(app, "pravidla:[['HP-36-v1.0', 'HP-36-v1.1']],", "pravidla:[['HP-36-v1.0', 'HP-36-v1.1', 'HP-36-v1.2']],")
    rep(app, "version:'DED-24-v2.2'", "version:'DED-24-v2.3'"); rep(app, "CUR.formLabel = 'DED-24-v2.2';", "CUR.formLabel = 'DED-24-v2.3';")
    rep(app, "['DED-24-v2.0', 'DED-24-v2.1', 'DED-24-v2.2']", "['DED-24-v2.0', 'DED-24-v2.1', 'DED-24-v2.2', 'DED-24-v2.3']")
    rep(app, "version:'v2-39-ui3-bl'", "version:'v2-39-ui3-bl3'"); rep(app, "'v2-39-ui3-bl', 'v2-39-ui3-bl2']]", "'v2-39-ui3-bl', 'v2-39-ui3-bl2', 'v2-39-ui3-bl3']]")
    rep(app, "version:'Gv-KOS-v4',", "version:'Gv-KOS-v4t', capFor:() => 90,")
    rep(app, "version:'SK-v1', pickN:3,", "version:'SK-v1t', capFor:() => 90, pickN:3,")
    t = open(app, encoding='utf8').read()
    for key, v in (('kostky', 'Gv-KOS-v4'), ('skladani', 'SK-v1')):
        if ('\n  %s:[[' % key) in t: raise SystemExit('neočekávaná skupina ' + key)
    rep(app, "  pravidla:[['HP-36-v1.0', 'HP-36-v1.1', 'HP-36-v1.2']],", "  pravidla:[['HP-36-v1.0', 'HP-36-v1.1', 'HP-36-v1.2']],\n  kostky:[['Gv-KOS-v4', 'Gv-KOS-v4t']], skladani:[['SK-v1', 'SK-v1t']],")
    # --- aplikace: druhá čára ve výsledcích ---
    rep(app, "function kbDensitySVG(vals, mine){", "function kbDensitySVG(vals, mine, pred){")
    rep(app, "  const lo = Math.min(...vals, mine), hi = Math.max(...vals, mine), span = (hi - lo) || 1;",
        "  const two = typeof pred === 'number' && pred !== mine;\n  const lo = Math.min(...vals, mine, two ? pred : mine), hi = Math.max(...vals, mine, two ? pred : mine), span = (hi - lo) || 1;")
    you = 'Vy' if d == CZ else 'You'
    rep(app, """    <text x="${X(mine)}" y="${pad - 8}" text-anchor="middle" font-size="24" font-weight="700" fill="var(--ink)">""" + you + """</text>""",
        """    <text x="${X(mine)}" y="${pad - 8}" text-anchor="middle" font-size="24" font-weight="700" fill="var(--ink)">""" + you + """</text>${two ? `
    <line x1="${X(pred)}" x2="${X(pred)}" y1="${pad + 22}" y2="${Hh - pad}" stroke="var(--muted)" stroke-width="3" stroke-dasharray="7 5"/>
    <text x="${X(pred)}" y="${pad + 16}" text-anchor="middle" font-size="17" fill="var(--muted)">${KB_PRED_LBL}</text>` : ''}""")
    lbl = ('původně', 'Váš výsledek po úpravě časových limitů: <b>${raw}</b> bodů <span class="muted">(dříve bez nich ${pred})</span>',
           'Přerušovaná čára je váš dřívější výsledek – položky vyřešené až po novém časovém limitu se teď počítají jako chybné, stejně jako u všech nových vyplnění.')
    if d == EN: lbl = ('before', 'Your result after the time-limit update: <b>${raw}</b> points <span class="muted">(previously ${pred})</span>',
                       'The dashed line is your earlier result – items solved only after the new time limit now count as wrong, the same as for everyone taking the test now.')
    rep(app, "async function kbResultCard(k, raw, version){",
        "const KB_PRED_LBL = '%s';\nasync function kbResultCard(k, raw, version, pred){\n  const two = typeof pred === 'number' && pred !== raw;" % lbl[0])
    t = open(app, encoding='utf8').read(); a = t.index('async function kbResultCard('); b = t.index('\n}', a)
    body = t[a:b]
    old_head = [ln for ln in body.split('\n') if ln.strip().startswith('return `<section class="card res-card"><h2>${MODULES[k].name}</h2>')][0]
    pre, rest = old_head.split('<p style="font-size:20px">', 1); _, after = rest.split('</p>', 1)
    new_head = pre + '<p style="font-size:20px">` + (two ? `%s` : `' % lbl[1] + rest.split('</p>', 1)[0] + '`) + `</p>' + after
    body2 = body.replace(old_head, new_head).replace('kbDensitySVG(vals, raw)', 'kbDensitySVG(vals, raw, two ? pred : undefined)')
    body2 = body2.replace("lidí, kteří test vyplnili.</p>`", "lidí, kteří test vyplnili.</p>` + (two ? `<p class=\"muted\" style=\"font-size:15px\">%s</p>` : '')" % lbl[2]) if d == CZ else \
            body2.replace("people who took the test scored the same or lower.</p>`", "people who took the test scored the same or lower.</p>` + (two ? `<p class=\"muted\" style=\"font-size:15px\">%s</p>` : '')" % lbl[2])
    assert body2.count('two ?') >= 3, body2[:400]
    t = t[:a] + body2 + t[b:]; open(app, 'w', encoding='utf8').write(t)
    rep(app, "if (v.raw_score !== null && v.valid) mine[k] = {raw:v.raw_score, version:v.version}; });",
        "if (v.raw_score !== null && v.valid) mine[k] = {raw:v.raw_score, version:v.version, pred:typeof v.raw_pred === 'number' ? v.raw_pred : undefined}; });")
    rep(app, "for (const k of keys) html += await kbResultCard(k, mine[k].raw, mine[k].version);", "for (const k of keys) html += await kbResultCard(k, mine[k].raw, mine[k].version, mine[k].pred);")
rep(CZ + 'kognitivni-baterie.php', '3.62.0', '3.63.0', 2); rep(EN + 'cognitive-battery-en.php', '1.23.0', '1.24.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.62.0</div>', '>verze 3.63.0</div>'); rep(EN + 'assets/app.html', '>version 1.23.0 (EN)</div>', '>version 1.24.0 (EN)</div>')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VE VERZI 3.63.0 – Časové stropy: běžné položky max 90 s, náročné bloky max 120 s; přepočet dřívějších výsledků
Záměr: zefektivnit administraci (jako časované subtesty WAIS); rychlost se tím do skóre přidá jen málo.
- Matice v10-56t90: úrovně 9–11 120 → 90 s (data 2026-10: utne 8 % správných).
- Tvarové klíče DED-24-v2.3: úrovně 4–5 100 → 90 s (utne 0 %); 8–9 zůstávají 120 s (náročný blok; 90 s by utnulo 43 %).
- Hledání pravidla HP-36-v1.2: úroveň 5 150 → 120 s (utne 15 %; 90 s by utnulo 25 %).
- Váhy v2-39-ui3-bl3: blok K 180 → 120 s (utne 23 %; 90 s by utnulo 33 %).
- Pohled na stavbu Gv-KOS-v4t a Skládání tvarů SK-v1t: nově tvrdý limit 90 s (dříve jen pobídka po 60 s).
- Beze změny: Skládání papíru (úroveň 10: 120 s), Mentální rotace (45/60/90 s), Počítání a Slovní úlohy (45–90 s),
  Stanoviště (45–90 s), testy rychlosti s pevným časem (Symboly, Shodné řady, SRCE) a testy Gc bez limitu.
Přepočet dřívějších výsledků (includes/admin.php, kb_recode_caps2 + kb_recode_dedukce_v2 se značkou limity-DED-24-v2.3):
spustí se sám při prvním otevření administrace. Správná odpověď za novým limitem = chybná; hrubý skór = skór před úpravou
− ztracené položky (bez dominového efektu pravidla ukončení; u Tvarových klíčů se ukončení přepočítává jako dřív).
Mentální rotace MR-v5-50* a MR-v6-38t se převedou na škálu MR-v6-38h (38 položek; úvod pro děti se dospělým připisuje).
Skór před úpravou je v datech jako hruby_pred_upravou a ve výsledcích se zobrazí jako druhá (přerušovaná) čára
„původně“; srovnání a korelace už počítají s upraveným skórem. Ve srovnání spojeno s předchozími verzemi (stejné položky).
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.24.0 – časové stropy (běžné 90 s, náročné bloky 120 s), přepočet dřívějších výsledků a druhá čára ve výsledcích – stejně jako česká 3.63.0.
''')
dd = CZ + 'docs/casove_limity_2026-10/'; shutil.copy('st12/patch_v363.py', dd + 'patch_v363.py'); shutil.copy('st12/recode.php.tpl', dd + 'prepocet_limity_2026-10b.php.txt')
print('ok')
