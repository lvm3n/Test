import csv, io, re, collections, json
U='/root/.claude/uploads/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/'
def lvl(t,r):
    if t=='matice': return int(r['uroven']) if r.get('uroven') else None
    if t=='vahy': m=re.match(r'V2_([A-Z])',r['id'] or ''); return m.group(1) if m else None
    if t in ('papir','rotace'): m=re.search(r'(\d+)',r.get('typ') or ''); return int(m.group(1)) if m else None
    if t=='pravidla': return int(r['uroven']) if r.get('uroven') else None
    if t in ('pocitani','ulohy'): 
        try: b=float(r['b_prior']); return 'b<0' if b<0 else 'b0-2' if b<2 else 'b≥2'
        except: return None
CUR={'matice':{**{i:90 for i in range(1,9)},**{i:120 for i in (9,10,11)}},
     'vahy':{**{c:45 for c in 'ABCDEF'},'G':60,'H':75,'J':90,'K':180},
     'papir':{1:45,2:45,3:45,4:45,5:45,6:90,7:60,8:60},
     'rotace':{1:45,2:45,3:45,4:120,5:120,6:120,7:120,8:150},
     'pravidla':{1:45,2:60,3:90,4:90,5:150},
     'pocitani':{'b<0':90,'b0-2':90,'b≥2':90},'ulohy':{'b<0':90,'b0-2':90,'b≥2':90}}
D=[]
for f,lab in (('46c379cc-kb_rows_20261002_192427.csv','CZ'),('f92f1e9e-kben_rows_20261002_192417.csv','EN')):
    for r in csv.DictReader(io.StringIO(open(U+f,encoding='utf-8-sig').read()),delimiter=';'):
        t=r['test']
        if t not in CUR or r.get('faze') not in ('test','sonda'): continue
        if t=='papir' and not (r.get('forma') or '').startswith('Gv-PAP-v5-r2'): continue
        if t=='rotace' and not (r.get('forma') or '').startswith('MR-v5-50'): continue
        if t=='pravidla' and not (r.get('forma') or '').startswith('HP-36'): continue
        L=lvl(t,r)
        if L is None or not r.get('rt_ms'): continue
        lim=int(r['time_limit_ms']) if (r.get('time_limit_ms') or '0').isdigit() and r.get('time_limit_ms') else 0
        ok=r.get('spravne')=='1' or (t=='rotace' and r.get('skore')==r.get('max_skore') and r.get('skore'))
        D.append(dict(src=lab,t=t,L=L,ok=1 if ok else 0,rt=float(r['rt_ms'])/1000,lim=lim/1000,to=r.get('timeout')=='1',who=r['sezeni']))
json.dump(D,open('rows.json','w'))
def q(xs,p):
    xs=sorted(xs); k=(len(xs)-1)*p; f=int(k); c=min(f+1,len(xs)-1); return xs[f]+(xs[c]-xs[f])*(k-f)
for t in CUR:
    X=[d for d in D if d['t']==t]
    print('\n== %s  (%d odpovědí, %d sezení; CZ %d / EN %d)'%(t,len(X),len({d['who'] for d in X}),sum(d['src']=='CZ' for d in X),sum(d['src']=='EN' for d in X)))
    print(' úr.   n    p | bez limitu: n_ok  p90  p95  max | všechny správné: n_ok  nad limitem | limit | vypršení')
    for L in sorted({d['L'] for d in X if d['L'] in CUR[t]},key=lambda x:(str(type(x)),x)):
        Y=[d for d in X if d['L']==L]; ok=[d['rt'] for d in Y if d['ok']]; unc=[d['rt'] for d in Y if d['ok'] and d['lim']==0]
        cap=CUR[t][L]
        u=' %4d %4.0f %4.0f %4.0f'%(len(unc),q(unc,.9),q(unc,.95),max(unc)) if len(unc)>=6 else '      (málo / useknuto) '
        lost=sum(r>cap for r in ok)
        print(' %-4s %4d %.2f |%s | %4d  %3d = %4.1f %% | %4ds | %d'%(L,len(Y),sum(d['ok'] for d in Y)/len(Y),u,len(ok),lost,100*lost/max(1,len(ok)),cap,sum(d['to'] for d in Y)))
