import json, math, collections
D = [r for r in json.load(open('rot_rows.json')) if r['forma'].startswith('MR-v5')]
B = {x['id']: x for x in json.load(open('rot.json'))}
X = collections.defaultdict(dict)
for r in D: X[r['sezeni']][r['id']] = 1 if r['spravne'] == '1' else 0
items = sorted({i for v in X.values() for i in v}); P = list(X)
# položky / osoby s extrémním skóre: přidáme slabý prior (penalizace) místo vyřazení
b = {i: 0.0 for i in items}; th = {p: 0.0 for p in P}
for it in range(300):
    for p in P:
        g = sum(x - 1 / (1 + math.exp(-(th[p] - b[i]))) for i, x in X[p].items()) - th[p] * 0.1
        h = sum((q := 1 / (1 + math.exp(-(th[p] - b[i])))) * (1 - q) for i in X[p]) + 0.1
        th[p] += max(-1, min(1, g / h))
    for i in items:
        rs = [(p, X[p][i]) for p in P if i in X[p]]
        g = sum(1 / (1 + math.exp(-(th[p] - b[i]))) - x for p, x in rs) - b[i] * 0.1
        h = sum((q := 1 / (1 + math.exp(-(th[p] - b[i])))) * (1 - q) for p, _ in rs) + 0.1
        b[i] += max(-1, min(1, g / h))
    m = sum(b.values()) / len(b); b = {i: v - m for i, v in b.items()}
out = {i: round(b[i], 2) for i in items}
json.dump(out, open('rasch_b.json', 'w'))
lv = collections.defaultdict(list)
for i in items: lv[B[i]['level']].append(b[i])
print('průměrné b podle úrovně:', {k: round(sum(v) / len(v), 2) for k, v in sorted(lv.items())})
for i in sorted(items, key=lambda i: b[i]): print(i, B[i]['level'], round(b[i], 2), 'n=%d' % sum(1 for p in P if i in X[p]), 'p=%.2f' % (sum(X[p][i] for p in P if i in X[p]) / sum(1 for p in P if i in X[p])))
