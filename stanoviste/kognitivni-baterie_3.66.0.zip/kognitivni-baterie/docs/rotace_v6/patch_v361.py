"""3.61.0 / 1.22.0 – Mentální rotace MR-v6-38t: pořadí podle empirické obtížnosti (Rasch), 38 položek."""
import os, json, csv, io, shutil
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:90], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
BEMP = json.load(open('st11/rasch_b.json'))
KIDS = ['MR4_001', 'MR4_002', 'MR4_003', 'MR4_004', 'MR4_006', 'MR4_008', 'MR4_010']       # úvod pro děti (do 8 let); dospělým se připíšou
DROP = ['MR4_005', 'MR4_007', 'MR4_009', 'MR4_011', 'MR4_012', 'MR4_014', 'MR4_015',        # úrovně 2–3: všichni správně (21/21)
        'MR4_031', 'MR4_033', 'MR4_038', 'MR4_048', 'MR4_050']                               # úrovně 6–8, ale všichni správně
def newbank(B):
    prac = [x for x in B if x.get('practice')]; it = {x['id']: x for x in B if not x.get('practice')}
    rest = sorted([i for i in it if i not in KIDS and i not in DROP], key=lambda i: (BEMP[i], it[i]['level'], i))
    out = prac + [it[i] for i in KIDS] + [it[i] for i in rest]
    for x in out:
        if x['id'] in BEMP: x['b_emp'] = BEMP[x['id']]
    assert len(out) - len(prac) == 38, len(out); return out
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read(); i = s.index('const BANK_ROT = ') + 17
    B, end = json.JSONDecoder().raw_decode(s[i:]); assert len(B) == 52; NB = newbank(B)
    s = s[:i] + json.dumps(NB, ensure_ascii=False, separators=(',', ':')) + s[i + end:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'MR-v5-50t', pickN:2,", "version:'MR-v6-38t', pickN:2,", 1)
    rep(app, "startFor:(list, age) => age <= 8 ? 0 : Math.min(5, list.length - 1),      // od 9 let start u položky 6",
        "startFor:(list, age) => age <= 8 ? 0 : Math.max(0, list.findIndex(x => x.id === 'MR4_020')),   // od 9 let start za úvodem pro děti (7 položek se připíše)", 1)
    rep(app, "  rotace:[['MR-v4-50', 'MR-v5-50', 'MR-v5-50t']],", "  rotace:[['MR-v4-50', 'MR-v5-50', 'MR-v5-50t'], ['MR-v6-38t']],   // v6: 38 položek, pořadí podle dat → samostatná skupina", 1)
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'rotace']
    for k, x in enumerate(NB):
        body.append(['rotace', 'MR-v6-38t', k + 1, x['id'], 'mentální rotace, %d možností' % len(x['options']), ' '.join(str(j + 1) for j in x['answerIdx']),
                     'úroveň %s' % x['level'] + ('; b (data 2026-10) %s' % x['b_emp'] if 'b_emp' in x else ''), '', 'nácvik' if x.get('practice') else ''])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.60.1', '3.61.0', 2); rep(EN + 'cognitive-battery-en.php', '1.21.1', '1.22.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.60.1</div>', '>verze 3.61.0</div>', 1); rep(EN + 'assets/app.html', '>version 1.21.1 (EN)</div>', '>version 1.22.0 (EN)</div>', 1)
dd = CZ + 'docs/rotace_v6/'; os.makedirs(dd, exist_ok=True)
for f in ('rasch.py', 'rasch_b.json', 'patch_v361.py'): shutil.copy('st11/' + f, dd + f)
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VE VERZI 3.61.0 – Mentální rotace MR-v6-38t (38 položek místo 50, pořadí podle dat)
Data 2026-10 (MR-v5, 21 sezení, Rasch JML, docs/rotace_v6/): úrovně 2–3 vyřešili všichni (10 položek bez informace),
úrovně 4–8 jsou v průměru stejně těžké (průměrné b 0,4 / 0,8 / 0,9 / 1,0 / 0,8) a návrhové facety (kostky, osy, úhel,
spojitý povrch, úroveň) obtížnost nepředpovídají (r ≈ 0,05–0,2). Dokončení 45 položek trvalo 19–49 min.
- Vyřazeno 12 položek, které vyřešili všichni: MR4_005, 007, 009, 011, 012, 014, 015 (úrovně 2–3) a MR4_031, 033, 038,
  048, 050 (úrovně 6–8).
- Úvod pro děti (do 8 let): MR4_001–004, 006, 008, 010. Od 9 let se začíná za ním (7 položek se připíše, při chybě
  v prvních dvou návrat jako dřív).
- Zbylých 31 položek seřazeno podle empirické obtížnosti (b −2,5 … 3,3) místo podle úrovní – obtížnost teď stoupá,
  takže pravidlo 4 chyb v řadě ukončuje dřív a strop dává smysl. Pole b_emp v bance.
- Časové limity beze změny (podle úrovně položky 45 / 120 / 150 s; utínají 5–7 % správných u těžkých).
- Nová srovnávací skupina. Odhady b stojí na 10–21 odpovědích na položku – po nasbírání dat přepočítat.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.22.0 – Mental Rotation MR-v6-38t: 38 položek seřazených podle empirické obtížnosti, vyřazeno 12 položek, které vyřešili všichni
(stejně jako česká 3.61.0).
''')
print('ok')
