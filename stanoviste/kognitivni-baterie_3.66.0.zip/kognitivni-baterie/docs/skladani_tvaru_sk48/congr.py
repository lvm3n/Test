import math, json
from shapely import affinity
from roundcheck import geo
def best_overlap(a, b, mirror=False):
    if mirror: b = affinity.scale(b, -1, 1)
    ca, cb = a.centroid, b.centroid; b0 = affinity.translate(b, ca.x - cb.x, ca.y - cb.y); best = 9
    for k in range(720):
        r = affinity.rotate(b0, k * 0.5, origin=ca)
        best = min(best, a.symmetric_difference(r).area / a.area)
    return best
if __name__ == '__main__':
    B = {it['n']: it for it in json.load(open('bank_sk48.json'))}
    for n, pairs in ((11, [(2, 1)]), (23, [(6, 1)]), (25, [(2, 6)]), (28, [(6, 4)]), (33, [(1, 3), (5, 2)]), (41, [(5, 3)]), (47, [(1, 4), (3, 2)])):
        it = B[n]; G = [geo(o['paths']) for o in it['options']]
        for d, k in pairs:
            print(n, 'distraktor', d, 'vs klíč', k, 'rozdíl po otočení %.3f, po zrcadlení %.3f' % (best_overlap(G[k - 1], G[d - 1]), best_overlap(G[k - 1], G[d - 1], True)), flush=True)
