"""Předpokládaná obtížnost (bez dat): složitost dílů, blízkost distraktorů, zrcadla, barevná vodítka, počet dílů."""
import json, math, statistics as st
F = json.load(open('features.json')); BANDS = {'podlahová': 0, 'velmi lehká': 1, 'střední': 2, 'vyšší': 3, 'velmi obtížná': 4, 'vysoká': 4, 'ceiling probe': 5}
def z(vals):
    m, s = st.mean(vals), st.pstdev(vals) or 1; return [(v - m) / s for v in vals]
def index(F):
    cx = z([(f['vrcholu'] if f['vrcholu'] != 'oblouk' else 8.0) for f in F])
    cl = z([-math.log(max(f['nejbliz'], 0.02)) for f in F])
    mi = [min(f['zrcadel'], 1) for f in F]; co = [1 if f['barvy'] >= 2 else 0 for f in F]
    sm = z([-f['nejmensi_dil'] for f in F]); bd = z([BANDS.get(f['pasmo'], 5) for f in F])
    out = []
    for i, f in enumerate(F):
        v = 0.9 * cx[i] + 0.8 * cl[i] + 0.4 * mi[i] - 0.4 * co[i] + 0.3 * sm[i] + 0.4 * bd[i] - (2.5 if f['dilu'] == 2 else 0)
        out.append(round(v, 2))
    return out
if __name__ == '__main__':
    idx = index(F)
    for f, v in sorted(zip(F, idx), key=lambda t: t[1]): print('%5.2f' % v, f['n'], f['pasmo'], 'vrch', f['vrcholu'], 'nejbliž', f['nejbliz'], 'zrc', f['zrcadel'], 'barvy', f['barvy'])
