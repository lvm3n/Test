"""Shodné/téměř shodné položky: stejný cílový tvar (až na podobnost) a stejné klíčové díly."""
import json, math, itertools
from roundcheck import geo
from congr import best_overlap
from shapely import affinity
B = json.load(open('bank_sk48.json'))
def norm(g):
    c = g.centroid; return affinity.translate(g, -c.x, -c.y)
T = {it['n']: geo(it['target']['paths']) for it in B}
K = {it['n']: [geo(it['options'][i]['paths']) for i in it['answerIdx']] for it in B}
TC = {it['n']: tuple(sorted({p['fill'] for p in it['target']['paths']})) for it in B}
def tsim(a, b):
    ga, gb = norm(T[a]), norm(T[b]); return min(best_overlap(ga, gb), best_overlap(ga, gb, True))
def ksim(a, b):
    # párování klíčových dílů podle nejlepší shody (otáčení i zrcadlení – jde o „stejnou položku“)
    best = 9
    for perm in itertools.permutations(range(len(K[b]))):
        if len(K[a]) != len(K[b]): return 9
        s = max(min(best_overlap(norm(K[a][i]), norm(K[b][j])), best_overlap(norm(K[a][i]), norm(K[b][j]), True)) for i, j in zip(range(len(K[a])), perm))
        best = min(best, s)
    return best
pairs = []
ns = sorted(T)
for a, b in itertools.combinations(ns, 2):
    if abs(T[a].area - T[b].area) > 0.02: pass
    t = tsim(a, b)
    if t < 0.06:
        k = ksim(a, b); pairs.append((a, b, round(t, 3), round(k, 3), TC[a] == TC[b]))
        print(a, b, 'cíl %.3f' % t, 'díly %.3f' % k, 'stejné barvy' if TC[a] == TC[b] else 'jiné barvy', flush=True)
json.dump(pairs, open('dupes.json', 'w'))
