import math, json, numpy as np
import solve as S
from solve import *
x = D[42]; T = poly_of(x['target']); A = T.area; k = 1 / math.sqrt(A); T = affinity.scale(T, k, k, origin=(0, 0))
G = {i: poly_of(x['cands'][i - 1]['paths']) for i in x['key']}
Rs = simplify(T, 0.004); rv = sorted([v for v in verts(Rs) if v[3] < math.pi - 0.05], key=lambda v: v[3])
best = None
P = G[3]; rest = [(6, G[6]), (4, G[4])]
for v in rv:
    for u in verts(simplify(P, 0.02)):
        if u[3] > v[3] + 0.03: continue
        for s in np.linspace(0.01238 * 0.985, 0.01238 * 1.015, 301):
            for w in (0, 1):
                g = place(P, u, v, s, w); e = g.difference(T).area
                if e > 2e-4: continue
                R2 = T.difference(g).buffer(-2.5e-3, join_style=2).buffer(2.5e-3, join_style=2)
                sub = S.solve(R2, rest, [None, None], 6e-4)
                if sub is not None:
                    left = R2.area - sum(q.area for _, _, q in sub)
                    cand = (abs(left) + e, {3: s} | {pid: sc for pid, sc, _ in sub})
                    if best is None or cand[0] < best[0]: best = cand
print(best)
ks = json.load(open('keyscales.json')); ks['43'] = {str(a): b for a, b in best[1].items()}; json.dump(ks, open('keyscales.json', 'w'))
