import math, json
from shapely.geometry import Polygon
from solve import D, poly_of, verts, simplify, edge_lens
def sig(g):
    """podpis tvaru do podobnosti: (úhly, poměry hran) po směru, normalizace na obvod; bez zrcadlení"""
    g = simplify(g, 0.004 * math.sqrt(g.area))
    v = verts(g); L = edge_lens(g); per = sum(L)
    # verts: (p, prev, next, ang); edge i = p_i -> p_{i+1}
    return [(round(a[3], 2), round(l / per, 3)) for a, l in zip(v, L)]
def similar(g1, g2, mirror=False):
    a, b = sig(g1), sig(g2)
    if len(a) != len(b): return False
    n = len(a)
    for k in range(n):
        if all(abs(a[i][0] - b[(i + k) % n][0]) < 0.06 and abs(a[i][1] - b[(i + k) % n][1]) < 0.012 for i in range(n)): return True
    return False
if __name__ == '__main__':
    for x in D:
        fills = [p for p in x['target'] if p['fill'] != 'none']
        if len(fills) < 2 or len({p['fill'] for p in fills}) > 1 and x['no'] > 8 and x['no'] != 11: continue
        if any(p['fill'] == '#FFFFFF' for p in fills): continue
        T = [Polygon(p['pts']).buffer(0) for p in fills]
        C = {c['i']: poly_of(c['paths']) for c in x['cands']}
        match = {ti: [i for i, g in C.items() if similar(t, g)] for ti, t in enumerate(T)}
        mm = {ti: [i for i, g in C.items() if similar(t, affinity_mirror(g))] for ti, t in enumerate(T)} if False else None
        print(x['no'], 'klíč', x['key'], 'díly cíle → podobné kandidáty', match, 'počty vrcholů cíl', [len(sig(t)) for t in T], 'kand', {i: len(sig(g)) for i, g in C.items()})
