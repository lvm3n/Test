"""3.66.0 / 1.27.0 – Skládání tvarů SK30-v2: strop se strukturní obtížností (zuby, výřezy, půlkruhové spoje) místo nepatrných odchylek."""
import os, json, shutil, csv, io
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st13/BANK_SK30.json', encoding='utf8'))
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK30-v1', pickN:3,", "version:'SK30-v2', pickN:3,")
    rep(app, "['SK30-v1']]", "['SK30-v1'], ['SK30-v2']]")
    rep(app, "(23 z původní sady bez duplicit + 7 nových stropových)", "(23 z původní sady bez duplicit + 7 strukturních stropových SKS: zuby, výřezy, půlkruhové spoje)")
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']; extra = '; mřížka %s, spojů %s; distraktory: %s' % (f['mrizka'], f['spoju'], f['distraktory']) if 'mrizka' in f else ''
        body.append(['skladani', 'SK30-v2', k + 1, it['id'], 'vyber %d z 6 dílů; %s%s' % (it['pick'], f['pasmo'], extra),
                     ' '.join(str(i + 1) for i in it['answerIdx']), 'nácvik' if it['level'] == 0 else 'pořadí %d; předpoklad %s' % (k - 1, f.get('predpoklad', '')),
                     '', '' if it['level'] == 0 else 'limit %d s; původní položka %s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60, f.get('puvodni', ''))])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.65.0', '3.66.0', 2); rep(EN + 'cognitive-battery-en.php', '1.26.0', '1.27.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.65.0</div>', '>verze 3.66.0</div>'); rep(EN + 'assets/app.html', '>version 1.26.0 (EN)</div>', '>version 1.27.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('gen_struct.py', 'ceiling_struct.json', 'BANK_SK30.json', 'preview30.html', 'preview_struct.html'): shutil.copy('st13/' + f, dd + f)
shutil.copy('st14/patch_v366.py', dd + 'patch_v366.py')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.66.0 – Skládání tvarů SK30-v2: strukturní strop
Stropové položky SKC_01–07 (distraktory lišící se nepatrnou odchylkou velikosti/rohu) nahrazeny 7 položkami SKS_01–07, kde
obtížnost leží ve struktuře – jako u stropu Visual Puzzles: cíl je obdélník/čtverec (mřížka 4×3 až 5×4), 3 díly do sebe
zapadají zuby a výřezy, 0–2 spoje mají půlkruhový čep a jamku. Distraktory mluví stejným „jazykem“ a jsou na pohled
věrohodné: zrcadlo nesouměrného dílu, zub na jiném místě, čep místo jamky / spoj jinde, o kostku větší díl. Díly ukázané
otočené po 90°. Přesná kontrola dlaždicovým řešičem (otáčení po 90°, bez zrcadlení, čep musí sedět do jamky): klíč se složí
a žádná jiná trojice ne (docs/skladani_tvaru_sk48/gen_struct.py). Zařazeny do horní třetiny (SKS_01–04 mezi nejtěžší původní
položky, SKS_05–07 na konec). Nová srovnávací skupina SK30-v2.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.27.0 – Shape Assembly SK30-v2: strukturní strop (zuby, výřezy, půlkruhové spoje) místo nepatrných odchylek – jako česká 3.66.0.
''')
print('ok')
