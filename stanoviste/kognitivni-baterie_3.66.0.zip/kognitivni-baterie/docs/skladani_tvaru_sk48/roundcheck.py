import json, itertools, math, re, statistics as st
from shapely.geometry import Polygon
from shapely.ops import unary_union
from solve import D, poly_of, edge_lens
def geo(paths):
    ps = [Polygon([tuple(map(float, q.split())) for q in re.findall(r'(-?[\d.]+ -?[\d.]+)', p['d'])]).buffer(0) for p in paths]
    return unary_union(ps)
def check(it, verbose=True):
    T = geo(it['target']['paths']); LT = edge_lens(T); seg = st.median(LT)
    G = [geo(o['paths']) for o in it['options']]
    def arc(g): return sum(l for l in edge_lens(g) if abs(l / seg - 1) < 0.05)
    tarc = arc(T); ar = [g.area for g in G]; ac = [arc(g) for g in G]
    keys = it['answerIdx']
    kk = (sum(ar[i] for i in keys), sum(ac[i] for i in keys) / tarc)
    bad = [c for c in itertools.combinations(range(6), it['pick']) if set(c) != set(keys) and abs(sum(ar[i] for i in c) - 1) < 0.04 and abs(sum(ac[i] for i in c) / tarc - 1) < 0.04]
    if verbose: print(it['n'], 'klíč plocha %.3f oblouk %.3f' % kk, 'plochy', [round(a, 3) for a in ar], 'oblouky', [round(a / tarc, 3) for a in ac], 'podezřelé', [''.join(str(i + 1) for i in c) for c in bad])
    return kk, bad
if __name__ == '__main__':
    B = json.load(open('bank_sk48.json'))
    for it in B:
        if it['n'] in (11, 18, 23, 25, 28, 33, 41, 47): check(it)
