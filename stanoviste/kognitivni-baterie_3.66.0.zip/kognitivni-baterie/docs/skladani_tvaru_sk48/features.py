"""Vlastnosti položek SK48 (bez dat): co by mělo určovat obtížnost."""
import json, math, re, itertools
from roundcheck import geo
from congr import best_overlap
from shapely import affinity
B = json.load(open('bank_sk48.json')); ROUND = {11, 18, 23, 25, 28, 33, 41, 47}
rows = []
for it in B:
    G = [geo(o['paths']) for o in it['options']]
    cols = [tuple(sorted({p['fill'] for p in o['paths']})) for o in it['options']]
    tcols = {p['fill'] for p in it['target']['paths']}
    keys = it['answerIdx']; dis = [i for i in range(6) if i not in keys]
    # barevné vodítko: díly cíle mají různé barvy a každý správný díl má „svou“ barvu, kterou distraktory nesdílejí
    multicolor = len(tcols) >= 2
    colorcue = multicolor and sum(1 for d in dis if cols[d] in [cols[k] for k in keys]) <= 1
    # nejbližší distraktor ke správnému dílu (rozdíl po nejlepším otočení, stejné měřítko) a zda jde o zrcadlo
    close = []
    for d in dis:
        best = min(best_overlap(G[k], G[d]) for k in keys)
        mir = min(best_overlap(G[k], G[d], True) for k in keys)
        close.append((round(best, 2), mir < 0.03))
    nmir = sum(1 for c in close if c[1]); minc = min(c[0] for c in close)
    vk = sum(len(G[k].exterior.coords) - 1 for k in keys) / len(keys) if it['n'] not in ROUND else None
    areas = sorted(G[k].area for k in keys)
    rows.append(dict(n=it['n'], pasmo=it['facety']['pasmo'], dilu=it['pick'], kulaty=it['n'] in ROUND, barvy=len(tcols), barevne_vodítko=colorcue,
                     zrcadel=nmir, nejbliz=minc, vrcholu=round(vk, 1) if vk else 'oblouk', nejmensi_dil=round(areas[0], 2)))
for r in rows: print(r)
json.dump(rows, open('features.json', 'w'), ensure_ascii=False)
