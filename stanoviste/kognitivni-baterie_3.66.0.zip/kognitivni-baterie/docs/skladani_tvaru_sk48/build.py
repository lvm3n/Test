"""Skládání tvarů v ověřeném měřítku: díly ve stejném měřítku jako cíl, velikosti distraktorů, kontrola jednoznačnosti."""
import json, math, itertools, re
from shapely.geometry import Polygon
from shapely import affinity
from solve import D, poly_of
from sim import similar
from tscale import piece_scale
from solve import solve
KS = json.load(open('keyscales.json'))
ROUND = {11, 18, 23, 25, 28, 33, 41, 47}
def mirror_only(a, b):     # a je zrcadlem b, ale otočením se na b převést nedá
    return similar(affinity.scale(a, -1, 1), b) and not similar(a, b)
def nverts(g): return len(g.exterior.coords) - 1
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def path_d(pts): return 'M' + ' L'.join(fmt(x) + ' ' + fmt(y) for x, y in pts) + 'Z'
log = []; bank = []
for x in D:
    n = x['no']; T = poly_of(x['target']); A = T.area; kT = 1 / math.sqrt(A)
    G = {c['i']: poly_of(c['paths']) for c in x['cands']}
    sc = {int(i): v for i, v in KS[str(n)].items()}
    keys = x['key']; notes = []
    for d in G:
        if d in keys: continue
        if n in ROUND and d in sc:
            cnt, _ = piece_scale(T, G[d])
            if cnt >= 10 and 0.04 < sc[d] ** 2 * G[d].area < 0.9:
                from congr import best_overlap
                tw = [k for k in keys if abs(sc[k] ** 2 * G[k].area - sc[d] ** 2 * G[d].area) < 0.02 and best_overlap(affinity.scale(G[k], sc[k], sc[k]), affinity.scale(G[d], sc[d], sc[d])) < 0.04]
                if tw: sc[d] *= 0.84; notes.append('%d: téměř shodný s dílem %d (zrcadlo souměrného dílu) → zmenšen ×0.84' % (d, tw[0]))
                else: notes.append('%d: měřítko z oblouku' % d)
                continue
        sim_k = [k for k in keys if similar(G[d], G[k])]
        mir_k = [k for k in keys if mirror_only(G[d], G[k])]
        if sim_k:
            k = sim_k[0]; f = 0.78 if sc[k] ** 2 * G[k].area > 0.3 else 1.28
            sc[d] = sc[k] * f; notes.append('%d: jen jiná velikost než %d (×%.2f)' % (d, k, f))
        elif mir_k:
            sc[d] = sc[mir_k[0]]; notes.append('%d: zrcadlo dílu %d' % (d, mir_k[0]))
        else:
            k = min(keys, key=lambda k: (abs(nverts(G[k]) - nverts(G[d])), abs(G[k].length ** 2 / G[k].area - G[d].length ** 2 / G[d].area)))
            fa = 1.0
            sc[d] = sc[k] * math.sqrt(G[k].area / G[d].area * fa); notes.append('%d: plocha ×%.2f dílu %d' % (d, fa, k))
    # jednoznačnost: žádná jiná kombinace dílů nesmí mít plochu cíle (podmínka nutná pro složení); výjimka = záměna za zrcadlo
    area = lambda i: sc[i] ** 2 * G[i].area
    m = len(keys)
    dis = [i for i in sorted(G) if i not in keys]
    Tn = affinity.scale(T, kT, kT, origin=(0, 0))
    def tiles(comb, mult):
        if abs(sum(area(i) * (mult.get(i, 1) ** 2) for i in comb) - 1) > 0.05: return False
        return solve(Tn, [(i, G[i]) for i in comb], [sc[i] * mult.get(i, 1) for i in comb], 1.5e-3) is not None
    def alt(mult):
        return [c for c in itertools.combinations(sorted(G), m) if set(c) != set(keys) and tiles(c, mult)]
    mult = {}
    for rnd in range(6):
        bad = alt(mult)
        if not bad: break
        for c in bad:
            d = [i for i in c if i not in keys][-1]; mult[d] = mult.get(d, 1) * (0.86 if area(d) > 0.3 else 1.16)
            notes.append('%d: velikost upravena – kombinace %s by šla složit' % (d, ''.join(map(str, c))))
    else: raise SystemExit('nelze zajistit jednoznačnost %d' % n)
    for i, v in mult.items(): sc[i] *= v
    if solve(Tn, [(i, G[i]) for i in keys], [sc[i] for i in keys], 1.5e-3) is None: notes.append('POZOR: klíč se při pevných měřítkách nesložil')
    assert abs(sum(area(k) for k in keys) - 1) < 0.02, (n, sum(area(k) for k in keys))
    # kresba: vše v jednotkách cíle (plocha cíle = 1)
    tminx, tminy = T.bounds[0], T.bounds[1]
    tg = [{'d': path_d([((px - tminx) * kT, (py - tminy) * kT) for px, py in p['pts']]), 'fill': p['fill']} for p in x['target'] if p['fill'] != 'none']
    tb = [(T.bounds[2] - tminx) * kT, (T.bounds[3] - tminy) * kT]
    outline = {'d': path_d([((px - tminx) * kT, (py - tminy) * kT) for px, py in (T.exterior.coords if T.geom_type == 'Polygon' else max(T.geoms, key=lambda q: q.area).exterior.coords)])}
    opts = []
    for c in x['cands']:
        i = c['i']; g = G[i]; s = sc[i]; bx, by = g.bounds[0], g.bounds[1]
        paths = [{'d': path_d([((px - bx) * s, (py - by) * s) for px, py in p['pts']]), 'fill': p['fill']} for p in c['paths']]
        opts.append({'paths': paths, 'w': round((g.bounds[2] - bx) * s, 4), 'h': round((g.bounds[3] - by) * s, 4), 'correct': i in keys})
    band = x['diff']
    lvl = {'podlahová': 1, 'velmi lehká': 2, 'střední': 3, 'vyšší': 4, 'velmi obtížná': 5, 'vysoká': 5, 'ceiling probe': 6}[band]
    bank.append({'id': 'SK48_%02d' % n, 'n': n, 'level': lvl, 'pick': m, 'target': {'paths': tg, 'outline': outline['d'], 'w': round(tb[0], 4), 'h': round(tb[1], 4)},
                 'options': opts, 'answerIdx': [k - 1 for k in keys], 'facety': {'pasmo': band, 'dilu': m}})
    log.append('%2d %-14s klíč %s | %s' % (n, band, keys, '; '.join(notes)))
json.dump(bank, open('bank_sk48.json', 'w'), ensure_ascii=False)
open('build_log.txt', 'w').write('\n'.join(log)); print('\n'.join(log))
