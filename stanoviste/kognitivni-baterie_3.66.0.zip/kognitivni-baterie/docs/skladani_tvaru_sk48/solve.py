"""Ověření Skládání tvarů: lze z klíčových dílů (otáčení, bez zrcadlení, libovolné měřítko – kresba měřítko ztratila) složit cíl?"""
import json, math, itertools, sys
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union
from shapely import affinity
D = json.load(open('items.json'))
def poly_of(paths, skip_none=True):
    ps = []
    for p in paths:
        if skip_none and p['fill'] == 'none': continue
        pts = p['pts']
        if len(pts) >= 3: ps.append(Polygon(pts).buffer(0))
    u = unary_union(ps)
    return u
def simplify(g, tol):
    return g.simplify(tol, preserve_topology=True)
def verts(g):
    """vrcholy hlavního obrysu s vnitřním úhlem"""
    if isinstance(g, MultiPolygon): g = max(g.geoms, key=lambda q: q.area)
    c = list(g.exterior.coords)[:-1]
    if Polygon(c).exterior.is_ccw is False: c = c[::-1]
    out = []
    n = len(c)
    for i in range(n):
        p0, p1, p2 = c[i - 1], c[i], c[(i + 1) % n]
        a1 = math.atan2(p0[1] - p1[1], p0[0] - p1[0]); a2 = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
        ang = (a1 - a2) % (2 * math.pi)       # vnitřní úhel pro ccw
        out.append((p1, p0, p2, ang))
    return out
def place(P, u, Rv, s, which):
    """umístí díl P (měřítko s) tak, že jeho vrchol u leží ve vrcholu Rv a jedna jeho hrana leží na hraně cíle"""
    (pu, pprev, pnext, pang) = u; (rv, rprev, rnext, rang) = Rv
    if which == 0:   # hrana u→next podél hrany v→next
        a_p = math.atan2(pnext[1] - pu[1], pnext[0] - pu[0]); a_r = math.atan2(rnext[1] - rv[1], rnext[0] - rv[0])
    else:            # hrana u→prev podél v→prev
        a_p = math.atan2(pprev[1] - pu[1], pprev[0] - pu[0]); a_r = math.atan2(rprev[1] - rv[1], rprev[0] - rv[0])
    g = affinity.scale(P, s, s, origin=pu)
    g = affinity.rotate(g, a_r - a_p, origin=pu, use_radians=True)
    return affinity.translate(g, rv[0] - pu[0], rv[1] - pu[1])
def edge_lens(g):
    if isinstance(g, MultiPolygon): g = max(g.geoms, key=lambda q: q.area)
    c = list(g.exterior.coords); return [math.dist(c[i], c[i + 1]) for i in range(len(c) - 1)]
def fits(g, R, tol):
    return g.difference(R).area < tol
def solve(R, pieces, scales, tolA, depth=0):
    """pieces: seznam (id, polygon v normalizované kresbě); scales: pevné měřítko nebo None (hledat)"""
    if not pieces: return [] if R.area < tolA * 3 else None
    if len(pieces) == 1 and scales[0] is None:
        pid, P = pieces[0]; s = math.sqrt(R.area / P.area); sc = [s]
    else: sc = None
    if isinstance(R, MultiPolygon):
        parts = [q for q in R.geoms if q.area > tolA]
        if len(parts) > 1: R = MultiPolygon(parts)
        elif parts: R = parts[0]
    Rs = simplify(R, 0.004)
    rv = [v for v in verts(Rs) if v[3] < math.pi - 0.05 and math.dist(v[0], v[1]) > 0.01 and math.dist(v[0], v[2]) > 0.01]
    rv.sort(key=lambda v: v[3]); rv = rv[:1]            # nejostřejší roh musí někdo vyplnit
    if not rv:                                          # kulatý tvar bez rohů: libovolný vrchol obrysu (díly sdílejí úseky obrysu)
        allv = [v for v in verts(Rs) if math.dist(v[0], v[1]) > 0.01 and math.dist(v[0], v[2]) > 0.01]
        rv = allv[:1]
    for k, (pid, P) in enumerate(pieces):
        rest = pieces[:k] + pieces[k + 1:]; rsc = scales[:k] + scales[k + 1:]
        Pv = verts(simplify(P, 0.02))
        for v in rv:
            for u in Pv:
                if u[3] > v[3] + 0.03: continue
                cand_s = sc if sc else ([scales[k]] if scales[k] is not None else None)
                if cand_s is None:
                    RL = edge_lens(Rs); PL = edge_lens(simplify(P, 0.02))
                    cand_s = sorted({float('%.6g' % (a / b)) for a in RL for b in PL if b > 1e-6 and (a / b) ** 2 * P.area <= R.area * 1.001})
                for s in cand_s:
                    for which in (0, 1):
                        g = place(P, u, v, s, which)
                        if not fits(g, R, tolA): continue
                        R2 = R.difference(g).buffer(-2.5e-3, join_style=2).buffer(2.5e-3, join_style=2)
                        sub = solve(R2, rest, rsc, tolA, depth + 1)
                        if sub is not None: return [(pid, s, g)] + sub
    return None
if __name__ == '__main__':
    res = {}
    only = set(map(int, sys.argv[1:])) if len(sys.argv) > 1 else None
    for x in D:
        if only and x['no'] not in only: continue
        T = poly_of(x['target']); A = T.area
        T = affinity.scale(T, 1 / math.sqrt(A), 1 / math.sqrt(A), origin=(0, 0))
        C = {c['i']: poly_of(c['paths']) for c in x['cands']}
        keyp = [(i, C[i]) for i in x['key']]
        sol = solve(T, keyp, [None] * len(keyp), 1.5e-3)
        ok = sol is not None
        res[x['no']] = {'ok': ok, 'scales': {pid: s for pid, s, _ in sol} if ok else None}
        try: allr = json.load(open('keyscales.json'))
        except Exception: allr = {}
        if ok: allr[str(x['no'])] = {str(pid): s for pid, s, _ in sol}; json.dump(allr, open('keyscales.json', 'w'))
        print(x['no'], x['diff'], 'klíč', x['key'], 'SKLÁDÁ SE' if ok else '!!! NESKLÁDÁ SE', {pid: round(s, 4) for pid, s, _ in sol} if ok else '', flush=True)

