"""Stropové položky se STRUKTURNÍ obtížností (princip Visual Puzzles): díly na mřížce do sebe zapadají zuby a výřezy,
některé spoje mají půlkruhový čep/jamku. Distraktory jsou strukturně věrohodné díly stejné „slovní zásoby“
(zub jinde, čep místo jamky, zrcadlo, o kostku jiný), ne nepatrné odchylky. Přesná kontrola: dlaždicový řešič
(otáčení po 90°, bez zrcadlení, spoje musí sedět)."""
import random, itertools, json, math
from shapely.geometry import box, Point
from shapely.ops import unary_union
from shapely import affinity
DIRS = {(1, 0): 'R', (-1, 0): 'L', (0, 1): 'D', (0, -1): 'U'}
def rot_cell(c, k):            # otočení o k×90° (po směru)
    x, y = c
    for _ in range(k): x, y = -y, x
    return (x, y)
def rot_dir(d, k):
    x, y = d
    for _ in range(k): x, y = -y, x
    return (x, y)
class Piece:
    """cells: množina buněk; conn: {(buňka, směr): +1 čep / -1 jamka} na hranách obrysu"""
    def __init__(self, cells, conn=None): self.cells = frozenset(cells); self.conn = dict(conn or {})
    def norm(self):
        mx = min(x for x, y in self.cells); my = min(y for x, y in self.cells)
        return Piece({(x - mx, y - my) for x, y in self.cells}, {((c[0] - mx, c[1] - my), d): v for (c, d), v in self.conn.items()})
    def rot(self, k): return Piece({rot_cell(c, k) for c in self.cells}, {(rot_cell(c, k), rot_dir(d, k)): v for (c, d), v in self.conn.items()}).norm()
    def mirror(self): return Piece({(-x, y) for x, y in self.cells}, {((-c[0], c[1]), (-d[0], d[1])): v for (c, d), v in self.conn.items()}).norm()
    def key(self): p = self.norm(); return (tuple(sorted(p.cells)), tuple(sorted(p.conn.items())))
    def shapes(self): return {self.rot(k).key() for k in range(4)}
    def congruent(self, o): return bool(self.shapes() & o.shapes())
    def boundary(self):
        return [(c, d) for c in self.cells for d in DIRS if (c[0] + d[0], c[1] + d[1]) not in self.cells]
def tiles(W, H, pieces, want_all=False):
    """přesné pokrytí obdélníku W×H; spoje na švech musí být čep proti jamce, na okraji žádné"""
    sols = []
    def rec(grid, conn, i):
        if i == len(pieces):
            if len(grid) == W * H:
                for (c, d), v in conn.items():
                    nb = (c[0] + d[0], c[1] + d[1])
                    if not (0 <= nb[0] < W and 0 <= nb[1] < H): return False
                    if conn.get((nb, (-d[0], -d[1]))) != -v: return False
                sols.append(1); return not want_all
            return False
        seen = set()
        for k in range(4):
            p = pieces[i].rot(k); kk = p.key()
            if kk in seen: continue
            seen.add(kk)
            for ox in range(W):
                for oy in range(H):
                    cs = {(x + ox, y + oy) for x, y in p.cells}
                    if any(not (0 <= x < W and 0 <= y < H) or (x, y) in grid for x, y in cs): continue
                    cn = dict(conn); bad = False
                    for (c, d), v in p.conn.items():
                        cc = (c[0] + ox, c[1] + oy); nb = (cc[0] + d[0], cc[1] + d[1])
                        if not (0 <= nb[0] < W and 0 <= nb[1] < H): bad = True; break
                        cn[(cc, d)] = v
                    if bad: continue
                    if rec(grid | cs, cn, i + 1): return True
        return False
    rec(frozenset(), {}, 0)
    return len(sols) > 0
def connected(cells):
    cells = set(cells); st = [next(iter(cells))]; seen = set()
    while st:
        c = st.pop()
        if c in seen: continue
        seen.add(c); st += [(c[0] + d[0], c[1] + d[1]) for d in DIRS if (c[0] + d[0], c[1] + d[1]) in cells]
    return len(seen) == len(cells)
def is_rect(cells):
    xs = [x for x, y in cells]; ys = [y for x, y in cells]; return (max(xs) - min(xs) + 1) * (max(ys) - min(ys) + 1) == len(cells)
def partition(W, H, rng):
    allc = [(x, y) for x in range(W) for y in range(H)]
    for _ in range(4000):
        seeds = rng.sample(allc, 3); own = {s: i for i, s in enumerate(seeds)}
        front = list(seeds)
        while len(own) < W * H:
            c = rng.choice(list(own)); d = rng.choice(list(DIRS)); nb = (c[0] + d[0], c[1] + d[1])
            if 0 <= nb[0] < W and 0 <= nb[1] < H and nb not in own: own[nb] = own[c]
        P = [{c for c, i in own.items() if i == k} for k in range(3)]
        n = W * H
        if any(len(p) < n * 0.22 or len(p) > n * 0.45 for p in P): continue
        if not all(connected(p) for p in P) or any(is_rect(p) for p in P): continue
        # každý díl musí mít „zub“: aspoň 2 konkávní rohy (zapadání)
        def concave(p):
            k = 0
            for c in p:
                for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                    a = (c[0] + dx, c[1]) in p; b = (c[0], c[1] + dy) in p; dg = (c[0] + dx, c[1] + dy) in p
                    if a and b and not dg: k += 1
            return k
        if any(concave(p) < 1 for p in P): continue
        return P
    return None
def add_connectors(P, rng, n):
    pieces = [Piece(p) for p in P]; owner = {c: i for i, p in enumerate(P) for c in p}
    seams = [(c, d) for i, p in enumerate(P) for c in p for d in DIRS if (c[0] + d[0], c[1] + d[1]) in owner and owner[(c[0] + d[0], c[1] + d[1])] != i]
    rng.shuffle(seams); used = set()
    for c, d in seams:
        if n == 0: break
        nb = (c[0] + d[0], c[1] + d[1])
        if (c, d) in used or (nb, (-d[0], -d[1])) in used: continue
        pieces[owner[c]].conn[(c, d)] = 1; pieces[owner[nb]].conn[(nb, (-d[0], -d[1]))] = -1
        used |= {(c, d), (nb, (-d[0], -d[1]))}; n -= 1
    return [p.norm() for p in pieces]
def variants(k, rng):
    """strukturní distraktory ke klíčovému dílu k"""
    out = []
    m = k.mirror()
    if not k.congruent(m): out.append(('zrcadlo', m))
    cells = set(k.cells)
    for _ in range(60):                                       # zub jinde (stejný počet kostek)
        rem = rng.choice(list(cells)); add = rng.choice([(c[0] + d[0], c[1] + d[1]) for c in cells for d in DIRS if (c[0] + d[0], c[1] + d[1]) not in cells])
        nc = (cells - {rem}) | {add}
        if connected(nc) and not is_rect(nc):
            conn = {(c, d): v for (c, d), v in k.conn.items() if c in nc and (c[0] + d[0], c[1] + d[1]) not in nc}
            if len(conn) == len(k.conn): out.append(('zub jinde', Piece(nc, conn).norm())); break
    if k.conn:                                               # čep ↔ jamka
        out.append(('čep místo jamky', Piece(k.cells, {cd: -v for cd, v in k.conn.items()}).norm()))
        b = [cd for cd in k.boundary() if cd not in k.conn]
        if b:
            (c0, v0), = list(k.conn.items())[:1]; nb = rng.choice(b); conn = {cd: v for cd, v in k.conn.items() if cd != c0}; conn[nb] = v0
            out.append(('spoj jinde', Piece(k.cells, conn).norm()))
    for _ in range(60):                                       # o kostku víc
        add = rng.choice([(c[0] + d[0], c[1] + d[1]) for c in cells for d in DIRS if (c[0] + d[0], c[1] + d[1]) not in cells])
        nc = cells | {add}
        if not is_rect(nc): out.append(('o kostku víc', Piece(nc, {cd: v for cd, v in k.conn.items() if (cd[0][0] + cd[1][0], cd[0][1] + cd[1][1]) not in nc}).norm())); break
    return out
def make(W, H, nconn, rng):
    for _ in range(300):
        P = partition(W, H, rng)
        if not P: continue
        K = add_connectors(P, rng, nconn)
        if any(K[i].congruent(K[j]) for i, j in itertools.combinations(range(3), 2)): continue
        if any(K[i].congruent(K[i].mirror()) for i in range(3)) and rng.random() < 0.7: continue   # raději nesouměrné díly
        D = []
        for k in K:
            vs = [v for v in variants(k, rng) if not any(v[1].congruent(x) for x in K) and not any(v[1].congruent(x[1]) for x in D)]
            if not vs: break
            pref = [v for v in vs if v[0] != 'o kostku víc'] or vs
            D.append(rng.choice(pref))
        if len(D) < 3: continue
        opts = [('cíl', k) for k in K] + D; rng.shuffle(opts)
        G = [p for _, p in opts]; keys = [i for i, (t, _) in enumerate(opts) if t == 'cíl']
        if not tiles(W, H, [G[i] for i in keys]): continue
        if any(tiles(W, H, [G[i] for i in c]) for c in itertools.combinations(range(6), 3) if set(c) != set(keys)): continue
        return opts, keys
    return None
R0 = 0.32   # poloměr čepu (v kostkách)
def poly(p, rot):
    q = p.rot(rot)
    g = unary_union([box(x, y, x + 1, y + 1) for x, y in q.cells])
    for (c, d), v in q.conn.items():
        mx, my = c[0] + 0.5 + d[0] * 0.5, c[1] + 0.5 + d[1] * 0.5
        disk = Point(mx, my).buffer(R0, 32)
        g = g.union(disk) if v > 0 else g.difference(disk)
    return g.simplify(1e-6)
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def pd(g, s):
    b = g.bounds; return 'M' + ' L'.join(fmt((x - b[0]) * s) + ' ' + fmt((y - b[1]) * s) for x, y in list(g.exterior.coords)[:-1]) + 'Z'
SPEC = [(4, 3, 0), (4, 3, 1), (4, 4, 1), (5, 3, 1), (4, 4, 2), (5, 4, 1), (5, 4, 2)]
COL = ['#3D8CCD', '#7C58B5', '#5FAF63', '#ED8B37', '#E0574D', '#2B4586', '#D25499']
if __name__ == '__main__':
    rng = random.Random(4242); out = []
    for k, (W, H, nc) in enumerate(SPEC):
        r = make(W, H, nc, rng)
        print(W, H, nc, 'OK' if r else 'NE', r and [t for t, _ in r[0]], flush=True)
        if not r: continue
        opts, keys = r; s = 1 / math.sqrt(W * H); col = COL[k]
        T = box(0, 0, W, H)
        items_opts = []
        for i, (t, p) in enumerate(opts):
            g = poly(p, rng.randrange(4)); b = g.bounds
            items_opts.append({'paths': [{'d': pd(g, s), 'fill': col}], 'w': round((b[2] - b[0]) * s, 4), 'h': round((b[3] - b[1]) * s, 4), 'correct': i in keys, 'kind': t})
        out.append({'id': 'SKS_%02d' % (k + 1), 'n': 200 + k, 'level': 6, 'pick': 3,
                    'target': {'paths': [{'d': pd(T, s), 'fill': col}], 'outline': pd(T, s), 'w': round(W * s, 4), 'h': round(H * s, 4)},
                    'options': items_opts, 'answerIdx': keys,
                    'facety': {'pasmo': 'strop (strukturní)', 'dilu': 3, 'mrizka': '%d×%d' % (W, H), 'spoju': nc, 'distraktory': ', '.join(t for t, _ in opts if t != 'cíl')}})
    json.dump(out, open('ceiling_struct.json', 'w'), ensure_ascii=False); print(len(out))
