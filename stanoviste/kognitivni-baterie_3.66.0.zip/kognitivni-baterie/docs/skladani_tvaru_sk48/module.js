/* ===== Skládání tvarů SK48 (Gv – vizualizace, obdoba Visual Puzzles): vybrat 2–3 díly, ze kterých se složí tvar.
   Díly se kreslí ve STEJNÉM měřítku jako cílový tvar (velikost je vodítko i past); otáčet lze, zrcadlit ne.
   Banka: 48 položek, klíče a jednoznačnost ověřeny řešičem (docs/skladani_tvaru_sk48/). ===== */
function mod_skladani48(root, B, TX){
  const box = () => { if (innerWidth >= 900) return {tw:320, th:240, ow:168, oh:138};
    const w = Math.floor((Math.min(innerWidth, 520) - 64) / 3); return {tw:Math.min(300, innerWidth - 48), th:170, ow:w, oh:Math.round(w * 0.82)}; };
  const unit = (it) => { const b = box(), t = it.target, mw = Math.max(...it.options.map(o => o.w)), mh = Math.max(...it.options.map(o => o.h));
    return Math.min(b.tw / t.w, b.th / t.h, (b.ow - 14) / mw, (b.oh - 14) / mh); };
  function svg(paths, w, h, u, outline, W, H){
    W = W || w * u + 8; H = H || h * u + 8;
    const ox = (W / u - w) / 2, oy = (H / u - h) / 2, sw = (1.6 / u).toFixed(4);
    let s = `<svg width="${W.toFixed(0)}" height="${H.toFixed(0)}" viewBox="${(-ox).toFixed(4)} ${(-oy).toFixed(4)} ${(W / u).toFixed(4)} ${(H / u).toFixed(4)}" aria-hidden="true">`;
    paths.forEach(p => { s += `<path d="${p.d}" fill="${p.fill}" stroke="${outline ? p.fill : '#1d232b'}" stroke-width="${outline ? (1.2 / u).toFixed(4) : sw}" stroke-linejoin="round"/>`; });
    if (outline) s += `<path d="${outline}" fill="none" stroke="#1d232b" stroke-width="${sw}" stroke-linejoin="round"/>`;
    return s + '</svg>';
  }
  const refRender = (it) => { const u = unit(it), t = it.target; return svg(t.paths, t.w, t.h, u, t.outline); };
  const optRender = (it, o) => { const u = unit(it), b = box(); return svg(o.paths, o.w, o.h, u, null, b.ow, b.oh); };
  return mod_pick(root, {key:'skladani', name:TX.name, blurb:TX.blurb, version:'SK48-v1', pickN:3,
    capFor:(it) => (it.pick === 2 || (it.level || 1) <= 2) ? 45 : 60,
    startFor:(list, age) => age <= 8 ? 0 : Math.max(0, list.findIndex(x => x.pick === 3)),   // od 9 let start u první položky se 3 díly
    icon:'<svg viewBox="0 0 48 48"><path d="M6 10h20v14H6z" fill="#5FAF63" stroke="#2B3440" stroke-width="2"/><path d="M26 10h16v14H26z" fill="#ED8B37" stroke="#2B3440" stroke-width="2"/><path d="M6 24h36v14H6z" fill="#3D8CCD" stroke="#2B3440" stroke-width="2"/></svg>',
    instr:TX.instr, refLabel:TX.ref, pickLabel:TX.pick3, pickText:(it) => it.pick === 2 ? TX.pick2 : TX.pick3, wrongHint:TX.wrong,
    items:B.items, practice:B.practice, refRender, optRender,
    onPrepare(d){
      const it = B.practice[0], u = Math.min(unit(it), 70);
      d.innerHTML = '<div class="gv-demo"><div style="text-align:center"><b style="display:block">' + TX.ref + '</b>' + svg(it.target.paths, it.target.w, it.target.h, u, it.target.outline) + '</div><div class="gv-demo-arrow">→</div>' +
        it.answerIdx.map(i => '<div style="outline:3px solid var(--good);border-radius:10px">' + svg(it.options[i].paths, it.options[i].w, it.options[i].h, u) + '</div>').join('') + '</div><p class="muted">' + TX.demo + '</p>';
    }});
}
