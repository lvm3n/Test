"""Nové stropové položky: 3 díly z lomených řezů, distraktory blízko správným (zrcadlo, ±10 % velikost, posunutý roh)."""
import math, random, json, itertools
from shapely.geometry import Polygon, LineString, Point
from shapely.ops import split
from shapely import affinity
from solve import solve
from congr import best_overlap
def unit_area(P):
    P = Polygon(P); k = 1 / math.sqrt(P.area); P = affinity.scale(P, k, k, origin=(0, 0)); b = P.bounds
    return affinity.translate(P, -b[0], -b[1])
def reg(n, r=1, rot=0): return [(r * math.cos(rot + 2 * math.pi * i / n), r * math.sin(rot + 2 * math.pi * i / n)) for i in range(n)]
TARGETS = {
    'šestiúhelník': unit_area(reg(6, rot=math.pi / 6)),
    'čtverec': unit_area([(0, 0), (1, 0), (1, 1), (0, 1)]),
    'obdélník': unit_area([(0, 0), (1.6, 0), (1.6, 1), (0, 1)]),
    'pětiúhelník': unit_area([(0, 0), (1.3, 0), (1.55, 0.8), (0.6, 1.3), (-0.2, 0.7)]),
    'sedmiúhelník': unit_area(reg(7, rot=0.3)),
    'lichoběžník': unit_area([(0, 0), (1.8, 0), (1.35, 1), (0.3, 1)]),
    'písmeno L': unit_area([(0, 0), (1.4, 0), (1.4, 0.6), (0.6, 0.6), (0.6, 1.4), (0, 1.4)]),
}
COLORS = ['#3D8CCD', '#5FAF63', '#7C58B5', '#ED8B37', '#E0574D', '#2B4586', '#D25499']
def cut_line(T, rng, bends):
    b = T.exterior; L = b.length
    while True:
        t1 = rng.random(); t2 = (t1 + rng.uniform(0.35, 0.65)) % 1
        p1, p2 = b.interpolate(t1 * L), b.interpolate(t2 * L)
        if p1.distance(p2) > 0.6: break
    dx, dy = p2.x - p1.x, p2.y - p1.y; d = math.hypot(dx, dy); nx, ny = -dy / d, dx / d
    pts = [(p1.x - dx * 0.05, p1.y - dy * 0.05)]
    for k in range(1, bends + 1):
        t = k / (bends + 1) + rng.uniform(-0.06, 0.06); off = rng.choice([-1, 1]) * rng.uniform(0.07, 0.16)
        pts.append((p1.x + dx * t + nx * off, p1.y + dy * t + ny * off))
    pts.append((p2.x + dx * 0.05, p2.y + dy * 0.05)); return LineString(pts)
def ok_piece(g):
    if g.geom_type != 'Polygon' or g.area < 0.17 or g.area > 0.48: return False
    c = list(g.exterior.coords)[:-1]
    if any(math.dist(c[i], c[(i + 1) % len(c)]) < 0.07 for i in range(len(c))): return False
    for i in range(len(c)):
        a, b, e = c[i - 1], c[i], c[(i + 1) % len(c)]
        v1 = (a[0] - b[0], a[1] - b[1]); v2 = (e[0] - b[0], e[1] - b[1])
        ang = math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (math.hypot(*v1) * math.hypot(*v2))))))
        if ang < 28: return False
    return True
def pieces(T, rng):
    for _ in range(400):
        a = split(T, cut_line(T, rng, rng.choice([2, 3])))
        if len(a.geoms) != 2: continue
        big, small = sorted(a.geoms, key=lambda g: -g.area)
        b = split(big, cut_line(big, rng, rng.choice([1, 2])))
        if len(b.geoms) != 2: continue
        P = [small] + list(b.geoms)
        P = [g.simplify(1e-6) for g in P]
        if not all(ok_piece(g) for g in P): continue
        if any(best_overlap(g, g, True) < 0.07 for g in P): continue          # díly nesmí být souměrné (zrcadlo by bylo totéž)
        if any(min(best_overlap(P[i], P[j]), best_overlap(P[i], P[j], True)) < 0.15 for i, j in itertools.combinations(range(3), 2)): continue
        return P
    return None
def perturb(g, rng):
    c = list(g.exterior.coords)[:-1]
    for _ in range(200):
        i = rng.randrange(len(c)); ang = rng.uniform(0, 2 * math.pi); r = rng.uniform(0.04, 0.065)
        c2 = c[:]; c2[i] = (c[i][0] + r * math.cos(ang), c[i][1] + r * math.sin(ang))
        h = Polygon(c2)
        if h.is_valid and ok_piece(h) and 0.045 < best_overlap(g, h) < 0.10 and best_overlap(g, h, True) > 0.045: return h
    return None
def make(name, T, rng, color):
    for attempt in range(150):
        P = pieces(T, rng)
        if not P: continue
        sym = [best_overlap(g, g, True) for g in P]
        a = min(range(3), key=lambda i: sym[i])                                                # nejméně nesouměrný díl → zrcadlo je nenápadné
        b, c = rng.sample([i for i in range(3) if i != a], 2)
        if not (0.07 <= sym[a] <= 0.22): continue
        d1 = affinity.scale(P[a], -1, 1, origin='centroid')                                  # zrcadlo (stejná velikost)
        f = rng.choice([0.92, 1.08]); d2 = affinity.scale(P[b], f, f, origin='centroid')       # o 10 % menší/větší
        d3 = perturb(P[c], rng)                                                               # posunutý roh
        if d3 is None: continue
        D = [d1, d2, d3]
        if any(min(best_overlap(k, d) for k in P) < 0.04 for d in D): continue
        opts = [(g, True) for g in P] + [(g, False) for g in D]; rng.shuffle(opts)
        G = [affinity.rotate(g, rng.uniform(40, 320), origin='centroid') for g, _ in opts]
        keys = [i for i, (_, k) in enumerate(opts) if k]
        # jednoznačnost: žádná jiná trojice se nesloží (řešič, pevná velikost, bez zrcadlení)
        bad = [cmb for cmb in itertools.combinations(range(6), 3) if set(cmb) != set(keys)
               and abs(sum(G[i].area for i in cmb) - 1) < 0.05 and solve(T, [(i, G[i]) for i in cmb], [1.0] * 3, 1.5e-3) is not None]
        if bad: continue
        if solve(T, [(i, G[i]) for i in keys], [1.0] * 3, 1.5e-3) is None: continue          # klíč musí řešič najít
        return {'name': name, 'T': T, 'G': G, 'keys': keys, 'color': color, 'kinds': ['cíl' if k else '' for _, k in opts],
                'dist': {'zrcadlo': a, 'velikost ×%.1f' % f: b, 'posunutý roh': c}}
    return None
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def pd(g, bx=None, by=None):
    b = g.bounds; bx = b[0] if bx is None else bx; by = b[1] if by is None else by
    return 'M' + ' L'.join(fmt(x - bx) + ' ' + fmt(y - by) for x, y in list(g.exterior.coords)[:-1]) + 'Z'
if __name__ == '__main__':
    rng = random.Random(20261003); out = []
    for k, (name, T) in enumerate(TARGETS.items()):
        r = make(name, T, rng, COLORS[k])
        print(name, 'OK' if r else 'NEPODAŘILO SE', r and r['dist'], flush=True)
        if not r: continue
        tb = T.bounds
        out.append({'id': 'SKC_%02d' % (k + 1), 'n': 100 + k + 1, 'level': 6, 'pick': 3,
                    'target': {'paths': [{'d': pd(T), 'fill': r['color']}], 'outline': pd(T), 'w': round(tb[2] - tb[0], 4), 'h': round(tb[3] - tb[1], 4)},
                    'options': [{'paths': [{'d': pd(g), 'fill': r['color']}], 'w': round(g.bounds[2] - g.bounds[0], 4), 'h': round(g.bounds[3] - g.bounds[1], 4),
                                 'correct': i in r['keys'], 'kind': 'cíl' if i in r['keys'] else 'distraktor'} for i, g in enumerate(r['G'])],
                    'answerIdx': r['keys'], 'facety': {'pasmo': 'strop (nová)', 'dilu': 3, 'tvar': name}})
    json.dump(out, open('ceiling_new.json', 'w'), ensure_ascii=False)
    print(len(out), 'položek')
