import json
import sys
B = json.load(open(sys.argv[1]))['items'] if len(sys.argv) > 1 else json.load(open('bank_sk48.json'))
TW, TH, OW, OH = 250, 170, 120, 96
def svg(paths, w, h, u, outline=None, pad=4):
    W, H = w * u + 2 * pad, h * u + 2 * pad
    s = f'<svg width="{W:.0f}" height="{H:.0f}" viewBox="{-pad / u:.4f} {-pad / u:.4f} {W / u:.4f} {H / u:.4f}">'
    sw = 1.6 / u
    for p in paths: s += f'<path d="{p["d"]}" fill="{p["fill"]}" stroke="{p["fill"] if outline else "#111"}" stroke-width="{sw:.4f}" stroke-linejoin="round"/>'
    if outline: s += f'<path d="{outline}" fill="none" stroke="#111" stroke-width="{sw:.4f}" stroke-linejoin="round"/>'
    return s + '</svg>'
html = ['<html><head><meta charset="utf-8"><style>body{font-family:Arial;background:#eef}.it{display:flex;gap:10px;background:#fff;margin:6px;padding:6px;border-radius:8px;align-items:center}.t{width:270px;text-align:center}.o{display:grid;grid-template-columns:repeat(3,130px);gap:4px}.o div{height:104px;display:flex;align-items:center;justify-content:center;border:1px solid #ccd;position:relative}.o div.k{border:3px solid #49a16c}.o b{position:absolute;left:3px;top:1px;font-size:11px}</style></head><body>']
for it in B:
    t = it['target']; mw = max(o['w'] for o in it['options']); mh = max(o['h'] for o in it['options'])
    u = min(TW / t['w'], TH / t['h'], OW / mw, OH / mh)
    html.append(f'<div class="it"><div class="t"><b>{B.index(it) + 1}. {it["id"]}</b> <small>{it["facety"]["pasmo"]}</small><br>{svg(t["paths"], t["w"], t["h"], u, t["outline"])}</div><div class="o">')
    for i, o in enumerate(it['options']):
        html.append(f'<div class="{"k" if i in it["answerIdx"] else ""}"><b>{i + 1}</b>{svg(o["paths"], o["w"], o["h"], u)}</div>')
    html.append('</div></div>')
open(sys.argv[2] if len(sys.argv) > 2 else 'preview.html', 'w').write(''.join(html) + '</body></html>')
