"""Měřítko každého dílu z hran společných s obrysem cíle (+ kontrola: součet ploch klíče = plocha cíle)."""
import math, json
from solve import D, poly_of, edge_lens
from ratios import support, solve_scales
def piece_scale(T, g):
    LT = edge_lens(T); Lg = edge_lens(g)
    cnt, r = support(Lg, LT)          # r = délka v cíli / délka v dílu
    return cnt, r
if __name__ == '__main__':
    S = json.load(open('solve_res.json')) if False else {}
    out = {}
    for x in D:
        T = poly_of(x['target']); A = T.area
        sc = {}
        for c in x['cands']:
            g = poly_of(c['paths']); cnt, r = piece_scale(T, g); sc[c['i']] = (cnt, r / math.sqrt(A) if r else None, g.area)
        ksum = sum((sc[i][1] or 0) ** 2 * sc[i][2] for i in x['key'])
        out[x['no']] = {i: v[1] for i, v in sc.items()}
        print(x['no'], 'Σ ploch klíče/cíl = %.3f' % ksum, 'klíč', {i: (sc[i][0], round(sc[i][1] or 0, 4)) for i in x['key']})
    json.dump(out, open('tscale.json', 'w'))
