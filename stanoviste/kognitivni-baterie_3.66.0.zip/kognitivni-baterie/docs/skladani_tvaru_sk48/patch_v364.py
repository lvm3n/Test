"""3.64.0 / 1.25.0 – Skládání tvarů SK48 místo Mentální rotace (díly ve skutečném měřítku, ověřené klíče)."""
import os, json, shutil, csv, io, glob
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
BANK = open('st13/BANK_SK48.json', encoding='utf8').read(); MOD = open('st14/module.js', encoding='utf8').read()
TX = {CZ: dict(name='Skládání tvarů', blurb='Vyber díly, ze kterých se složí tvar',
          instr='Nahoře je tvar. Dole vyber díly, ze kterých se dá přesně složit – nic nesmí chybět ani přečnívat. Díly můžeš v duchu otáčet, ale ne převracet (zrcadlit). Jsou nakreslené ve stejné velikosti jako tvar, takže záleží i na velikosti. Nejdřív se vybírají 2 díly, potom 3.',
          ref='Tvar', pick2='Vyber 2 díly, ze kterých se tvar složí:', pick3='Vyber 3 díly, ze kterých se tvar složí:',
          wrong='Správné díly mají zelený rámeček. Díly se dají otáčet, ale ne převracet, a musí mít správnou velikost.',
          demo='Dva zelené čtverce dohromady dají obdélník. Díly jsou nakreslené ve stejné velikosti jako tvar.'),
      EN: dict(name='Shape Assembly', blurb='Pick the pieces that make the shape',
          instr='At the top is a shape. Below, pick the pieces that fit together exactly to make it – nothing may be missing or stick out. You may rotate the pieces in your mind, but not flip them over (mirror them). They are drawn at the same size as the shape, so size matters too. First you pick 2 pieces, later 3.',
          ref='Shape', pick2='Pick the 2 pieces that make the shape:', pick3='Pick the 3 pieces that make the shape:',
          wrong='The correct pieces have a green frame. Pieces can be rotated but not flipped, and they must be the right size.',
          demo='Two green squares together make the rectangle. The pieces are drawn at the same size as the shape.')}
for d in (CZ, EN):
    app = d + 'assets/app.html'
    # mod_pick: počet vybíraných dílů může být u položky (it.pick), popisek výběru podle položky
    rep(app, 'class="gv-lbl">${cfg.pickLabel}</p>', 'class="gv-lbl" id="${K}-picklbl">${cfg.pickLabel}</p>')
    rep(app, "    $('#' + K + '-ref').innerHTML = cfg.refRender(it);", "    $('#' + K + '-ref').innerHTML = cfg.refRender(it);\n    if (cfg.pickText) $('#' + K + '-picklbl').textContent = cfg.pickText(it);")
    rep(app, "ST.sel.length !== cfg.pickN", "ST.sel.length !== (it.pick || cfg.pickN)")
    rep(app, "if (ST.sel.length > cfg.pickN) ST.sel.shift();", "if (ST.sel.length > (it.pick || cfg.pickN)) ST.sel.shift();")
    rep(app, "ok = (hits === cfg.pickN && !ST.timedOut)", "ok = (hits === (it.pick || cfg.pickN) && !ST.timedOut)")
    rep(app, "format:cfg.key + '-' + cfg.pickN + 'z'", "format:cfg.key + '-' + (it.pick || cfg.pickN) + 'z'")
    rep(app, "max_skore:cfg.pickN,", "max_skore:(it.pick || cfg.pickN),")
    # banka + modul
    rep(app, "\nfunction mod_skladani(root, BANK){", "\nconst BANK_SK48 = " + BANK + ";\nconst SK48_TX = " + json.dumps(TX[d], ensure_ascii=False) + ";\n" + MOD + "\nfunction mod_skladani(root, BANK){")
    # registrace: Skládání tvarů místo Mentální rotace
    rep(app, ' mod_rotace(document.getElementById("m-rotace"), BANK_ROT),',
        ' /* Mentální rotace skrytá od 3.64.0 – nahrazena Skládáním tvarů SK48 (kód, banka i data zůstávají): mod_rotace(document.getElementById("m-rotace"), BANK_ROT), */\n mod_skladani48(document.getElementById("m-skladani"), BANK_SK48, SK48_TX),')
    rep(app, "skladani:[['SK-v1', 'SK-v1t']]", "skladani:[['SK-v1', 'SK-v1t'], ['SK48-v1']]")
    # kódovník
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    B = json.loads(BANK)
    for k, it in enumerate(B['practice'] + B['items']):
        body.append(['skladani', 'SK48-v1', k + 1, it['id'], 'vyber %d z 6 dílů; %s' % (it['pick'], it['facety']['pasmo']),
                     ' '.join(str(i + 1) for i in it['answerIdx']), 'úroveň %s' % it['level'], '', 'nácvik' if it['level'] == 0 else 'limit %d s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60)])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(EN + 'assets/app.html', "'papir', 'rotace', 'rds'", "'papir', 'skladani', 'rds'", 2)
rep(CZ + 'includes/rest.php', "'papir', 'rotace', 'rds'", "'papir', 'rotace', 'skladani', 'rds'")
rep(EN + 'includes/admin.php', "$keys = array('matice', 'vahy', 'dedukce', 'pravidla', 'stanoviste', 'papir', 'rotace', 'rds'", "$keys = array('matice', 'vahy', 'dedukce', 'pravidla', 'stanoviste', 'papir', 'rotace', 'skladani', 'rds'")
rep(CZ + 'kognitivni-baterie.php', '3.63.0', '3.64.0', 2); rep(EN + 'cognitive-battery-en.php', '1.24.0', '1.25.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.63.0</div>', '>verze 3.64.0</div>'); rep(EN + 'assets/app.html', '>version 1.24.0 (EN)</div>', '>version 1.25.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'; os.makedirs(dd, exist_ok=True)
for f in ('solve.py', 'sim.py', 'tscale.py', 'ratios.py', 'curve.py', 'grid.py', 'refine43.py', 'roundcheck.py', 'congr.py', 'build.py', 'make_bank.py', 'preview.py',
          'keyscales.json', 'build_log.txt', 'preview.html', 'BANK_SK48.json'):
    shutil.copy('st13/' + f, dd + f)
shutil.copy('st13/src.html', dd + 'puvodni_skladani_tvaru_48_final.html')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.64.0 – Skládání tvarů SK48-v1 místo Mentální rotace
Mentální rotace (MR-v6-38h) je skrytá: kód, banka, data i přepočet zůstávají, jen se nenabízí. Na jejím místě je Skládání
tvarů (obdoba Visual Puzzles z WAIS): nahoře tvar, dole 6 dílů, vybrat 2 (položky 1–3) nebo 3 díly, ze kterých se tvar
přesně složí; díly lze otáčet, ne zrcadlit.
Zdroj: sada 48 položek (skladani_tvaru_48_final). Původní kresba měla každý díl zvětšený na výšku svého políčka, takže
neseděly velikosti (u položek 4, 6, 8, 9, 15, 40, 48 byl distraktor stejného tvaru jako správný díl, lišící se jen
velikostí → dvě správné odpovědi). Skutečné měřítko v souboru nebylo, proto se dopočítalo (docs/skladani_tvaru_sk48/):
- klíč: řešič skládání (otáčení bez zrcadlení) ověřil u všech 48 položek, že se správné díly složí do tvaru, a určil
  jejich skutečnou velikost; u kulatých tvarů z délky obloukových úseků (součet ploch klíče = plocha tvaru ±0,6 %);
- distraktory: zrcadlo správného dílu = stejná velikost; díl stejného tvaru = jiná velikost (×0,78 / ×1,28); jiný tvar =
  stejná plocha jako nejpodobnější správný díl; u kulatých tvarů velikost z obloukových úseků;
- jednoznačnost: u mnohoúhelníkových tvarů řešič ověřil, že žádná jiná trojice (dvojice) dílů tvar nesloží; u kulatých
  tvarů kontrola plochy, délky oblouku a shodnosti. Upraveny 3 distraktory (pol. 12: kombinace 1-2-5 šla složit;
  pol. 11 a 41: zrcadlo téměř souměrného dílu bylo prakticky totožné se správným dílem → zmenšeno).
- kresba: všechny díly položky ve stejném měřítku jako tvar; cílový tvar bez viditelných švů mezi díly.
Administrace: 2 cvičné položky se zpětnou vazbou; od 9 let start u položky 4 (první se 3 díly, položky 1–3 se připíší,
při chybě návrat); limit 45 s (položky se 2 díly a velmi lehké), jinak 60 s; ukončení po S.stop chybách v řadě + sondy.
Skór = počet správně (všechny vybrané díly správně). Pořadí zatím podle autorských pásem obtížnosti – po sběru dat přeřadit.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.25.0 – Shape Assembly (Skládání tvarů SK48-v1) místo Mental Rotation, stejně jako česká 3.64.0.
''')
print('ok')
