"""Měřítko dílů u kulatých cílů: kružnice/elipsa proložená obloukovými body dílu vs. cíl (otočení nevadí – porovnávají se poloosy)."""
import math, json, numpy as np
from solve import D, poly_of
def arc_points(g, frac=0.03):
    c = list(g.exterior.coords); per = g.length; pts = set()
    for i in range(len(c) - 1):
        if math.dist(c[i], c[i + 1]) < frac * per: pts.add(c[i]); pts.add(c[i + 1])
    return np.array(sorted(pts))
def conic_axes(P):
    x, y = P[:, 0], P[:, 1]
    M = np.stack([x * x, x * y, y * y, x, y, np.ones_like(x)], 1)
    _, _, Vt = np.linalg.svd(M); a, b, c, d, e, f = Vt[-1]
    A = np.array([[a, b / 2], [b / 2, c]]); ctr = np.linalg.solve(2 * A, [-d, -e])
    k = -(a * ctr[0] ** 2 + b * ctr[0] * ctr[1] + c * ctr[1] ** 2 + d * ctr[0] + e * ctr[1] + f)
    ev = np.linalg.eigvalsh(A / k)
    if np.any(ev <= 0): return None
    ax = sorted(1 / np.sqrt(ev)); return ax
if __name__ == '__main__':
    out = {}
    for n in (11, 18, 23, 25, 28, 33, 41, 47):
        x = D[n - 1]; T = poly_of(x['target']); A = T.area
        ta = conic_axes(np.array(T.exterior.coords))
        res = {}
        for c in x['cands']:
            g = poly_of(c['paths']); ap = arc_points(g)
            ax = conic_axes(ap) if len(ap) >= 6 else None
            if ax is None: res[c['i']] = None; continue
            s = (ta[0] / ax[0] + ta[1] / ax[1]) / 2; spread = abs(ta[0] / ax[0] - ta[1] / ax[1]) / s
            res[c['i']] = (round(s / math.sqrt(A), 5), round(spread, 3), round((s * s * g.area) / A, 3))
        keysum = sum(res[i][2] for i in x['key'] if res[i])
        print(n, 'cíl poloosy', [round(v, 1) for v in ta], 'klíč', x['key'], 'Σ ploch klíče / cíl = %.3f' % keysum, res)
        out[n] = res
    json.dump(out, open('curve_res.json', 'w'))
