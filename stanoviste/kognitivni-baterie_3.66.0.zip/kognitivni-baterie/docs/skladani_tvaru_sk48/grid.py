import math, sys, numpy as np
import solve as S
from solve import *
def solve_grid(n):
    x = D[n - 1]; T = poly_of(x['target']); A = T.area; k = 1 / math.sqrt(A); T = affinity.scale(T, k, k, origin=(0, 0))
    G = {i: poly_of(x['cands'][i - 1]['paths']) for i in x['key']}
    Rs = simplify(T, 0.004)
    rv = [v for v in verts(Rs) if v[3] < math.pi - 0.05]
    best = None
    for i, P in G.items():
        smax = math.sqrt(1 / P.area)
        rest = [(j, G[j]) for j in G if j != i]
        for v in rv:
            for u in verts(simplify(P, 0.02)):
                if u[3] > v[3] + 0.03: continue
                for s in np.linspace(0.3 * smax, 0.95 * smax, 260):
                    for w in (0, 1):
                        g = place(P, u, v, s, w)
                        if g.difference(T).area > 4e-4: continue
                        R2 = T.difference(g).buffer(-2.5e-3, join_style=2).buffer(2.5e-3, join_style=2)
                        sub = S.solve(R2, rest, [None, None], 1.5e-3)
                        if sub is not None: return {i: s} | {pid: sc for pid, sc, _ in sub}
    return None
for n in map(int, sys.argv[1:]): print(n, solve_grid(n), flush=True)
