"""3.65.0 / 1.26.0 – Skládání tvarů SK30-v1: zkráceno na 30 položek (vyřazeny duplicitní), pořadí podle předpokládané obtížnosti, 7 nových stropových."""
import os, json, shutil, csv, io
base = '/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/'; os.chdir(base)
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st13/BANK_SK30.json', encoding='utf8'))
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK48-v1', pickN:3,", "version:'SK30-v1', pickN:3,")
    rep(app, "['SK48-v1']]", "['SK48-v1'], ['SK30-v1']]")
    rep(app, "   Banka: 48 položek, klíče a jednoznačnost ověřeny řešičem (docs/skladani_tvaru_sk48/). ===== */",
        "   Banka SK30: 30 položek (23 z původní sady bez duplicit + 7 nových stropových), pořadí podle předpokládané obtížnosti;\n   klíče a jednoznačnost ověřeny řešičem (docs/skladani_tvaru_sk48/). ===== */")
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']
        body.append(['skladani', 'SK30-v1', k + 1, it['id'], 'vyber %d z 6 dílů; %s%s' % (it['pick'], f['pasmo'], '; ' + f['tvar'] if f.get('tvar') else ''),
                     ' '.join(str(i + 1) for i in it['answerIdx']), 'nácvik' if it['level'] == 0 else 'pořadí %d; předpokládaná obtížnost %s' % (k - 1, f.get('predpoklad', '')),
                     '', '' if it['level'] == 0 else 'limit %d s; původní položka %s' % (45 if it['pick'] == 2 or it['level'] <= 2 else 60, f.get('puvodni', ''))])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.64.0', '3.65.0', 2); rep(EN + 'cognitive-battery-en.php', '1.25.0', '1.26.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.64.0</div>', '>verze 3.65.0</div>'); rep(EN + 'assets/app.html', '>version 1.25.0 (EN)</div>', '>version 1.26.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('features.py', 'features.json', 'dupes.py', 'dupes.json', 'predict.py', 'gen_ceiling.py', 'ceiling_new.json', 'assemble.py', 'BANK_SK30.json', 'preview30.html', 'preview.py'):
    shutil.copy('st13/' + f, dd + f)
shutil.copy('st14/patch_v365.py', dd + 'patch_v365.py')
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.65.0 – Skládání tvarů SK30-v1 (30 položek místo 48)
- Vyřazeny duplicitní položky (stejný tvar a téměř stejné řezy, liší se jen barvou/vzorem): 2 (= 1), 5 (= 4), 9 (= 10),
  12 (= 14), 16 (= 34), 23 (= 28), 20, 31, 36 (= 15/22); kvůli převaze čtverců (16 ze 48) a slabým distraktorům dále 6, 10,
  13, 17, 18, 19, 21, 25, 27, 30, 32, 37, 41, 42, 46, 48. Zůstává 23 položek (7 čtverců, kruhy, elipsy, šesti- a víceúhelníky).
- 7 nových stropových položek SKC_01–07 (šestiúhelník, čtverec, obdélník, pětiúhelník, sedmiúhelník, lichoběžník, L):
  3 díly z lomených řezů, jednobarevné (bez barevného vodítka), díly nesouměrné; distraktory těsně u správných dílů:
  zrcadlo mírně nesouměrného dílu, správný díl ±8 % velikosti, díl s rohem posunutým o 0,04–0,065 (≈ 5–10 % rozdílu).
  Klíč i jednoznačnost (žádná jiná trojice se nesloží, bez zrcadlení) ověřil řešič.
- Pořadí podle předpokládané obtížnosti (docs/skladani_tvaru_sk48/predict.py), ne podle autorských pásem:
  složitost správných dílů (+), blízkost nejpodobnějšího distraktoru (+), zrcadlový distraktor (+), vícebarevný tvar jako
  vodítko (−), malý díl (+), autorské pásmo jen slabě; položky se 2 díly vždy na začátku. Po sběru dat přeřadit podle Rasche.
- Start, limity a ukončení beze změny (od 9 let start u první položky se 3 díly). Nová srovnávací skupina SK30-v1.
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.26.0 – Shape Assembly SK30-v1: 30 položek (bez duplicit), pořadí podle předpokládané obtížnosti, 7 nových stropových – jako česká 3.65.0.
''')
print('ok')
