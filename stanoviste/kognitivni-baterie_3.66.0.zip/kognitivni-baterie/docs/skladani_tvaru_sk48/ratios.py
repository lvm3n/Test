"""Měřítka klíčových dílů ze sdílených řezů: hrany, které dva díly sdílejí, mají ve skutečném měřítku stejnou délku.
Poměr měřítek s_i/s_j = délka hrany j / délka hrany i, který podporuje nejvíc dvojic hran; absolutní měřítko z plochy cíle."""
import math, json, itertools, collections
from solve import D, poly_of, edge_lens
def support(Li, Lj, tol=0.004):
    rs = sorted(b / a for a in Li for b in Lj if a > 0.5 and b > 0.5)
    best = (0, None)
    for r in rs:
        cnt = sum(1 for q in rs if abs(q / r - 1) < tol)
        if cnt > best[0]: best = (cnt, r)
    return best
def solve_scales(n):
    x = D[n - 1]; T = poly_of(x['target']); A = T.area
    G = {i: poly_of(x['cands'][i - 1]['paths']) for i in x['key']}
    L = {i: edge_lens(G[i]) for i in G}
    k = x['key']; r = {}
    for a, b in itertools.combinations(k, 2):
        r[(a, b)] = support(L[a], L[b])      # s_a/s_b
    a0 = k[0]; rel = {a0: 1.0}
    for b in k[1:]: rel[b] = 1 / r[(a0, b)][1]           # s_b relativně k s_a0
    cons = None
    if len(k) == 3: cons = rel[k[2]] / rel[k[1]] * r[(k[1], k[2])][1]   # má být 1
    s0 = math.sqrt(A / sum(rel[i] ** 2 * G[i].area for i in k))
    return {i: rel[i] * s0 / math.sqrt(A) for i in k}, r, cons
if __name__ == '__main__':
    for n in (11, 18, 23, 25, 28, 32, 33, 41, 43, 47, 1, 13, 44):
        sc, r, cons = solve_scales(n)
        print(n, {i: round(v, 4) for i, v in sc.items()}, 'podpora', {k: v[0] for k, v in r.items()}, 'konzistence %.3f' % cons if cons else '')
