"""BANK_SK48 pro aplikaci: 48 položek v ověřeném měřítku + 2 cvičné položky s přesnou geometrií."""
import json, math
from shapely.geometry import Polygon
from shapely import affinity
B = json.load(open('bank_sk48.json'))
def fmt(v): return ('%.4f' % v).rstrip('0').rstrip('.')
def pd(pts): return 'M' + ' L'.join(fmt(x) + ' ' + fmt(y) for x, y in pts) + 'Z'
def opt(poly, fill, rot, correct, kind):
    g = affinity.rotate(Polygon(poly), rot, origin='centroid'); bx, by, ex, ey = g.bounds
    pts = [(x - bx, y - by) for x, y in list(g.exterior.coords)[:-1]]
    return {'paths': [{'d': pd(pts), 'fill': fill}], 'w': round(ex - bx, 4), 'h': round(ey - by, 4), 'correct': correct, 'kind': kind}
def item(iid, target, fill, opts, pick):
    T = Polygon(target); k = 1 / math.sqrt(T.area)
    tt = [(x * k, y * k) for x, y in target]
    o = [dict(x) for x in opts]
    for x in o:   # stejné měřítko jako cíl
        x['paths'] = [{'d': pd([(float(a) * k, float(b) * k) for a, b in [q.split() for q in p['d'][1:-1].split(' L')]]), 'fill': p['fill']} for p in x['paths']]; x['w'] = round(x['w'] * k, 4); x['h'] = round(x['h'] * k, 4)
    w = max(p[0] for p in tt); h = max(p[1] for p in tt)
    return {'id': iid, 'level': 0, 'pick': pick, 'target': {'paths': [{'d': pd(tt), 'fill': fill}], 'outline': pd(tt), 'w': round(w, 4), 'h': round(h, 4)},
            'options': o, 'answerIdx': [i for i, x in enumerate(o) if x['correct']], 'facety': {'pasmo': 'nácvik', 'dilu': pick}}
G = '#5FAF63'; O = '#ED8B37'
sq = [(0, 0), (1, 0), (1, 1), (0, 1)]
P1 = item('SK48_N1', [(0, 0), (2, 0), (2, 1), (0, 1)], G, [
    opt(sq, G, 20, True, 'cíl'), opt([(0, 0), (1.4, 0), (1.4, 1), (0, 1)], G, -15, False, 'jiný poměr stran'),
    opt(sq, G, -35, True, 'cíl'), opt([(0, 0), (0.7, 0), (0.7, 0.7), (0, 0.7)], G, 10, False, 'jiná velikost')], 2)
tri_big = [(0, 0), (2, 0), (0, 2)]; tri_q = [(0, 0), (2, 0), (1, 1)]
P2 = item('SK48_N2', [(0, 0), (2, 0), (2, 2), (0, 2)], O, [
    opt([(0, 0), (2, 0), (2, 2)], O, 30, True, 'cíl'), opt([(0, 0), (1, 0), (1, 1), (0, 1)], O, 15, False, 'jiný tvar'),
    opt([(0, 0), (1.4, 0), (0.7, 0.7)], O, -60, False, 'jiná velikost'), opt([(0, 0), (2, 0), (1, 1)], O, 160, True, 'cíl'),
    opt([(0, 0), (2, 0), (1.5, 1)], O, 75, False, 'jiný úhel'), opt([(0, 2), (0, 0), (1, 1)], O, -110, True, 'cíl')], 3)
# cíl N2 = čtverec 2×2 = velký pravoúhlý trojúhelník (polovina) + dva čtvrtinové trojúhelníky
for it in B:
    it['options'] = [{**o, 'kind': 'cíl' if o['correct'] else 'distraktor'} for o in it['options']]
bank = {'verze': 'SK48-v1', 'practice': [P1, P2], 'items': B}
json.dump(bank, open('BANK_SK48.json', 'w'), ensure_ascii=False, separators=(',', ':'))
print(len(json.dumps(bank)) // 1024, 'kB')
