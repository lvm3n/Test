"""SK30: 23 vybraných položek + 7 nových stropových, seřazeno podle předpokládané obtížnosti."""
import json, math
from roundcheck import geo
from congr import best_overlap
from predict import index
B = {it['n']: it for it in json.load(open('bank_sk48.json'))}
C = json.load(open('ceiling_new.json'))
KEEP = [1, 3, 4, 14, 7, 8, 11, 26, 24, 15, 34, 33, 35, 29, 32, 47, 28, 39, 43, 22, 38, 45, 40, 44]
KEEP.remove(32)                                           # 23 původních
ROUND = {11, 18, 23, 25, 28, 33, 41, 47}
F0 = {f['n']: f for f in json.load(open('features.json'))}
def feats(it):
    if it['n'] in F0: return F0[it['n']]
    G = [geo(o['paths']) for o in it['options']]; keys = it['answerIdx']; dis = [i for i in range(6) if i not in keys]
    close = [(min(best_overlap(G[k], G[d]) for k in keys), min(best_overlap(G[k], G[d], True) for k in keys) < 0.03) for d in dis]
    return {'n': it['n'], 'pasmo': 'ceiling probe', 'dilu': 3, 'barvy': 1, 'zrcadel': sum(c[1] for c in close), 'nejbliz': round(min(c[0] for c in close), 2),
            'vrcholu': round(sum(len(G[k].exterior.coords) - 1 for k in keys) / 3, 1), 'nejmensi_dil': round(min(G[k].area for k in keys), 2)}
items = [B[n] for n in KEEP] + C
F = [feats(it) for it in items]
idx = index(F)
order = sorted(range(len(items)), key=lambda i: (items[i]['pick'] != 2, idx[i]))
final = []
for r, i in enumerate(order):
    it = dict(items[i]); it['facety'] = dict(it['facety'], predpoklad=idx[i], puvodni=it['n'] if it['n'] < 100 else 'nová')
    it['level'] = 1 + min(5, int(r / 6)); final.append(it)
    print('%2d %-8s %5.2f %s nejbliž %.2f vrch %s' % (r + 1, it['id'], idx[i], it['facety']['pasmo'], F[i]['nejbliz'], F[i]['vrcholu']))
pr = json.load(open('BANK_SK48.json'))['practice']
for it in final: it['options'] = [{**o, 'kind': o.get('kind') or ('cíl' if o['correct'] else 'distraktor')} for o in it['options']]
json.dump({'verze': 'SK30-v1', 'practice': pr, 'items': final}, open('BANK_SK30.json', 'w'), ensure_ascii=False, separators=(',', ':'))
print(len(final), 'položek')
