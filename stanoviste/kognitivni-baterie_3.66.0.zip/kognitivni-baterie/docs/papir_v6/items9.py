"""Skládání papíru – nový strop (úroveň 9) + přeřazení úrovně 6 za úrovně 7–8. Výstup: bank_papir_v6.json"""
import json, collections
from paper import fold_cells, answer, layers
from gen9b import dirty
NEW = [  # (přehyby, dírky) – pořadí = odhad obtížnosti
    (['DU', 'HB'], [[0, 2], [1, 0]]),
    (['AL', 'HT'], [[2, 0], [3, 2]]),
    (['VL1', 'HB1', 'VR1'], [[0, 2], [2, 1]]),
    (['HT1', 'VR1', 'HB2'], [[0, 2], [1, 1]]),
    (['AU', 'VR1'], [[2, 2, 3]]),
    (['HB3', 'VR1', 'HB2'], [[-3, 2], [-2, 1]]),
    (['DL', 'HT1'], [[1, 2, 0]]),
    (['VR3', 'HT1', 'VR1'], [[1, -1], [2, -2]]),
]
s = open('../out/kognitivni-baterie/assets/app.html', encoding='utf8').read(); i = s.index('const BANK_GV = ') + 16
B = json.JSONDecoder().raw_decode(s[i:])[0]
old = B['papir']
order = [x for x in old if x['level'] != 6] + [x for x in old if x['level'] == 6]
new = []
for k, (fs, hs) in enumerate(NEW):
    pos, _ = fold_cells(4, fs); st = collections.Counter(pos.values()); occ = set(pos.values()); bad = dirty(fs)
    for h in hs:
        assert (h[0], h[1]) in occ, (fs, h)
        assert not any(o in bad for o, p in pos.items() if p == (h[0], h[1])), (fs, h)
    a = answer(4, fs, hs)
    off = [f for f in fs if len(f) > 2]
    def w_at(f, j):
        p, _ = fold_cells(4, fs[:j]); v = list(p.values())
        return (max(q[1] for q in v) - min(q[1] for q in v) + 1) if f[0] == 'V' else (max(q[0] for q in v) - min(q[0] for q in v) + 1)
    pruh = any(len(f) > 2 and 2 * int(f[2:]) < w_at(f, j) for j, f in enumerate(fs))
    netyp = any(len(f) > 2 and 2 * int(f[2:]) > w_at(f, j) for j, f in enumerate(fs))
    tri = any(len(h) > 2 for h in hs)
    fac = {'prelozeni': len(fs), 'pruhove': int(pruh), 'netypicke': int(netyp), 'uhlopricne': int(any(f[0] in 'DA' for f in fs)),
           'vystrih': int(tri), 'max_vrstev': layers(4, fs), 'polickek': len(a)}
    new.append({'level': 9, 'n': 4, 'folds': fs, 'holes': hs, 'answer': a, 'shapes': tri, 'facety': fac,
                'id': 'PAP_%03d' % (43 + k), 'poradi_v1': None, 'obtiznost_odhad': round(5.2 + 0.2 * k, 1)})
bank = order + new
for x in new:
    g = [['.'] * 4 for _ in range(4)]
    for q in x['answer']: g[q[0]][q[1]] = '↖↗↘↙'[q[2]] if len(q) > 2 else '#'
    print(x['id'], x['folds'], x['holes'], x['facety'], ' '.join(''.join(r) for r in g))
json.dump(bank, open('bank_papir_v6.json', 'w'), ensure_ascii=False)
print(len(bank), [x['level'] for x in bank])
