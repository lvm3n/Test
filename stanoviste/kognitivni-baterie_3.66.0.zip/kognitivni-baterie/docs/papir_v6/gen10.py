"""Extrémní položky: 2 přehyby → výstřih → 3. přehyb → další výstřih."""
import itertools, collections, json, random
from paper import fold_cells, answer
from gen9 import opts, bbox
from gen9b import dirty, dopts
N = 4
def seqs():
    def rec(fs):
        if len(fs) == 3: yield list(fs); return
        pos, _ = fold_cells(N, fs)
        for f in opts(pos) + dopts(pos): yield from rec(fs + [f])
    yield from rec([])
def cands(fs, k):
    pos, _ = fold_cells(N, fs[:k]); bad = dirty(fs[:k]) if k else set()
    st = collections.defaultdict(list)
    for o, p in pos.items(): st[p].append(o)
    return [p for p in st if not any(o in bad for o in st[p])], st
out = []
for fs in seqs():
    pos, _ = fold_cells(N, fs); r0, r1, c0, c1 = bbox(pos)
    if min(r0, c0) < -3 or max(r1, c1) > 6: continue
    weird = sum(len(f) > 2 for f in fs) + 2 * sum(f[0] in 'DA' for f in fs)
    if weird < 2: continue
    A, _ = cands(fs, 2); Bc, stB = cands(fs, 3)
    for a in A:
        for b in Bc:
            for oa in range(4):
                ansA = answer(N, fs[:2], [[a[0], a[1], oa]])
                if not (2 <= len(ansA) <= 4): continue
                for ob in range(4):
                    ansB = answer(N, fs, [[b[0], b[1], ob]])
                    if not (2 <= len(ansB) <= 4): continue
                    cA = {(x[0], x[1]) for x in ansA}; cB = {(x[0], x[1]) for x in ansB}
                    if cA & cB: continue
                    if len(set(x[2] for x in ansA + ansB)) < 3: continue
                    out.append((fs, [a[0], a[1], oa], [b[0], b[1], ob], sorted(ansA + ansB), weird))
print(len(out))
json.dump(out, open('cand10.json', 'w'))
c = collections.Counter(tuple(x[0]) for x in out); print(len(c))
random.seed(5)
for fs, A, B, ans, w in random.sample(out, 30):
    g = [['.'] * 4 for _ in range(4)]
    for x in ans: g[x[0]][x[1]] = '↖↗↘↙'[x[2]]
    print(fs, A, B, w, len(ans), ' '.join(''.join(r) for r in g))
