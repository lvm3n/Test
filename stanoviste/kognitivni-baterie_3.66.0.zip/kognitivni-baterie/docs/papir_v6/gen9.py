"""Kandidáti na těžší položky (3 přehyby, nerovnoměrné vrstvy)."""
import itertools, collections, json, random
from paper import fold_cells, answer
N = 4
def bbox(pos):
    v = list(pos.values()); return min(p[0] for p in v), max(p[0] for p in v), min(p[1] for p in v), max(p[1] for p in v)
def opts(pos):
    r0, r1, c0, c1 = bbox(pos); h, w = r1 - r0 + 1, c1 - c0 + 1; out = []
    for ax, L, a, b in (('V', w, 'L', 'R'), ('H', h, 'T', 'B')):
        if L % 2 == 0 and L >= 2: out += [ax + a, ax + b]
        for k in range(1, L):
            if 2 * k != L: out += [ax + a + str(k), ax + b + str(k)]
    return out
def seqs():
    def rec(fs):
        if len(fs) == 3: yield list(fs); return
        pos, _ = fold_cells(N, fs)
        for f in opts(pos): yield from rec(fs + [f])
    yield from rec([])
res = []
for fs in seqs():
    pos, hist = fold_cells(N, fs)
    r0, r1, c0, c1 = bbox(pos)
    if r0 < -3 or c0 < -3 or r1 > 6 or c1 > 6: continue
    st = collections.Counter(pos.values())
    if max(st.values()) > 8: continue
    if not any(len(f) > 2 for f in fs): continue
    cells = sorted(st)
    for nh in (1, 2):
        for hs in itertools.combinations(cells, nh):
            a = answer(N, fs, [list(h) for h in hs])
            sz = [st[h] for h in hs]
            if not (5 <= len(a) <= 8): continue
            if nh == 2 and sz[0] == sz[1]: continue
            res.append((fs, [list(h) for h in hs], a, sz))
print(len(res))
json.dump(res, open('cand9.json', 'w'))
random.seed(1)
for x in random.sample(res, 25): print(x)
