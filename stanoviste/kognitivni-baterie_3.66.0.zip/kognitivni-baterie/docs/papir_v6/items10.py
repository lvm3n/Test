"""Extrémní položky úrovně 10: 2 přehyby → výstřih → 3. přehyb → další výstřih. Výstup: bank_papir_v7.json"""
import json
from paper import fold_cells, answer, layers
from gen9b import dirty
X = [  # (přehyby, výstřih po 2. přehybu, výstřih na konci)
    (['DU', 'VL1', 'HT'], [2, 1, 1], [3, 2, 2]),
    (['AU', 'VL1', 'VR1'], [3, 3, 2], [2, 2, 3]),
    (['VL3', 'HB3', 'DU'], [0, 3, 1], [0, 4, 2]),
]
bank = json.load(open('bank_papir_v6.json', encoding='utf8'))
for k, (fs, A, Bh) in enumerate(X):
    for upto, h in ((2, A), (3, Bh)):
        pos, _ = fold_cells(4, fs[:upto]); bad = dirty(fs[:upto])
        assert (h[0], h[1]) in set(pos.values()) and not any(o in bad for o, p in pos.items() if p == (h[0], h[1]))
    aA = answer(4, fs[:2], [A]); aB = answer(4, fs, [Bh])
    assert not ({(x[0], x[1]) for x in aA} & {(x[0], x[1]) for x in aB})
    ans = sorted(aA + aB)
    fac = {'prelozeni': 3, 'pruhove': int(any(len(f) > 2 and int(f[2:]) == 1 for f in fs)), 'netypicke': int(any(len(f) > 2 and int(f[2:]) == 3 for f in fs)),
           'uhlopricne': 1, 'vystrih': 1, 'max_vrstev': layers(4, fs), 'polickek': len(ans), 'strihy': 2}
    bank.append({'level': 10, 'n': 4, 'folds': fs, 'cuts': [{'po': 2, 'holes': [A]}], 'holes': [Bh], 'answer': ans, 'shapes': True,
                 'facety': fac, 'id': 'PAP_%03d' % (51 + k), 'poradi_v1': None, 'obtiznost_odhad': round(6.8 + 0.2 * k, 1)})
    g = [['.'] * 4 for _ in range(4)]
    for x in ans: g[x[0]][x[1]] = '↖↗↘↙'[x[2]]
    print(bank[-1]['id'], fs, A, Bh, fac, ' '.join(''.join(r) for r in g))
json.dump(bank, open('bank_papir_v7.json', 'w'), ensure_ascii=False)
print(len(bank))
