"""Skládání papíru – nezávislý výpočet řešení (stejná geometrie jako GV_DRAW.applyFolds: středy políček)."""
import json
REF = {'V': {0: 1, 1: 0, 2: 3, 3: 2}, 'H': {0: 3, 3: 0, 1: 2, 2: 1}, 'D': {0: 0, 2: 2, 1: 3, 3: 1}, 'A': {1: 1, 3: 3, 0: 2, 2: 0}}
def fold_cells(n, folds):
    pos = {(r, c): (r, c) for r in range(n) for c in range(n)}; hist = {k: [] for k in pos}
    for f in folds:
        occ = list(pos.values())
        r0 = min(p[0] for p in occ); r1 = max(p[0] for p in occ); c0 = min(p[1] for p in occ); c1 = max(p[1] for p in occ)
        w = c1 - c0 + 1
        kk = int(f[2:]) if len(f) > 2 else None
        new = {}
        for o, (r, c) in pos.items():
            if f[0] in 'VH':
                if kk is None: mid = (c0 + c1) / 2 if f[0] == 'V' else (r0 + r1) / 2
                else:                                        # posunutý přehyb: kk políček od kraje (hrana mezi políčky)
                    if f[0] == 'V': mid = (c0 + kk - 0.5) if f[1] == 'L' else (c1 - kk + 0.5)
                    else: mid = (r0 + kk - 0.5) if f[1] == 'T' else (r1 - kk + 0.5)
                k = c if f[0] == 'V' else r
                moving = (k < mid) if f[1] in 'LT' else (k > mid)
                k2 = round(2 * mid - k)
                if moving: new[o] = (r, k2) if f[0] == 'V' else (k2, c); hist[o].append(f[0])
                else: new[o] = (r, c)
            else:
                rr, cc = r - r0, c - c0
                if f[0] == 'D':
                    s = cc - rr
                    if s == 0: new[o] = (r, c); continue
                    mv = s > 0 if f[1] == 'U' else s < 0
                    if mv: new[o] = (r0 + cc, c0 + rr); hist[o].append('D')
                    else: new[o] = (r, c)
                else:
                    s = rr + cc - (w - 1)
                    if s == 0: new[o] = (r, c); continue
                    mv = s < 0 if f[1] == 'U' else s > 0
                    if mv: new[o] = (r0 + (w - 1 - cc), c0 + (w - 1 - rr)); hist[o].append('A')
                    else: new[o] = (r, c)
        pos = new
    return pos, hist
def answer(n, folds, holes):
    pos, hist = fold_cells(n, folds); out = []
    for o, p in pos.items():
        for h in holes:
            if (h[0], h[1]) == p:
                if len(h) > 2:
                    ori = h[2]
                    for t in reversed(hist[o]): ori = REF[t][ori]
                    out.append([o[0], o[1], ori])
                else: out.append([o[0], o[1]])
    return sorted(out)
def layers(n, folds):
    pos, _ = fold_cells(n, folds)
    from collections import Counter
    return max(Counter(pos.values()).values())
if __name__ == '__main__':
    s = open(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else '../out/kognitivni-baterie/assets/app.html', encoding='utf8').read(); i = s.index('const BANK_GV = ') + 16
    B = json.JSONDecoder().raw_decode(s[i:])[0]
    bad = 0
    for x in B['papir']:
        a = sorted(answer(x['n'], x['folds'], x['holes']) + sum((answer(x['n'], x['folds'][:c['po']], c['holes']) for c in x.get('cuts', [])), []))
        if a != sorted(x['answer']): bad += 1; print('NESOUHLASÍ', x['id'], x['folds'], x['holes'], a, sorted(x['answer']))
    print('ověřeno', len(B['papir']), 'položek, nesouhlasí', bad)
