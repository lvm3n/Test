import json, collections, random
from paper import fold_cells, answer
R = json.load(open('cand9.json'))
def comps(cells):
    S = set(map(tuple, cells)); seen = set(); k = 0
    for c in S:
        if c in seen: continue
        k += 1; st = [c]
        while st:
            x = st.pop()
            if x in seen: continue
            seen.add(x); st += [(x[0]+d[0], x[1]+d[1]) for d in ((1,0),(-1,0),(0,1),(0,-1)) if (x[0]+d[0], x[1]+d[1]) in S]
    return k
def sym(cells):
    S = set(map(tuple, cells))
    return {S == {(r, 3-c) for r, c in S}, S == {(3-r, c) for r, c in S}}
good = []
for fs, hs, a, sz in R:
    if not ({f[0] for f in fs} == {'V', 'H'}): continue
    if comps(a) < 2: continue
    if True in sym(a): continue
    good.append((fs, hs, a, sz))
print(len(good))
random.seed(7)
for x in random.sample(good, 40):
    fs, hs, a, sz = x
    g = [['.']*4 for _ in range(4)]
    for r, c in a: g[r][c] = '#'
    print(fs, hs, sz, len(a), ' '.join(''.join(r) for r in g))
