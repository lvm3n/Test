import itertools, collections, json, random
from paper import fold_cells, answer
from gen9 import opts, bbox
N = 4
def dirty(fs):
    """políčka, která někdy ležela na úhlopříčném přehybu (poloviční políčka) -> díra přes ně není jednoznačná"""
    bad = set()
    for i, f in enumerate(fs):
        if f[0] in 'DA':
            pos, _ = fold_cells(N, fs[:i]); r0, r1, c0, c1 = bbox(pos); w = c1 - c0 + 1
            for o, (r, c) in pos.items():
                s = (c - c0) - (r - r0) if f[0] == 'D' else (r - r0) + (c - c0) - (w - 1)
                if s == 0: bad.add(o)
    return bad
def dopts(pos):
    r0, r1, c0, c1 = bbox(pos)
    return ['DU', 'DL', 'AU', 'AL'] if r1 - r0 == c1 - c0 else []
B = []
for f1 in ['DU', 'DL', 'AU', 'AL']:
    pos, _ = fold_cells(N, [f1])
    for f2 in opts(pos):
        fs = [f1, f2]; B.append(fs)
for f1 in opts(fold_cells(N, [])[0]):
    pos, _ = fold_cells(N, [f1])
    for f2 in dopts(pos): B.append([f1, f2])
out = []
for fs in B:
    pos, hist = fold_cells(N, fs); bad = dirty(fs)
    st = collections.defaultdict(list)
    for o, p in pos.items(): st[p].append(o)
    for nh in (1, 2):
        for hs in itertools.combinations(sorted(st), nh):
            if any(o in bad for h in hs for o in st[h]): continue
            for tri in (False, True):
                if tri and nh == 2: continue
                H = [list(h) + ([0] if tri else []) for h in hs]
                best = None
                for ori in (range(4) if tri else [None]):
                    if tri: H = [list(hs[0]) + [ori]]
                    a = answer(N, fs, H)
                    if 4 <= len(a) <= 8: out.append((fs, H, a, [len(st[h]) for h in hs]))
print(len(out))
random.seed(3)
for fs, H, a, sz in random.sample(out, 30):
    g = [['.'] * 4 for _ in range(4)]
    for x in a: g[x[0]][x[1]] = '↖↗↘↙'[x[2]] if len(x) > 2 else '#'
    print(fs, H, sz, len(a), ' '.join(''.join(r) for r in g))
json.dump(out, open('cand9b.json', 'w'))
