<?php
if (!defined('ABSPATH')) { exit; }

add_action('rest_api_init', function () {
    $ns = 'kb/v1';
    register_rest_route($ns, '/session', array('methods' => 'POST', 'callback' => 'kb_rest_session', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/rows', array('methods' => 'POST', 'callback' => 'kb_rest_rows', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/score', array('methods' => 'POST', 'callback' => 'kb_rest_score', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/distribution', array('methods' => 'GET', 'callback' => 'kb_rest_distribution', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/progress', array('methods' => 'GET', 'callback' => 'kb_rest_progress', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/correlations', array('methods' => 'GET', 'callback' => 'kb_rest_correlations', 'permission_callback' => '__return_true'));
});

function kb_now() { return current_time('mysql', true); }
function kb_valid_uuid($s) { return is_string($s) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $s); }
function kb_clean_key($s) { return substr(preg_replace('/[^a-z0-9_\-]/i', '', (string) $s), 0, 40); }
function kb_err($msg, $code = 400) { return new WP_Error('kb_error', $msg, array('status' => $code)); }

/* jednoduché omezení frekvence bez ukládání IP (jen krátkodobý hash v transientu) */
function kb_rate_ok($bucket, $limit, $seconds) {
    $ip  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $key = 'kb_rl_' . $bucket . '_' . substr(hash('sha256', $ip . wp_salt('nonce')), 0, 20);
    $n   = (int) get_transient($key);
    if ($n >= $limit) { return false; }
    set_transient($key, $n + 1, $seconds);
    return true;
}

function kb_session_by_token($sid, $token) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kb_table('sessions') . " WHERE id = %d", $sid));
    if (!$row || !hash_equals($row->token, (string) $token)) { return null; }
    return $row;
}

/* POST /session – založí (nebo najde) účastníka a nové sezení */
function kb_rest_session(WP_REST_Request $r) {
    global $wpdb;
    if (!kb_rate_ok('sess', 30, HOUR_IN_SECONDS)) { return kb_err('Příliš mnoho požadavků.', 429); }
    $p    = $r->get_json_params();
    $mode = (isset($p['mode']) && $p['mode'] === 'admin') ? 'admin' : 'public';
    if ($mode === 'admin' && !current_user_can('edit_posts')) { return kb_err('Nepřihlášený uživatel.', 403); }
    $anon = isset($p['anon_id']) ? $p['anon_id'] : '';
    if (!kb_valid_uuid($anon)) { return kb_err('Neplatný identifikátor.'); }
    if ($mode === 'public' && empty($p['consent']['gdpr'])) { return kb_err('Chybí souhlas se zpracováním údajů.'); }

    $pt  = kb_table('participants');
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM $pt WHERE anon_id = %s", $anon));
    $age = isset($p['age']) ? max(0, min(120, intval($p['age']))) : null;
    $demo = isset($p['demographics']) ? wp_json_encode($p['demographics']) : null;
    $cons = isset($p['consent']) ? wp_json_encode($p['consent']) : null;
    $code = isset($p['code']) ? sanitize_text_field(substr($p['code'], 0, 60)) : '';
    if (!$pid) {
        $wpdb->insert($pt, array('anon_id' => $anon, 'created' => kb_now(), 'mode' => $mode, 'code' => $code,
            'age' => $age, 'demographics' => $demo, 'consent' => $cons));
        $pid = $wpdb->insert_id;
    } else {
        $wpdb->update($pt, array('age' => $age, 'demographics' => $demo, 'consent' => $cons, 'code' => $code), array('id' => $pid));
    }
    $token = wp_generate_password(40, false, false);
    $wpdb->insert(kb_table('sessions'), array(
        'participant_id' => $pid, 'token' => $token, 'started' => kb_now(), 'last_seen' => kb_now(),
        'battery_version' => sanitize_text_field(isset($p['battery_version']) ? $p['battery_version'] : ''),
        'settings' => isset($p['settings']) ? wp_json_encode($p['settings']) : null,
        'device'   => isset($p['device']) ? wp_json_encode($p['device']) : null));
    return array('session_id' => (int) $wpdb->insert_id, 'token' => $token);
}

/* POST /rows – dávka řádků (každá odpověď s časy v ms) */
function kb_rest_rows(WP_REST_Request $r) {
    global $wpdb;
    if (!kb_rate_ok('rows', 3000, HOUR_IN_SECONDS)) { return kb_err('Příliš mnoho požadavků.', 429); }
    $p = $r->get_json_params();
    $s = kb_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kb_err('Neplatné sezení.', 403); }
    $rows = isset($p['rows']) && is_array($p['rows']) ? array_slice($p['rows'], 0, 500) : array();
    $saved = 0;
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $json = wp_json_encode($row);
        if (strlen($json) > 30000) { continue; }
        $seq = isset($row['_seq']) ? intval($row['_seq']) : 0;
        // INSERT IGNORE: opakované odeslání téže dávky nevytvoří duplicitu
        $ok = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO " . kb_table('rows') . " (session_id, test_key, client_seq, created, data) VALUES (%d, %s, %d, %s, %s)",
            $s->id, kb_clean_key(isset($row['test']) ? $row['test'] : ''), $seq, kb_now(), $json));
        if ($ok) { $saved++; }
    }
    $wpdb->update(kb_table('sessions'), array('last_seen' => kb_now()), array('id' => $s->id));
    return array('saved' => $saved);
}

/* POST /score – výsledek jednoho testu (pro rozložení a e-mail) */
function kb_rest_score(WP_REST_Request $r) {
    global $wpdb;
    $p = $r->get_json_params();
    $s = kb_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kb_err('Neplatné sezení.', 403); }
    $pt  = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kb_table('participants') . " WHERE id = %d", $s->participant_id));
    $key = kb_clean_key(isset($p['test_key']) ? $p['test_key'] : '');
    if ($key === '') { return kb_err('Chybí test.'); }
    $raw = (isset($p['raw_score']) && is_numeric($p['raw_score'])) ? floatval($p['raw_score']) : null;
    $ver = sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : '');
    // pojistka proti duplicitám: aplikace posílá výsledek testu v jednom sezení jen jednou; opakované odeslání se ignoruje
    if ($wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('scores') . " WHERE session_id = %d AND test_key = %s AND test_version = %s LIMIT 1", $s->id, $key, $ver))) {
        return array('ok' => true, 'duplicate' => true);
    }
    $wpdb->insert(kb_table('scores'), array(
        'session_id' => $s->id, 'participant_id' => $s->participant_id, 'test_key' => $key,
        'test_version' => sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : ''),
        'raw_score' => $raw, 'valid' => empty($p['valid']) ? 0 : 1, 'age' => $pt ? $pt->age : null,
        'mode' => $pt ? $pt->mode : 'public', 'created' => kb_now(),
        'data' => wp_json_encode(isset($p['score']) ? $p['score'] : null)));
    kb_maybe_notify($s, $pt, $key, $raw);
    return array('ok' => true);
}

/* GET /distribution?test=...&version=...&age_min=&age_max= – jen souhrnné údaje, nikdy data jednotlivců */
function kb_rest_distribution(WP_REST_Request $r) {
    global $wpdb;
    $key = kb_clean_key($r->get_param('test'));
    $ver = sanitize_text_field((string) $r->get_param('version'));
    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));
    $sql = "SELECT sc.raw_score, sc.test_version, sc.data FROM " . kb_table('scores') . " sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL"
         . " AND sc.id = (SELECT MIN(s2.id) FROM " . kb_table('scores') . " s2 WHERE s2.participant_id = sc.participant_id AND s2.test_key = sc.test_key AND s2.valid >= 1 AND s2.raw_score IS NOT NULL)";   // jedna (první) hodnota na osobu; valid 2 = odvozené hodnoty škál
    $args = array($key);
    if ($ver !== '') {                         // jedna verze nebo skupina srovnatelných verzí oddělená „|“
        $vs = array_values(array_filter(array_map('trim', explode('|', $ver)), 'strlen'));
        $vs = array_slice($vs, 0, 20);
        $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')';
        foreach ($vs as $v) { $args[] = $v; }
    }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    $vals = array();
    foreach ($wpdb->get_results($wpdb->prepare($sql, $args)) as $x) {
        $v = floatval($x->raw_score);
        // SRCE: hlavní skór je „správně − chybně“; jen verze v08 ukládala jako hlavní skór počet správně → přepočet
        if ($key === 'srce' && $x->test_version === 'SRCE-v08') {
            $d = json_decode((string) $x->data, true);
            if (is_array($d) && isset($d['spravne_minus_chybne']) && is_numeric($d['spravne_minus_chybne'])) { $v = floatval($d['spravne_minus_chybne']); }
            elseif (is_array($d) && isset($d['spravne_administrovane'], $d['chybne'])) { $v = floatval($d['spravne_administrovane']) - floatval($d['chybne']); }
        }
        $vals[] = $v;
    }
    $vals = array_merge($vals, kb_en_values($key, isset($vs) ? $vs : array(), $amin, $amax));   // + výsledky z anglické verze
    $set  = get_option('kb_settings', array());
    $minn = isset($set['min_n']) ? intval($set['min_n']) : 30;
    $n = count($vals);
    if ($n === 0) { return array('n' => 0, 'min_n' => $minn, 'bins' => array()); }
    // zaokrouhlené hodnoty s četnostmi (dostatečné pro graf, neidentifikují jednotlivce)
    $counts = array();
    foreach ($vals as $v) { $k = (string) round($v, 1); $counts[$k] = isset($counts[$k]) ? $counts[$k] + 1 : 1; }
    ksort($counts, SORT_NUMERIC);
    $bins = array();
    foreach ($counts as $k => $c) { $bins[] = array('x' => floatval($k), 'n' => $c); }
    return array('n' => $n, 'min_n' => $minn, 'bins' => $bins);
}

/* Výsledky z anglického pluginu (Cognitive Battery EN, tabulky wp_kben_*) pro srovnání na české stránce – jen čtení, živě.
   Jen jazykově nezávislé testy se stejnými verzemi; vynechávají se české výsledky importované do EN (mode = cz), aby se
   nikdo nepočítal dvakrát. Jedna (první) hodnota na osobu. */
function kb_en_values($key, $vs, $amin, $amax) {
    global $wpdb;
    if (!in_array($key, array('matice', 'vahy', 'dedukce', 'pravidla', 'stanoviste', 'papir', 'rotace', 'skladani', 'rds', 'zpetna', 'por', 'symboly', 'rady'), true)) { return array(); }
    $T = $wpdb->prefix . 'kben_scores';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $T)) !== $T) { return array(); }
    $sql = "SELECT sc.raw_score FROM $T sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL AND sc.mode <> 'cz'"
         . " AND sc.id = (SELECT MIN(s2.id) FROM $T s2 WHERE s2.participant_id = sc.participant_id AND s2.test_key = sc.test_key AND s2.valid >= 1 AND s2.raw_score IS NOT NULL)";
    $args = array($key);
    if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    return array_map('floatval', $wpdb->get_col($wpdb->prepare($sql, $args)));
}

/* GET /progress?anon_id=... – co už účastník dokončil (pro návrat do baterie) */
function kb_rest_progress(WP_REST_Request $r) {
    global $wpdb;
    $anon = $r->get_param('anon_id');
    if (!kb_valid_uuid($anon)) { return kb_err('Neplatný identifikátor.'); }
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('participants') . " WHERE anon_id = %s", $anon));
    if (!$pid) { return array('tests' => array()); }
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT test_key, test_version, raw_score, valid, created, data FROM " . kb_table('scores') . " WHERE participant_id = %d ORDER BY created ASC", $pid));
    $out = array();
    foreach ($rows as $x) {
        if ($x->raw_score === null && (int) $x->valid === 0) { continue; }   // přerušený test – lze zopakovat
        $d = json_decode((string) $x->data, true);
        $out[$x->test_key] = array('version' => $x->test_version, 'raw_score' => $x->raw_score === null ? null : floatval($x->raw_score),
                                   'valid' => (int) $x->valid, 'date' => $x->created, 'konec' => is_array($d) && isset($d['konec']) ? (string) $d['konec'] : '');
        if (is_array($d) && (isset($d['hruby_pred_upravou']) || isset($d['hruby_puvodni'])) && (isset($d['prepocet_limity']) || isset($d['prepocet']))) {   // přepočet podle časových limitů
            $pred = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : $d['hruby_puvodni'];
            if (is_numeric($pred) && $x->raw_score !== null && floatval($pred) != floatval($x->raw_score)) { $out[$x->test_key]['raw_pred'] = floatval($pred); }
        }
    }
    return array('tests' => $out);
}

function kb_maybe_notify($s, $pt, $key, $raw) {
    $set = get_option('kb_settings', array());
    if (empty($set['notify']) || $set['notify'] === 'none' || empty($set['notify_email'])) { return; }
    $who = $pt ? (($pt->code !== '' ? $pt->code : substr($pt->anon_id, 0, 8)) . ', věk ' . $pt->age . ', ' . $pt->mode) : '?';
    wp_mail($set['notify_email'], 'Kognitivní baterie: dokončen test ' . $key,
        "Účastník: $who\nTest: $key\nHrubý skór: " . ($raw === null ? '-' : $raw) . "\nSezení: " . $s->id . "\n");
}

/* GET /correlations – Pearsonovy korelace mezi testy (poslední platný výsledek každého účastníka); jen souhrn, žádná data jednotlivců */
function kb_correlation_matrix($allow = null, $minOverride = null) {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, p.mode, p.code, p.anon_id FROM " . kb_table('scores') . " sc JOIN " . kb_table('participants') . " p ON p.id = sc.participant_id WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) ORDER BY sc.id ASC");
    $by = array();
    foreach ($rows as $r) {
        // jen testy a verze, které aplikace posílá jako současné (starší verze a zrušené testy se vynechají)
        if (is_array($allow)) {
            if (!isset($allow[$r->test_key]) || !in_array($r->test_version, (array) $allow[$r->test_key], true)) { continue; }
        }
        // osoba = všechna její sezení dohromady (vaše verze podle kódu); u opakovaného testu platí PRVNÍ dokončený výsledek
        $pk = function_exists('kb_person_key') ? kb_person_key($r->mode, $r->code, $r->anon_id) : $r->participant_id;
        if (!isset($by[$pk][$r->test_key])) { $by[$pk][$r->test_key] = floatval($r->raw_score); }
    }
    $set = get_option('kb_settings', array());
    $minn = $minOverride !== null ? intval($minOverride) : (isset($set['min_n']) ? intval($set['min_n']) : 30);
    $count = array();
    foreach ($by as $pid => $t) { foreach ($t as $k => $v) { $count[$k] = isset($count[$k]) ? $count[$k] + 1 : 1; } }
    $keys = array();
    foreach ($count as $k => $c) { if ($c >= $minn) { $keys[] = $k; } }
    sort($keys);
    $R = array(); $N = array();
    foreach ($keys as $i => $a) {
        foreach ($keys as $j => $b) {
            $x = array(); $y = array();
            foreach ($by as $t) { if (isset($t[$a]) && isset($t[$b])) { $x[] = $t[$a]; $y[] = $t[$b]; } }
            $n = count($x); $N[$i][$j] = $n; $R[$i][$j] = null;
            if ($i === $j || $n < $minn) { continue; }
            $mx = array_sum($x) / $n; $my = array_sum($y) / $n; $sxy = 0; $sxx = 0; $syy = 0;
            for ($q = 0; $q < $n; $q++) { $dx = $x[$q] - $mx; $dy = $y[$q] - $my; $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy; }
            $R[$i][$j] = ($sxx > 0 && $syy > 0) ? round($sxy / sqrt($sxx * $syy), 3) : null;
        }
    }
    return array('keys' => $keys, 'r' => $R, 'n' => $N, 'min_n' => $minn);
}
function kb_rest_correlations(WP_REST_Request $r) {
    $allow = null; $raw = $r->get_param('allow');
    if (is_string($raw) && $raw !== '') {
        $dec = json_decode(wp_unslash($raw), true);
        if (is_array($dec)) {
            $allow = array();
            foreach ($dec as $k => $vs) { $k = sanitize_key($k); if ($k === '' || !is_array($vs)) { continue; }
                $allow[$k] = array_slice(array_map('sanitize_text_field', array_map('strval', $vs)), 0, 20); }
        }
    }
    $ck = 'kb_corr_' . md5(wp_json_encode($allow));
    $cached = get_transient($ck);
    if ($cached) { return $cached; }
    $m = kb_correlation_matrix($allow);
    set_transient($ck, $m, 10 * MINUTE_IN_SECONDS);
    return $m;
}
