"""Stanoviště 2 (ST2) – generátor a solver.
Princip: síť stanovišť (4–6), na každém nakonec právě jeden objekt, všechna stanoviště se zaplní.
Část objektů je pevně na místě, zbytek se rozmisťuje. Otázka: kam patří JEDEN cílový objekt.
Slovník pravidel: vedle (adj), není vedle (nadj), na barvě (col), není na barvě (ncol).
Obtížnost = struktura úsudku (hloubka odvození, nutnost úvahy „co kdyby“), ne počet pravidel (max. 4).

Model řešení (lidský, bez enumerace):
  kolo = jedno projití všech pravidel nad současnými možnostmi (synchronně) + „obsazené místo“ + „jediný kandidát
  na stanoviště“ (všechna stanoviště se zaplní). Hloubka = kolo, ve kterém je cíl poprvé jednoznačný.
  Když se odvozování zastaví: úvaha „co kdyby“ = zkusit jednu možnost, odvozovat, při sporu ji vyloučit
  (jen jedna úroveň předpokladu; položky, které by potřebovaly vnořené předpoklady, se vyřazují)."""
import random, itertools, json, sys, collections

LAYOUTS = {
 # 4 stanoviště
 'Y4': ([[50,14],[16,80],[50,80],[84,80]], [(0,1),(0,2),(0,3)]),
 'P4': ([[10,28],[37,72],[63,28],[90,72]], [(0,1),(1,2),(2,3)]),
 'C4': ([[26,24],[74,24],[74,76],[26,76]], [(0,1),(1,2),(2,3),(3,0)]),
 'K4': ([[16,22],[16,78],[52,50],[88,50]], [(0,1),(0,2),(1,2),(2,3)]),
 # 5 stanovišť
 'H5': ([[24,48],[76,48],[76,86],[24,86],[50,12]], [(0,1),(1,2),(2,3),(3,0),(0,4),(1,4)]),
 'P5': ([[8,64],[29,24],[50,64],[71,24],[92,64]], [(0,1),(1,2),(2,3),(3,4)]),
 'T5': ([[50,12],[24,48],[76,48],[10,86],[40,86]], [(0,1),(0,2),(1,3),(1,4)]),
 'C5': ([[50,10],[88,38],[74,86],[26,86],[12,38]], [(0,1),(1,2),(2,3),(3,4),(4,0)]),
 'B5': ([[50,20],[22,62],[78,62],[10,92],[90,92]], [(0,1),(0,2),(1,2),(1,3),(2,4)]),
 # 6 stanovišť
 'HX': ([[50,8],[86,30],[86,72],[50,94],[14,72],[14,30]], [(0,1),(1,2),(2,3),(3,4),(4,5),(5,0),(1,4)]),
 'G6': ([[14,26],[50,26],[86,26],[14,76],[50,76],[86,76]], [(0,1),(1,2),(3,4),(4,5),(0,3),(1,4),(2,5)]),
 'BW': ([[10,22],[10,80],[36,51],[64,51],[90,22],[90,80]], [(0,1),(1,2),(2,0),(2,3),(3,4),(4,5),(5,3)]),
 'HT': ([[24,46],[64,46],[64,86],[24,86],[44,10],[92,66]], [(0,1),(1,2),(2,3),(3,0),(0,4),(1,4),(2,5)]),
 'C6': ([[50,8],[86,30],[86,72],[50,94],[14,72],[14,30]], [(0,1),(1,2),(2,3),(3,4),(4,5),(5,0)]),
 'TR': ([[50,10],[22,46],[78,46],[8,86],[38,86],[78,86]], [(0,1),(0,2),(1,3),(1,4),(2,5)]),
 'KT': ([[30,30],[70,30],[70,70],[30,70],[6,8],[94,92]], [(0,1),(1,2),(2,3),(3,0),(0,4),(2,5)]),
 'LD': ([[10,30],[38,14],[66,30],[94,14],[38,70],[66,86]], [(0,1),(1,2),(2,3),(1,4),(4,5),(2,5)]),
}
SHAPES = ['hvezda', 'srdce', 'trojuhelnik', 'ctverec', 'mesic', 'kapka']
COLORS = ['orange', 'blue', 'green']

def adjset(edges, n):
    A = {i: set() for i in range(n)}
    for a, b in edges: A[a].add(b); A[b].add(a)
    return A

class Item:
    def __init__(s, layout, colors, fixed, free, rules, target):
        s.layout = layout; s.pos, s.edges = LAYOUTS[layout]; s.n = len(s.pos); s.A = adjset(s.edges, s.n)
        s.colors = colors; s.fixed = fixed; s.free = free; s.rules = rules; s.target = target
        s.empty = [v for v in range(s.n) if v not in fixed.values()]

def sat(it, r, P):
    k = r[0]
    if k == 'col': return it.colors[P[r[1]]] == r[2]
    if k == 'ncol': return it.colors[P[r[1]]] != r[2]
    if k == 'adj': return P[r[2]] in it.A[P[r[1]]]
    if k == 'nadj': return P[r[2]] not in it.A[P[r[1]]]

def all_solutions(it, rules=None):
    rules = it.rules if rules is None else rules
    out = []
    for perm in itertools.permutations(it.empty):
        P = dict(it.fixed); P.update(zip(it.free, perm))
        if all(sat(it, r, P) for r in rules): out.append(P)
    return out

def target_cells(it, rules=None):
    return sorted({P[it.target] for P in all_solutions(it, rules)})

# ---------- lidský model ----------
def one_round(it, D):
    """jedno kolo; vrací (nové domény, použité techniky)"""
    N = {t: set(v) for t, v in D.items()}; used = set()
    for r in it.rules:
        k = r[0]
        if k in ('col', 'ncol'):
            t = r[1]; keep = {x for x in D[t] if (it.colors[x] == r[2]) == (k == 'col')}
            if keep != D[t]: used.add('barva'); N[t] &= keep
        else:
            a, b = r[1], r[2]
            ok = (lambda x, y: y in it.A[x]) if k == 'adj' else (lambda x, y: y not in it.A[x])
            for u, w, fl in ((a, b, False), (b, a, True)):
                keep = {x for x in D[u] if any(x != y and (ok(y, x) if fl else ok(x, y)) for y in D[w])}
                if keep != D[u]:
                    used.add(('vedle' if k == 'adj' else 'nevedle') + ('_pevny' if len(D[w]) == 1 else '_nejisty'))
                    N[u] &= keep
    for t in it.free:                                   # obsazené místo
        for u in D:
            if u != t and len(D[u]) == 1 and D[u] <= N[t] and len(N[t]) > 1:
                N[t] -= D[u]; used.add('obsazeno')
    for v in it.empty:                                  # jediný kandidát na stanoviště (všechna se zaplní)
        c = [t for t in it.free if v in D[t]]
        if len(c) == 1 and len(N[c[0]]) > 1 and v in N[c[0]]:
            N[c[0]] = {v}; used.add('jediny_kandidat')
    return N, used

def init_domains(it):
    D = {t: set(it.empty) for t in it.free}; D.update({t: {v} for t, v in it.fixed.items()})
    return D

def propagate(it, D, maxr=30):
    """odvozuje do ustálení; vrací (domény, kolo určení cíle nebo None, techniky, spor)"""
    used = set(); hit = None
    if len(D[it.target]) == 1: hit = 0
    for r in range(1, maxr + 1):
        N, u = one_round(it, D); used |= u
        if any(len(v) == 0 for v in N.values()): return N, hit, used, True
        if hit is None and len(N[it.target]) == 1: hit = r
        if N == D: return N, hit, used, False
        D = N
    return D, hit, used, False

def human_solve(it):
    D, hit, used, bad = propagate(it, init_domains(it))
    assert not bad
    if hit is not None: return {'depth': hit, 'refutations': 0, 'refutation_depth': 0, 'techniques': sorted(used)}
    # úvaha „co kdyby“: opakovaně najdi předpoklad, který vede ke sporu (nejkratší spor), vylouč ho, odvozuj dál
    refs = 0; rdepth = 0
    for _ in range(8):
        best = None
        for t in it.free:
            if len(D[t]) < 2: continue
            for v in sorted(D[t]):
                H = {k: set(x) for k, x in D.items()}; H[t] = {v}
                # hloubka sporu = počet kol do prázdné domény
                Dh = H; dd = None
                for r in range(1, 20):
                    Nh, _ = one_round(it, Dh)
                    if any(len(x) == 0 for x in Nh.values()): dd = r; break
                    if Nh == Dh: break
                    Dh = Nh
                if dd is not None and (best is None or dd < best[0] or (dd == best[0] and t == it.target)): best = (dd, t, v)
        if best is None: return None                    # potřeba vnořených předpokladů → vyřadit
        dd, t, v = best; refs += 1; rdepth = max(rdepth, dd)
        D[t] = D[t] - {v}
        D, hit, u, bad = propagate(it, D); used |= u
        if bad: return None
        if len(D[it.target]) == 1:
            return {'depth': None, 'refutations': refs, 'refutation_depth': rdepth, 'techniques': sorted(used | {'co_kdyby'})}
    return None

def near_miss(it):
    """pro každé chybné stanoviště: nejmenší počet porušených pravidel při libovolném doplnění"""
    out = {}
    for v in it.empty:
        best = 99; which = None
        for perm in itertools.permutations(it.empty):
            P = dict(it.fixed); P.update(zip(it.free, perm))
            if P[it.target] != v: continue
            viol = [i for i, r in enumerate(it.rules) if not sat(it, r, P)]
            if len(viol) < best: best = len(viol); which = viol
        out[v] = (best, which)
    return out

def level_of(h):
    if h['depth'] is not None:
        d = h['depth']
        return {1: 1, 2: 2, 3: 3}.get(d, 4)
    return 5 if h['refutations'] == 1 and h['refutation_depth'] <= 2 else 6

def random_item(rng, layout, n_fixed, n_rules, kinds_w):
    pos, edges = LAYOUTS[layout]; n = len(pos)
    toks = rng.sample(SHAPES, n)
    while True:
        colors = [rng.choice(COLORS) for _ in range(n)]
        if len(set(colors)) >= 2: break
    P = dict(zip(toks, rng.sample(range(n), n)))
    fixedt = rng.sample(toks, n_fixed); fixed = {t: P[t] for t in fixedt}; free = [t for t in toks if t not in fixed]
    target = rng.choice(free)
    A = adjset(edges, n); rules = []; tries = 0
    while len(rules) < n_rules and tries < 60:
        tries += 1
        k = rng.choices(['adj', 'nadj', 'col', 'ncol'], kinds_w)[0]
        if k in ('col', 'ncol'):
            t = rng.choice(free); c = colors[P[t]] if k == 'col' else rng.choice([c for c in COLORS if c != colors[P[t]]])
            r = (k, t, c)
        else:
            a, b = rng.sample(toks, 2)
            if a in fixed and b in fixed: continue
            if (P[b] in A[P[a]]) != (k == 'adj'): continue
            r = (k, a, b)
        if r in rules or any(set(x[1:3]) == set(r[1:3]) and x[0][-3:] == r[0][-3:] for x in rules): continue
        rules.append(r)
    if len(rules) < n_rules: return None
    it = Item(layout, colors, fixed, free, rules, target); it.solution = P
    return it

def evaluate(it):
    cells = target_cells(it)
    if len(cells) != 1: return None
    for i in range(len(it.rules)):                      # každé pravidlo nutné
        if len(target_cells(it, it.rules[:i] + it.rules[i + 1:])) == 1: return None
    h = human_solve(it)
    if h is None: return None
    nm = near_miss(it)
    wrong = [v for v in it.empty if v != cells[0]]
    nm_count = sum(1 for v in wrong if nm[v][0] == 1)
    return {'answer': cells[0], 'human': h, 'level': level_of(h), 'near_miss': nm_count, 'n_wrong': len(wrong),
            'nm_detail': {v: nm[v] for v in wrong}, 'n_solutions': len(all_solutions(it))}

PLAN = [  # (úroveň, počet, rozvržení, pevných, pravidel)
    (1, 4, ['Y4', 'P4', 'C4', 'K4'], 2, [1]),
    (2, 6, ['H5', 'P5', 'T5', 'C5', 'B5'], 2, [2]),
    (3, 6, ['HX', 'G6', 'BW', 'HT', 'TR', 'KT', 'LD', 'C6'], 2, [3]),
    (4, 6, ['HX', 'G6', 'BW', 'HT', 'TR', 'KT', 'LD', 'C6'], 2, [3, 4]),
    (5, 7, ['HX', 'G6', 'BW', 'HT', 'TR', 'KT', 'LD', 'C6'], 2, [3, 4]),
    (6, 7, ['HX', 'G6', 'BW', 'HT', 'TR', 'KT', 'LD', 'C6'], 2, [3, 4]),
]

def to_json(it, ev, iid):
    return {'id': iid, 'level': ev['level'], 'layout': it.layout, 'n': it.n, 'pos': it.pos, 'edges': [list(e) for e in it.edges],
            'colors': it.colors, 'fixed': it.fixed, 'free': it.free, 'target': it.target,
            'rules': [list(r) for r in it.rules], 'answer': ev['answer'],
            'metriky': {'hloubka': ev['human']['depth'], 'co_kdyby': ev['human']['refutations'], 'hloubka_sporu': ev['human']['refutation_depth'],
                        'techniky': ev['human']['techniques'], 'pravidel': len(it.rules), 'near_miss': ev['near_miss'], 'chybnych_moznosti': ev['n_wrong'],
                        'reseni_celkem': ev['n_solutions']},
            **({'solution': {t: v for t, v in it.solution.items() if t in it.free}} if ev['n_solutions'] == 1 else {})}

def canon(it):
    return (it.layout, tuple(sorted((r[0], r[1] == it.target, r[2] == it.target if r[0] in ('adj', 'nadj') else 0) for r in it.rules)))

def build(seed=7):
    rng = random.Random(seed); items = []; seen = set()
    for lvl, cnt, lays, nf, nrs in PLAN:
        got = []; used_lay = collections.Counter(); tries = 0
        while len(got) < cnt and tries < 400000:
            tries += 1
            lay = min(lays, key=lambda l: (used_lay[l], rng.random()))
            nr = rng.choice(nrs); w = [3, 2, 2, 1]
            it = random_item(rng, lay, nf, nr, w)
            if not it: continue
            ev = evaluate(it)
            if not ev or ev['level'] != lvl: continue
            if ev['near_miss'] < ev['n_wrong'] - (0 if lvl <= 2 else 1): continue   # chybné možnosti = „skoro správně“
            if lvl >= 3 and ev['n_solutions'] > 1 and lvl < 5: continue             # do úrovně 4 jednoznačné celé rozmístění
            c = canon(it)
            if c in seen: continue
            kinds = collections.Counter(r[0] for r in it.rules)
            if lvl >= 3 and max(kinds.values()) > 2: continue                     # pestrost pravidel
            seen.add(c); used_lay[lay] += 1; got.append((it, ev))
        if len(got) < cnt: print('úroveň', lvl, 'jen', len(got), file=sys.stderr)
        items += got
    return items

def practice(seed=3):
    rng = random.Random(seed); out = []
    fx = lambda it: all(r[0] in ('col', 'ncol') or r[1] in it.fixed or r[2] in it.fixed for r in it.rules)
    specs = [  # N1 barva; N2 vedle + není vedle vůči pevným objektům; N3 cíl bez vlastního pravidla (zbude na něj místo)
        (['C4', 'Y4'], 2, 1, [0, 0, 1, 0], lambda it, ev: ev['level'] == 1),
        (['P5', 'H5', 'C5'], 2, 2, [1, 1, 0, 0], lambda it, ev: ev['level'] == 1 and set(ev['_k']) == {'adj', 'nadj'} and fx(it) and all(it.target in r for r in it.rules)),
        (['T5', 'C5', 'P5'], 2, 2, [2, 0, 2, 0], lambda it, ev: ev['level'] == 2 and fx(it) and all(it.target not in r for r in it.rules)),
    ]
    for i, (lays, nf, nr, w, ok) in enumerate(specs):
        for _ in range(200000):
            it = random_item(rng, rng.choice(lays), nf, nr, w)
            if not it: continue
            ev = evaluate(it)
            if not ev: continue
            ev['_k'] = [r[0] for r in it.rules]
            if (i == 2 and ev['n_solutions'] != 1) or ev['near_miss'] < ev['n_wrong'] or not ok(it, ev): continue
            out.append(to_json(it, ev, 'N%d' % (i + 1))); break
    return out

if __name__ == '__main__':
    items = build()
    bank = {'verze': 'ST2-36-v1.0', 'caps': {1: 45, 2: 45, 3: 45, 4: 60, 5: 60, 6: 60}, 'practice': practice(), 'items': [to_json(it, ev, 'S%02d' % (k + 1)) for k, (it, ev) in enumerate(items)]}
    json.dump(bank, open('bank_st2.json', 'w'), ensure_ascii=False, separators=(',', ':'))
    for x in bank['practice'] + bank['items']:
        m = x['metriky']
        print(x['id'], 'L%d' % x['level'], x['layout'], 'pravidel', m['pravidel'], 'hl', m['hloubka'], 'ck', m['co_kdyby'], m['hloubka_sporu'], 'nm %d/%d' % (m['near_miss'], m['chybnych_moznosti']), 'řeš', m['reseni_celkem'], ' '.join(m['techniky']), [r[0] for r in x['rules']])
