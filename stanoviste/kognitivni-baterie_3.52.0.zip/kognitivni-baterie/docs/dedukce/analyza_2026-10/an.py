import csv, io, re, collections, statistics as st, json
U='/root/.claude/uploads/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/'
def load(f, lab):
    R=list(csv.DictReader(io.StringIO(open(U+f,encoding='utf-8-sig').read()),delimiter=';'))
    out=[]
    for r in R:
        if r.get('test')!='dedukce' or r.get('forma') not in ('DED-24-v1.2','DED-24-v2.0') or r.get('faze') not in ('test','sonda'): continue
        fc=r.get('facety','')
        m=re.search(r'tier=(\d+)',fc); tl=re.search(r'time_limit_ms=(\d+)',fc)
        out.append(dict(src=lab, v=r['forma'], faze=r['faze'], id=r['id'], tier=int(m.group(1)) if m else None, ok=int(r['spravne'] or 0),
            rt=float(r['rt_ms'] or 0)/1000, lim=int(tl.group(1))/1000 if tl else None, to=('timeout' in (r.get('chyby') or '')) or r.get('timeout')=='1', who=r['anon_id']+'|'+r['sezeni'], age=r.get('age'), mode=r.get('mode')))
    return out
D=load('46c379cc-kb_rows_20261002_192427.csv','CZ')+load('f92f1e9e-kben_rows_20261002_192417.csv','EN')
json.dump(D,open('ded.json','w'))
for src in ('CZ','EN'):
    X=[d for d in D if d['src']==src]
    print(src,'odpovědí',len(X),'osob',len({d['who'] for d in X}), collections.Counter((d['v']) for d in X), 'modes',collections.Counter(d['mode'] for d in X), 'věk', sorted(collections.Counter(d['age'] for d in X).items())[:20])
    print(' limity podle verze/úrovně', sorted(collections.Counter((d['v'],d['tier'],d['lim']) for d in X).items()))
