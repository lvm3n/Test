1.90.0 (2026-11-15)
– Tug of War 2.0 (PV-49-v1, klíče pretah2 a pretah2b) v sekci úplně nahoře „New Tug of War“; vývojová sada PF-24 (ptvyvoj, ptvyvoj2) už v menu není, výsledky zůstávají ve Výsledcích. Odkazy ?test=new-test a ?test=develop vedou na Tug of War 2.0. Stejné jako česká 4.31.0.
– Nový test Arcs (klíč oblouky, OB-17-v1) v sekci Spatial ability, zatím mimo souhrn Gv a g. Stejné jako česká 4.31.0.

1.89.5 (2026-11-15)
– Doba v menu: současná verze testu stačí sama už od 5 dokončených běhů (dřív 10). U anglických Stanovišť měla ST-v7.3-25 jen 6 běhů, takže se přibírala ST-v7.2-35 (35 úloh, medián čistého času asi 26 min) a vycházelo 27 min.

1.89.4 (2026-11-15)
– Doba v menu = čistý čas: u úlohových testů a škál součet časů řešení úloh (rt_ms) včetně nácviku, bez instrukcí; každá úloha nejvýš 3 min (na pozadí se časovač úlohy zastaví). U rychlostních, paměťových a reakčních testů součet mezer mezi záznamy (každá nejvýš 3 min), protože jejich rt_ms nezahrnuje pevnou délku ani předvádění podnětů.

1.89.3 (2026-11-15)
– Doba v menu = aktivní čas: součet mezer mezi po sobě jdoucími záznamy testu od první odpovědi po uložení výsledku, každá mezera nejvýš 3 minuty. Dřív se brala celá doba od první odpovědi, takže se do ní počítaly i pauzy (u Stanovišť vycházelo 27 min, samotné řešení aktuální verze má medián asi 15 min).

1.89.2 (2026-11-15)
– Doba v menu: nepočítají se běhy, kde test nezačal od začátku – převzaté odpovědi z dřívější verze (doplnění jen nových úloh), rozšíření o nové úlohy, navázání na rozpracovaný test, opakování a nový pokus. U Matic tím vycházela doba asi 4 minuty, protože většina lidí s novou verzí jen doplňovala nové úlohy.

1.89.1 (2026-11-15)
– Doba v menu z nejpodobnější verze testu: současná verze, má-li aspoň 10 výsledků; jinak se přibírají verze téže srovnávací skupiny od nejnovější, dokud není aspoň 15 výsledků (staré delší verze se tak nepočítají). Dřív se braly všechny verze skupiny a server jich přijal jen prvních 20 (u Matic tím vypadla současná verze).
– g: náboje z pilotní analýzy (6. 11. 2026); živý odhad z korelací jen u testů, které v ní nejsou (Přetahovaná), a jen v rozmezí 0,10–0,95 (u Stanovišť vycházel náboj > 1).

1.89.0 (2026-11-15)
– Menu: u každého testu se ukazuje medián doby vyplnění a reliabilita, v anglické verzi i předběžný náboj g; u oblastí se souhrnem kompozitní reliabilita souhrnu (Mosier). Pod nadpisem menu je krátké vysvětlení.
– Doba: nový bod REST /teststats (includes/teststats.php, cache 6 h) – medián (a kvartily) času od první zaznamenané odpovědi testu (včetně nácviku) do uložení výsledku; jen platné výsledky současné skupiny verzí, bez screeningu a bez sezení, kde osoba dělala týž test víckrát; 20 s až 3 h; ukazuje se od 15 výsledků.
– Reliabilita: u úlohových testů s IRT empirická marginální reliabilita EAP théty var(θ)/(var(θ) + průměr SE²) z uložených výsledků (nejnovější verze IRT parametrů s aspoň 50 výsledky); jinak pevné hodnoty z pilotní analýzy (split-half, PCM).
– g: první faktor (hlavní osy, iterované komunality) z korelační matice /correlations; testy, kterým chybí některý pár s dostatečným N, se vyřadí; reakční časy se otáčejí.
– Souhrn oblasti: 1 − Σ(1 − r_ii) / (k + 2 Σ r_ij) pro testy, ze kterých se souhrn počítá.

1.88.0 (2026-11-15)
– Věk od 3 let (dřív od 6) ve veřejném formuláři i v administraci.
– Do 18 let se ve veřejném formuláři ptáme na datum narození (povinné). Prohlížeč z něj spočítá přesný věk k datu testování; na server jde jen věk: demografie vek_presny (roky;měsíce;dny) a vek_mesice (měsíce celkem). Samotné datum zůstává jen v prohlížeči účastníka, aby se věk při další návštěvě přepočítal. Věk v letech musí s datem souhlasit (kontrola překlepu). V administraci je datum narození nepovinné.
– Vzdělání: nové možnosti „zatím nechodím do školky ani do školy“ (predskolni) a „mateřská škola“ (ms). U „studuji ZŠ“ se nabídne třída 1–9 (demografie trida).
– Start podle věku: děti 3–5 let začínají jako 6–8leté (od první položky).

1.87.0 (2026-11-15)
– Menu: Stanoviště jsou zpět v sekci Gf (Řešení nových problémů). Do souhrnu Gf se zatím nepočítají – souhrn je dál z Matic, Vah a Hledání pravidla. Verze testu ani data se nemění.
– V sekci Gf jsou všechny testy vidět rovnou, bez tlačítka „Další testy“.
– Rychlé řešení problémů (krátký test) přesunuto do Doplňkových testů. Test, verze ani data se nemění.

1.86.0 (2026-11-15)
– Zkušenost s testy: v úvodním formuláři nová nepovinná sekce – země, kde člověk žije (roletka, kód ISO, názvy zemí podle jazyka prohlížeče, USA, Velká Británie, Indie, Kanada a Austrálie nahoře), kolikrát za poslední 2 roky dělal IQ test nebo úlohy typu matic (0 / 1–2 / 3–5 / 6–10 / víc), cílená příprava na podobné úlohy za poslední 2 roky (přijímačky, Mensa, výběrová řízení, trénink mozku; zk_v = 2 – verze otázky s časovým rámcem) a vyšetření psychologem v posledním roce. Kdo už profil má, uvidí stejné otázky jako zvýrazněnou kartu nad testy v menu („Teď ne“ ji skryje do zavření karty prohlížeče). Ukládá se do demografie (zeme, testy_2r, priprava, vysetreni_rok) přes nový bod REST /profile (jen tyto klíče, bez nového sezení). Krátký formulář odkazu na jeden test se nemění.
– Po dokončení testu (veřejný režim) dvě krátké otázky: „Snažil(a) jste se test udělat co nejlépe?“ (ano / spíš ano / ne – výsledek nepoužívejte) a „Dělal(a) jste tento test (nebo jeho úlohy) už dříve – u nás nebo jinde?“ (ano / ne / nevím; neptá se, když baterie sama nabídla opakování testu). Neptá se po doplňování nových položek, u stropového testu, u vývojových sad Přetahované (ptvyvoj, ptvyvoj2) a u dotazníků. Jde přeskočit. Odpověď je řádek odpovědí faze po_testu (snaha, drive, preskoceno) u daného testu.
– Kdo po testu uvedl, že se nesnažil, nebo že test už dělal, nejde u tohoto testu do norem (théta i hrubé skóry) ani do korelací (norm-filter.php 1.2, kód sam; screening výsledků).
– Čištění théty pro normy (nový soubor includes/norm-filter.php, stejná kopie je v české baterii 4.27.0 a v Přehledu baterie 1.9.0). Do srovnávacího souboru théty nejde člověk, u kterého platí aspoň jedno z pravidel:
  · nedokončený – nemá uložený výsledek a test neskončil přirozeně (ani 3 chyby za sebou, ani konec testu, ani sondy): otevřel, zkusil část úloh a odešel;
  · rychlé hádání – aspoň 3 odpovědi rychlejší než 10 % mediánu času úlohy (1–10 s), úsilí RTE pod 90 % a rychlé odpovědi většinou chybně (rychle a správně se nepočítá);
  · samé T – aspoň čtvrtina úloh skončila vypršením času bez jakékoli akce;
  · misfit – lz pod −3 (od 10 úloh; např. chyby v lehkých a správně v těžkých úlohách);
  · pravděpodobné opakování – dřívější člověk ve stejné verzi baterie se stejným věkem, pohlavím a vzděláním (do 14 dní), na úlohách vyřešených oběma aspoň 2,5× rychleji a ne horší théta; vyřazuje se pozdější pokus (typicky druhé vyplnění v anonymním okně).
  Vlastní výsledek člověka se nemění, jen se nepočítá do norem. Prahy jsou v kbnf_defaults() v includes/norm-filter.php (při změně upravit všechny tři kopie).
1.85.0 (2026-11-14)
– Matice M12-K35-v3: vyřazeno 5 pokusných úloh, které podle analýzy 14. 11. 2026 (N = 601, společná 2PL kalibrace CZ + EN) nefungovaly: V12-221 a V12-225 (velmi snadné, korelace se zbytkem testu 0,10 a 0,06), V12-222 (nejednoznačné pravidlo, korelace 0,06), V12-223 (slabá diskriminace, a 0,93) a V12-224 (všichni správně). Data z nich zůstávají.
– Pokusné V12-226, V12-227 (dobře rozlišují, a 2,8 a 2,3) a V12-228 zůstávají jako pilotní, dokud nebudou česká data; jejich okna jsou posunutá podle změřené obtížnosti (228 mezi V12-20 a V12-06, 227 mezi V12-31_r a V12-22_r, 226 mezi V12-27 a V12-34_r2).
– Nové pokusné úlohy V12-231 až V12-235 (pět nových scén, každá s vlastním principem; cíl b 0,2–1,0, tedy pásmo mezi V12-11_r a V12-97, které je zatím prázdné): 231 balónky (velikosti se seřadí, barvy zůstanou na místě), 232 šipky (modré se obrátí, žluté otočí o čtvrt otáčky), 233 dva tvary si vymění barvu a velikost, 234 zrcadlení vlaječek z šedé poloviny, 235 šipky převezmou barvu té, na kterou ukazují. Jednoznačnost ověřená strojově proti konkurenčním pravidlům (generátor, banka a náhled v docs/matice_v12/piloty_2026-11-14/).
– Každá pokusná úloha jde na náhodné místo (stálé pro osobu) ve svém okně; okna se nepřekrývají, takže dvě pokusné úlohy nikdy nejdou hned po sobě. Do skóre, ukončení ani théty se nepočítají.
– Skórovaných 35 úloh je nově seřazeno podle b ze společné 2PL kalibrace 14. 11. 2026 (dřív podle odhadu b z 10. 11.). Skórované položky ani b pro výpočet théty se nemění, M12-K35-v3 je ve stejné skupině srovnání jako K35-v2.
1.84.0 (2026-11-14)
– Přetahovaná PR-29-v1: vyřazeno 10 slabých položek – PR18, PR25, PR29, PR31 (4 panáčci) a PR35, PR37, PR43, PR47, PR49, PR50 (5 panáčků). Podle exportu 14. 11. 2026 skoro nesouvisely se zbytkem testu; na dosavadních datech zkrácení snižuje medián času asi ze 13,4 na 9,7 min, reliabilita théty 0,74 → 0,73, théta zkrácené a plné verze koreluje 0,97.
– Zůstává 26 skórovaných položek + podlaha PR00a–c (lehké položky pro děti a slabší dospělé beze změny), z 5 panáčků zatím PR38, PR45, PR36, PR40, PR42, PR44 jako dočasný strop.
– Pilotní blok PN-11-v3: bez pětifigurkových pilotů PN11, PN12, PN14; každý dostane nejvýš 3 pilotní úlohy (náhodně, stálé pro osobu). Okna pilotů posunutá na zbylé položky. Při doplnění (převzetí z PR-39-v1/v1p) bez omezení.
– Théta se počítá dál se stejnými b, takže výsledky zůstávají srovnatelné: PR-29-v1 je ve stejné skupině srovnání jako PR-39-v1/v1p/v1q a kdo test už udělal, nedostane nabídku opakování.
1.83.0 (2026-11-14)
– Nový test v samostatné sekci úplně nahoře v menu („Nový test ve vývoji“ / „New test in development“): „Pomozte s vývojem nového testu“ (klíč ptvyvoj) a „Vývoj nového testu – 2. část“ (ptvyvoj2). Pilotní sada PF-24-v1: 24 nových úloh Přetahované se 4 panáčky podle plánu odvozené dvojice (1–3) × hloubka (2/3) × lákadlo (ne/ano) × počet zápasů (3/4), na obrazovce 9–11 panáčků; rozdělené na dvě vyvážené poloviny A/B po 12.
– 1. část: kotvy PR16, PR17, PR32 (kdo už dělal Přetahovanou, kotvy nedostane) + jedna polovina (losuje se podle osoby a zůstává stálá); PR16 první, ostatní v náhodném pořadí pro osobu. 2. část se v menu objeví až po 1. části: druhá polovina, bez kotev a bez zácviku.
– Limit 45 s, bez ukončení po chybách a bez sond, průběh testu je vidět. Výsledek = počet správně vyřešených nových úloh, bez srovnání s ostatními; do souhrnů se nepočítá.
– Řádky navíc: vyvoj_role (kotva/nova), vyvoj_cast (A/B), navrh, b_odhad. Ve výsledku vyvoj_cast, varianta, hruby_kotvy, kotev, polozky, poradi. Přímý odkaz ?test=new-test. V administraci jsou oba klíče v sekci Gf (export po testech).
1.82.0 (2026-11-13)
– Přetahovaná PR-39-v1q: pilotní úlohy už nejsou v bloku na konci, ale přimíchané do hlavní části. Každá jde na náhodné místo (stálé pro osobu) ve svém okně podle odhadu b; těžké piloty (odhad b nad 1,2) nejvýš do okna b 0,6–1,8, aby se k nim dostalo víc lidí. Okna: PN01 PR23–PR37; PN02 PR34–PR40; PN03 PR18–PR26; PN04 PR34–PR40; PN05 PR23–PR37; PN08 PR19–PR38; PN09 PR29–PR45; PN11 PR35–PR40; PN12 PR35–PR40; PN14 PR35–PR40; PN3_01 PR28–PR26; PN3_02 PR28–PR25; PN3_03 PR18–PR26; PN3_04 PR18–PR26. Pilotní úlohy se nepočítají do skóre, ukončení ani sond – série chyb se jimi nepřeruší ani neprodlouží; kdo test ukončí dřív, k pozdějším pilotům se nedostane.
– Přibyly 4 těžší úlohy se 3 figurkami PN3_01–PN3_04 (obě rovnice/nerovnosti je nutné zkombinovat; odhad b −0,8 až −0,3 jen podle analogie, model kalibrovaný na 3figurkových úlohách bez kombinování to neumí odhadnout). Pilotní sada PN-14-v2 = PN01–PN05, PN08, PN09, PN11, PN12, PN14, PN3_01–PN3_04.
– Řádky pilotů: pilot 1, neskorovano 1, pilotni_blok, b_odhad, pilot_okno; skutečná pozice v poradi. Ve výsledku pilot_zadano, pilot_spravne, pilot_ids (pilot_poradi a obrazovka „Ještě pár úloh navíc“ zrušeny).
– Doplnění: kdo dělal PR-39-v1 nebo PR-39-v1p (a vyřešil aspoň jednu úlohu s b ≥ −1), doplní jen pilotní úlohy, které ještě neřešil (po v1p tedy jen PN3_01–04), od lehčích, konec po 4 chybách v řadě. PR-39-v1, v1p a v1q jsou jedna skupina srovnání. Kódovník má řádky PR-39-v1q, banka v docs/pretahovana/pretahovana_PR-39-v1q.json.

1.81.0 (2026-11-13)
– Přetahovaná PR-39-v1p: po hlavní části přibyl neskórovaný pilotní blok PN-10-v1 (10 nových úloh: PN03, PN08, PN05, PN01, PN09, PN02 – odhad b −0,2 až 1,2; PN04, PN11, PN12, PN14 – odhad b 2,0 až 3,2). Dává se po skončení hlavní části (po konci banky i po ukončení a sondách): nejdřív 6 středních, pak 4 těžké, uvnitř v náhodném pořadí stálém pro osobu; blok končí po 4 chybách v řadě. Blok dostane jen ten, kdo v hlavní části vyřešil aspoň jednu úlohu s b ≥ −1 (PT_PILOT_MIN_B; u slabších by šlo jen o hádání). Před blokem krátká obrazovka „Ještě pár úloh navíc“. Limity 45 s, u 5 figurek 60 s. PN06, PN07 a PN13 vynechány (pásmo už pokryté, PN13 bez kombinování zápasů).
– Pilotní úlohy nevstupují do hrubého skóru, ukončení, sond ani théty (nemají b). Řádky: faze test, pilot 1, neskorovano 1, blok pilot, pilotni_blok, poradi_pilot, b_odhad; v širokém exportu jsou jako sloupce PN01…PN14. Ve výsledku přibylo pilotni_blok, pilot_zadano, pilot_spravne, pilot_poradi, pilot_konec.
– Kdo už udělal PR-39-v1 (celý nebo ukončený po chybách) a vyřešil v něm aspoň jednu úlohu s b ≥ −1, dostane v menu nabídku „Přidali jsme 10 nových úloh“ a doplní jen pilotní blok; dřívější odpovědi se převezmou (hrubý skór se převezme z dřívějšího výsledku včetně připsané podlahy, tedy beze změny). PR-39-v1 a PR-39-v1p jsou jedna skupina srovnání.
– Přepočet limitu (kb_recode_pt_limit) pilotní řádky do běhů nepočítá. Kódovník má řádky PR-39-v1p, banka je v docs/pretahovana/pretahovana_PR-39-v1p.json.

1.80.0 (2026-11-13)
– Screening norem: výsledky, kde člověk test pustil a nechal běžet, se nepočítají do srovnání (théta i hrubé skóry), do korelací ani do souhrnů z nich. Stejná pravidla jako Přehled baterie 1.8.0; posuzuje se poslední běh testu v sezení:
  · jen otevřený – dosavadní pravidlo (beze změny);
  · konec bez akce – běh končí aspoň 3 úlohami za sebou bez jakékoli akce (vypršel čas, nic neoznačeno);
  · Gs nečinnost – v Prohozených barvách, Shodných řadách a Symbolech nejdelší úsek bez odpovědi aspoň 20 s (i zbytek limitu po poslední odpovědi);
  · Rychlý test – jedna úloha aspoň 180 s.
  Théta: úlohy z konce běhu bez akce (a sondy bez akce) se berou jako nezadané, ne jako chyby; vyřazený výsledek se nepočítá jako uložený, takže člověk zůstává v normách jen s ≥ 10 úlohami a SE ≤ 0,5. Hrubé skóry: vyřazený výsledek se vynechá a platí další pokus téže osoby, pokud nějaký má.
  Platí pro data všech verzí, se kterými se tady srovnává (EN, CZ, děti, gifted). Gc s psaním a reakční testy (vlastní validita) se neposuzují. Člověku se jeho vlastní výsledek ukazuje dál; nic v databázi se nemění (valid zůstává), screening se počítá při čtení (cache 30 min). Prahy jsou v kben_scr_set() v includes/irt.php.

1.79.0 (2026-11-13)
– Přetahovaná PR-39-v1: na začátek přibyla podlaha PR00a–PR00c (PR00a: dva panáčci, jeden zápas, vítěz vlevo; PR00b: totéž, vítěz vpravo; PR00c: tři panáčci, všechny tři dvojice zápasí přímo). Do 9 let (a při nastavení „Vždy od první položky“) se dávají všechny tři a skórují se. Starší dostanou PR00a jako rozehřátí; při chybě v něm dostanou hned i PR00b–c. Když PR00a vyřeší, jdou rovnou na první úlohu banky. Chyba v 1. nebo 2. úloze banky vrátí na PR00b–c a pak se pokračuje. Obě správně → PR00b–c se připíšou jako správné (pripsane). Ve výsledku přibylo pripsane, navrat, podlaha; v řádcích podlaha, rozehrati. Podlaha nemá b a do théty nevstupuje.
– Přetahovaná má vlastní vzhled, aby nevypadala jako Hledání pravidla: místo geometrických tvarů panáčci (červený s bambulí, modrý s kšiltovkou, zelený s tykadly, fialový s mašlí, oranžový s ježatými vlasy), zápasy na hřišti s pruhovaným lanem a praporkem, vítězný tým zlatě. Klíče figurek v datech (circle, square, triangle, diamond, pentagon) se nemění. Texty instrukcí a ikona v menu upravené.
– Nová verze = nová skupina srovnání (u starších se připisuje podlaha, hrubý skór je o 3 vyšší než u PR-36-v2). Kódovník má řádky PR-39-v1, banka je v docs/pretahovana/pretahovana_PR-39-v1.json.

