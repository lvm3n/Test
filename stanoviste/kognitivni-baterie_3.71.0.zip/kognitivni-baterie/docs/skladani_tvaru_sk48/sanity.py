from gen_brutal import *
import json
T = unit(Polygon(SHAPES['lichob'])); rng = random.Random(5)
r = attempt(T, 3, rng)
while not r: r = attempt(T, 3, rng)
good, D = r
dup = affinity.rotate(good[0], 77, origin='centroid')          # 2. kopie správného dílu => musí vzniknout 2 řešení
print('s duplikátem:', solutions(T, good + [dup] + [d for d, _ in D][:2]))
half = cut(good[1], [((-5, 0.3), (5, 0.9))])                    # díl rozpůlený na dva => řešení i se 4 díly
print('s rozpůleným:', solutions(T, good + half + [d for d, _ in D][:1]))
