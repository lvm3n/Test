"""3.71.0 / 1.32.0 – Skládání tvarů SK36-W3: na konec 5 brutálních položek SKB_1–5 (šikmé řezy, zrcadla, počet dílů 2–4 neuveden)."""
import os, json, shutil, csv, io
os.chdir('/tmp/claude-0/-home-user-Test/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/scratchpad/')
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:100], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
CZ = 'out/kognitivni-baterie/'; EN = 'out/cognitive-battery-en/'
NEW = json.load(open('st15/BANK_SK36.json', encoding='utf8'))
TXT = {CZ: ('Nejdřív se vybírají 2 díly, potom 3.', 'Nejdřív se vybírají 2 díly, potom 3. Na úplném konci se počet dílů neuvádí – může jich být 2 až 4.',
            '"pick3": "Vyber 3 díly, ze kterých se tvar složí:",', '"pick3": "Vyber 3 díly, ze kterých se tvar složí:", "pickFree": "Pozor, počet dílů se teď neuvádí (může jich být 2 až 4). Vyber všechny díly, ze kterých se tvar složí:",'),
       EN: ('First you pick 2 pieces, later 3.', 'First you pick 2 pieces, later 3. At the very end the number of pieces is not given – it can be 2 to 4.',
            '"pick3": "Pick the 3 pieces that make the shape:",', '"pick3": "Pick the 3 pieces that make the shape:", "pickFree": "Careful – the number of pieces is no longer given (it can be 2 to 4). Pick all the pieces that make the shape:",')}
for d in (CZ, EN):
    app = d + 'assets/app.html'; s = open(app, encoding='utf8').read()
    i = s.index('const BANK_SK48 = ') + len('const BANK_SK48 = '); _, e = json.JSONDecoder().raw_decode(s[i:])
    s = s[:i] + json.dumps(NEW, ensure_ascii=False, separators=(',', ':')) + s[i + e:]; open(app, 'w', encoding='utf8').write(s)
    rep(app, "version:'SK31-W2', pickN:3,", "version:'SK36-W3', pickN:3,")
    rep(app, "['SK31-W2']]", "['SK31-W2'], ['SK36-W3']]")
    a, b, c, e2 = TXT[d]; rep(app, a, b); rep(app, c, e2)
    rep(app, "pickText:(it) => it.pick === 2 ? TX.pick2 : TX.pick3,", "pickText:(it) => it.free ? TX.pickFree : it.pick === 2 ? TX.pick2 : TX.pick3,")
    # mod_pick: volný počet (it.free) – Hotovo od 2 vybraných, bez omezení počtu, správně = přesně množina klíče
    rep(app, "    if (cfg.pickText) $('#' + K + '-picklbl').textContent = cfg.pickText(it);",
        "    if (cfg.pickText) $('#' + K + '-picklbl').textContent = cfg.pickText(it);\n    $('#' + K + '-picklbl').style.color = it.free ? '#B3261E' : '';   // volný počet dílů: výrazné upozornění")
    rep(app, "    $('#' + K + '-done').disabled = ST.sel.length !== (it.pick || cfg.pickN) || !!reveal;",
        "    $('#' + K + '-done').disabled = (it.free ? ST.sel.length < 2 : ST.sel.length !== (it.pick || cfg.pickN)) || !!reveal;")
    rep(app, "if (ST.sel.includes(i)) ST.sel = ST.sel.filter(x => x !== i); else { ST.sel.push(i); if (ST.sel.length > (it.pick || cfg.pickN)) ST.sel.shift(); }",
        "if (ST.sel.includes(i)) ST.sel = ST.sel.filter(x => x !== i); else { ST.sel.push(i); if (!it.free && ST.sel.length > (it.pick || cfg.pickN)) ST.sel.shift(); }")
    rep(app, "const hits = ST.sel.filter(i => it.answerIdx.includes(i)).length, ok = (hits === (it.pick || cfg.pickN) && !ST.timedOut) ? 1 : 0;",
        "const need = it.free ? it.answerIdx.length : (it.pick || cfg.pickN), hits = ST.sel.filter(i => it.answerIdx.includes(i)).length,\n      ok = (hits === need && ST.sel.length === need && !ST.timedOut) ? 1 : 0;")
    rep(app, "format:cfg.key + '-' + (it.pick || cfg.pickN) + 'z' + it.options.length,", "format:cfg.key + '-' + (it.free ? 'vse' : (it.pick || cfg.pickN)) + 'z' + it.options.length,")
    rep(app, "spravne:ok, skore:hits, max_skore:(it.pick || cfg.pickN),", "spravne:ok, skore:hits, max_skore:need, navic:ST.sel.length - hits,")
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    head, body = rows[0], [r for r in rows[1:] if r and r[0] != 'skladani']
    for k, it in enumerate(NEW['practice'] + NEW['items']):
        f = it['facety']
        desc = '; '.join(x for x in (f.get('pasmo', ''), f.get('sablona', ''), f.get('ornament', ''), ('švy ' + f['svy']) if f.get('svy') else '',
                                     ('cíl ' + f['cil']) if f.get('cil') else '', ('mřížka %s, spojů %s' % (f['mrizka'], f['spoju'])) if 'mrizka' in f else '',
                                     ('distraktory: ' + f['distraktory']) if f.get('distraktory') else '') if x)
        what = 'vyber všechny díly (2–4, počet neuveden; správně %d) z 6' % len(it['answerIdx']) if it.get('free') else 'vyber %d z 6 dílů' % it['pick']
        body.append(['skladani', 'SK36-W3', k + 1, it['id'], '%s; %s' % (what, desc), ' '.join(str(i + 1) for i in it['answerIdx']),
                     'nácvik' if it['level'] == 0 else 'pořadí %d' % (k - 1), '', '' if it['level'] == 0 else 'limit 45 s'])
    out = io.StringIO(); w = csv.writer(out, delimiter=';', lineterminator='\n'); w.writerow(head); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(out.getvalue())
rep(CZ + 'kognitivni-baterie.php', '3.70.1', '3.71.0', 2); rep(EN + 'cognitive-battery-en.php', '1.31.1', '1.32.0', 2)
rep(CZ + 'assets/app.html', '>verze 3.70.1</div>', '>verze 3.71.0</div>'); rep(EN + 'assets/app.html', '>version 1.31.1 (EN)</div>', '>version 1.32.0 (EN)</div>')
dd = CZ + 'docs/skladani_tvaru_sk48/'
for f in ('gen_brutal.py', 'gen_b2.py', 'sanity.py', 'BANK_SK36.json', 'brutal.html', 'patch_v371.py'): shutil.copy('st15/' + f, dd + f)
open(CZ + 'readme-cz.txt', 'a', encoding='utf8').write('''
ZMĚNY VERZE 3.71.0 – Skládání tvarů SK36-W3: brutální strop pro nadané (SKB_1–5)
Data od nadaných dospělých ukázala, že dosahují 23–27 z 31 – nahoře chyběl prostor. Na konec přidáno 5 položek:
 nekonvexní cíl se šikmými hranami, rozřezaný šikmými řezy na 2–4 nepravidelné díly; POČET DÍLŮ SE NEUVÁDÍ
 („vyber všechny díly“, 2–4) – nelze se opřít o počet, je nutné ověřit úplnost. Distraktory: zrcadla správných
 dílů, díly z jiného rozřezu téhož cíle, zrcadlo sloučení dvou dílů. Správně = přesně množina klíče.
 SKB_1 lichoběžník s výřezem (2 díly), SKB_2 blesk (3), SKB_3 kosník s výřezem (3), SKB_4 šipka (4), SKB_5 loďka (4).
Jednoznačnost: úplný řešič přes všechny podmnožiny 2–4 z 6 (gen_brutal.py; sanity.py ověřuje, že řešič najde
podstrčená druhá řešení). Filtry: úhel ≥ 28°, hrana ≥ 0,15, žádné třísky. Limit 45 s. Nová skupina SK36-W3.
Záznam položky nově obsahuje pole navic (počet vybraných dílů navíc).
''')
open(EN + 'readme-cz.txt', 'a', encoding='utf8').write('''
1.32.0 – Shape Assembly SK36-W3: 5 brutálních stropových položek s neuvedeným počtem dílů (jako česká 3.71.0).
''')
print('ok')
