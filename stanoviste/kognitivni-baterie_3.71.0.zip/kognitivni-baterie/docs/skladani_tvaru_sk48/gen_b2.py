from gen_brutal import *
import json
out = []
for name in ('krystal', 'lichob'):
    T = unit(Polygon(SHAPES[name])); rng = random.Random(hash((name, 2)) & 0xffff)
    for t in range(300):
        r = attempt(T, 2, rng)
        if r: out.append(build('SKB_%s_2' % name, '#455A64', T, r[0], r[1], t, name)); print(name, 'ok po', t + 1, flush=True); break
    else: print(name, 'nenalezeno')
json.dump({'items': out}, open('brutal_k2.json', 'w'), ensure_ascii=False)
