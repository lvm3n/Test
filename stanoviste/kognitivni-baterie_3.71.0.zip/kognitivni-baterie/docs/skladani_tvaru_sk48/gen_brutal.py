"""Brutální stropové položky: nekonvexní cíl se šikmými hranami, šikmé řezy, počet dílů 2–4 NEUVEDEN.
Distraktory: zrcadla správných dílů, díly z jiného rozřezu téhož cíle, zrcadlo sloučení dvou dílů.
Jednoznačnost: úplný řešič (pevné měřítko, otáčení bez zrcadlení, kotvení v nejostřejším rohu) přes VŠECHNY podmnožiny 2–4 z 6."""
import json, math, random, itertools, sys
from shapely.geometry import Polygon, LineString, MultiPolygon, GeometryCollection
from shapely.ops import split, unary_union
from shapely import affinity
from gen_orn import d_of, norm
TOL = 1.5e-3
def verts(g):
    if isinstance(g, MultiPolygon): g = max(g.geoms, key=lambda q: q.area)
    g = g.simplify(0.003); c = list(g.exterior.coords)[:-1]
    if not Polygon(c).exterior.is_ccw: c = c[::-1]
    out = []
    for i in range(len(c)):
        p0, p1, p2 = c[i - 1], c[i], c[(i + 1) % len(c)]
        a1 = math.atan2(p0[1] - p1[1], p0[0] - p1[0]); a2 = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
        out.append((p1, p0, p2, (a1 - a2) % (2 * math.pi)))
    return out
def place(P, u, v, which):
    (pu, pp, pn, _), (rv, rp, rn, _) = u, v
    if which == 0: a_p = math.atan2(pn[1] - pu[1], pn[0] - pu[0]); a_r = math.atan2(rn[1] - rv[1], rn[0] - rv[0])
    else: a_p = math.atan2(pp[1] - pu[1], pp[0] - pu[0]); a_r = math.atan2(rp[1] - rv[1], rp[0] - rv[0])
    g = affinity.rotate(P, a_r - a_p, origin=pu, use_radians=True); return affinity.translate(g, rv[0] - pu[0], rv[1] - pu[1])
def clean(R):
    R = R.buffer(-2e-3, join_style=2).buffer(2e-3, join_style=2)
    if isinstance(R, (MultiPolygon, GeometryCollection)):
        parts = [q for q in getattr(R, 'geoms', []) if q.area > TOL]
        R = MultiPolygon(parts) if len(parts) > 1 else (parts[0] if parts else Polygon())
    return R
def tiles(R, pieces):
    if not pieces: return R.area < 3 * TOL
    V = [v for v in verts(R if not isinstance(R, MultiPolygon) else max(R.geoms, key=lambda q: q.area)) if v[3] < math.pi - 0.05]
    if not V: return False
    v = min(V, key=lambda x: x[3])                       # nejostřejší roh musí vyplnit některý díl svým rohem
    for k, P in enumerate(pieces):
        rest = pieces[:k] + pieces[k + 1:]
        for u in verts(P):
            if u[3] > v[3] + 0.03: continue
            for which in (0, 1):
                g = place(P, u, v, which)
                if g.difference(R).area > TOL: continue
                if tiles(clean(R.difference(g)), rest): return True
    return False
def solutions(T, opts):
    out = []
    for k in (2, 3, 4):
        for sub in itertools.combinations(range(len(opts)), k):
            if abs(sum(opts[i].area for i in sub) - T.area) > 4 * TOL: continue
            if tiles(T, [opts[i] for i in sub]): out.append(sub)
    return out
def mirror(g): return affinity.scale(g, -1, 1, origin='centroid')
def cut(T, lines):
    parts = [T]
    for (a, b) in lines:
        L = LineString([a, b]); nxt = []
        for p in parts:
            r = split(p, L); nxt += [q for q in r.geoms if q.area > 1e-6]
        parts = nxt
    return parts
def sym_self(g):                                         # díl je zrcadlově souměrný (zrcadlo = otočení) => zrcadlo není distraktor
    m = mirror(g)
    for u in verts(m):
        for v in verts(g):
            for w in (0, 1):
                if abs(u[3] - v[3]) < 0.02 and place(m, u, v, w).symmetric_difference(g).area < 0.02 * g.area: return True
    return False
def thin(g):
    if g.geom_type != 'Polygon' or g.buffer(-0.09).is_empty or g.buffer(-0.09).geom_type != 'Polygon': return True
    c = list(g.simplify(0.003).exterior.coords)[:-1]
    if len(c) > 6 or min(math.dist(c[i], c[i - 1]) for i in range(len(c))) < 0.15: return True
    return min(v[3] for v in verts(g)) < math.radians(28)
def congruent(a, b):
    if abs(a.area - b.area) > 0.03 * a.area: return False
    for u in verts(a):
        for v in verts(b):
            for w in (0, 1):
                if abs(u[3] - v[3]) < 0.02 and place(a, u, v, w).symmetric_difference(b).area < 0.06 * a.area: return True
    return False
SHAPES = {
 'sipka':   [(0, 0), (1.6, 0), (2.3, 0.7), (1.6, 1.4), (0, 1.4), (0.5, 0.7)],
 'blesk':   [(0, 0), (1.3, 0), (1.0, 0.65), (1.8, 0.65), (0.5, 1.9), (0.75, 1.0), (0, 1.0)],
 'kosnik':  [(0, 0), (1.6, 0), (2.2, 1.2), (1.3, 1.2), (1.1, 0.7), (0.9, 1.2), (0.6, 1.2)],
 'lichob':  [(0, 0), (2.2, 0), (1.8, 1.2), (1.3, 1.2), (1.0, 0.65), (0.7, 1.2), (0.4, 1.2)],
 'krystal': [(0, 0.5), (0.8, 0), (1.9, 0.3), (2.1, 1.2), (1.4, 1.1), (1.0, 1.7), (0.3, 1.3)],
 'lod':     [(0, 0.5), (2.4, 0.5), (1.9, 1.2), (0.6, 1.2)],
}
def unit(T): s = 1 / math.sqrt(T.area); return affinity.scale(T, s, s, origin=(0, 0))
def rand_line(T, rng):
    b = T.exterior; L = b.length
    for _ in range(200):
        p, q = b.interpolate(rng.uniform(0, L)), b.interpolate(rng.uniform(0, L))
        if p.distance(q) < 0.5: continue
        dx, dy = q.x - p.x, q.y - p.y; a = math.degrees(math.atan2(dy, dx)) % 180
        if min(abs(a - x) for x in (0, 90, 180)) < 12: continue          # šikmé řezy, ne osové
        return ((p.x - dx * 0.05, p.y - dy * 0.05), (q.x + dx * 0.05, q.y + dy * 0.05))
def attempt(T, k, rng):
    good = None
    for _ in range(60):
        P = cut(T, [rand_line(T, rng) for _ in range(k - 1)])
        if len(P) == k and all(p.area > 0.13 for p in P) and not any(thin(p) for p in P) and all(p.geom_type == 'Polygon' for p in P): good = P; break
    if not good: return None
    asym = [p for p in good if not sym_self(p)]
    if len(asym) < 2: return None
    D = []
    rng.shuffle(asym); D += [(mirror(p), 'zrcadlo dílu') for p in asym[:2]]
    if k == 4:
        for a, b in itertools.combinations(good, 2):
            u = unary_union([a, b])
            if u.geom_type == 'Polygon' and a.intersection(b).length > 0.3 and not sym_self(u): D.append((mirror(u), 'zrcadlo dvou spojených dílů')); break
    while len(D) < 6 - k:                                                   # díly z jiného rozřezu téhož cíle
        for _ in range(80):
            Q = cut(T, [rand_line(T, rng) for _ in range(rng.choice([1, 2]))])
            c = [q for q in Q if q.geom_type == 'Polygon' and q.area > 0.13 and not thin(q) and any(abs(q.area - g.area) < 0.35 * g.area for g in good)]
            if c: D.append((rng.choice(c), 'díl z jiného rozřezu')); break
        else: return None
    D = D[:6 - k]
    allp = good + [d for d, _ in D]
    for a, b in itertools.combinations(allp, 2):
        if congruent(a, b): return None
    if solutions(T, allp) != [tuple(range(k))]: return None
    return good, D
def build(iid, fill, T, good, D, seed, shape):
    rng = random.Random(seed); k = len(good)
    tg, w, h = norm(T, 1.0, 0)
    allp = [(g, True, 'cíl') for g in good] + [(d, False, kind) for d, kind in D]
    order = list(range(6)); rng.shuffle(order); opts = []
    for j in order:
        g, ok, kind = allp[j]; og, ow, oh = norm(g, 1.0, rng.uniform(0, 360))
        opts.append({'paths': [{'d': d_of(og), 'fill': fill}], 'w': round(ow, 4), 'h': round(oh, 4), 'correct': ok, 'kind': kind})
    return {'id': iid, 'level': 6, 'pick': 0, 'free': True, 'target': {'paths': [{'d': d_of(tg), 'fill': fill}], 'outline': d_of(tg), 'w': round(w, 4), 'h': round(h, 4)},
            'options': opts, 'answerIdx': [i for i, o in enumerate(opts) if o['correct']],
            'facety': {'pasmo': 'strop (brutální)', 'dilu': k, 'pocet_dilu': 'neuveden (2–4)', 'cil': shape, 'distraktory': ', '.join(kd for _, kd in D), 'reseni': 'jediná podmnožina 2–4 z 6 (řešič)'}}
if __name__ == '__main__':
    out = []; seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    for name, pts in SHAPES.items():
        T = unit(Polygon(pts))
        for k in (3, 4):
            rng = random.Random(hash((name, k, seed)) & 0xffff)
            for t in range(150):
                r = attempt(T, k, rng)
                if r: out.append(build('SKB_%s_%d' % (name, k), '#455A64', T, r[0], r[1], t, name)); print(name, k, 'ok po', t + 1, flush=True); break
            else: print(name, k, 'nenalezeno', flush=True)
    json.dump({'items': out}, open('brutal_cand.json', 'w'), ensure_ascii=False)
