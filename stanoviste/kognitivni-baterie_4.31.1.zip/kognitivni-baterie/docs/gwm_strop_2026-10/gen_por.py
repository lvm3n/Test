import json, random
from collections import Counter
rng = random.Random(1307)
B = json.load(open('/tmp/BANK_POR.json')); A = B['forms']['A']
ICONS = sorted(set(json.load(open('icons.json'))))
tc = Counter(); lc = Counter()
for it in A: tc.update(it['targets']); lc.update(it['lures'])
prev = set(A[-1]['targets']); out = []
for K, F, n in ((13, 5, 36), (14, 4, 37)):
    pool = sorted([x for x in ICONS if x not in prev], key=lambda x: (tc[x], rng.random()))
    tg = pool[:K]; rng.shuffle(tg)
    lpool = sorted([x for x in ICONS if x not in tg and x not in prev], key=lambda x: (lc[x] + tc[x] * 0.3, rng.random()))
    lu = lpool[:F]
    lay = tg + lu; rng.shuffle(lay)
    it = {'id': f'I{n}', 'lab': f'T{K} R{K+F}', 'K': K, 'F': F, 'targets': tg, 'lures': lu, 'layout': lay, 'max': 2}
    tc.update(tg); lc.update(lu); prev = set(tg); out.append(it)
    print(it['id'], it['lab'], tg, lu)
json.dump(out, open('por_new.json', 'w'))
