import json, re, sys
PATH, LANG = sys.argv[1], sys.argv[2]
s = open(PATH, encoding='utf-8').read()
D = json.load(open('/home/claude/gwm/digits.json')); P = json.load(open('/home/claude/gwm/por_new.json'))
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:80], n); s = s.replace(old, new)
def bank(name, fn):
    global s
    m = re.search(r'^const ' + name + r' = (.*);\s*$', s, re.M); b = json.loads(m.group(1)); fn(b)
    s = s[:m.start(1)] + json.dumps(b, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
def f_db(b):
    assert b[-1]['id'] == 'DB_K9_2'; b.extend(D['db'])
def f_rds(b):
    assert b['forms']['A'][-1]['id'] == 'RDS_K9_A3'; b['forms']['A'].extend(D['rds'])
def f_por(b):
    assert b['forms']['A'][-1]['id'] == 'I35'; b['forms']['A'].extend(P)
bank('BANK_DB', f_db); bank('BANK_RDS', f_rds); bank('BANK_POR', f_por)
if LANG == 'cz':
    rep("8:'posledních osm čísel', 9:'posledních devět čísel'};", "8:'posledních osm čísel', 9:'posledních devět čísel', 10:'posledních deset čísel', 11:'posledních jedenáct čísel'};")
else:
    rep("8:'the last eight numbers', 9:'the last nine numbers'};", "8:'the last eight numbers', 9:'the last nine numbers', 10:'the last ten numbers', 11:'the last eleven numbers'};")
rep("CUR.formLabel = 'jednotná banka (K1–K9, U 2/4/6)';", "CUR.formLabel = 'jednotná banka (K1–K11, U 2/4/6; od K10 se čísla v řadě opakují)';")
rep("CUR.formLabel = 'K2, K3 lehčí (1–5), K3, K4–K9; 2 položky na úroveň';", "CUR.formLabel = 'K2, K3 lehčí (1–5), K3, K4–K11 (od K10 se čísla opakují); 2 položky na úroveň';")
rep("CUR.formLabel = 'banka v3 T1–T12 (35 položek)';", "CUR.formLabel = 'banka v3 T1–T14 (37 položek)';")
rep("group:'gwm', version:'rds-2.3',", "group:'gwm', version:'rds-2.4',")
rep("group:'gwm', version:'db-1.2',", "group:'gwm', version:'db-1.3',")
rep("group:'gwm', version:'por-4.0'", "group:'gwm', version:'por-4.1'")
# srovnání: přidány jen těžší úrovně nahoře – stejná skupina jako dosud
rep("rds:[['rds-2.0', 'rds-2.1', 'rds-2.2', 'rds-2.3']], zpetna:[['db-1.0', 'db-1.1', 'db-1.2']],",
    "rds:[['rds-2.0', 'rds-2.1', 'rds-2.2', 'rds-2.3', 'rds-2.4']], zpetna:[['db-1.0', 'db-1.1', 'db-1.2', 'db-1.3']], por:[['por-4.0', 'por-4.1']],")
# dlouhé řady: okénka na mobilu se zalomí a zmenší (11 okének)
rep("@media (max-width:560px){.sp-slot{min-width:40px;height:52px;font-size:24px}",
    "@media (max-width:560px){.sp-slots{gap:6px;flex-wrap:wrap}.sp-slot{min-width:36px;height:50px;font-size:23px}")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
# ---- Pořadí obrázků na úzkém displeji: dlouhé řady (K ≥ 8) ve dvou řádcích místo přetečení přes okraj
s = open(PATH, encoding='utf-8').read()
def rep2(old, new):
    global s
    assert s.count(old) == 1, (old[:80], s.count(old)); s = s.replace(old, new)
rep2(": (K >= 8 ? 54 : K >= 6 ? 66 : 80);", ": (K >= 8 ? (innerWidth < 560 ? Math.max(38, Math.min(54, Math.floor((innerWidth - 40) / Math.ceil(K / 2)) - 10)) : 54) : K >= 6 ? 66 : 80);")
rep2("Math.max(4, ST.item ? ST.item.K : 4)", "Math.max(4, ST.item ? (innerWidth < 560 && ST.item.K >= 8 ? Math.ceil(ST.item.K / 2) : ST.item.K) : 4)")
rep2("@media (max-width:560px){.sp-slots{gap:6px;flex-wrap:wrap}", "@media (max-width:560px){.por-slots,.por-belt{flex-wrap:wrap;gap:6px}.sp-slots{gap:6px;flex-wrap:wrap}")
open(PATH, 'w', encoding='utf-8').write(s); print('ok mobile por', PATH)
