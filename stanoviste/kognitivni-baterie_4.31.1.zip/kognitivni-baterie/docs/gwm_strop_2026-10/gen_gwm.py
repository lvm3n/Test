import json, random
from collections import Counter
rng = random.Random(20261007)
def ok_seq(s, min_dist):
    for i in range(1, len(s)):
        if s[i] == s[i-1]: return False
    for i in range(len(s)):
        for j in range(i+1, len(s)):
            if s[i] == s[j] and j - i < min_dist: return False
    for i in range(2, len(s)):                                    # žádné trojice 1-2-3 / 7-6-5
        if s[i]-s[i-1] == s[i-1]-s[i-2] and abs(s[i]-s[i-1]) == 1: return False
    bg = [(s[i], s[i+1]) for i in range(len(s)-1)]
    if len(bg) != len(set(bg)): return False                       # žádná dvojice dvakrát
    if max(Counter(s).values()) > 2: return False
    return True
def gen_db(K, avoid_first):
    while True:
        s = [rng.randint(1, 9) for _ in range(K)]
        if s[0] in avoid_first: continue
        if len(s) - len(set(s)) != K - 9: continue                 # jen nutný počet opakování (K10: 1, K11: 2)
        if ok_seq(s, 4): return s
DB = []; firsts = set([2])
for K in (10, 11):
    for n in (1, 2):
        s = gen_db(K, firsts); firsts.add(s[0])
        DB.append({'id': f'DB_K{K}_{n}', 'lab': f'K{K}_{n}', 'K': K, 'seq': s, 'target': s[::-1], 'uroven': f'K{K}', 'rozsah': '1–9 (opakují se)'})
def gen_rds(K, U):
    L = K + U
    while True:
        s = [rng.randint(1, 9) for _ in range(L)]
        t = s[U:]
        if len(t) - len(set(t)) != K - 9: continue
        if not ok_seq(s, 3): continue
        if s[U-1] == t[0]: continue
        return s
RDS = []
for K in (10, 11):
    for n, U in enumerate((2, 4, 6), 1):
        s = gen_rds(K, U)
        RDS.append({'id': f'RDS_K{K}_A{n}', 'lab': f'K{K}-A{n}', 'form': 'A', 'K': K, 'U': U, 'L': K + U, 'full': s, 'target': s[U:], 'lag1': s[U-1], 'lag2': s[U-2] if U >= 2 else None})
for x in DB: print(x['id'], ''.join(map(str, x['seq'])))
for x in RDS: print(x['id'], ''.join(map(str, x['full'])), '->', ''.join(map(str, x['target'])), 'lag', x['lag1'], x['lag2'])
json.dump({'db': DB, 'rds': RDS}, open('digits.json', 'w'), ensure_ascii=False)
