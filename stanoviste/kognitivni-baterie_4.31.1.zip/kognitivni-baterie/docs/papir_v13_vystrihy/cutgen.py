"""Skládání papíru – výstřihy na hraně/v rohu složeného papíru (PAP_073–076).
Spojitá geometrie: každé původní políčko má po přeložení polohu a lineární část (součin zrcadlení).
Výstřih se umístí na hranu/roh složeného útvaru (offset se zaokrouhlí na střed políčka podél hrany),
zpětně se promítne do všech vrstev a vytvoří klíč na odpovědní ploše se záchytnými body
(body s alespoň jednou souřadnicí na čáře mřížky). Pro každý záchytný bod se vygenerují kandidátní tvary
(8 symetrií základního výstřihu × zrcadlení přes čáry přehybů procházející bodem), seřazené deterministicky."""
import json, math, sys, itertools
sys.path.insert(0,'/home/claude/v3/cz/kognitivni-baterie/docs/papir_v6')
from paper import fold_cells
M = {'V':((-1,0),(0,1)), 'H':((1,0),(0,-1)), 'D':((0,1),(1,0)), 'A':((0,-1),(-1,0))}
def mul(A,B): return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(2)) for j in range(2)) for i in range(2))
def app(A,v): return (A[0][0]*v[0]+A[0][1]*v[1], A[1][0]*v[0]+A[1][1]*v[1])
def T(A): return ((A[0][0],A[1][0]),(A[0][1],A[1][1]))
I2=((1,0),(0,1))
D4=[((1,0),(0,1)),((0,-1),(1,0)),((-1,0),(0,-1)),((0,1),(-1,0)),((-1,0),(0,1)),((1,0),(0,-1)),((0,1),(1,0)),((0,-1),(-1,0))]
R=lambda v: (round(v[0],4)+0.0, round(v[1],4)+0.0)
def base(kind, orient):
    if kind=='edge_semicircle':
        r=.32; return 'edge',[ (r*math.cos(t), r*math.sin(t)) for t in [math.pi*k/10 for k in range(11)] ]
    if kind=='edge_v_notch':
        s=1 if orient%2 else -1; return 'edge',[(-.28,0),(.28,0),(.14*s,.44)]
    if kind=='corner_quarter_circle':
        r=.42; return 'corner',[(0,0)]+[(r*math.cos(t), r*math.sin(t)) for t in [math.pi/2*k/8 for k in range(9)]]
    if kind=='corner_L_notch':
        P=[(0,0),(.58,0),(.58,.2),(.2,.2),(.2,.36),(0,.36)]
        if orient%2: P=[(y,x) for x,y in P]
        return 'corner',P
def key_of(polys): return json.dumps(sorted(sorted(R(v) for v in P) for P in polys))
def build(it):
    n=it['n']; folds=it['folds']; fc=it['finalCut']
    pos,hist=fold_cells(n,folds)
    L={}
    for o in pos:
        A=I2
        for t in hist[o]: A=mul(M[t],A)
        L[o]=A
    cells=set(pos.values()); rs=[p[0] for p in cells]; cs=[p[1] for p in cells]
    r0,r1,c0,c1=min(rs),max(rs),min(cs),max(cs)
    kind,B=base(fc['kind'],fc.get('orientation',0))
    if kind=='edge':
        e=fc['edge']
        if e in ('right','left'):
            col=c1 if e=='right' else c0; rows=sorted(r for r,c in cells if c==col); row=rows[min(len(rows)-1,int(fc['offset']*len(rows)))]
            q=((col+1) if e=='right' else col, row+.5); along=(0,1); inward=(-1,0) if e=='right' else (1,0)
        else:
            row=r0 if e=='top' else r1; colsr=sorted(c for r,c in cells if r==row); col=colsr[min(len(colsr)-1,int(fc['offset']*len(colsr)))]
            q=(col+.5, row if e=='top' else row+1); along=(1,0); inward=(0,1) if e=='top' else (0,-1)
        frame=(along,inward)
    else:
        cn=fc['corner']; top='top' in cn; left='left' in cn
        r=r0 if top else r1; c=c0 if left else c1
        assert (r,c) in cells, 'roh není obsazen'
        q=(c if left else c+1, r if top else r+1); ax=(1 if left else -1,0); ay=(0,1 if top else -1); frame=(ax,ay)
    folded=[ (q[0]+u*frame[0][0]+v*frame[1][0], q[1]+u*frame[0][1]+v*frame[1][1]) for u,v in B ]
    # zpětné promítnutí do všech vrstev
    copies={}
    for o,(R_,C_) in pos.items():
        if not (C_-1e-9<=q[0]<=C_+1+1e-9 and R_-1e-9<=q[1]<=R_+1+1e-9): continue
        Lt=T(L[o]); cf=(C_+.5,R_+.5); co=(o[1]+.5,o[0]+.5)
        P=[ (co[0]+d[0],co[1]+d[1]) for d in [app(Lt,(v[0]-cf[0],v[1]-cf[1])) for v in folded] ]
        p=app(Lt,(q[0]-cf[0],q[1]-cf[1])); p=R((co[0]+p[0],co[1]+p[1]))
        copies.setdefault(p,{})[key_of([P])]=P
    # záchytné body
    pts=[]
    for x2 in range(0,2*n+1):
        for y2 in range(0,2*n+1):
            if x2%2 and y2%2: continue                     # střed políčka – ne pro výstřihy
            pts.append((x2/2,y2/2))
    def mirrors(p):
        """Transformace mezi vrstvami, které se v bodě p po složení potkají (z poskládání, ne z odpovědi)."""
        x,y=p; touch=[o for o in pos if o[1]-1e-9<=x<=o[1]+1+1e-9 and o[0]-1e-9<=y<=o[0]+1+1e-9]
        if not touch: return []
        def F(o):
            R_,C_=pos[o]; cf=(C_+.5,R_+.5); co=(o[1]+.5,o[0]+.5); d=app(L[o],(x-co[0],y-co[1])); return R((cf[0]+d[0],cf[1]+d[1]))
        a0=touch[0]; fa=F(a0); H=[]
        for b in touch:
            if F(b)!=fa: continue
            Mx=mul(T(L[b]),L[a0])
            if Mx!=I2 and Mx not in H: H.append(Mx)
        return H
    def inside(P): return all(-1e-6<=v[0]<=n+1e-6 and -1e-6<=v[1]<=n+1e-6 for v in P)
    def on_support(p,d):        # směr d leží podél hranice papíru nebo podél přehybu přes p
        x,y=p
        if d[1]==0 and (y in (0,n) or (y==int(y))): return True
        if d[0]==0 and (x in (0,n) or (x==int(x))): return True
        if abs(d[0])==abs(d[1]) and x==int(x) and y==int(y): return True
        return False
    data=[]; keymap={}
    for p in pts:
        H=mirrors(p); cand=[]; seen=set()
        for g in D4:
            if kind=='edge':
                a=app(g,(1,0)); b=app(g,(0,1))
                if not on_support(p,a): continue
            else:
                a=app(g,(1,0)); b=app(g,(0,1))
                if not (on_support(p,a) and on_support(p,b)): continue
            P0=[ (p[0]+app(g,v)[0], p[1]+app(g,v)[1]) for v in B ]
            if not inside(P0): continue
            S=[P0]
            # uzávěr přes zrcadlení bodem p (grupa generovaná H)
            changed=True
            while changed:
                changed=False
                for h in H:
                    for P in list(S):
                        Q=[ (p[0]+app(h,(v[0]-p[0],v[1]-p[1]))[0], p[1]+app(h,(v[0]-p[0],v[1]-p[1]))[1]) for v in P ]
                        if key_of([Q]) not in {key_of([X]) for X in S}: S.append(Q); changed=True
            if not all(inside(P) for P in S): continue
            k=key_of(S)
            if k in seen: continue
            seen.add(k); cand.append(S)
        if not cand: continue
        rec={'p':[int(round(p[0]*2)),int(round(p[1]*2))],'c':[[[ [round(v[0],3),round(v[1],3)] for v in P] for P in S] for S in cand]}
        if p in copies:
            tk=key_of(list(copies[p].values()))
            idx=[i for i,S in enumerate(cand) if key_of(S)==tk]
            if not idx:
                cand.append(list(copies[p].values())); rec['c'].append([[[round(v[0],3),round(v[1],3)] for v in P] for P in copies[p].values()]); idx=[len(cand)-1]
                print('  ! klíčový tvar doplněn mezi kandidáty v bodě',p)
            keymap['%d,%d'%(rec['p'][0],rec['p'][1])]=idx[0]
        data.append(rec)
    missing=[p for p in copies if p not in [ (r['p'][0]/2,r['p'][1]/2) for r in data]]
    return {'kind':fc['kind'],'folded':[[round(v[0],3),round(v[1],3)] for v in folded],'q':list(q),'points':data,'key':keymap}, copies, missing
if __name__=='__main__':
    Q=json.load(open('/mnt/user-data/uploads/papir_v13_final40.json'))
    out={}
    for it in Q:
        if it.get('renderer_compatibility')!='requires_v12_edge_corner': continue
        cd,copies,missing=build(it)
        print(it['id'],it['folds'],cd['kind'],'q',cd['q'],'| klíč',cd['key'],'| kopie',[ (p,len(v)) for p,v in copies.items()],'| chybí',missing,'| bodů',len(cd['points']),'max kand',max(len(r['c']) for r in cd['points']))
        out[it['id']]=cd
    json.dump(out,open('/home/claude/pcut/cutdata.json','w'))
    print(len(json.dumps(out))//1024,'kB')
