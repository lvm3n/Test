"""Výstřihy na hraně/rohu – přesná geometrie skládání (i diagonální přehyby).
Papír = konvexní kusy, každý s afinním zobrazením originál→složený stav. Přehyb rozřízne kusy podél čáry a pohyblivou
část zrcadlí. Výstřih (polygon v souřadnicích složeného papíru) se ořízne každým kusem a promítne zpět.
Kandidáti v záchytném bodě p: výstřih v každém z 8 natočení umístěný do F(p), oříznutý papírem, promítnutý zpět;
bere se jen část kotvená v p. Nezávisí na klíči – jen na skládání."""
import json, math, sys
EPS=1e-9
def area(P): return 0.5*sum(P[i][0]*P[(i+1)%len(P)][1]-P[(i+1)%len(P)][0]*P[i][1] for i in range(len(P)))
def clip_half(P, a,b,c):            # ponechá a*x+b*y+c >= 0
    out=[]
    for i in range(len(P)):
        A=P[i]; B=P[(i+1)%len(P)]; fa=a*A[0]+b*A[1]+c; fb=a*B[0]+b*B[1]+c
        if fa>=-EPS: out.append(A)
        if (fa>EPS and fb<-EPS) or (fa<-EPS and fb>EPS):
            t=fa/(fa-fb); out.append((A[0]+t*(B[0]-A[0]),A[1]+t*(B[1]-A[1])))
    return out
def clip_convex(S, C):              # S libovolný polygon, C konvexní (CCW nebo CW)
    if area(C)<0: C=C[::-1]
    out=S
    for i in range(len(C)):
        A=C[i]; B=C[(i+1)%len(C)]
        a=-(B[1]-A[1]); b=B[0]-A[0]; c=-(a*A[0]+b*A[1])
        out=clip_half(out,a,b,c)
        if not out: return []
    return out
def compose(M2,M1):  # M=(A,t): x -> A x + t
    A2,t2=M2; A1,t1=M1
    A=tuple(tuple(sum(A2[i][k]*A1[k][j] for k in range(2)) for j in range(2)) for i in range(2))
    t=(A2[0][0]*t1[0]+A2[0][1]*t1[1]+t2[0], A2[1][0]*t1[0]+A2[1][1]*t1[1]+t2[1]); return (A,t)
def ap(M,v): A,t=M; return (A[0][0]*v[0]+A[0][1]*v[1]+t[0], A[1][0]*v[0]+A[1][1]*v[1]+t[1])
def inv(M):
    A,t=M; At=((A[0][0],A[1][0]),(A[0][1],A[1][1])); return (At,(-(At[0][0]*t[0]+At[0][1]*t[1]),-(At[1][0]*t[0]+At[1][1]*t[1])))
ID=(((1,0),(0,1)),(0,0))
def fold_paper(n, folds):
    pieces=[([(0,0),(n,0),(n,n),(0,n)], ID)]          # (polygon v originálu, zobrazení)
    for f in folds:
        imgs=[ [ap(M,v) for v in P] for P,M in pieces ]
        xs=[v[0] for I in imgs for v in I]; ys=[v[1] for I in imgs for v in I]
        x0,x1,y0,y1=min(xs),max(xs),min(ys),max(ys)
        kk=int(f[2:]) if len(f)>2 else None
        if f[0]=='V':
            m=(x0+x1)/2 if kk is None else (x0+kk if f[1]=='L' else x1-kk)
            mov=(-1,0,m) if f[1]=='L' else (1,0,-m); R=(((-1,0),(0,1)),(2*m,0))
        elif f[0]=='H':
            m=(y0+y1)/2 if kk is None else (y0+kk if f[1]=='T' else y1-kk)
            mov=(0,-1,m) if f[1]=='T' else (0,1,-m); R=(((1,0),(0,-1)),(0,2*m))
        elif f[0]=='D':                                  # čára x-x0 = y-y0; U: (x-x0)-(y-y0) > 0
            s=(1,-1,-(x0-y0)); mov=s if f[1]=='U' else (-s[0],-s[1],-s[2])
            R=(((0,1),(1,0)),(x0-y0,y0-x0))
        else:                                            # A: (x-x0)+(y-y0) = w ; U: < w
            w=x1-x0; s=(-1,-1,x0+y0+w); mov=s if f[1]=='U' else (-s[0],-s[1],-s[2])
            R=(((0,-1),(-1,0)),(x0+y0+w,x0+y0+w))
        new=[]
        for (P,M),I in zip(pieces,imgs):
            a,b,c=mov
            stay=clip_half(I,-a,-b,-c); move=clip_half(I,a,b,c)
            Mi=inv(M)
            if len(stay)>=3 and abs(area(stay))>1e-7: new.append(([ap(Mi,v) for v in stay],M))
            if len(move)>=3 and abs(area(move))>1e-7: new.append(([ap(Mi,v) for v in move],compose(R,M)))
        pieces=new
    return pieces
def contains(P,p):
    s=None
    for i in range(len(P)):
        A=P[i]; B=P[(i+1)%len(P)]; cr=(B[0]-A[0])*(p[1]-A[1])-(B[1]-A[1])*(p[0]-A[0])
        if abs(cr)<1e-7: continue
        if s is None: s=cr>0
        elif s!=(cr>0): return False
    return True
D4=[((1,0),(0,1)),((0,-1),(1,0)),((-1,0),(0,-1)),((0,1),(-1,0)),((-1,0),(0,1)),((1,0),(0,-1)),((0,1),(1,0)),((0,-1),(-1,0))]
def lin(A,v): return (A[0][0]*v[0]+A[0][1]*v[1], A[1][0]*v[0]+A[1][1]*v[1])
def base(kind, orient):
    if kind=='edge_semicircle': r=.32; return [ (r*math.cos(math.pi*k/12), r*math.sin(math.pi*k/12)) for k in range(13)]
    if kind=='edge_v_notch': s=1 if orient%2 else -1; return [(-.28,0),(.28,0),(.14*s,.44)]
    if kind=='corner_quarter_circle': r=.42; return [(0,0)]+[(r*math.cos(math.pi/2*k/8), r*math.sin(math.pi/2*k/8)) for k in range(9)]
    if kind=='corner_L_notch':
        P=[(0,0),(.58,0),(.58,.2),(.2,.2),(.2,.36),(0,.36)]
        return [(y,x) for x,y in P] if orient%2 else P
def rnd(v): return (round(v[0],4)+0.0, round(v[1],4)+0.0)
def canon(S): return json.dumps(sorted(sorted(rnd(v) for v in P) for P in S))
def cut_at(pieces, poly_f, qf):
    """Výsledek výstřihu poly_f (ve složeném stavu): seznam (kotva v originálu, polygon v originálu)."""
    out=[]
    for P,M in pieces:
        I=[ap(M,v) for v in P]; C=clip_convex(poly_f, I)
        if len(C)<3 or abs(area(C))<1e-6: continue
        Mi=inv(M); out.append((rnd(ap(Mi,qf)), [ap(Mi,v) for v in C]))
    return out
def build(it):
    n=it['n']; fc=it['finalCut']; pieces=fold_paper(n,it['folds'])
    imgs=[[ap(M,v) for v in P] for P,M in pieces]
    xs=[v[0] for I in imgs for v in I]; ys=[v[1] for I in imgs for v in I]; x0,x1,y0,y1=min(xs),max(xs),min(ys),max(ys)
    kind=fc['kind']; B=base(kind, fc.get('orientation',0)); edge=kind.startswith('edge')
    # místo výstřihu na složeném útvaru (střed políčka podél hrany / roh obálky, který leží na papíře)
    if edge:
        e=fc['edge']
        if e in ('left','right'):
            x=x1 if e=='right' else x0; ys_on=sorted({round(v[1],6) for I in imgs for v in I if abs(v[0]-x)<1e-6}); lo,hi=min(ys_on),max(ys_on)
            cells=[k+.5 for k in range(int(math.floor(lo+1e-9)),int(math.ceil(hi-1e-9)))]; q=(x, cells[min(len(cells)-1,int(fc['offset']*len(cells)))])
            frame=((0,1),(-1,0) if e=='right' else (1,0))
        else:
            y=y0 if e=='top' else y1; xs_on=sorted({round(v[0],6) for I in imgs for v in I if abs(v[1]-y)<1e-6}); lo,hi=min(xs_on),max(xs_on)
            cells=[k+.5 for k in range(int(math.floor(lo+1e-9)),int(math.ceil(hi-1e-9)))]; q=(cells[min(len(cells)-1,int(fc['offset']*len(cells)))], y)
            frame=((1,0),(0,1) if e=='top' else (0,-1))
    else:
        cn=fc['corner']; top='top' in cn; left='left' in cn
        q=(x0 if left else x1, y0 if top else y1); frame=((1 if left else -1,0),(0,1 if top else -1))
    Af=((frame[0][0],frame[1][0]),(frame[0][1],frame[1][1]))
    poly_f=[ (q[0]+lin(Af,v)[0], q[1]+lin(Af,v)[1]) for v in B ]
    res=cut_at(pieces, poly_f, q)
    folded_vis=[ clip_convex(poly_f, I) for I in imgs ]; folded_vis=[C for C in folded_vis if len(C)>=3 and abs(area(C))>1e-6]
    pts=[(x2/2,y2/2) for x2 in range(2*n+1) for y2 in range(2*n+1) if not (x2%2 and y2%2)]
    def F(p):
        for P,M in pieces:
            if contains(P,p): return ap(M,p)
    key={}; groups={}
    for a,Pl in res: groups.setdefault(a,[]).append(Pl)
    data=[]
    for p in pts:
        fp=F(p); cand=[]; seen=set()
        if fp is None: continue
        for g in D4:
            pf=[ (fp[0]+lin(g,v)[0], fp[1]+lin(g,v)[1]) for v in B ]
            S=[Pl for a,Pl in cut_at(pieces,pf,fp) if abs(a[0]-p[0])<1e-6 and abs(a[1]-p[1])<1e-6]
            if not S: continue
            k=canon(S)
            if k in seen: continue
            seen.add(k); cand.append(S)
        if not cand: continue
        # pořadí natočení je dané tvarem v rozloženém papíře (relativně k bodu), ne natočením ve složeném stavu –
        # jinak by výchozí volba u všech kopií odpovídala klíči. Největší (nejpřirozenější) tvar první, pak podle tvaru.
        rel=lambda S: canon([[ (v[0]-p[0], v[1]-p[1]) for v in P] for P in S])
        if kind in ('edge_v_notch','corner_L_notch'): cand.sort(key=rel)          # orientované: pořadí jen podle tvaru (výchozí natočení nic nenapovídá)
        else: cand.sort(key=lambda S: (-round(sum(abs(area(P)) for P in S),3), rel(S)))
        rec={'p':[int(round(p[0]*2)),int(round(p[1]*2))],'c':[[[[round(v[0],3),round(v[1],3)] for v in Pl] for Pl in S] for S in cand]}
        if rnd(p) in groups:
            tk=canon(groups[rnd(p)]); idx=[i for i,S in enumerate(cand) if canon(S)==tk]
            if not idx: print('  ! klíč mimo kandidáty v',p)
            else: key['%d,%d'%tuple(rec['p'])]=idx[0]
        data.append(rec)
    stray=[a for a in groups if a not in [ (r['p'][0]/2,r['p'][1]/2) for r in data]]
    if stray: print('  ! kotvy mimo síť:',stray)
    return {'kind':kind,'folded':[[[round(v[0],3),round(v[1],3)] for v in C] for C in folded_vis],'q':list(q),'points':data,'key':key}, groups
if __name__=='__main__':
    Q=json.load(open('/mnt/user-data/uploads/papir_v13_final40.json')); out={}
    for it in Q:
        if it.get('renderer_compatibility')!='requires_v12_edge_corner': continue
        if it['id']=='PAP_076':   # od 3.74.2: výstřih v pravoúhlém rohu trojúhelníku (v 45° rohu se L-zářez nevejde)
            it=dict(it); it['finalCut']=dict(it['finalCut'], corner='bottom_left')
        cd,groups=build(it)
        print(it['id'],it['folds'],cd['kind'],'q',cd['q'],'klíč',cd['key'],'kopie',{k:len(v) for k,v in groups.items()},'bodů',len(cd['points']),'max kand',max(len(r['c']) for r in cd['points']), 'výstřih ve složeném stavu: kusů',len(cd['folded']))
        out[it['id']]=cd
    json.dump(out,open('/home/claude/pcut/cutdata.json','w')); print(len(json.dumps(out))//1024,'kB')
