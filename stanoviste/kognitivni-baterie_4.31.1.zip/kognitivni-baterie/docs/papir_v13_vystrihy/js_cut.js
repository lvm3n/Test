/* ===== Skládání papíru: výstřihy na hraně a v rohu (od 3.74.0) =====
   Odpovědní plocha se záchytnými body: kromě středů políček i body na čarách mřížky, na hranách a v rozích.
   Body nejsou vidět; na počítači se při najetí ukáže průhledný náhled. Typ výstřihu je dán položkou. */
const PAP_CUT = (function(){
  const BG = '#FFFFFF', INK = '#2B3440';
  const polyPath = (P, cs) => 'M' + P.map(v => (v[0] * cs).toFixed(1) + ' ' + (v[1] * cs).toFixed(1)).join(' L') + 'Z';
  const shapePaths = (S, cs) => S.map(P => polyPath(P, cs)).join(' ');
  /* obrys tvaru bez vnitřních hran (společné hrany dvou zrcadlových kopií se nekreslí) */
  const outline = (S, cs) => {
    const segs = []; S.forEach(P => P.forEach((v, i) => segs.push([v, P[(i + 1) % P.length]])));
    const k = (a, b) => a[0].toFixed(3) + ',' + a[1].toFixed(3) + '|' + b[0].toFixed(3) + ',' + b[1].toFixed(3), cnt = {};
    segs.forEach(([a, b]) => { cnt[k(a, b)] = (cnt[k(a, b)] || 0) + 1; cnt[k(b, a)] = (cnt[k(b, a)] || 0) + 1; });
    return segs.filter(([a, b]) => cnt[k(a, b)] === 1).map(([a, b]) => `M${(a[0] * cs).toFixed(1)} ${(a[1] * cs).toFixed(1)} L${(b[0] * cs).toFixed(1)} ${(b[1] * cs).toFixed(1)}`).join(' ');
  };
  function paper(it, resp, px, interactive, active){
    const n = it.n, cs = px / n, D = it.cut, id = 'pc' + Math.random().toString(36).slice(2, 8);
    let s = `<svg viewBox="-3 -3 ${px + 6} ${px + 6}" width="${px + 6}" height="${px + 6}" class="gv-answer pc-paper" data-cs="${cs}"${interactive ? ' style="cursor:pointer;touch-action:manipulation"' : ''} role="img" aria-label="Rozložený papír">`;
    s += `<clipPath id="${id}"><rect x="1.5" y="1.5" width="${px - 3}" height="${px - 3}"/></clipPath>`;
    s += `<rect x="0" y="0" width="${px}" height="${px}" fill="#FFF8E7" stroke="#C9B98F" stroke-width="1.5"/>`;
    let g = ''; for (let k = 1; k < n; k++) g += `M${k * cs} 0 V${px} M0 ${k * cs} H${px} `;
    s += `<path d="${g}" stroke="#C9B98F" stroke-width="1.2"/>`;
    for (const [k, idx] of resp) {
      const pt = D.points.find(p => p.p[0] + ',' + p.p[1] === k); if (!pt) continue;
      const S = pt.c[idx % pt.c.length], d = shapePaths(S, cs);
      const o = outline(S, cs);
      s += `<path d="${d}" fill="${BG}" stroke="${BG}" stroke-width="0.8"/><path d="${o}" fill="none" stroke="${INK}" stroke-width="1.8" stroke-linecap="round" clip-path="url(#${id})"/>`;
      if (interactive && k === active) s += `<path d="${o}" fill="none" stroke="#0B5CAD" stroke-width="3.2" stroke-opacity=".55" stroke-dasharray="5 3" clip-path="url(#${id})"/>`;
    }
    if (interactive) s += `<g class="pc-ghost" pointer-events="none"></g>`;
    return s + '</svg>';
  }
  function nearest(it, x, y){
    let best = null, bd = 1e9;
    it.cut.points.forEach(p => { const dx = p.p[0] / 2 - x, dy = p.p[1] / 2 - y, d = dx * dx + dy * dy; if (d < bd) { bd = d; best = p; } });
    return bd <= 0.36 * 0.36 ? best : null;
  }
  function bind(it, resp, box, ctl, redraw){
    const svg = box.querySelector('.pc-paper'); if (!svg) return;
    const cs = +svg.dataset.cs, ghost = svg.querySelector('.pc-ghost');
    const loc = (e) => { const r = svg.getBoundingClientRect(), sx = (svg.viewBox.baseVal.width) / r.width; return [((e.clientX - r.left) * sx - 3) / cs, ((e.clientY - r.top) * sx - 3) / cs]; };
    svg.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse' || !ghost) return;
      const [x, y] = loc(e), p = nearest(it, x, y);
      ghost.innerHTML = p && !resp.has(p.p.join(',')) ? `<path d="${shapePaths(p.c[0], cs)}" fill="${BG}" fill-opacity=".7" stroke="none"/><path d="${outline(p.c[0], cs)}" fill="none" stroke="${INK}" stroke-opacity=".45" stroke-width="1.5" stroke-dasharray="4 3"/>` : '';
    });
    svg.addEventListener('pointerleave', () => { if (ghost) ghost.innerHTML = ''; });
    svg.addEventListener('click', (e) => {
      const [x, y] = loc(e), p = nearest(it, x, y); if (!p) return;
      const k = p.p.join(',');
      if (resp.has(k)) {
        if (p.c.length <= 1) { resp.delete(k); ctl.active = null; }                 // neorientovaný výstřih: klepnutí odebere
        else { resp.set(k, (resp.get(k) + 1) % p.c.length); ctl.active = k; }       // orientovaný: klepnutí otočí (nikdy nesmaže)
      } else { resp.set(k, 0); ctl.active = k; }
      redraw();
    });
    svg.addEventListener('contextmenu', (e) => { if (!ctl.active || !resp.has(ctl.active)) return; e.preventDefault(); const p = it.cut.points.find(q => q.p.join(',') === ctl.active);
      if (p && p.c.length > 1) { resp.set(ctl.active, (resp.get(ctl.active) + 1) % p.c.length); redraw(); } });
    const rm = box.querySelector('.pc-remove'); if (rm) rm.addEventListener('click', () => { if (ctl.active && resp.has(ctl.active)) { resp.delete(ctl.active); ctl.active = null; redraw(); } });
    if (!ctl.keys) { ctl.keys = true; document.addEventListener('keydown', (e) => {
      const live = document.querySelector('.pc-paper'); if (!live || !ctl.cur || !ctl.active || !ctl.cur.resp.has(ctl.active)) return;
      if (e.key === 'r' || e.key === 'R') { const p = ctl.cur.it.cut.points.find(q => q.p.join(',') === ctl.active); if (p && p.c.length > 1) { ctl.cur.resp.set(ctl.active, (ctl.cur.resp.get(ctl.active) + 1) % p.c.length); ctl.cur.redraw(); } }
      if (e.key === 'Delete' || e.key === 'Backspace') { ctl.cur.resp.delete(ctl.active); ctl.active = null; ctl.cur.redraw(); }
    }); }
    ctl.cur = {it, resp, redraw};
  }
  function folded(it, seqHTML, px){
    const cs = px / it.n, seen = new Set(), S = [];
    it.cut.folded.forEach(P => { const k = P.map(v => v[0].toFixed(3) + ',' + v[1].toFixed(3)).sort().join(';'); if (!seen.has(k)) { seen.add(k); S.push(P); } });   // vrstvy se kryjí
    const k = seqHTML.lastIndexOf('</svg>');
    return seqHTML.slice(0, k) + `<path d="${shapePaths(S, cs)}" fill="#FFFFFF" stroke="#FFFFFF" stroke-width="0.8"/><path d="${outline(S, cs)}" fill="none" stroke="${INK}" stroke-width="2" stroke-linecap="round"/>` + seqHTML.slice(k);
  }
  const keyMap = (it) => new Map(Object.entries(it.cut.key));
  return {paper, bind, folded, keyMap};
})();
