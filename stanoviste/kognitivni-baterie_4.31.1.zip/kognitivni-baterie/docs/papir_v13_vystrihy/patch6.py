import sys,json
p=sys.argv[1]; lang=sys.argv[2]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:100]))
    s=s.replace(a,b)
def sub_in(fn, a, b):
    global s
    i=s.index(fn); j=s.index('\nfunction ',i+20); g=s[i:j]
    if g.count(a)!=1: raise SystemExit('FAIL-in %s (%d) %s'%(fn,g.count(a),a[:80]))
    s=s[:i]+g.replace(a,b)+s[j:]
CUT=json.load(open('/home/claude/pcut/cutdata.json'))
Q=json.load(open('/mnt/user-data/uploads/papir_v13_final40.json'))
# 1) položky do banky (na místa podle finálního pořadí v13)
i0=s.index('const BANK_GV = ')+len('const BANK_GV = '); G,e=json.JSONDecoder().raw_decode(s[i0:])
items=G['papir']; ids={x['id'] for x in items}
order={x['id']:x['final_order_v13_40'] for x in Q}
for x in Q:
    if x['id'] in CUT and x['id'] not in ids:
        y={k:x[k] for k in ('id','level','n','folds','holes','facety','obtiznost_odhad') if k in x}
        y.update({'shapes':False,'answer':[],'cut':CUT[x['id']],'poradi_v13':x['final_order_v13_40'],'markerType':x['markerType']})
        items.append(y)
items.sort(key=lambda x: order.get(x['id'],999))
G['papir']=items
s=s[:i0]+json.dumps(G,ensure_ascii=False,separators=(',',':'))+s[i0+e:]
# 2) kód výstřihů
rep("function mod_papir(root, BANK){", open('/home/claude/pcut/js_cut.js',encoding='utf8').read()+"\nfunction mod_papir(root, BANK){")
# 3) mod_gv: háček pro vlastní obsluhu odpovědní plochy
sub_in('function mod_gv(root, cfg){', """      g.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(); } });
    });
  }""", """      g.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(); } });
    });
    if (cfg.bindAns) cfg.bindAns(it, ST.resp, $('#' + K + '-ans'), () => { if (ST.tFirst === null) ST.tFirst = performance.now() - ST.t0; ST.clicks++; drawAns(it); });
  }""")
TX = {'cz':{'q':'Jak bude papír vypadat, když ho rozložíš?','lbl':'Rozložený papír:','rm':'Odebrat',
            'card':'<p style="font-size:20px">Teď se stříhá <b>do okraje nebo do rohu složeného papíru</b>. Na rozloženém papíře klepni na místo, kde bude výstřih – může být na okraji, v rohu i uprostřed papíru (tam, kde byl přehyb, se z výstřihu na okraji stane otvor).</p><p class="muted">Tvar výstřihu je daný. Klepnutím na vložený výstřih ho otočíš; tlačítkem Odebrat ho smažeš. Výstřih, který se otáčet nedá, se klepnutím odebere.</p>'},
      'en':{'q':'What will the paper look like when you unfold it?','lbl':'Unfolded paper:','rm':'Remove',
            'card':'<p style="font-size:20px">Now the cut is made <b>into the edge or corner of the folded paper</b>. On the unfolded paper, tap where the cut will be – it can be on the edge, in a corner or in the middle of the paper (where there was a fold, an edge cut becomes a hole).</p><p class="muted">The shape of the cut is given. Tap a placed cut to turn it; use Remove to delete it. A cut that cannot be turned is removed by tapping it.</p>'}}[lang]
# 4) mod_papir: konfigurace pro výstřihy
sub_in('function mod_papir(root, BANK){', "  let sel = 0, cardShown = false, cutShown = false;", "  let sel = 0, cardShown = false, cutShown = false, edgeShown = false; const CTL = {active:null};")
sub_in('function mod_papir(root, BANK){', "    introCard:(it) => {\n", "    introCard:(it) => {\n      if (it.cut && !edgeShown) { edgeShown = true; return " + json.dumps(TX['card'],ensure_ascii=False) + "; }\n")
sub_in('function mod_papir(root, BANK){', "    stimulus:(it) => GV_DRAW.paperSequence(it, stepPx(it)),",
       "    stimulus:(it) => it.cut ? PAP_CUT.folded(it, GV_DRAW.paperSequence(it, stepPx(it)), stepPx(it)) : GV_DRAW.paperSequence(it, stepPx(it)),\n    bindAns:(it, resp, box, redraw) => { if (it.cut) PAP_CUT.bind(it, resp, box, CTL, redraw); },")
sub_in('function mod_papir(root, BANK){', "    onLoad:(it) => { sel = it.shapes ? 0 : -1; },", "    onLoad:(it) => { sel = it.shapes ? 0 : -1; CTL.active = null; },")
sub_in('function mod_papir(root, BANK){', "    answerSVG:(it, resp, readonly) => (readonly ? '' : palette(it))",
       "    answerSVG:(it, resp, readonly) => it.cut ? '<p class=\"gv-lbl\">" + TX['lbl'] + "</p>' + PAP_CUT.paper(it, resp, px(), !readonly, CTL.active) + (readonly ? '' : '<div class=\"pc-tools\"><button type=\"button\" class=\"btn ghost pc-remove\"' + (CTL.active && resp.has(CTL.active) ? '' : ' disabled') + '>" + TX['rm'] + "</button></div>') : (readonly ? '' : palette(it))")
sub_in('function mod_papir(root, BANK){', "    correct:(it, resp) => { const A = K2(it);", "    correct:(it, resp) => { if (it.cut) { const A = PAP_CUT.keyMap(it); return resp.size === A.size && [...resp].every(([k, v]) => A.has(k) && A.get(k) === v); } const A = K2(it);")
sub_in('function mod_papir(root, BANK){', "    keyText:(it) => it.answer.map(", "    keyText:(it) => it.cut ? Object.entries(it.cut.key).map(([k, v]) => k + ':' + v).join(' ') : it.answer.map(")
sub_in('function mod_papir(root, BANK){', "    respText:(it, resp) => [...resp].map(", "    respText:(it, resp) => it.cut ? [...resp].map(([k, v]) => k + ':' + v).sort().join(' ') : [...resp].map(")
sub_in('function mod_papir(root, BANK){', "      cardShown = false; cutShown = false;", "      cardShown = false; cutShown = false; edgeShown = false;")
q=TX['q']
s=s.replace("question:(it) => it.shapes ?","question:(it) => it.cut ? "+json.dumps(q,ensure_ascii=False)+" : it.shapes ?",1)
s=s.replace("version:'Gv-PAP-v13',","version:'Gv-PAP-v13e',",1)
s=s.replace("['Gv-PAP-v8'], ['Gv-PAP-v13']]","['Gv-PAP-v8'], ['Gv-PAP-v13'], ['Gv-PAP-v13e']]",1)
k=s.index('</style>'); s=s[:k]+"\n.pc-tools{display:flex;justify-content:center;margin-top:8px}\n"+s[k:]
open(p,'w',encoding='utf8').write(s); print('patch6 ok',p,len(items))
