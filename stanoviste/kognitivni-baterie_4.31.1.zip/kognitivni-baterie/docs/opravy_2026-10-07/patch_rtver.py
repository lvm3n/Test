import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
# opakování pod JINOU verzí (test se mezitím změnil) = první pokus podle nových pravidel → běžný výsledek, ne „retake“
rep("  if (rt && rt.n) return kbRetakeCard(k, raw, version, rt);\n",
    "  if (rt && rt.n && !(rt.prevVer && rt.prevVer !== version)) return kbRetakeCard(k, raw, version, rt);\n")
rep("sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore)} : null);",
    "sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore), prevVer:sc.predchozi_verze || ''} : null);")
rep("rt:v.opakovani ? {n:+v.opakovani, prev:parseFloat(v.predchozi)} : null}; });",
    "rt:v.opakovani ? {n:+v.opakovani, prev:parseFloat(v.predchozi), prevVer:v.predchozi_verze || ''} : null}; });")
rep("rt:sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore)} : null}; });",
    "rt:sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore), prevVer:sc.predchozi_verze || ''} : null}; });")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
