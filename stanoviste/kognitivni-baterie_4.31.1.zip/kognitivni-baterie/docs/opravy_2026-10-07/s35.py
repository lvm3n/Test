import itertools, random
P1=lambda x:[x[2],x[0],x[1]]; P2=lambda x:[x[1],x[2],x[0]]; ID=lambda x:list(x)
PERMS={'P1':P1,'P2':P2,'ID':ID,'SW12':lambda x:[x[0],x[2],x[1]],'SW01':lambda x:[x[1],x[0],x[2]],'SW02':lambda x:[x[2],x[1],x[0]]}
def intended(x):
    y=(P1 if x[0][2]=='S' else P2)(x); y=[list(o) for o in y]; y[0][2]='H' if y[0][2]=='S' else 'S'; return y
def feats(x):
    return {'f0':x[0][2],'f1':x[1][2],'f2':x[2][2],'nS':sum(o[2]=='S' for o in x)%2,'z0':x[0][1],'const':0}
FILLOPS=['copy','tog','S','H','oldtop','notoldtop']
def apply(x,perm,ops):
    y=[list(o) for o in PERMS[perm](x)]
    for j,op in enumerate(ops):
        f=y[j][2]
        y[j][2]={'copy':f,'tog':'H' if f=='S' else 'S','S':'S','H':'H','oldtop':x[0][2],'notoldtop':'H' if x[0][2]=='S' else 'S'}[op]
    return y
def preds(demos,t):
    out=set()
    for fk in ['f0','f1','f2','nS','z0','const']:
        # mapping feature value -> perm (lookup) and fill ops also possibly depend on same feature
        vals=sorted({feats(d)[fk] for d in demos}|{feats(t)[fk]},key=str)
        if feats(t)[fk] not in {feats(d)[fk] for d in demos}: continue
        for pm in itertools.product(PERMS,repeat=len(vals)):
            pmap=dict(zip(vals,pm))
            for ops in itertools.product(FILLOPS,repeat=3):
                if all(apply(d,pmap[feats(d)[fk]],ops)==intended(d) for d in demos):
                    out.add(str(apply(t,pmap[feats(t)[fk]],ops)))
    return out
SH=['circle','triangle','square','star','hex','diamond']
def rnd():
    s=random.sample(SH,3); return [[s[k],random.choice([1,2,3]),random.choice('SH')] for k in range(3)]
random.seed(5); found=[]
for _ in range(3000):
    demos=[rnd() for _ in range(3)]; t=rnd()
    if not ({d[0][2] for d in demos}=={'S','H'}): continue
    p=preds(demos,t)
    if p=={str(intended(t))}:
        # want: new top in some demo starts solid (toggle to hollow) and some starts hollow
        nt=[intended(d)[0][2] for d in demos]
        if set(nt)=={'S','H'} and len({o[1] for o in t})>1:
            found.append((demos,t,intended(t)))
            if len(found)>=5: break
print(len(found))
for f in found: print(f)
