set -e
cd /home/claude && rm -rf out && mkdir out && cp -r cz/kognitivni-baterie out/ && cp -r cb/cognitive-battery-en out/
cd /home/claude/fix && python3 patch_all.py /home/claude/out/kognitivni-baterie/assets/app.html cz >/dev/null && python3 patch_all.py /home/claude/out/cognitive-battery-en/assets/app.html en >/dev/null
cd /home/claude/out
for L in "kognitivni-baterie cz kb" "cognitive-battery-en en kben"; do set -- $L
  python3 /home/claude/fix2/patch_carry.py $1/assets/app.html $2 >/dev/null
  python3 /home/claude/fix2/patch_carry_php.py $1/includes/rest.php $3 >/dev/null
  python3 /home/claude/fix2/patch_ded.py $1/assets/app.html >/dev/null
  python3 /home/claude/fix3/patch_gwm.py $1/assets/app.html $2
done
for L in "kognitivni-baterie" "cognitive-battery-en"; do python3 /home/claude/fix4/patch_sk.py /home/claude/out/$L/assets/app.html; done
for L in "kognitivni-baterie" "cognitive-battery-en"; do python3 /home/claude/fix4/patch_sk2.py /home/claude/out/$L/assets/app.html; done
for L in "kognitivni-baterie" "cognitive-battery-en"; do python3 /home/claude/fix4/patch_sk3.py /home/claude/out/$L/assets/app.html; done
python3 /home/claude/fix5/patch_retest.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix5/patch_retest.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix5/patch_retest_php.py /home/claude/out/kognitivni-baterie/includes/rest.php kb
python3 /home/claude/fix5/patch_retest_php.py /home/claude/out/cognitive-battery-en/includes/rest.php kben
python3 /home/claude/fix6/patch_rtgraph.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix6/patch_rtgraph.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix6/patch_rtgraph_php.py /home/claude/out/kognitivni-baterie/includes/rest.php
python3 /home/claude/fix6/patch_rtgraph_php.py /home/claude/out/cognitive-battery-en/includes/rest.php
python3 /home/claude/fix7/patch_ceil.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix7/patch_ceil.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix7/patch_ceil_php.py /home/claude/out/kognitivni-baterie/includes/rest.php kb
python3 /home/claude/fix7/patch_ceil_php.py /home/claude/out/cognitive-battery-en/includes/rest.php kben
python3 /home/claude/fix8/patch_orig.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix8/patch_orig.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix8/patch_orig_php.py /home/claude/out/kognitivni-baterie/includes/rest.php kb
python3 /home/claude/fix8/patch_orig_php.py /home/claude/out/cognitive-battery-en/includes/rest.php kben
python3 /home/claude/fix9/patch_rtver.py /home/claude/out/kognitivni-baterie/assets/app.html
python3 /home/claude/fix9/patch_rtver.py /home/claude/out/cognitive-battery-en/assets/app.html
python3 /home/claude/fix9/patch_rtver_php.py /home/claude/out/kognitivni-baterie/includes/rest.php
python3 /home/claude/fix9/patch_rtver_php.py /home/claude/out/cognitive-battery-en/includes/rest.php
python3 /home/claude/fix10/patch_dv.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix10/patch_dv.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix10/patch_dv_php.py /home/claude/out/kognitivni-baterie
python3 /home/claude/fix10/patch_dv_php.py /home/claude/out/cognitive-battery-en
python3 /home/claude/fix11/patch_retest_prac.py /home/claude/out/kognitivni-baterie/assets/app.html
python3 /home/claude/fix11/patch_retest_prac.py /home/claude/out/cognitive-battery-en/assets/app.html

python3 /home/claude/fix13/patch_corsi.py /home/claude/out/kognitivni-baterie/assets/app.html cz
python3 /home/claude/fix13/patch_corsi.py /home/claude/out/cognitive-battery-en/assets/app.html en
python3 /home/claude/fix13/patch_corsi_php.py /home/claude/out/kognitivni-baterie
python3 /home/claude/fix13/patch_corsi_php.py /home/claude/out/cognitive-battery-en
python3 /home/claude/fix14/patch_touch.py /home/claude/out/kognitivni-baterie/assets/app.html
python3 /home/claude/fix14/patch_touch.py /home/claude/out/cognitive-battery-en/assets/app.html
