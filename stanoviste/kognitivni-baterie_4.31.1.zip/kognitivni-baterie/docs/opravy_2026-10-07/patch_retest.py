import sys
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
# dlaždice hotového testu: klikem nabídne opakování
if CZ:
    rep("<span class=\"tile-state\">${sc ? 'Hotovo' : ext ?", "<span class=\"tile-state\">${sc ? 'Hotovo · zkusit znovu' : ext ?")
else:
    rep("<span class=\"tile-state\">${sc ? 'Done' : ext ?", "<span class=\"tile-state\">${sc ? 'Done · retake' : ext ?")
rep("      b.disabled = !!sc;\n      b.addEventListener('click', () => ext ? runExtension(m.key, done[m.key]) : carry ? runCarry(m.key, carry) : runModule(m.key));",
    "      b.addEventListener('click', () => sc ? runRetest(m.key, sc) : ext ? runExtension(m.key, done[m.key]) : carry ? runCarry(m.key, carry) : runModule(m.key));")
rep(".tile.done{opacity:.55;cursor:default;border-style:dashed}", ".tile.done{opacity:.7;border-style:dashed}\n.tile.done:hover{opacity:.9}")
# KB: znovu odeslat výsledek téhož testu (opakování v témže sezení)
rep("return {mode, page, privacy, anonId, startSession, sync, flush, loadProgress, distribution, correlations, done:() => progress, LS};",
    "return {mode, page, privacy, anonId, startSession, sync, flush, loadProgress, distribution, correlations, done:() => progress, LS, resend:(k) => { delete sentScores[k]; }};")
H, ASK, B0, B1 = (('Zkusit test znovu?',
    "Tento test už máte hotový. Můžete ho udělat znovu – nový výsledek se uloží zvlášť jako opakování. Do srovnání s ostatními se dál počítá váš první výsledek (při opakování už úlohy znáte), nový výsledek ale uvidíte.",
    'Zpět', 'Zkusit znovu') if CZ else ('Retake this test?',
    "You have already completed this test. You can take it again – the new result is saved separately as a retake. Comparisons with others keep using your first result (on a retake you already know the tasks), but you will see your new score.",
    'Back', 'Retake'))
CORE = r"""
/* ===== Opakování hotového testu (retest) =====
   Hotový test lze spustit znovu. Výsledek se uloží jako opakování (výsledek: opakovani = pořadí opakování, predchozi_skore);
   do srovnání (distribuce) i korelací se dál počítá PRVNÍ výsledek osoby v dané skupině verzí – server bere první záznam.
   Bez zácviku; rozpracovaný běh se neukládá pro navázání. */
function retestAsk(){
  return new Promise(res => {
    const d = document.createElement('div'); d.className = 'mx-modal';
    d.innerHTML = `<div class="mx-box"><h2 style="margin-top:0">__H__</h2><p style="font-size:19px">__ASK__</p>
      <div class="actions" style="justify-content:center"><button class="btn ghost" type="button" data-a="0">__B0__</button><button class="btn" type="button" data-a="1">__B1__</button></div></div>`;
    document.body.appendChild(d);
    d.querySelectorAll('button').forEach(b => b.addEventListener('click', () => { d.remove(); res(b.dataset.a === '1'); }));
  });
}
async function runRetest(key, sc){
  if (!(await retestAsk())) return;
  const prevRaw = sc.hruby !== undefined ? sc.hruby : sc.raw_score, prevVer = sc.forma || sc.version || '';
  const n = (+sc.opakovani || ((+sc.pokusy || 1) - 1) || 0) + 1;
  S.scoresPrev = S.scoresPrev || {}; if (S.scores[key]) { (S.scoresPrev[key] = S.scoresPrev[key] || []).push(S.scores[key]); delete S.scores[key]; }
  if (typeof KB !== 'undefined' && KB.resend) KB.resend(key);
  S.retest = {key, n, prevRaw, prevVer, nacvik:S.nacvik}; S.nacvik = false;
  S.rows.push({test:key, polozka:'opakovani', faze:'opakovani', chyby:'opakování testu č. ' + n + ' (předchozí výsledek ' + (prevRaw ?? '') + ', verze ' + prevVer + ')', cas:new Date().toISOString()});
  ckClear(key); runModuleFresh(key);
}
function retestApply(){
  const r = S.retest; if (!r) return;
  const sc = S.scores && S.scores[r.key]; if (!sc || sc.opakovani !== undefined) return;
  sc.opakovani = r.n; sc.predchozi_skore = r.prevRaw; sc.predchozi_verze = r.prevVer;
  S.nacvik = r.nacvik; S.retest = null;
}
"""
CORE = CORE.replace('__H__', H).replace('__ASK__', ASK).replace('__B0__', B0).replace('__B1__', B1)
rep("/* ===== Převzetí odpovědí podle ID položky", CORE.strip('\n') + "\n/* ===== Převzetí odpovědí podle ID položky")
rep("function save(){\n  carryApply();", "function save(){\n  carryApply(); retestApply();")
rep("function ckSave(k, data){ if (S.carry && S.carry.key === k) return;", "function ckSave(k, data){ if ((S.carry && S.carry.key === k) || (S.retest && S.retest.key === k)) return;")
rep("  if (S.carryEnded) { carryRestore(S.carryEnded); S.carryEnded = null; }\n",
    "  if (S.carryEnded) { carryRestore(S.carryEnded); S.carryEnded = null; }\n  if (S.retest && !(S.scores && S.scores[S.retest.key])) { S.nacvik = S.retest.nacvik; S.retest = null; }   // nedokončené opakování\n")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
