import sys
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
YOU = 'Vy' if CZ else 'You'
rep("function kbDensitySVG(vals, mine, pred){", "function kbDensitySVG(vals, mine, pred, lbl){\n  lbl = lbl || {};")
rep(f'fill="var(--ink)">{YOU}</text>', f'fill="var(--ink)">${{lbl.mine || \'{YOU}\'}}</text>')
rep(">${KB_PRED_LBL}</text>", ">${lbl.pred || KB_PRED_LBL}</text>")
if CZ:
    RT = r"""/* opakování testu: v grafu plná čára = opakování, přerušovaná = předchozí výsledek; do srovnání se počítá první výsledek */
async function kbRetakeCard(k, raw, version, rt){
  const prev = typeof rt.prev === 'number' && !isNaN(rt.prev) ? rt.prev : null, two = prev !== null && prev !== raw;
  const d = await KB.distribution(k, version);
  const vals = d && d.bins ? d.bins.flatMap(b => Array(b.n).fill(b.x)) : [];
  const pct = vals.length ? Math.round(100 * vals.filter(v => v <= raw).length / vals.length) : null;
  const enough = d && d.n >= d.min_n, lab = rt.n > 1 ? rt.n + '. opakování' : 'opakování';
  return `<section class="card res-card"><h2>${MODULES[k].name} <span class="muted" style="font-size:16px;font-weight:600">· ${lab}</span></h2><p style="font-size:20px">Váš výsledek při opakování: <b>${raw}</b> bodů` + (prev !== null ? ` <span class="muted">(předtím ${prev})</span>` : '') + `</p>` +
    (enough ? kbDensitySVG(vals, raw, two ? prev : undefined, {mine:'Opakování', pred:'předtím'}) + `<p>Stejného nebo nižšího výsledku dosáhlo ${pct} % z ${d.n} lidí, kteří test vyplnili.</p><p class="muted" style="font-size:15px">Plná čára je výsledek opakování` + (two ? ', přerušovaná váš předchozí výsledek' : '') + `. Do srovnání s ostatními se počítá váš první výsledek – při opakování už úlohy znáte.</p>`
            : `<p class="muted">Zatím je málo dat pro srovnání (${d ? d.n : 0} z potřebných ${d ? d.min_n : 30}).</p>`) + `</section>`;
}
"""
else:
    RT = r"""/* retake: solid line = retake, dashed = previous result; comparisons use the first result */
async function kbRetakeCard(k, raw, version, rt){
  const prev = typeof rt.prev === 'number' && !isNaN(rt.prev) ? rt.prev : null, two = prev !== null && prev !== raw;
  const d = await KB.distribution(k, version);
  const vals = d && d.bins ? d.bins.flatMap(b => Array(b.n).fill(b.x)) : [];
  const pct = vals.length ? Math.round(100 * vals.filter(v => v <= raw).length / vals.length) : null;
  const enough = d && d.n >= d.min_n, ord = (n) => n + (n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th');
  const lab = rt.n > 1 ? ord(rt.n) + ' retake' : 'retake';
  return `<section class="card res-card"><h2>${MODULES[k].name} <span class="muted" style="font-size:16px;font-weight:600">· ${lab}</span></h2><p style="font-size:20px">Your retake result: <b>${raw}</b> points` + (prev !== null ? ` <span class="muted">(before ${prev})</span>` : '') + `</p>` +
    (enough ? kbDensitySVG(vals, raw, two ? prev : undefined, {mine:'Retake', pred:'before'}) + `<p>${pct} % of the ${d.n} people who took the test scored the same or lower.</p><p class="muted" style="font-size:15px">The solid line is your retake` + (two ? ', the dashed line your previous result' : '') + `. Comparisons with others use your first result – on a retake you already know the tasks.</p>`
            : `<p class="muted">There are not enough data for a comparison yet (${d ? d.n : 0} of the ${d ? d.min_n : 30} needed).</p>`) + `</section>`;
}
"""
rep("async function kbResultCard(k, raw, version, pred){\n", RT + "async function kbResultCard(k, raw, version, pred, rt){\n  if (rt && rt.n) return kbRetakeCard(k, raw, version, rt);\n")
rep("wrap.innerHTML = await kbResultCard(CUR.key, raw, MODULES[CUR.key].version || '');",
    "wrap.innerHTML = await kbResultCard(CUR.key, raw, MODULES[CUR.key].version || '', undefined, sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore)} : null);")
rep("mine[k] = {raw:v.raw_score, version:v.version, pred:typeof v.raw_pred === 'number' ? v.raw_pred : undefined}; });",
    "mine[k] = {raw:v.raw_score, version:v.version, pred:typeof v.raw_pred === 'number' ? v.raw_pred : undefined, rt:v.opakovani ? {n:+v.opakovani, prev:parseFloat(v.predchozi)} : null}; });")
rep("mine[k] = {raw:r, version:(MODULES[k] && MODULES[k].version) || ''}; });",
    "mine[k] = {raw:r, version:(MODULES[k] && MODULES[k].version) || '', rt:sc.opakovani ? {n:+sc.opakovani, prev:parseFloat(sc.predchozi_skore)} : null}; });")
rep("html += await kbResultCard(k, mine[k].raw, mine[k].version, mine[k].pred);", "html += await kbResultCard(k, mine[k].raw, mine[k].version, mine[k].pred, mine[k].rt);")
rep('<text x="${X(mine)}" y="${pad - 8}" text-anchor="middle" font-size="24"', '<text x="${X(mine)}" y="${pad - 8}" text-anchor="${X(mine) > W - 100 ? \'end\' : X(mine) < 100 ? \'start\' : \'middle\'}" font-size="24"')
rep('<text x="${X(pred)}" y="${pad + 16}" text-anchor="middle" font-size="17"', '<text x="${X(pred)}" y="${pad + 16}" text-anchor="${X(pred) > W - 70 ? \'end\' : X(pred) < 70 ? \'start\' : \'middle\'}" font-size="17"')
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
