import sys
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
rep("      if (!sc && pub && TEST_PREDECESSOR[m.key] && done[TEST_PREDECESSOR[m.key]]) novy = true;\n      const b = document.createElement('button'); b.type = 'button'; b.className = 'tile' + (sc ? ' done' : '') + (novy ? ' newver' : '');",
    "      if (!sc && pub && TEST_PREDECESSOR[m.key] && done[TEST_PREDECESSOR[m.key]]) novy = true;\n"
    "      const ceil = (sc && pub && !S.scores[m.key]) ? ceilFor(m.key, done[m.key]) : null;   // test se od minula změnil (nová verze v téže skupině)\n"
    "      const b = document.createElement('button'); b.type = 'button'; b.className = 'tile' + (sc && !ceil ? ' done' : '') + (novy || ceil ? ' newver' : '');")
if CZ:
    rep("<span class=\"tile-state\">${sc ? 'Hotovo · zkusit znovu' : ext ?", "<span class=\"tile-state\">${sc ? (ceil ? 'Test jsme upravili – můžete ho udělat znovu' : 'Hotovo · zkusit znovu') : ext ?")
else:
    rep("<span class=\"tile-state\">${sc ? 'Done · retake' : ext ?", "<span class=\"tile-state\">${sc ? (ceil ? 'Test updated – you can take it again' : 'Done · retake') : ext ?")
rep("b.addEventListener('click', () => sc ? runRetest(m.key, sc) :", "b.addEventListener('click', () => sc ? runRetest(m.key, sc, ceil) :")
H2, ASK2, B2 = (('Test jsme upravili',
    "Od vašeho pokusu jsme test upravili (opravené úlohy, nové úrovně nebo jiné časové limity). Když ho uděláte znovu, nový výsledek se počítá jako první pokus podle nových pravidel a do srovnání s ostatními půjde místo starého.",
    'Udělat test znovu') if CZ else ('Test updated',
    "We have updated this test since your attempt (fixed items, new levels or different time limits). If you take it again, the new result counts as your first attempt under the new rules and replaces the old one in comparisons with others.",
    'Take the test again'))
CEIL = r"""/* Test se od minula změnil (opravené úlohy, nové úrovně, jiné časové limity – nová verze v téže skupině srovnání): nový výsledek
   se počítá jako první pokus podle nových pravidel (nova_pravidla = 1; server ve srovnání i korelacích bere první výsledek
   nejnovější verze, kterou osoba dělala). Opakování téže verze se nepočítá. */
function ceilFor(key, prev){      // dřív dělaná starší verze téže skupiny srovnání (test se mezitím změnil)
  const cur = MODULES[key] && MODULES[key].version;
  if (!prev || !prev.version || !cur || prev.version === cur) return null;
  return (cmpVersions(key, cur) || '').split('|').includes(prev.version) ? {from:prev.version, to:cur} : null;
}
function ceilAsk(){
  return new Promise(res => {
    const d = document.createElement('div'); d.className = 'mx-modal';
    d.innerHTML = `<div class="mx-box"><h2 style="margin-top:0">__H2__</h2><p style="font-size:19px">__ASK2__</p>
      <div class="actions" style="justify-content:center"><button class="btn ghost" type="button" data-a="0">__B0__</button><button class="btn" type="button" data-a="1">__B2__</button></div></div>`;
    document.body.appendChild(d);
    d.querySelectorAll('button').forEach(b => b.addEventListener('click', () => { d.remove(); res(b.dataset.a === '1'); }));
  });
}
"""
CEIL = CEIL.replace('__H2__', H2).replace('__ASK2__', ASK2).replace('__B2__', B2).replace('__B0__', 'Zpět' if CZ else 'Back')
rep("async function runRetest(key, sc){\n  if (!(await retestAsk())) return;",
    CEIL + "async function runRetest(key, sc, ceil){\n  if (!(await (ceil ? ceilAsk() : retestAsk()))) return;")
rep("  S.retest = {key, n, prevRaw, prevVer, nacvik:S.nacvik}; S.nacvik = false;\n  S.rows.push({test:key, polozka:'opakovani', faze:'opakovani', chyby:'opakování testu č. ' + n + ' (předchozí výsledek ' + (prevRaw ?? '') + ', verze ' + prevVer + ')', cas:new Date().toISOString()});",
    "  S.retest = {key, n, prevRaw, prevVer, nacvik:S.nacvik, strop:!!ceil}; S.nacvik = false;\n"
    "  S.rows.push(ceil ? {test:key, polozka:'nova_pravidla', faze:'nova_pravidla', chyby:'nová verze testu (' + ceil.from + ' → ' + ceil.to + '), předchozí výsledek ' + (prevRaw ?? '') + ' – počítá se jako první pokus podle nových pravidel', cas:new Date().toISOString()}\n"
    "                   : {test:key, polozka:'opakovani', faze:'opakovani', chyby:'opakování testu č. ' + n + ' (předchozí výsledek ' + (prevRaw ?? '') + ', verze ' + prevVer + ')', cas:new Date().toISOString()});")
rep("  sc.opakovani = r.n; sc.predchozi_skore = r.prevRaw; sc.predchozi_verze = r.prevVer;",
    "  if (r.strop) sc.nova_pravidla = 1; else sc.opakovani = r.n;\n  sc.predchozi_skore = r.prevRaw; sc.predchozi_verze = r.prevVer;")
rep("  const sc = S.scores && S.scores[r.key]; if (!sc || sc.opakovani !== undefined) return;",
    "  const sc = S.scores && S.scores[r.key]; if (!sc || sc.opakovani !== undefined || sc.nova_pravidla !== undefined) return;")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
