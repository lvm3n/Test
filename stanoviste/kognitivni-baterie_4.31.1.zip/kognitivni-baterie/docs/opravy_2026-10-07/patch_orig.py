import sys
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
rep("  async function distribution(key, version){\n    const vs = cmpVersions(key, version);\n    try { return await get('distribution?test=' + encodeURIComponent(key) + (vs ? '&version=' + encodeURIComponent(vs) : '')); } catch (e) { return null; } }",
    "  async function distribution(key, version, zaklad){\n    const vs = cmpVersions(key, version);\n    try { return await get('distribution?test=' + encodeURIComponent(key) + (vs ? '&version=' + encodeURIComponent(vs) : '') + (zaklad ? '&zaklad=' + encodeURIComponent(zaklad) : '')); } catch (e) { return null; } }")
if CZ:
    F = r"""/* výsledek přepočtený po zkrácení časových limitů: hlavní srovnání = původní výsledek mezi lidmi, kteří test dělali
   za stejných (původních) podmínek; přepočtený výsledek jen v poznámce. Když je takových lidí málo, platí dosavadní zobrazení. */
async function kbOrigCard(k, raw, version, pred){
  const d = await KB.distribution(k, version, 'puvodni');
  if (!d || !(d.n >= d.min_n)) return '';
  const vals = d.bins.flatMap(b => Array(b.n).fill(b.x));
  const pct = Math.round(100 * vals.filter(v => v <= pred).length / vals.length);
  return `<section class="card res-card"><h2>${MODULES[k].name}</h2><p style="font-size:20px">Váš výsledek: <b>${pred}</b> bodů</p>` +
    kbDensitySVG(vals, pred) + `<p>Stejného nebo nižšího výsledku dosáhlo ${pct} % z ${d.n} lidí, kteří test dělali za stejných podmínek jako vy.</p>` +
    `<p class="muted" style="font-size:15px">Test má teď kratší časové limity. Podle nich by váš výsledek byl ${raw} bodů – proto vás porovnáváme jen s lidmi, kteří test dělali s původními limity.</p></section>`;
}
"""
else:
    F = r"""/* result rescored after shorter time limits: main comparison = original score among people who took the test under the
   same (original) conditions; the rescored result only in a note. With too few such people the previous display is used. */
async function kbOrigCard(k, raw, version, pred){
  const d = await KB.distribution(k, version, 'puvodni');
  if (!d || !(d.n >= d.min_n)) return '';
  const vals = d.bins.flatMap(b => Array(b.n).fill(b.x));
  const pct = Math.round(100 * vals.filter(v => v <= pred).length / vals.length);
  return `<section class="card res-card"><h2>${MODULES[k].name}</h2><p style="font-size:20px">Your result: <b>${pred}</b> points</p>` +
    kbDensitySVG(vals, pred) + `<p>${pct} % of the ${d.n} people who took the test under the same conditions as you scored the same or lower.</p>` +
    `<p class="muted" style="font-size:15px">The test now has shorter time limits. Under them your result would be ${raw} points – that is why you are compared only with people who took the test with the original limits.</p></section>`;
}
"""
rep("async function kbResultCard(k, raw, version, pred, rt){\n  if (rt && rt.n) return kbRetakeCard(k, raw, version, rt);\n",
    F + "async function kbResultCard(k, raw, version, pred, rt){\n  if (rt && rt.n) return kbRetakeCard(k, raw, version, rt);\n  if (typeof pred === 'number' && pred !== raw) { const oc = await kbOrigCard(k, raw, version, pred); if (oc) return oc; }\n")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
