import sys
PATH, P = sys.argv[1], sys.argv[2]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
# 1) opakování v témže sezení se nesmí zahodit jako duplicita
rep("""    if ($wpdb->get_var($wpdb->prepare("SELECT id FROM " . """ + P + """_table('scores') . " WHERE session_id = %d AND test_key = %s AND test_version = %s LIMIT 1", $s->id, $key, $ver))) {
        return array('ok' => true, 'duplicate' => true);
    }""",
"""    $rep = (isset($p['score']) && is_array($p['score']) && isset($p['score']['opakovani'])) ? intval($p['score']['opakovani']) : 0;   // opakování testu (retest)
    foreach ($wpdb->get_col($wpdb->prepare("SELECT data FROM " . """ + P + """_table('scores') . " WHERE session_id = %d AND test_key = %s AND test_version = %s", $s->id, $key, $ver)) as $dj) {
        $dd = json_decode((string) $dj, true);
        if ((is_array($dd) && isset($dd['opakovani']) ? intval($dd['opakovani']) : 0) === $rep) { return array('ok' => true, 'duplicate' => true); }
    }""")
# 2) srovnání: první výsledek osoby V RÁMCI požadované skupiny verzí (dřív první vůbec – výsledek nové verze po převzetí odpovědí se nezapočítal)
rep("""        $vs = array_slice($vs, 0, 20);
        $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')';
        foreach ($vs as $v) { $args[] = $v; }""",
"""        $vs = array_slice($vs, 0, 20);
        $in = implode(',', array_fill(0, count($vs), '%s'));
        $sql = str_replace('s2.raw_score IS NOT NULL)', 's2.raw_score IS NOT NULL AND s2.test_version IN (' . $in . '))', $sql);   // první výsledek v rámci skupiny verzí
        foreach ($vs as $v) { $args[] = $v; }
        $sql .= ' AND sc.test_version IN (' . $in . ')';
        foreach ($vs as $v) { $args[] = $v; }""")
if P == 'kb':
    rep("""    if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }""",
        """    if ($vs) {
        $in = implode(',', array_fill(0, count($vs), '%s'));
        $sql = str_replace('s2.raw_score IS NOT NULL)', 's2.raw_score IS NOT NULL AND s2.test_version IN (' . $in . '))', $sql);
        foreach ($vs as $v) { $args[] = $v; }
        $sql .= ' AND sc.test_version IN (' . $in . ')'; foreach ($vs as $v) { $args[] = $v; }
    }""")
# 3) /progress: počet dokončených pokusů (pro číslování opakování)
rep("""        $d = json_decode((string) $x->data, true);
        $out[$x->test_key] = array('version' => $x->test_version,""",
"""        $d = json_decode((string) $x->data, true);
        $pok = isset($out[$x->test_key]['pokusy']) ? $out[$x->test_key]['pokusy'] : 0;
        $out[$x->test_key] = array('pokusy' => $x->raw_score === null ? $pok : $pok + 1, 'version' => $x->test_version,""")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
