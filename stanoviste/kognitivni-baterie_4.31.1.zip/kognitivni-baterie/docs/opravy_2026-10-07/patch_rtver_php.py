import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
old = "            if (isset($d['predchozi_skore']) && is_numeric($d['predchozi_skore'])) { $out[$x->test_key]['predchozi'] = floatval($d['predchozi_skore']); }\n"
assert s.count(old) == 1
s = s.replace(old, old + "            if (isset($d['predchozi_verze'])) { $out[$x->test_key]['predchozi_verze'] = (string) $d['predchozi_verze']; }\n")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
