import sys
PATH, P = sys.argv[1], sys.argv[2]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
HELP = """
/* Výběr výsledku osoby pro srovnání a korelace (od 3.85.0): v rámci skupiny verzí platí PRVNÍ výsledek NEJNOVĚJŠÍ verze,
   kterou osoba dělala. Opakování téže verze se nepočítá (člověk úlohy zná); když se ale test mezitím změnil (opravené
   úlohy, nové úrovně, jiné časové limity) a člověk udělal novou verzi, počítá se první výsledek nové verze. */
function P_ceil_rules() { return array(); }   // (dřívější seznam testů s rozšířeným stropem – už se nepoužívá)
function P_ceil_pick($rows, $rule = null) {      // řádky seřazené podle id → jeden řádek na osobu
    $pick = array(); $seen = array();
    foreach ($rows as $x) {
        $pid = $x->participant_id; $v = (string) $x->test_version;
        if (!isset($pick[$pid])) { $pick[$pid] = $x; $seen[$pid] = array($v => 1); continue; }
        if (!isset($seen[$pid][$v])) { $seen[$pid][$v] = 1; $pick[$pid] = $x; }   // první výsledek nové verze nahradí starší
    }
    return array_values($pick);
}
""".replace('P_', P + '_')
# vložit pomocné funkce před distribuci
rep("/* GET /distribution?test=", HELP.strip('\n') + "\n\n/* GET /distribution?test=")
# distribuce
rep("""    $vals = array();
    foreach ($wpdb->get_results($wpdb->prepare($sql, $args)) as $x) {
        $v = floatval($x->raw_score);""",
"""    $vals = array();
    $rule = """ + P + """_ceil_rules();
    if (!empty($vs)) {                                      // první výsledek nejnovější verze (viz *_ceil_pick)
        $sql = preg_replace('/ AND sc\\.id = \\(SELECT MIN\\(s2\\.id\\).*?\\)\\)/s', '', $sql, 1);
        array_splice($args, 1, count($vs));
        $sql = str_replace('SELECT sc.raw_score,', 'SELECT sc.id, sc.participant_id, sc.raw_score,', $sql) . ' ORDER BY sc.id ASC';
        $res = """ + P + """_ceil_pick($wpdb->get_results($wpdb->prepare($sql, $args)));
    } else {
        $res = $wpdb->get_results($wpdb->prepare($sql, $args));
    }
    foreach ($res as $x) {
        $v = floatval($x->raw_score);""")
# korelace
rep("""    $rows = $wpdb->get_results("SELECT sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, p.mode, p.code, p.anon_id FROM \"""",
    """    $seenV = array();
    $rows = $wpdb->get_results("SELECT sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, sc.data, p.mode, p.code, p.anon_id FROM \"""")
rep("""        if (!isset($by[$pk][$r->test_key])) { $by[$pk][$r->test_key] = floatval($r->raw_score); }""",
    """        if (!isset($by[$pk][$r->test_key])) { $by[$pk][$r->test_key] = floatval($r->raw_score); $seenV[$pk][$r->test_key] = array($r->test_version => 1); }
        elseif (!isset($seenV[$pk][$r->test_key][$r->test_version])) { $seenV[$pk][$r->test_key][$r->test_version] = 1; $by[$pk][$r->test_key] = floatval($r->raw_score); }   // první výsledek nové verze""")
# hodnoty z anglické verze (jen v české)
if P == 'kb':
    rep("""    $sql = "SELECT sc.raw_score FROM $T sc""", """    $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $T sc""")
    rep("""    return array_map('floatval', $wpdb->get_col($wpdb->prepare($sql, $args)));""",
        """    if ($vs) {
        $sql = preg_replace('/ AND sc\\.id = \\(SELECT MIN\\(s2\\.id\\).*?\\)\\)/s', '', $sql, 1);
        array_splice($args, 1, count($vs));
        return array_map(function ($x) { return floatval($x->raw_score); }, kb_ceil_pick($wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args))));
    }
    return array_map(function ($x) { return floatval($x->raw_score); }, $wpdb->get_results($wpdb->prepare($sql, $args)));""")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
