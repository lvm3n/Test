import json, re, sys
M12 = json.load(open('/home/claude/fix/m12_r2.json'))
PAP = json.load(open('/home/claude/papfix.json'))
LANG = sys.argv[2]; PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, (old[:80], n)
    s = s.replace(old, new)
def bankline(name):
    m = re.search(r'^const ' + name + r' = (.*);$', s, re.M); assert m, name
    return m
# ---------------- Matice V12 ----------------
m = bankline('BANK_M12'); old = json.loads(m.group(1))
assert old['version'] == 'M12-40-pilot-r1' and [i['id'] for i in old['items']] == [i.get('revised_from', i['id']) for i in M12['items']]
s = s[:m.start(1)] + json.dumps(M12, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
rep("quantity_operator_dial:(o) => o.S_dir !== undefined ? shape('chevron', 50, 50, 28, {color:'blue', dir:o.S_dir})\n      : shape('chevron', 28, 50, 17, {color:'blue', dir:o.A_dir})",
    "quantity_operator_dial:(o) => o.S_dir !== undefined ? shape('notched', 50, 50, 30, {color:'blue', dir:o.S_dir})\n      : shape('notched', 28, 50, 18, {color:'blue', dir:o.A_dir})")
rep('<polygon points="0,-28 11,0 0,28 -11,0"', '<polygon points="0,-30 13,-6 5,-6 5,26 -5,26 -5,-6 -13,-6"')
rep('<line x1="-30" y1="0" x2="30" y2="0" stroke="#C9D1DA" stroke-width="5" stroke-linecap="round"/>',
    '<line x1="-30" y1="0" x2="20" y2="0" stroke="#AEB8C4" stroke-width="5" stroke-linecap="round"/><polygon points="36,0 18,-10 18,10" fill="#8A96A3"/>')
# ---------------- Skládání papíru ----------------
m = bankline('BANK_GV'); gv = json.loads(m.group(1))
for k, it in enumerate(gv['papir']):
    if it['id'] in PAP:
        fx = PAP[it['id']]; new = dict(it)
        new['id'] = it['id'] + '_r'; new['revised_from'] = it['id']
        new['holes'] = fx['holes']; new['answer'] = fx['answer']
        new['facety'] = dict(it['facety']); new['facety']['polickek'] = len(fx['answer'])
        gv['papir'][k] = new
assert sum(1 for it in gv['papir'] if it['id'].endswith('_r') and it.get('revised_from') in PAP) == 4
s = s[:m.start(1)] + json.dumps(gv, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
rep("capFor:() => 75, /* jednotně 75 s */ version:'Gv-PAP-v13e'", "capFor:() => 75, /* jednotně 75 s */ version:'Gv-PAP-v13f'")
rep("['Gv-PAP-v13'], ['Gv-PAP-v13e']],", "['Gv-PAP-v13'], ['Gv-PAP-v13e'], ['Gv-PAP-v13f']],")
# ---------------- Stanoviště: banka ----------------
NEWK = ['between', 'common', 'dist', 'samecol', 'diffcol']
m = bankline('BANK_STAN'); st = json.loads(m.group(1))
assert st['verze'] == 'ST-v7.1-35'
st['verze'] = 'ST-v7.2-35'
ren = []
for it in st['items']:
    if any(r[0] in NEWK for r in it['rules']):
        it['revised_from'] = it['id']; it['id'] = it['id'] + '_r'; ren.append(it['id'])
assert len(ren) == 21
s = s[:m.start(1)] + json.dumps(st, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
# ---------------- Stanoviště: texty ----------------
if LANG == 'cz':
    rep("  const LOC = {orange:'oranžovém', blue:'modrém', green:'zeleném'}, CNOM = {orange:'oranžové', blue:'modré', green:'zelené'};",
        "  const LOC = {orange:'oranžovém', blue:'modrém', green:'zeleném'}, CNOM = {orange:'oranžové', blue:'modré', green:'zelené'};\n"
        "  const INS = {hvezda:'hvězdou', srdce:'srdcem', trojuhelnik:'trojúhelníkem', ctverec:'čtvercem', mesic:'měsícem', kapka:'kapkou', kriz:'křížem', blesk:'bleskem'};\n"
        "  const KROK = (n) => n + ' ' + (n === 1 ? 'krok' : n < 5 ? 'kroky' : 'kroků');")
    rep("""    ruleText:([k, a, b]) => k === 'adj' ? cap(NOM[a]) + ' je vedle ' + GEN[b] : k === 'nadj' ? cap(NOM[a]) + ' není vedle ' + GEN[b]
      : k === 'col' ? cap(NOM[a]) + ' je na ' + LOC[b] + ' stanovišti' : cap(NOM[a]) + ' není na ' + LOC[b] + ' stanovišti',""",
"""    ruleText:([k, a, b, c]) => k === 'adj' ? cap(NOM[a]) + ' je vedle ' + GEN[b] : k === 'nadj' ? cap(NOM[a]) + ' není vedle ' + GEN[b]
      : k === 'col' ? cap(NOM[a]) + ' je na ' + LOC[b] + ' stanovišti' : k === 'ncol' ? cap(NOM[a]) + ' není na ' + LOC[b] + ' stanovišti'
      : k === 'between' ? cap(NOM[a]) + ' je mezi ' + INS[b] + ' a ' + INS[c]
      : k === 'common' ? cap(NOM[c]) + ' je vedle ' + GEN[a] + ' i vedle ' + GEN[b]
      : k === 'dist' ? 'Nejkratší cesta mezi ' + INS[a] + ' a ' + INS[b] + ': ' + KROK(c)
      : k === 'samecol' ? cap(NOM[a]) + ' a ' + NOM[b] + ': stanoviště stejné barvy'
      : cap(NOM[a]) + ' a ' + NOM[b] + ': stanoviště různé barvy',
    /* další druhy pravidel (od ST-v7.2 vykreslené; vysvětlí se před první úlohou, kde se objeví) */
    newH:'Nový druh pravidla', newH2:'Nové druhy pravidel', newOk:'Rozumím',
    newHead:{between:'Mezi', common:'Společný soused', dist:'Vzdálenost', samecol:'Stejná barva', diffcol:'Různá barva'},
    newText:{between:'Prostřední objekt sousedí s oběma krajními. Krajní dva spolu přímo spojené nejsou (přeškrtnutý oblouk).',
      common:'Horní objekt sousedí s oběma dolními. Jestli spolu sousedí i ty dva dolní, pravidlo neříká.',
      dist:'Nejkratší cesta mezi oběma objekty má přesně tolik kroků, kolik je nakresleno. Prázdná kolečka jsou kterákoli stanoviště po cestě.',
      samecol:'Oba objekty stojí na stanovištích stejné barvy – na jaké, pravidlo neříká. Spojené být nemusí.',
      diffcol:'Objekty stojí na stanovištích různé barvy. Spojené být mohou, ale nemusí.'},
    newNote:['Co v pravidle není nakreslené, může, ale nemusí platit. Čas na úlohu se spustí, až klepnete na „Rozumím“.',
             'Co v pravidle není nakreslené, může, ale nemusí platit. Čas na úlohu se spustí, až klepneš na „Rozumím“.'],
    newEx:{between:['between', 'hvezda', 'srdce', 'mesic'], common:['common', 'srdce', 'mesic', 'hvezda'], dist:['dist', 'srdce', 'hvezda', 3],
      samecol:['samecol', 'srdce', 'hvezda'], diffcol:['diffcol', 'srdce', 'hvezda']},""")
    rep("""    keyRule:['<b>Důležité:</b> na každém stanovišti bude nakonec právě jeden objekt a žádné nezůstane prázdné. Ostatní objekty si můžete rozmístit jako pomůcku – hodnotí se jen ten označený. Nejdřív si to vyzkoušíte na třech cvičných úlohách.',
             '<b>Důležité:</b> na každém stanovišti bude nakonec právě jeden objekt a žádné nezůstane prázdné. Ostatní objekty si můžeš rozmístit jako pomůcku – hodnotí se jen ten označený. Nejdřív si to vyzkoušíš na třech cvičných úlohách.'],""",
"""    keyRule:['<b>Důležité:</b> na každém stanovišti bude nakonec právě jeden objekt a žádné nezůstane prázdné. Pokládáte jen označený objekt, ostatní jsou dole pro přehled. Později přibudou další druhy pravidel – před první úlohou s novým pravidlem se objeví vysvětlení. Nejdřív si to vyzkoušíte na třech cvičných úlohách.',
             '<b>Důležité:</b> na každém stanovišti bude nakonec právě jeden objekt a žádné nezůstane prázdné. Pokládáš jen označený objekt, ostatní jsou dole pro přehled. Později přibudou další druhy pravidel – před první úlohou s novým pravidlem se objeví vysvětlení. Nejdřív si to vyzkoušíš na třech cvičných úlohách.'],""")
else:
    rep("""    ruleText:([k, a, b]) => k === 'adj' ? 'The ' + NOM[a] + ' is next to the ' + NOM[b] : k === 'nadj' ? 'The ' + NOM[a] + ' is not next to the ' + NOM[b]
      : k === 'col' ? 'The ' + NOM[a] + ' is on a ' + b + ' station' : 'The ' + NOM[a] + ' is not on a ' + b + ' station',""",
"""    ruleText:([k, a, b, c]) => k === 'adj' ? 'The ' + NOM[a] + ' is next to the ' + NOM[b] : k === 'nadj' ? 'The ' + NOM[a] + ' is not next to the ' + NOM[b]
      : k === 'col' ? 'The ' + NOM[a] + ' is on a ' + b + ' station' : k === 'ncol' ? 'The ' + NOM[a] + ' is not on a ' + b + ' station'
      : k === 'between' ? 'The ' + NOM[a] + ' is between the ' + NOM[b] + ' and the ' + NOM[c]
      : k === 'common' ? 'The ' + NOM[c] + ' is next to both the ' + NOM[a] + ' and the ' + NOM[b]
      : k === 'dist' ? 'Shortest path between the ' + NOM[a] + ' and the ' + NOM[b] + ': ' + c + (c === 1 ? ' step' : ' steps')
      : k === 'samecol' ? 'The ' + NOM[a] + ' and the ' + NOM[b] + ': same station colour'
      : 'The ' + NOM[a] + ' and the ' + NOM[b] + ': different station colours',
    /* further rule types (drawn from ST-v7.2; explained before the first item that uses them) */
    newH:'A new kind of rule', newH2:'New kinds of rules', newOk:'Got it',
    newHead:{between:'Between', common:'Shared neighbour', dist:'Distance', samecol:'Same colour', diffcol:'Different colour'},
    newText:{between:'The middle object is next to both outer ones. The two outer ones are not directly connected (crossed-out arc).',
      common:'The top object is next to both bottom ones. Whether the two bottom ones are next to each other, the rule does not say.',
      dist:'The shortest path between the two objects has exactly as many steps as drawn. Empty circles are any stations along the way.',
      samecol:'Both objects stand on stations of the same colour – which colour, the rule does not say. They need not be connected.',
      diffcol:'The objects stand on stations of different colours. They may or may not be connected.'},
    newNote:'Anything the rule does not show may or may not hold. The time for the item starts when you tap “Got it”.',
    newEx:{between:['between', 'hvezda', 'srdce', 'mesic'], common:['common', 'srdce', 'mesic', 'hvezda'], dist:['dist', 'srdce', 'hvezda', 3],
      samecol:['samecol', 'srdce', 'hvezda'], diffcol:['diffcol', 'srdce', 'hvezda']},""")
    rep("You may place the other objects as a help – only the marked one is scored.",
        "You place only the marked object; the others are shown below for reference. Later, further kinds of rules appear – before the first item with a new rule you will see an explanation.")
# ---------------- Stanoviště: kreslení nových pravidel ----------------
rep("""  function ruleSvg(r){
    const [k, a, b] = r, y = 24; let s = '';""",
"""  /* další druhy pravidel (ST-v7.2): mezi · společný soused · vzdálenost · stejná / různá barva stanoviště */
  const NEWK = ['between', 'common', 'dist', 'samecol', 'diffcol'];
  const stn = (cx, cy, r, t, tr) => anyStation(cx, cy, r) + tok(t, cx, cy, tr);
  const edge = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#9AA7B1" stroke-width="3.2" stroke-linecap="round"/>`;
  function ruleSvgNew(r){
    const k = r[0]; let s = '', vb = '0 0 120 48';
    if (k === 'between') {             // [k, prostřední, krajní, krajní]; krajní spolu nesousedí
      vb = '0 -3 120 53';
      s = '<path d="M22 24 Q60 -2 98 24" fill="none" stroke="#9AA7B1" stroke-width="2.4" stroke-dasharray="5 4"/>' + slash(60, 11, 8)
        + edge(18, 36, 102, 36) + stn(18, 36, 12.5, r[2], 9) + stn(60, 36, 12.5, r[1], 9) + stn(102, 36, 12.5, r[3], 9);
    } else if (k === 'common') {       // [k, a, b, společný soused]
      s = edge(60, 13, 22, 36) + edge(60, 13, 98, 36) + stn(60, 13, 11.5, r[3], 8) + stn(22, 36, 11.5, r[1], 8) + stn(98, 36, 11.5, r[2], 8);
    } else if (k === 'dist') {         // [k, a, b, počet kroků nejkratší cesty]
      const n = r[3], xa = 16, xb = 104, y = 24;
      s = edge(xa, y, xb, y);
      for (let i = 1; i < n; i++) s += `<circle cx="${(xa + (xb - xa) * i / n).toFixed(1)}" cy="${y}" r="6" fill="#fff" stroke="#7B8794" stroke-width="1.6" stroke-dasharray="3 2.4"/>`;
      s += stn(xa, y, 13, r[1], 9) + stn(xb, y, 13, r[2], 9);
    } else {                            // samecol / diffcol: [k, a, b]
      const ring = (cx) => `<circle cx="${cx}" cy="29" r="15.5" fill="#E9EDF1" stroke="#7B8794" stroke-width="1.6" stroke-dasharray="4.5 3"/>`;
      s = `<circle cx="50" cy="8" r="4" fill="${SC.orange}"/><circle cx="60" cy="8" r="4" fill="${SC.blue}"/><circle cx="70" cy="8" r="4" fill="${SC.green}"/>`
        + ring(28) + tok(r[1], 28, 29, 11) + ring(92) + tok(r[2], 92, 29, 11)
        + '<line x1="51" y1="25" x2="69" y2="25" stroke="#1f2933" stroke-width="3.4" stroke-linecap="round"/><line x1="51" y1="33" x2="69" y2="33" stroke="#1f2933" stroke-width="3.4" stroke-linecap="round"/>'
        + (k === 'diffcol' ? slash(60, 29, 12) : '');
    }
    return `<svg viewBox="${vb}" role="img" aria-label="${TX.ruleText(r)}">${s}</svg><div class="st-rcap">${TX.ruleText(r)}</div>`;
  }
  function showNewRules(kinds, done){
    const box = $('#' + K + '-newrule');
    box.innerHTML = `<div class="st-nr-box" role="dialog" aria-modal="true"><h2>${kinds.length > 1 ? TX.newH2 : TX.newH}</h2>` +
      kinds.map(k => `<div class="st-nr-item"><div class="st-rule">${ruleSvg(TX.newEx[k])}</div><div><b>${TX.newHead[k]}</b><p>${T(TX.newText[k])}</p></div></div>`).join('') +
      `<p class="st-nr-note">${T(TX.newNote)}</p><div class="actions"><button class="btn" id="${K}-nrok">${TX.newOk}</button></div></div>`;
    box.hidden = false;
    const b = $('#' + K + '-nrok'); try { b.focus(); } catch (e) {}
    b.onclick = () => { box.hidden = true; box.innerHTML = ''; done(); };
  }
  function ruleSvg(r){
    if (NEWK.includes(r[0])) return ruleSvgNew(r);
    const [k, a, b] = r, y = 24; let s = '';""")
rep("""      <div class="st-fb" id="${K}-fb" aria-live="polite"></div>""",
    """      <div class="st-fb" id="${K}-fb" aria-live="polite"></div>
      <div class="st-newrule" id="${K}-newrule" hidden></div>""")
rep("""    draw();
    U.t0 = performance.now();                                    // čas běží až po vykreslení
    const tl = $('#' + K + '-time'); tl.classList.remove('warn'); tl.textContent = '';
    const cap = CAP(item.level);
    if (phase !== 'tut' && !ST_UNTIMED && !S.untimed) {
      tl.textContent = TX.timeNote(cap);
      warnT = setTimeout(() => { if (!U.done) { tl.textContent = TX.timeWarn; tl.classList.add('warn'); } }, Math.max(0, cap - 15) * 1000);
      timer = setTimeout(() => submit(true), cap * 1000);
    }
  }""",
"""    draw();
    const tl = $('#' + K + '-time'); tl.classList.remove('warn'); tl.textContent = '';
    const cap = CAP(item.level);
    const go = () => {
      U.t0 = performance.now();                                  // čas běží až po vykreslení (a po vysvětlení nového pravidla)
      if (phase !== 'tut' && !ST_UNTIMED && !S.untimed) {
        tl.textContent = TX.timeNote(cap);
        warnT = setTimeout(() => { if (!U.done) { tl.textContent = TX.timeWarn; tl.classList.add('warn'); } }, Math.max(0, cap - 15) * 1000);
        timer = setTimeout(() => submit(true), cap * 1000);
      }
    };
    /* první úloha s novým druhem pravidla: nejdřív krátké vysvětlení, čas se spustí až po „Rozumím“ */
    const nk = phase === 'tut' ? [] : item.rules.map(r => r[0]).filter((k, i, a) => NEWK.includes(k) && a.indexOf(k) === i && !(ST.kinds || []).includes(k));
    U.intro = nk.join('+');
    if (nk.length) showNewRules(nk, () => { ST.kinds = (ST.kinds || []).concat(nk); go(); }); else go();
  }""")
rep("""    return it.rules.every(([k, a, b]) => k === 'col' ? it.colors[P[a]] === b : k === 'ncol' ? it.colors[P[a]] !== b : k === 'adj' ? adj(P[a], P[b]) : !adj(P[a], P[b])) ? 1 : 0;""",
"""    const dist = (s0, t0) => { const d = {[s0]:0}, q = [s0]; while (q.length) { const x = q.shift(); for (let y = 0; y < it.n; y++) if (d[y] === undefined && adj(x, y)) { d[y] = d[x] + 1; q.push(y); } } return d[t0]; };
    const ok = ([k, a, b, c]) => k === 'col' ? it.colors[P[a]] === b : k === 'ncol' ? it.colors[P[a]] !== b : k === 'adj' ? adj(P[a], P[b]) : k === 'nadj' ? !adj(P[a], P[b])
      : k === 'samecol' ? it.colors[P[a]] === it.colors[P[b]] : k === 'diffcol' ? it.colors[P[a]] !== it.colors[P[b]]
      : k === 'between' ? adj(P[a], P[b]) && adj(P[a], P[c]) && !adj(P[b], P[c]) : k === 'common' ? adj(P[c], P[a]) && adj(P[c], P[b])
      : k === 'dist' ? dist(P[a], P[b]) === c : true;
    return it.rules.every(ok) ? 1 : 0;""")
rep("""        '; target_moves=' + U.moves + '; input_mode=' +""", """        '; target_moves=' + U.moves + '; new_rule_intro=' + (U.intro || '') + '; input_mode=' +""")
rep(""".st-rule svg{display:block;width:100%;height:auto}""",
""".st-rule svg{display:block;width:100%;height:auto}
.st-rcap{font-size:13px;line-height:1.25;color:var(--muted);text-align:center;padding:0 4px 4px}
.st-newrule{position:fixed;inset:0;z-index:60;background:rgba(20,30,40,.9);display:flex;align-items:center;justify-content:center;padding:14px}
.st-newrule[hidden]{display:none}
.st-nr-box{background:#fff;border-radius:16px;max-width:640px;width:100%;max-height:92vh;overflow:auto;padding:16px 18px;box-shadow:0 10px 40px rgba(0,0,0,.25)}
.st-nr-box h2{margin:0 0 10px;font-size:22px}
.st-nr-item{display:grid;grid-template-columns:minmax(0,210px) 1fr;gap:12px;align-items:center;margin-bottom:12px}
.st-nr-item b{font-size:18px}
.st-nr-item p{margin:4px 0 0;font-size:17px;line-height:1.35}
.st-nr-note{font-size:16px;color:var(--muted)}
@media (max-width:640px){.st-nr-item{grid-template-columns:1fr}}""")
open(PATH, 'w', encoding='utf-8').write(s)
print('ok', PATH, 'stations renamed', len(ren))
