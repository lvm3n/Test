import json, itertools
from hyp import predictions
b=json.load(open('m12_r2.json')); I={it['id']:it for it in b['items']}
def check(name, demos, t, outkeys, dom, options, ci, enc):
    P=predictions(demos,t,outkeys,dom)
    ok=all(len(P[k])==1 for k in P)
    pred={k:next(iter(P[k])) for k in P}
    cons=[i for i,o in enumerate(options) if all(enc(o)[k]==pred[k] for k in outkeys)]
    print(name,'unique-per-attr' if ok else 'AMBIG '+str(P),'| consistent options',cons,'key',ci)
# 16
it=I['V12-16_r2']; f=lambda o:{'shape':o['shape'],'color':o['color']}
D=[(f(r[0]),f(r[1])) for r in it['stem'][:3]]; check('16',D,f(it['stem'][3][0]),['shape','color'],{'shape':'S','color':'C'},it['options'],it['correct_index'],f)
# 26
it=I['V12-26_r']; f=lambda o:dict(o)
D=[(r[0],r[1]) for r in it['stem'][:3]]; check('26',D,it['stem'][3][0],['shape','n','border'],{'shape':'S','n':'N','border':'N'},it['options'],it['correct_index'],f)
# 36
it=I['V12-36_r']; top,bot=it['stem']
def fi(c): d={'Ls':c['L']['shape'],'Lc':c['L']['color'],'Rs':c['R']['shape'],'Rc':c['R']['color']}; d['sameS']=d['Ls']==d['Rs']; d['sameC']=d['Lc']==d['Rc']; return d
fo=lambda o:{'shape':o['shape'],'color':o['color'],'border':o['border']}
D=[(fi(top[k]),fo(bot[k])) for k in range(3)]; check('36',D,fi(top[3]),['shape','color','border'],{'Ls':'S','Rs':'S','shape':'S','Lc':'C','Rc':'C','color':'C','border':'B','sameS':'X','sameC':'X'},it['options'],it['correct_index'],fo)
# 33: routing slots + boolean fill
it=I['V12-33_r2']; rows=it['stem']
slots=lambda c:{'A0':c['A'][0],'A1':c['A'][1],'A2':c['A'][2],'A3':c['A'][3],'B0':c['B'][0],'B1':c['B'][1],'B2':c['B'][2],'B3':c['B'][3]}
fo=lambda o:{'o0':o['out'][0],'o1':o['out'][1],'o2':o['out'][2],'o3':o['out'][3]}
D=[(slots(r[0]),fo(r[1])) for r in rows[:3]]
dom={k:('S' if k[1] in '02' else 'C') for k in ['A0','A1','A2','A3','B0','B1','B2','B3']}; dom.update({'o0':'S','o2':'S','o1':'C','o3':'C'})
check('33-routing',D,slots(rows[3][0]),['o0','o1','o2','o3'],dom,it['options'],it['correct_index'],fo)
fills=[(r[0]['A'][4],r[0]['B'][4],r[1]['out'][4]) for r in rows[:3]]; ta,tb=rows[3][0]['A'][4],rows[3][0]['B'][4]
cons=set()
for tab in itertools.product([0,1],repeat=4):
    F=lambda a,b:tab[2*a+b]
    if all(F(a,bb)==o for a,bb,o in fills): cons.add(F(ta,tb))
print('33-fill: all 16 boolean functions consistent predictions',cons,'(XOR=',ta^tb,')')
NAT={'const0':lambda a,b:0,'const1':lambda a,b:1,'A':lambda a,b:a,'B':lambda a,b:b,'notA':lambda a,b:1-a,'notB':lambda a,b:1-b,'and':lambda a,b:a&b,'or':lambda a,b:a|b,'nand':lambda a,b:1-(a&b),'nor':lambda a,b:1-(a|b),'xor':lambda a,b:a^b,'xnor':lambda a,b:1-(a^b)}
print('33-fill natural consistent:',[k for k,F in NAT.items() if all(F(a,bb)==o for a,bb,o in fills)])
full=[i for i,o in enumerate(it['options']) if o['out'][:4]==['triangle','red','hex','green']]; print('33 options with correct routing:',full,[it['options'][i]['out'][4] for i in full])
# 39
it=I['V12-39_r2']; rows=it['stem']
def diffs(c): return [int(c['A'][k]!=c['B'][k]) for k in ('shape','color','fill')]
demos=[(diffs(r[0]),r[1]['bits']) for r in rows[:3]]; t=diffs(rows[3][0])
feats=lambda d:{'s':d[0],'c':d[1],'f':d[2],'ns':1-d[0],'nc':1-d[1],'nf':1-d[2],'z':0,'o':1}
preds=[]
for k in range(3):
    pk={fn for fn in feats(t) if all(feats(d)[fn]==o[k] for d,o in demos)}
    preds.append({feats(t)[fn] for fn in pk}); 
print('39 per-bit predictions',preds,'key',it['options'][it['correct_index']]['bits'])
