import itertools
from hyp import predictions
S=['circle','square','triangle','diamond']; C=['red','yellow','blue','green']
dom={'shape':'S','color':'C'}
best=[]
for perm_s in itertools.permutations(S,3):
 for perm_c in itertools.permutations(C,3):
  CS=dict(zip(C[:3],perm_s)); SC=dict(zip(S[:3],perm_c))
  f=lambda i:{'shape':CS[i['color']],'color':SC[i['shape']]}
  allin=[{'shape':s,'color':c} for s in S[:3] for c in C[:3]]
  for demo in itertools.combinations(allin,3):
   for t in allin:
    if t in demo: continue
    D=[(i,f(i)) for i in demo]; out=f(t)
    P=predictions(D,t,['shape','color'],dom)
    if all(set(P[k])=={out[k]} for k in P):
      flags=(out==t, out in [o for _,o in D], sum(o==i for i,o in D), sum(o['shape']==i['shape'] or o['color']==i['color'] for i,o in D))
      best.append((flags,CS,SC,demo,t,out))
print(len(best))
best.sort(key=lambda x:(x[0][0],x[0][1],x[0][2],x[0][3]))
for b in best[:5]: print(b)
sel=[b for b in best if b[0][:3]==(False,False,0) and b[5]['shape']!=b[4]['shape'] and b[5]['color']!=b[4]['color'] and b[0][3]==0]
print(len(sel))
for b in sel[:8]: print(b[1:])
