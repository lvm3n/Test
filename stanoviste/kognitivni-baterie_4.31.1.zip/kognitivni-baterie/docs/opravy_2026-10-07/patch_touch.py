import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
old = ".screen{display:none;min-height:100vh;padding:clamp(16px,3vw,40px)}"
assert s.count(old) == 1
s = s.replace(old, old + """
.screen{min-height:100dvh}   /* mobil: 100vh je vyšší než viditelná plocha (lišta prohlížeče) → stránka šla mírně posouvat */
/* testové dlaždice a klávesy: dotyk na nich nikdy nezačne posouvat stránku, takže klepnutí s mírným pohybem prstu neprojede */
.sp-opt,.sp-key,.dv-tile,.mr-cell,.por-cell,.pb-card,.ded-ab{touch-action:none;-webkit-user-select:none;user-select:none}""")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
