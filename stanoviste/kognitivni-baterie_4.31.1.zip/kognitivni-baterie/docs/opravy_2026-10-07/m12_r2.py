import json, copy
def opt(*a): return list(a)
NEW = {}
def S(shape,color,**k): d={'shape':shape,'color':color}; d.update(k); return d
# ---------- 16: tři ukázky (jinak nejde vyloučit „výstup podle tvaru“) ----------
NEW['V12-16_r']=dict(id='V12-16_r2', stem=[
  [S('circle','yellow'), S('square','red')],
  [S('circle','blue'),   S('diamond','red')],
  [S('triangle','blue'), S('diamond','green')],
  [S('triangle','yellow'), None]],
 options=[S('square','green'),S('diamond','green'),S('square','red'),S('square','yellow'),S('triangle','green'),S('triangle','yellow')],
 option_models=['correct','copy_row3_output_same_shape','copy_row1_output_same_color','color_kept','shape_kept','no_change'], correct_index=0,
 principle='Výstupní tvar určuje vstupní barva (žlutá→čtverec, modrá→kosočtverec), výstupní barvu vstupní tvar (kruh→červená, trojúhelník→zelená). Tři ukázky: 1.–2. řádek stejný tvar, jiná barva; 2.–3. řádek stejná barva, jiný tvar.',
 notes='r2: přidán třetí řádek. Se dvěma ukázkami šlo každou vazbu vysvětlit i opačně (tvar→tvar apod.); teď je konzistentní jen zamýšlené přiřazení.')
# ---------- 24: rotace musí být vidět u všech tvarů ----------
def R(shape,border,d,color='purple'): return {'shape':shape,'border':border,'dir':d,'color':color}
NEW['V12-24']=dict(id='V12-24_r', stem=[R('triangle',0,0),R('notched',1,2),R('flag',0,4),None,R('notched',0,0),R('flag',1,2),R('triangle',0,4)],
 options=[R('triangle',1,6),R('triangle',0,6),R('flag',1,6),R('triangle',1,4),R('notched',1,6),R('triangle',1,6,'red')],
 option_models=['correct','border_omitted','shape_phase','orientation_phase','shape_wrong','wrong_color'], correct_index=0,
 principle='Vnitřní chybějící člen musí splnit současně cyklus tvaru (trojúhelník–šipka–vlajka), střídání ohraničení a otáčení o 90°.',
 notes='r: kruh a čtverec nahrazeny tvary, u nichž je otočení o 90° vidět (dřív bylo otáčení vidět jen u trojúhelníku).')
# ---------- 22: šipka místo „mašle“ (chevron vypadá po otočení o 180° skoro stejně) ----------
NEW['V12-22']=dict(id='V12-22_r', notes='r: tvar „chevron“ (mašle) nahrazen šipkou – otočení o 180° skoro nebylo vidět, takže správná odpověď vypadala téměř jako „jedna čtvrtotáčka“ a „ignoruj body“ jako „dvě čtvrtotáčky“.')
# ---------- 26: třetí ukázka, aby nešlo „výstup podle počtu/podle rámečku“ ----------
def CB(shape,n,b): return {'shape':shape,'n':n,'border':b}
NEW['V12-26']=dict(id='V12-26_r', stem=[
  [CB('circle',1,2),CB('circle',2,1)],
  [CB('square',1,3),CB('square',3,1)],
  [CB('triangle',3,2),CB('triangle',2,3)],
  [CB('diamond',2,1),None]],
 options=[CB('diamond',1,2),CB('diamond',2,1),CB('diamond',1,1),CB('diamond',2,2),CB('triangle',1,2),CB('diamond',3,1)],
 option_models=['correct','no_swap','count_from_border_only','border_from_count_only','wrong_shape','count_plus_one'], correct_index=0,
 principle='Počet prvků a počet rámečků si vymění hodnoty. Tři ukázky vylučují pravidla typu „výstup podle počtu“ nebo „podle rámečku“.',
 notes='r: dřív se dvěma ukázkami sedělo i přiřazení podle počtu (D) nebo podle rámečku (B).')
# ---------- 28: viditelné otočení o 180° (jen nové kreslení scény) ----------
NEW['V12-28']=dict(id='V12-28_r', notes='r: kosočtverec nahrazen nesouměrnou šipkou – otočení o 180° bylo neviditelné a dvě možnosti vypadaly stejně.')
# ---------- 33: třetí ukázka výplně (XOR jednoznačně) ----------
NEW['V12-33_r']=dict(id='V12-33_r2', stem=[
  [{'A':['kite','green','triangle','purple',1],'B':['flag','yellow','chevron','blue',1]},{'out':['flag','purple','triangle','yellow',0]}],
  [{'A':['star','red','diamond','green',0],'B':['circle','purple','square','yellow',0]},{'out':['circle','green','diamond','purple',0]}],
  [{'A':['hex','yellow','circle','blue',1],'B':['diamond','red','kite','green',0]},{'out':['diamond','blue','circle','red',1]}],
  [{'A':['chevron','blue','hex','red',0],'B':['triangle','green','star','purple',1]},None]],
 options=[{'out':['triangle','blue','hex','green',1]},{'out':['chevron','red','star','green',1]},{'out':['triangle','green','hex','red',1]},{'out':['triangle','red','star','green',1]},{'out':['triangle','red','hex','green',1]},{'out':['hex','red','triangle','green',1]}],
 option_models=['outer_color_from_A_outer','copy_same_source_shapes','colors_not_crossed','wrong_inner_source','correct','roles_swapped'], correct_index=4,
 notes='r2: přidána třetí ukázka (výplně plná + prázdná → plná). Se dvěma ukázkami (obě výstupy prázdné) bylo nejjednodušší „vždy prázdná“. Odstraněna možnost lišící se jen výplní.')
# ---------- 35: tři ukázky, nový horní objekt se mění oběma směry ----------
def T3(*p): return {'parts':[list(x) for x in p]}
NEW['V12-35_r']=dict(id='V12-35_r2', stem=[
  [T3(('triangle',2,'solid'),('circle',2,'solid'),('star',3,'hollow')), T3(('star',3,'solid'),('triangle',2,'solid'),('circle',2,'solid'))],
  [T3(('star',2,'hollow'),('square',2,'hollow'),('diamond',1,'solid')), T3(('square',2,'solid'),('diamond',1,'solid'),('star',2,'hollow'))],
  [T3(('star',3,'hollow'),('hex',2,'solid'),('triangle',1,'hollow')), T3(('hex',2,'hollow'),('triangle',1,'hollow'),('star',3,'hollow'))],
  [T3(('square',1,'hollow'),('hex',3,'solid'),('diamond',2,'hollow')), None]],
 options=[T3(('diamond',2,'solid'),('square',1,'hollow'),('hex',3,'solid')), T3(('hex',3,'solid'),('diamond',2,'hollow'),('square',1,'hollow')),
          T3(('hex',3,'hollow'),('diamond',2,'solid'),('square',1,'solid')), T3(('hex',3,'hollow'),('diamond',2,'hollow'),('square',1,'hollow')),
          T3(('square',1,'hollow'),('hex',3,'solid'),('diamond',2,'hollow')), T3(('hex',3,'hollow'),('square',1,'hollow'),('diamond',2,'hollow'))],
 option_models=['wrong_condition_branch','permute_without_toggle','toggle_all_after_permutation','correct','no_change','swapped_bottom'], correct_index=3,
 principle='Výplň horního objektu určuje směr otočení trojice: plný → proti směru hodinových ručiček (horní jde vlevo dolů), prázdný → po směru (horní jde vpravo dolů). Po otočení se přepne výplň objektu, který skončil nahoře.',
 notes='r2: třetí ukázka; nový horní objekt se v ukázkách mění z prázdného na plný i z plného na prázdný (dřív sedělo „nový horní bude plný“).')
# ---------- 36: čtvrtý sloupec (3 ukázky) ----------
def IN(Ls,Lc,Rs,Rc): return {'mode':'input','L':{'shape':Ls,'color':Lc},'R':{'shape':Rs,'color':Rc}}
def OUT(s,c,b): return {'mode':'output','shape':s,'color':c,'border':b}
NEW['V12-36']=dict(id='V12-36_r', stem=[
  [IN('triangle','red','triangle','yellow'),IN('star','blue','circle','blue'),IN('triangle','blue','triangle','blue'),IN('star','red','circle','yellow')],
  [OUT('square','yellow',2),OUT('circle','blue',1),OUT('circle','yellow',2),None]],
 options=[OUT('square','blue',1),OUT('square','yellow',1),OUT('circle','blue',1),OUT('square','blue',2),OUT('square','red',1),OUT('star','blue',1)],
 option_models=['correct','color_copied_from_right','shape_from_right_shape','wrong_relational_border','color_copied_from_left','copy_left_shape'], correct_index=0,
 principle='Výstupní tvar je kód barvy levého objektu (červená→čtverec, modrá→kruh), výstupní barva kód tvaru pravého objektu (trojúhelník→žlutá, kruh→modrá); dvojitý rámeček, když mají oba objekty stejný tvar. Tři hotové sloupce vylučují ostatní přiřazení.',
 notes='r: přidán třetí hotový sloupec. Se dvěma sloupci šlo vše odvodit jen z tvaru pravého objektu (→ B).')
# ---------- 37: šipka místo čáry, 4 dvojice ----------
def A(n,c,d): return {'n':n,'color':c,'dir':d}
NEW['V12-37']=dict(id='V12-37_r', stem=[A(1,'blue',0),A(1,'red',6),A(2,'blue',2),None,A(3,'blue',4),A(3,'red',2),A(4,'blue',6),A(4,'red',0)],
 options=[A(2,'red',4),A(2,'red',2),A(2,'red',0),A(2,'blue',4),A(1,'red',4),A(3,'red',4)],
 option_models=['correct','use_blue_map','same_direction_as_blue','wrong_color','wrong_count','next_count'], correct_index=0,
 principle='Dvojice podle počtu (modrá, červená). Modrá šipka se s každým dalším počtem otáčí o 90° doprava, červená o 90° doleva. Chybí červená dvojka.',
 notes='r: čára nahrazena šipkou (čára vypadá po otočení o 180° stejně) a přidána čtvrtá dvojice – se třemi body šlo u červené i otáčení doprava.')
# ---------- 39: tři ukázky ----------
def DI(a,b): return {'mode':'input','A':a,'B':b}
def O(*b): return {'mode':'output','bits':list(b)}
def ob(s,c,f): return {'shape':s,'color':c,'fill':f}
NEW['V12-39_r']=dict(id='V12-39_r2', stem=[
  [DI(ob('circle','blue','solid'),ob('square','red','solid')),O(1,1,0)],
  [DI(ob('triangle','yellow','solid'),ob('triangle','red','hollow')),O(0,1,1)],
  [DI(ob('star','green','hollow'),ob('star','green','hollow')),O(0,0,0)],
  [DI(ob('diamond','blue','hollow'),ob('star','blue','solid')),None]],
 options=[O(1,1,1),O(0,1,1),O(1,0,1),O(1,1,0),O(0,0,1),O(1,0,0)],
 option_models=['mark_all_different','copy_demo2','correct','copy_demo1','miss_shape_difference','miss_fill_difference'], correct_index=2,
 principle='Tři okénka = rozdíl tvaru, barvy, výplně mezi dvěma objekty. Ukázky 110, 011 a 000 určují význam každého okénka.',
 notes='r2: se dvěma ukázkami (100, 011) se barva a výplň vždy měnily spolu → nešlo určit, které okénko je barva (E). Třetí ukázka a jiná první ukázka to rozliší.')

def apply(bank):
    items=bank['items']; log=[]
    for i,it in enumerate(items):
        if it['id'] in NEW:
            ch=NEW[it['id']]; old=it['id']; new=copy.deepcopy(it)
            for k,v in ch.items():
                if k=='notes': new['notes']=(v)
                else: new[k]=v
            new['revised_from']=old
            items[i]=new; log.append((old,new['id']))
    bank['version']='M12-40-pilot-r2'
    return log
if __name__=='__main__':
    import sys
    b=json.load(open('/home/claude/m12.json')); print(apply(b)); json.dump(b,open('/home/claude/fix/m12_r2.json','w'),ensure_ascii=False)
