const fs=require('fs');
let src=fs.readFileSync('gv.js','utf8').split("const B=require")[0].replace("const GV_DRAW","var GV_DRAW"); eval(src);
const B=require('/home/claude/gv.json').papir;
const REFL = {V:[1, 0, 3, 2], H:[3, 2, 1, 0], D:[0, 3, 2, 1], A:[2, 1, 0, 3]};
// cells lying on a diagonal crease at the time of a diagonal fold
function crease(it){const bad=new Set();for(let s=0;s<it.folds.length;s++){const f=it.folds[s];if(f[0]!=='D'&&f[0]!=='A')continue;const m=GV_DRAW.mapCells(it.n,it.folds,s);
  const occ=Object.values(m.pos),r0=Math.min(...occ.map(p=>p[0])),c0=Math.min(...occ.map(p=>p[1])),c1=Math.max(...occ.map(p=>p[1]));const w=c1-c0+1;
  for(const o in m.pos){const [r,c]=m.pos[o];const rr=r-r0,cc=c-c0;const sg=f[0]==='D'?cc-rr:rr+cc-(w-1);if(sg===0)bad.add(o);}}return bad;}
function unfold(it,holes){const m=GV_DRAW.mapCells(it.n,it.folds,it.folds.length);const out=[];const bad=crease(it);
  holes.forEach(h=>{for(const o in m.pos){if(m.pos[o][0]===h[0]&&m.pos[o][1]===h[1]){if(bad.has(o))console.log('  !! preimage on crease',o);let ori=h.length>2?h[2]:-1;if(ori>=0)[...m.hist[o]].reverse().forEach(t=>{ori=REFL[t][ori];});out.push(o.split(',').map(Number).concat(ori>=0?[ori]:[]));}}});return out;}
const plan={PAP_071:[[0,2,0]],PAP_072:[[1,5,1],[1,3,3]],PAP_077:[[3,-2,1]],PAP_078:[[0,2,2],[-1,3,0]]};
const res={};
for(const id in plan){const it=B.find(x=>x.id===id);console.log(id,'crease cells',[...crease(it)].join(' '));const a=unfold(it,plan[id]);console.log(' holes',JSON.stringify(plan[id]),'-> answer',JSON.stringify(a));res[id]={holes:plan[id],answer:a};}
fs.writeFileSync('papfix.json',JSON.stringify(res));
// sanity: existing diagonal shape items, do any of their preimages lie on crease?
for(const it of B){ if(it.cut||!it.folds.some(f=>f[0]==='D'||f[0]==='A'))continue; const bad=crease(it); const m=GV_DRAW.mapCells(it.n,it.folds,it.folds.length);
  const hit=[];it.holes.forEach(h=>{for(const o in m.pos)if(m.pos[o][0]===h[0]&&m.pos[o][1]===h[1]&&bad.has(o))hit.push(o)}); console.log('existing',it.id,it.folds,'holes on crease preimages:',hit.join(' ')||'none');}
