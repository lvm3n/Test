import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
old = "        if (is_array($d) && (isset($d['hruby_pred_upravou'])"
assert s.count(old) == 1
s = s.replace(old, "        if (is_array($d) && !empty($d['opakovani'])) {   // opakování testu → popisek v grafu výsledku\n"
                   "            $out[$x->test_key]['opakovani'] = intval($d['opakovani']);\n"
                   "            if (isset($d['predchozi_skore']) && is_numeric($d['predchozi_skore'])) { $out[$x->test_key]['predchozi'] = floatval($d['predchozi_skore']); }\n"
                   "        }\n" + old)
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
