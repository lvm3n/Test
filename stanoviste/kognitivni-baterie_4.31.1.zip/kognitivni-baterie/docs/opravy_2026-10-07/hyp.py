# Generic hypothesis checker: each output attribute = (a) constant, (b) copy of an input attribute (same domain),
# (c) arbitrary lookup table from ONE input attribute. Returns set of predictions per output attr.
def predictions(demos, target, out_keys, dom):
    # demos: list of (inp dict, out dict); target inp dict; dom: attr -> domain name
    res = {}
    for ok in out_keys:
        preds = {}
        outs = [o[ok] for _, o in demos]
        if len(set(outs)) == 1: preds.setdefault(outs[0], []).append('const')
        for ik in target:
            # copy
            if dom.get(ik) == dom.get(ok) and all(i[ik] == o[ok] for i, o in demos):
                preds.setdefault(target[ik], []).append('copy:' + ik)
            # lookup
            tab = {}; okk = True
            for i, o in demos:
                if i[ik] in tab and tab[i[ik]] != o[ok]: okk = False; break
                tab[i[ik]] = o[ok]
            if okk and target[ik] in tab:
                preds.setdefault(tab[target[ik]], []).append('lookup:' + ik)
        res[ok] = preds
    return res
