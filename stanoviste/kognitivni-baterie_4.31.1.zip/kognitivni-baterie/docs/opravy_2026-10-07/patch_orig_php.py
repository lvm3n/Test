import sys
PATH, P = sys.argv[1], sys.argv[2]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
HELP = """
/* zaklad=puvodni: srovnání výsledků přepočtených po zkrácení časových limitů – PŮVODNÍ výsledek (před přepočtem) jen mezi
   výsledky, které vznikly za původních podmínek (mají příznak přepočtu). Vrací null, když řádek do tohoto srovnání nepatří. */
function P_orig_value($data) {
    $d = json_decode((string) $data, true);
    if (!is_array($d) || !(isset($d['prepocet_limity']) || isset($d['prepocet']))) { return null; }
    $pv = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : (isset($d['hruby_puvodni']) ? $d['hruby_puvodni'] : null);
    return is_numeric($pv) ? floatval($pv) : null;
}
""".replace('P_', P + '_')
rep("/* GET /distribution?test=", HELP.strip('\n') + "\n\n/* GET /distribution?test=")
rep("    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));\n    $sql = \"SELECT sc.raw_score, sc.test_version, sc.data FROM \"",
    "    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));\n    $orig = $r->get_param('zaklad') === 'puvodni';      // srovnání za původních časových limitů\n    $sql = \"SELECT sc.raw_score, sc.test_version, sc.data FROM \"")
rep("    foreach ($res as $x) {\n        $v = floatval($x->raw_score);",
    "    foreach ($res as $x) {\n        $v = floatval($x->raw_score);\n        if ($orig) { $ov = " + P + "_orig_value($x->data); if ($ov !== null) { $vals[] = $ov; } continue; }")
if P == 'kb':
    rep("$vals = array_merge($vals, kb_en_values($key, isset($vs) ? $vs : array(), $amin, $amax));", "$vals = array_merge($vals, kb_en_values($key, isset($vs) ? $vs : array(), $amin, $amax, $orig));")
    rep("function kb_en_values($key, $vs, $amin, $amax) {", "function kb_en_values($key, $vs, $amin, $amax, $orig = false) {")
    rep("        return array_map(function ($x) { return floatval($x->raw_score); }, kb_ceil_pick($wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args))));\n    }\n    return array_map(function ($x) { return floatval($x->raw_score); }, $wpdb->get_results($wpdb->prepare($sql, $args)));",
        "        $res = kb_ceil_pick($wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args)));\n    } else {\n        $res = $wpdb->get_results($wpdb->prepare($sql, $args));\n    }\n"
        "    $out = array();\n    foreach ($res as $x) { if ($orig) { $ov = kb_orig_value($x->data); if ($ov !== null) { $out[] = $ov; } } else { $out[] = floatval($x->raw_score); } }\n    return $out;")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
