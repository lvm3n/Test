import json,itertools,collections
b=json.load(open('st.json'))
def analyze(it,sem):
    n=it['n'];E=set(map(tuple,it['edges']));A=lambda x,y:(x,y) in E or (y,x) in E
    nb={i:[j for j in range(n) if A(i,j)] for i in range(n)}
    def D(s,t):
        d={s:0};q=[s]
        for x in q:
            for y in nb[x]:
                if y not in d:d[y]=d[x]+1;q.append(y)
        return d.get(t,99)
    col=it['colors']
    def ok(P,r):
        k=r[0]
        if k=='adj':return A(P[r[1]],P[r[2]])
        if k=='nadj':return not A(P[r[1]],P[r[2]])
        if k=='col':return col[P[r[1]]]==r[2]
        if k=='ncol':return col[P[r[1]]]!=r[2]
        if k=='samecol':return col[P[r[1]]]==col[P[r[2]]]
        if k=='diffcol':return col[P[r[1]]]!=col[P[r[2]]]
        if k=='dist':return D(P[r[1]],P[r[2]])==r[3]
        if k=='common':return sem['common'](P,r,A)
        if k=='between':return sem['between'](P,r,A)
    objs=list(it['fixed'])+it['free'];free=it['free'];fixed=it['fixed']
    rest=[v for v in range(n) if v not in fixed.values()]
    sols=[]
    for perm in itertools.permutations(rest):
        P=dict(fixed);P.update(zip(free,perm))
        if all(ok(P,r) for r in it['rules']):sols.append(P)
    return sols
sems={
 'common_a_adj_bc':{'common':lambda P,r,A:A(P[r[1]],P[r[2]]) and A(P[r[1]],P[r[3]]) ,'between':lambda P,r,A:A(P[r[3]],P[r[1]]) and A(P[r[3]],P[r[2]])},
 'common_abc_shared':{'common':lambda P,r,A:A(P[r[1]],P[r[3]]) and A(P[r[2]],P[r[3]]),'between':lambda P,r,A:A(P[r[3]],P[r[1]]) and A(P[r[3]],P[r[2]]) and not A(P[r[1]],P[r[2]])},
}
for name,sem in sems.items():
    bad=[]
    for it in b['practice']+b['items']:
        sols=analyze(it,sem)
        tg=set(s[it['target']] for s in sols)
        good= tg=={it['answer']} and any(all(s[o]==it.get('solution',{}).get(o,s[o]) for o in s) for s in sols)
        if not good: bad.append((it['id'],len(sols),tg,it['answer']))
    print(name,'mismatches:',bad)
print('----')
for strict in (False,True):
  sem={'between':(lambda P,r,A,s=strict:A(P[r[1]],P[r[2]]) and A(P[r[1]],P[r[3]]) and (not s or not A(P[r[2]],P[r[3]]))),
       'common':(lambda P,r,A,s=strict:A(P[r[3]],P[r[1]]) and A(P[r[3]],P[r[2]]) and (not s or not A(P[r[1]],P[r[2]])))}
  bad=[]
  for it in b['practice']+b['items']:
    sols=analyze(it,sem); tg=set(s[it['target']] for s in sols)
    solok = 'solution' not in it or any(all(s[o]==v for o,v in it['solution'].items()) for s in sols)
    if tg!={it['answer']} or not solok: bad.append((it['id'],len(sols),tg,it['answer'],solok))
  print('strict' if strict else 'loose',bad)
print('==== combos')
import types
for sb in (0,1):
 for sc in (0,1):
  for dmode in ('eq','ge','le'):
    sem={'between':(lambda P,r,A,s=sb:A(P[r[1]],P[r[2]]) and A(P[r[1]],P[r[3]]) and (not s or not A(P[r[2]],P[r[3]]))),
       'common':(lambda P,r,A,s=sc:A(P[r[3]],P[r[1]]) and A(P[r[3]],P[r[2]]) and (not s or not A(P[r[1]],P[r[2]])))}
    import builtins
    def analyze2(it):
      n=it['n'];E=set(map(tuple,it['edges']));A=lambda x,y:(x,y) in E or (y,x) in E
      nb={i:[j for j in range(n) if A(i,j)] for i in range(n)}
      def D(s,t):
        d={s:0};q=[s]
        for x in q:
          for y in nb[x]:
            if y not in d:d[y]=d[x]+1;q.append(y)
        return d.get(t,99)
      col=it['colors']
      def ok(P,r):
        k=r[0]
        if k=='dist':
          d=D(P[r[1]],P[r[2]]); return d==r[3] if dmode=='eq' else (d>=r[3] if dmode=='ge' else d<=r[3])
        if k in('adj','nadj'):return A(P[r[1]],P[r[2]])==(k=='adj')
        if k=='col':return col[P[r[1]]]==r[2]
        if k=='ncol':return col[P[r[1]]]!=r[2]
        if k=='samecol':return col[P[r[1]]]==col[P[r[2]]]
        if k=='diffcol':return col[P[r[1]]]!=col[P[r[2]]]
        return sem[k](P,r,A)
      free=it['free'];fixed=it['fixed'];rest=[v for v in range(n) if v not in fixed.values()]
      out=[]
      for perm in itertools.permutations(rest):
        P=dict(fixed);P.update(zip(free,perm))
        if all(ok(P,r) for r in it['rules']):out.append(P)
      return out
    bad=[]
    for it in b['practice']+b['items']:
      sols=analyze2(it); tg=set(s[it['target']] for s in sols)
      solok='solution' not in it or any(all(s[o]==v for o,v in it['solution'].items()) for s in sols)
      if tg!={it['answer']} or not solok: bad.append((it['id'],len(sols),sorted(tg),it['answer'],solok))
    print(sb,sc,dmode,len(bad),bad)
