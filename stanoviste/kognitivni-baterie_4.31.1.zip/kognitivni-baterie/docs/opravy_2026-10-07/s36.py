import itertools, random
from hyp import predictions
S=['circle','square','triangle','star']; C=['red','yellow','blue']
LC2S={'red':'square','yellow':'triangle','blue':'circle'}; RS2C={'circle':'blue','square':'red','triangle':'yellow','star':'red'}
def f(i): return {'shape':LC2S[i['Lc']],'color':RS2C[i['Rs']],'border':2 if i['Ls']==i['Rs'] else 1}
def feat(i): d=dict(i); d['sameS']=i['Ls']==i['Rs']; d['sameC']=i['Lc']==i['Rc']; return d
dom={'Ls':'S','Rs':'S','shape':'S','Lc':'C','Rc':'C','color':'C','border':'B','sameS':'X','sameC':'X'}
allin=[{'Ls':a,'Lc':b,'Rs':c,'Rc':d} for a in S for b in C for c in S[:3] for d in C]
random.seed(1); res=[]
for _ in range(400000):
  demo=random.sample(allin,3); t=random.choice(allin)
  if t in demo: continue
  D=[(feat(i),f(i)) for i in demo]; out=f(t)
  P=predictions(D,feat(t),['shape','color','border'],dom)
  if all(set(P[k])=={out[k]} for k in P):
    if out in [o for _,o in D]: continue
    if t['Ls']==t['Rs'] : continue   # cíl s různými tvary (rámeček 1)
    res.append((demo,t,out))
print(len(res))
for r in res[:6]: print(r)
sel=[r for r in res if any(d['Ls']==d['Rs'] for d in r[0]) and any(d['Ls']!=d['Rs'] for d in r[0]) and len({d['Lc'] for d in r[0]})>=2 and len({d['Rs'] for d in r[0]})>=2]
print(len(sel))
# prefer: each demo shapes/colours varied, target uses star somewhere (unseen shape as nuisance)
sel.sort(key=lambda r:(-(r[1]['Ls']=='star'), -len({(d['Ls'],d['Lc'],d['Rs'],d['Rc']) for d in r[0]})))
for r in sel[:8]: print(r)
