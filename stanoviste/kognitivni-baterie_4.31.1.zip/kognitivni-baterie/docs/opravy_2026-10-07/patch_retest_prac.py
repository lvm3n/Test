import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:80], s.count(old)); s = s.replace(old, new)
rep("nacvik:S.nacvik, strop:!!ceil}; S.nacvik = false;", "nacvik:S.nacvik, strop:!!ceil};   // opakování se zácvikem jako první pokus (standardizace)")
rep("   Bez zácviku; rozpracovaný běh se neukládá pro navázání. */", "   Se zácvikem jako první pokus (standardizace); rozpracovaný běh se neukládá pro navázání. */")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
