import itertools, random
from hyp import predictions
S=['circle','square','triangle','diamond']
def f(i): return {'shape':i['shape'],'n':i['border'],'border':i['n']}
dom={'shape':'S','n':'N','border':'N'}
allin=[{'shape':s,'n':a,'border':b} for s in S for a in (1,2,3) for b in (1,2,3) if a!=b]
res=[]
for demo in itertools.combinations(allin,3):
  if len({d['shape'] for d in demo})<3: continue
  for t in allin:
    if t in demo or t['shape'] in [d['shape'] for d in demo]: continue
    D=[(i,f(i)) for i in demo]; out=f(t)
    P=predictions(D,t,['shape','n','border'],dom)
    if all(set(P[k])=={out[k]} for k in P): res.append((demo,t,out))
print(len(res)); 
for r in res[:10]: print(r)
sel=[]
for demo,t,out in res:
  pairs=[(d['n'],d['border']) for d in demo]
  if len(set(pairs))<3 or (t['n'],t['border']) in pairs: continue
  D=[(i,f(i)) for i in demo]; P=predictions(D,t,['shape','n','border'],dom)
  hyps={k:sum(P[k].values(),[]) for k in P}
  if set(hyps['n'])<={'copy:border','lookup:border'} and set(hyps['border'])<={'copy:n','lookup:n'}: sel.append((demo,t,out,hyps))
print(len(sel))
for s in sel[:10]: print(s[:3])
