import itertools, numpy as np
from scipy.optimize import linprog
from fractions import Fraction
def d(c): return np.array(c["left"],float)-np.array(c["right"],float)
def feas(cl,n,extra=()):
    A=[];b=[];Ae=[];be=[]
    for c in cl:
        v=d(c)
        if c['result']=='tie': Ae.append(v);be.append(0)
        elif c['result']=='left': A.append(-v);b.append(-1)
        else: A.append(v);b.append(-1)
    for e in extra: A.append(-np.array(e,float));b.append(0)
    r=linprog(np.zeros(n),A_ub=A or None,b_ub=b or None,A_eq=Ae or None,b_eq=be or None,bounds=[(1,None)]*n,method='highs')
    return r.status==0
def forced(cl,n,i,j):
    e=np.zeros(n);e[j]=1;e[i]=-1
    return not feas(cl,n,[e])
def order(cl,n):
    if not feas(cl,n): return None
    above={i:0 for i in range(n)}
    for i,j in itertools.combinations(range(n),2):
        a,b=forced(cl,n,i,j),forced(cl,n,j,i)
        if a==b: return None
        above[j if a else i]+=1
    o=sorted(range(n),key=lambda k:above[k])
    if sorted(above.values())!=list(range(n)): return None
    return o
def signed(c):
    # vrátí vektor s orientací "vítěz - poražený" (>0) nebo remízu (=0)
    v=d(c)
    if c['result']=='right': v=-v
    return v
def cert(cl,n,i,j):
    """Nejmenší podmnožina zápasů dokazující w_i>w_j; vrací (velikost, zlomkové, kladnost)."""
    k=len(cl)
    for s in range(1,k+1):
        best=None
        for sub in itertools.combinations(range(k),s):
            if forced([cl[t] for t in sub],n,i,j):
                # LP: e_i-e_j = sum lam_c v_c + sum mu_m e_m ; lam>=0 for wins, free for ties; mu>=0
                cols=[];bounds=[]
                for t in sub:
                    v=signed(cl[t]); cols.append(v)
                    bounds.append((None,None) if cl[t]['result']=='tie' else (0,None))
                for m in range(n):
                    e=np.zeros(n);e[m]=1;cols.append(e);bounds.append((0,None))
                A=np.array(cols).T; tgt=np.zeros(n);tgt[i]=1;tgt[j]=-1
                # minimalizovat použití kladnosti, pak součet |lam| (přes split)
                nc=A.shape[1]
                # split free vars
                A2=np.hstack([A,-A[:,:len(sub)]])
                b2=bounds+[(0,None) if cl[sub[q]]['result']=='tie' else (0,0) for q in range(len(sub))]
                b2=[(0,None) if x==(None,None) else x for x in b2]
                cost=np.ones(A2.shape[1]); cost[len(sub):len(sub)+n]=10
                r=linprog(cost,A_eq=A2,b_eq=tgt,bounds=b2,method='highs')
                if r.status!=0: continue
                x=r.x; lam=x[:len(sub)]-x[len(sub)+n:]; mu=x[len(sub):len(sub)+n]
                frac=any(abs(abs(l)-round(abs(l)))>1e-6 for l in lam) or any(abs(abs(l))>1.5 for l in lam)
                pos=mu.sum()>1e-6
                cand=(s,frac,pos)
                if best is None or (cand[1],cand[2])<(best[1],best[2]): best=cand
        if best: return best
    return (k,False,False)
def features(it):
    n=it['n_shapes'];cl=it['clues']
    idx={f:i for i,f in enumerate(it['figures'])}
    o=[idx[f] for f in it['answer_order']]
    pairs=list(zip(o,o[1:]))
    cs=[cert(cl,n,i,j) for i,j in pairs]
    depth=max(c[0] for c in cs); ncomb=sum(c[0]>=2 for c in cs)
    frac=sum(c[1] for c in cs); pos=sum(c[2] for c in cs)
    shown=sum(sum(c['left'])+sum(c['right']) for c in cl)
    mult=sum(max(c['left']+c['right'])>=2 for c in cl)
    ties=sum(c['result']=='tie' for c in cl)
    mis=sum(1 for c in cl if (c['result']=='left' and sum(c['left'])<sum(c['right'])) or (c['result']=='right' and sum(c['right'])<sum(c['left'])) or (c['result']=='tie' and sum(c['left'])!=sum(c['right'])))
    # heuristika: počítání výher (členství na vítězné straně +, na poražené -)
    sc=np.zeros(n)
    for c in cl:
        v=signed(c)
        if c['result']!='tie': sc+=np.sign(v)
    # kendall vzdálenost heuristického pořadí od klíče
    rank={f:r for r,f in enumerate(o)}
    disc=sum(1 for a,b in itertools.combinations(range(n),2) if (sc[a]-sc[b])*(rank[b]-rank[a])<0)
    # heuristika 2: "víc figurek = silnější" (síla ~ průměrný podíl na stranách)
    return dict((a,int(b)) for a,b in dict(n=n,k=len(cl),shown=shown,depth=depth,ncomb=ncomb,frac=frac,pos=pos,mult=mult,ties=ties,mis=mis,heur_err=disc).items())
