import json,numpy as np
R=[r for r in json.load(open('/home/claude/gen/feat_existing.json')) if r['id']!='PR09']
def X(r,cols): 
    full=dict(c=1,n5=r['n']==5,shown=r['shown'],ncomb=r['ncomb'],depth=r['depth'],frac=r['frac'],pos=r['pos'],he=r['heur_err'])
    return [full[c] for c in cols]
S=['c','n5','ncomb','depth','frac','pos','he']; F=['c','n5','shown','ncomb','depth','frac','pos','he']
y=np.array([min(max(r['b'],-4),4) for r in R]); w=np.sqrt(np.minimum([r['N'] for r in R],100))
def fit(cols):
    A=np.array([X(r,cols) for r in R],float); Aw=A*w[:,None]
    P=np.eye(len(cols)); P[0,0]=0
    return np.linalg.solve(Aw.T@Aw+P,Aw.T@(y*w))
BS,BF=fit(S),fit(F)
def pred(f): return float(np.dot(X(f,S),BS)), float(np.dot(X(f,F),BF))
