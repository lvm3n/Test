import json,random,collections,numpy as np,itertools,sys
sys.path.insert(0,'/home/claude/gen')
rng=random.Random(20261115)
P=json.load(open('allpool.json'))
LV=[ # (úroveň, popis, n, bs_min, bs_max, počet, extra)
 (1,'3 figurky, jedno dosazení',3,-2.3,-0.3,4,lambda f:f['ncomb']>=1),
 (2,'4 figurky, jedna dvojice z kombinace',4,-1.6,-0.6,5,lambda f:f['ncomb']>=1),
 (3,'4 figurky, dvě dvojice z kombinace',4,-0.6,0.4,6,lambda f:f['ncomb']>=2),
 (4,'násobky / řetěz tří zápasů',4,0.4,1.2,7,lambda f:f['ncomb']>=2 and (f['frac']>=1 or f['depth']>=3)),
 (5,'všechny dvojice z kombinace, heuristika selže',4,1.2,1.9,7,lambda f:f['ncomb']==3 and f['heur_err']>=1),
 (6,'dvojí dosazení + lákadlo',4,1.9,9,5,lambda f:f['ncomb']==3 and f['depth']>=3 and f['heur_err']>=1),
 (7,'5 figurek, hluboké kombinace',5,2.4,9,4,lambda f:f['ncomb']>=3 and f['heur_err']>=1),
]
def vec(f): return np.array([f['ncomb'],f['depth'],f['frac'],f['pos'],f['ties'],f['mult'],f['mis'],f['heur_err'],f['shown']/2,f['k']],float)
def sig(p): return (p['f']['ncomb'],p['f']['depth'],p['f']['frac'],p['f']['pos'],p['f']['ties'],p['f']['mult'])
chosen=[]
for lv,desc,n,lo,hi,cnt,ex in LV:
    c=[p for p in P if p['f']['n']==n and lo<=p['bs']<hi and ex(p['f'])]
    if n==4: c=[p for p in c if p['f']['shown']<=11]
    rng.shuffle(c)
    # začít od nejúspornější (nejméně panáčků), pak maximin
    c.sort(key=lambda p:p['f']['shown'])
    sel=[c[0]]
    while len(sel)<cnt and len(sel)<len(c):
        used=collections.Counter(sig(s) for s in sel)
        best=max((p for p in c if p not in sel),key=lambda p:(used[sig(p)]==0, min(np.abs(vec(p['f'])-vec(s['f'])).sum() for s in sel)-0.3*p['f']['shown']))
        sel.append(best)
    print(lv,desc,'kandidátů',len(c),'vybráno',len(sel))
    for s in sel: s['lv']=lv; s['lvdesc']=desc
    chosen+=sorted(sel,key=lambda p:p['bs'])
# figurky a prezentace
SH=['circle','square','triangle','diamond','pentagon']
strong=collections.Counter(); items=[]
for i,p in enumerate(chosen,1):
    n=p['f']['n']
    for _ in range(30):
        figs=rng.sample(SH,n)
        if strong[figs[p['order'][0]]]<=min(strong[s] for s in SH)+1: break
    strong[figs[p['order'][0]]]+=1
    cl=[]
    for c in p['clues']:
        if rng.random()<0.5: c={'left':c['right'],'right':c['left'],'result':{'left':'right','right':'left','tie':'tie'}[c['result']]}
        cl.append(c)
    rng.shuffle(cl)
    f=p['f']
    lim=45 if p['lv']<=3 else (60 if p['lv']<=6 else 75)
    items.append({'id':f'PV{i:02d}','uroven':p['lv'],'typ':p['lvdesc'],'b_odhad':round(p['bs'],2),'b_odhad_s_panacky':round(p['bf'],2),
      'n_shapes':n,'n_clues':f['k'],'figures':figs,'clues':cl,'answer_order':[figs[x] for x in p['order']],
      'pairs_needing_combination':f['ncomb'],'max_clues_combined':f['depth'],'nasobky_v_dukazu':f['frac'],'vyuziva_kladnost':f['pos'],
      'tie_matches':f['ties'],'misleading_matches':f['mis'],'heuristika_chyb':f['heur_err'],'figures_shown':f['shown'],
      'guess_p':round(1/len(list(itertools.permutations(range(n)))),4),'limit_s':lim,'example_weights':p['w']})
json.dump(items,open('new_items.json','w'),ensure_ascii=False,indent=1)
for it in items: print(it['id'],it['uroven'],it['b_odhad'],it['b_odhad_s_panacky'],'sh',it['figures_shown'],'nc',it['pairs_needing_combination'],'d',it['max_clues_combined'],'fr',it['nasobky_v_dukazu'],'pos',it['vyuziva_kladnost'],'he',it['heuristika_chyb'],'tie',it['tie_matches'])
print(strong)
