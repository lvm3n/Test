import json,csv,numpy as np,sys
sys.path.insert(0,'/home/claude/gen')
from core import features,order
items=json.load(open('/home/claude/items.json'))
B={r['polozka']:r for r in csv.DictReader(open('/mnt/user-data/uploads/84682e35-pretahovana_linking_20261115.csv'))}
rows=[]
for k,r in B.items():
    f=features(items[k]); f['id']=k; f['b']=float(r['b_PR_metric']); f['N']=int(r['N'])
    f['r']=float(r['kor_rest_theta']) if r['kor_rest_theta'] else None
    rows.append(f)
json.dump(rows,open('feat_existing.json','w'))
for f in sorted(rows,key=lambda x:x['b']): print(f)
