import itertools, json, random, sys, time, collections, numpy as np
sys.path.insert(0,'/home/claude/gen')
from core import order, features
seed=int(sys.argv[1]); n=int(sys.argv[2]); k=int(sys.argv[3]); cap=int(sys.argv[4]); budget=float(sys.argv[5])
rng=random.Random(seed)
G={3:14,4:11,5:8}[n]
GR=np.array(list(itertools.product(range(1,G+1),repeat=n)),dtype=np.int32)
dist=~(np.diff(np.sort(GR,1),axis=1)==0).any(1)
def gridn(cl):
    m=np.ones(len(GR),bool)
    for c in cl:
        s=GR@(np.array(c['left'])-np.array(c['right'])).astype(np.int32)
        m&=(s==0) if c['result']=='tie' else ((s>0) if c['result']=='left' else (s<0))
    Y=GR[m]
    if len(Y)==0: return 0
    if (~dist[m]).any(): return 99
    return len({tuple(r) for r in np.argsort(-Y,1)})
# všechny strany: max 3 figurky, max 2 stejné
sides=[v for v in itertools.product(range(3),repeat=n) if 1<=sum(v)<=3]
def mk(w):
    for _ in range(200):
        L=rng.choice(sides); R=rng.choice(sides)
        if any(a and b for a,b in zip(L,R)): continue
        if np.gcd.reduce(np.array(L+R))>1: continue
        sl=sum(a*b for a,b in zip(L,w)); sr=sum(a*b for a,b in zip(R,w))
        if sl!=sr and rng.random()<0.45: continue   # preferovat remízy
        return {'left':list(L),'right':list(R),'result':'tie' if sl==sr else ('left' if sl>sr else 'right')}
def canon(cl,o):
    rank={f:r for r,f in enumerate(o)}
    out=[]
    for c in cl:
        L=tuple(sorted(r for f,cnt in enumerate(c['left']) for r in [rank[f]]*cnt))
        R=tuple(sorted(r for f,cnt in enumerate(c['right']) for r in [rank[f]]*cnt))
        res=c['result']
        if L>R: L,R=R,L; res={'left':'right','right':'left','tie':'tie'}[res]
        out.append((L,R,res))
    return str(tuple(sorted(out)))
pool={}; t0=time.time(); st=collections.Counter()
while time.time()-t0<budget:
    w=rng.sample(range(1,G+1),n)
    cl=[];tot=0
    for q in range(k):
        rem=cap-tot-2*(k-q-1)
        for _ in range(50):
            c=mk(w)
            if c and sum(c['left'])+sum(c['right'])<=rem: break
        else: c=None
        if c is None: break
        cl.append(c); tot+=sum(c['left'])+sum(c['right'])
    if len(cl)<k: continue
    if sum(sum(c['left'])+sum(c['right']) for c in cl)>cap: st['cap']+=1; continue
    if gridn(cl)!=1: st['nu']+=1; continue
    if any(gridn(cl[:m]+cl[m+1:])<2 for m in range(k)): st['red']+=1; continue
    o=order(cl,n)
    if o is None: st['lp']+=1; continue
    key=canon(cl,o)
    if key in pool: continue
    it={'n_shapes':n,'figures':list(range(n)),'clues':cl,'answer_order':o}
    f=features(it)
    pool[key]={'clues':cl,'order':o,'w':w,'f':f}
    st['ok']+=1
print(seed,n,k,dict(st),file=sys.stderr)
json.dump(list(pool.values()),open(f'pool_{n}_{k}_{seed}.json','w'))
