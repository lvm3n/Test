/* ---------- Přetahovaná 2.0 (PV-49-v1): kalibrační banka nové Přetahované ----------
   38 nových úloh PV01–PV38 (7 úrovní podle typu úvahy) + 11 slibných pilotů (PN/PF) k nové kalibraci, 4 bloky A–D (13 + 12 + 12 + 12).
   1. část (klíč pretah2): kotvy PR11, PR16, PR17, PR32, PR33, PR45 (kdo už dělal Přetahovanou, kotvy nedostane – má je v datech) + blok X;
   2. část (pretah2b, v menu až po 1. části): blok Y, bez kotev a bez zácviku. Dvojice bloků AB, BC, CD, DA se losuje podle osoby a zůstává stálá.
   Uvnitř části od nejlehčí úlohy, dál mírně stoupající, promíchané v okně ±1 úrovně. Limit podle položky (45 / 60 / 75 s), bez ukončení po chybách a bez sond.
   Výsledek = počet správně vyřešených úloh bloku (bez kotev), zatím bez srovnání. Banka: docs/pretahovana/pretahovana_PV-49-v1.json. */
const PT2 = {version:'PV-49-v1', anchors:__ANCHORS__, anchorLv:{PR11:0.5, PR16:1, PR17:2, PR32:3.5, PR33:4, PR45:4.5},
  blocks:__BLOCKS__, pairs:[['A', 'B'], ['B', 'C'], ['C', 'D'], ['D', 'A']]};
const PT2_KEYS = ['pretah2', 'pretah2b'];
const PT2_ITEMS = __ITEMS__;
function pt2Rnd(tag){
  let h = 2166136261; const str = pilotSeed('pretah2|' + tag); for (let k = 0; k < str.length; k++) { h ^= str.charCodeAt(k); h = Math.imul(h, 16777619); }
  return () => { h += 0x6D2B79F5; let t = h; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function pt2Pair(){
  const sc = S.scores && S.scores.pretah2; if (sc && /^[A-D]\+[A-D]$/.test(sc.vyvoj_bloky || '')) return sc.vyvoj_bloky.split('+');
  return PT2.pairs[Math.min(3, Math.floor(pt2Rnd('dvojice')() * 4))];
}
function pt2Done1(){ try { if (S.scores && S.scores.pretah2) return !(typeof kbNerNow === 'function' && kbNerNow('pretah2')); const d = typeof KB !== 'undefined' && KB.done ? (KB.done() || {}).pretah2 : null; return !!(d && d.raw_score !== null && d.raw_score !== undefined); } catch (e) { return false; } }
/* úroveň pro řazení: nové úlohy mají uroven; piloty bez úrovně ji přebírají od předchozí úlohy bloku (bloky jsou seřazené podle obtížnosti) */
function pt2Levels(ids, by){ let last = 1; return ids.map(id => { const u = by[id].uroven; if (u !== undefined) last = u; return u !== undefined ? u : last; }); }
function pt2Build(part){
  const by = {}; PT2_ITEMS.forEach(x => { by[x.id] = x; });
  const main = BANK_PT.items._puvodni || BANK_PT.items; main.forEach(x => { if (PT2.anchors.includes(x.id)) by[x.id] = x; });
  const pair = pt2Pair(), blk = pair[part - 1], ids = PT2.blocks[blk], lv = pt2Levels(ids, by);
  let list = ids.map((id, j) => ({it:Object.assign({}, by[id], {pilot:false, podlaha:false, vyvoj_role:by[id].role === 'nová' ? 'nova' : 'opakovana', vyvoj_cast:blk}), lv:lv[j]}));
  let anch = 0;
  if (part === 1 && !ptvSawMain()) PT2.anchors.forEach(id => { if (by[id]) { list.push({it:Object.assign({}, by[id], {pilot:false, podlaha:false, vyvoj_role:'kotva', vyvoj_cast:''}), lv:PT2.anchorLv[id] || 3}); anch++; } });
  S.pt2Var = (part === 1 ? (anch ? 'kotvy+' : 'bez-kotev+') : 'cast2-') + blk; S.pt2Pair = pair.join('+');
  const rnd = pt2Rnd('poradi' + part);
  list.sort((a, b) => a.lv - b.lv);                                   // nejlehčí úloha zůstává první
  const first = list.shift();
  list.forEach(x => { x.k = x.lv + (rnd() * 2 - 1); });               // okno ±1 úrovně
  list.sort((a, b) => a.k - b.k);
  return [first].concat(list).map(x => x.it);
}
function pt2Finish(sc, RUN, ST){
  let nove = 0, nN = 0, kot = 0, nK = 0; const pol = [];
  RUN.forEach((x, i) => { const v = ST.res[i]; if (v === undefined) return; pol.push(x.id + ':' + v);
    if (x.vyvoj_role === 'kotva') { kot += v; nK++; } else { nove += v; nN++; } });
  Object.assign(sc, {hruby:nove, spravne_administrovane:nove, pripsane:0, administrovano:nN, polozek:nN, vyvoj_cast:(RUN.find(x => x.vyvoj_role !== 'kotva') || {}).vyvoj_cast || '',
    vyvoj_bloky:S.pt2Pair || '', varianta:S.pt2Var || '', hruby_kotvy:nK ? kot : '', kotev:nK, polozky:pol.join(' '), poradi:RUN.map(x => x.id).join(' '), podlaha:'', navrat:0});
}
const PT2_TX = Object.assign({}, PT_TX, __TX1__);
const PT2B_TX = Object.assign({}, PT2_TX, __TX2__);
const PT2_CF = {key:'pretah2', version:PT2.version, group:'vyvoj', build:() => pt2Build(1), finish:pt2Finish};
const PT2B_CF = {key:'pretah2b', version:PT2.version, group:'vyvoj', noPractice:true, build:() => pt2Build(2), finish:pt2Finish};
function pt2Card(k, raw){
  const sc = (S.scores && S.scores[k]) || {}, n = sc.polozek || (k === 'pretah2' ? 12 : 12);
  return __CARD__;
}
