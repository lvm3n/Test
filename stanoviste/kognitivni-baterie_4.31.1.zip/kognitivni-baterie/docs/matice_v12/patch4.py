import sys
p=sys.argv[1]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1,where=None):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:100]))
    s=s.replace(a,b)
def sub_in(fn_start, a, b):
    global s
    i=s.index(fn_start); j=s.index('\nfunction ',i+20); g=s[i:j]
    if g.count(a)!=1: raise SystemExit('FAIL-in %s (%d) %s'%(fn_start,g.count(a),a[:80]))
    s=s[:i]+g.replace(a,b)+s[j:]
# ---- pomocné: pilotní pořadí (snadný začátek, pak mírně stoupající, ale promíchané bloky) ----
rep("function probePick(done, n, reachedMax){","""/* PILOTNÍ POŘADÍ (od 3.73.0): bez směrování podle věku a s mírným ukončováním. Prvních `warm` nejsnazších položek
   v pevném pořadí, zbytek po blocích `band` položek (v pořadí návrhu obtížnosti) a uvnitř bloku náhodně promíchaný –
   obtížnost tak jen mírně stoupá a poloha položky není svázaná s její obtížností. Pořadí je pro jednu osobu stálé
   (seed ze sezení), mění se v místě (pole položek), původní pořadí zůstává v _puvodni. */
const PILOT_STOP = 8;        // ukončení až po 8 chybách za sebou
function pilotSeed(key){
  let a = ''; try { a = (typeof KB !== 'undefined' && KB.mode === 'public') ? KB.anonId() : ''; } catch (e) {}
  if (!S.pilotSeed) S.pilotSeed = String(Date.now()) + Math.random();
  return (a || S.sid || S.pilotSeed) + '|' + key;
}
function pilotOrder(arr, key, warm, band){
  const orig = arr._puvodni || (arr._puvodni = arr.slice());
  orig.forEach((it, k) => { if (it && typeof it === 'object') it.poradi_banky = k + 1; });
  let h = 2166136261; const str = pilotSeed(key);
  for (let k = 0; k < str.length; k++) { h ^= str.charCodeAt(k); h = Math.imul(h, 16777619); }
  const rnd = () => { h += 0x6D2B79F5; let t = h; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  const out = orig.slice(0, warm);
  for (let k = warm; k < orig.length; k += band) {
    const b = orig.slice(k, k + band);
    for (let j = b.length - 1; j > 0; j--) { const r = Math.floor(rnd() * (j + 1)); [b[j], b[r]] = [b[r], b[j]]; }
    out.push(...b);
  }
  arr.splice(0, arr.length, ...out);
  return arr;
}
function probePick(done, n, reachedMax){""")
# ---- Stanoviště: bez směrování, mix, stop 8 ----
sub_in('function mod_stanoviste', "    const s = startIndex(); Object.assign(ST, {res:{}, n:0, run:0, tout:0, probe:null, s, s2:null, basal:0});",
       "    pilotOrder(ITEMS, K, 3, 6);\n    const s = 0; Object.assign(ST, {res:{}, n:0, run:0, tout:0, probe:null, s, s2:null, basal:0});   // pilot: bez směrování podle věku")
sub_in('function mod_stanoviste', "const stop = S.stop || 0;", "const stop = PILOT_STOP;")
# ---- Hledání pravidla ----
sub_in('function mod_pravidla', "$('#' + K + '-start').onclick = () => { ST.i = 0; ST.res = []; ST.run = 0; load(ITEMS[0], 'test'); };",
       "$('#' + K + '-start').onclick = () => { pilotOrder(ITEMS, K, 3, 6); ST.i = 0; ST.res = []; ST.run = 0; load(ITEMS[0], 'test'); };")
sub_in('function mod_pravidla', "else { ST = {t:PRAC.length, i:0, res:[], run:0}; load(ITEMS[0], 'test'); } },",
       "else { pilotOrder(ITEMS, K, 3, 6); ST = {t:PRAC.length, i:0, res:[], run:0}; load(ITEMS[0], 'test'); } },")
sub_in('function mod_pravidla', "if (ST.run >= 5) {", "if (ST.run >= PILOT_STOP) {")
sub_in('function mod_pravidla', "S.rows.push({test:K, forma:VERSION, faze:ST.phase === 'tut' ? 'nacvik' : ST.phase === 'probe' ? 'sonda' : 'test', polozka:it.id, id:it.id,",
       "S.rows.push({test:K, forma:VERSION, faze:ST.phase === 'tut' ? 'nacvik' : ST.phase === 'probe' ? 'sonda' : 'test', polozka:it.id, id:it.id, poradi:ST.phase === 'test' ? ST.i + 1 : '', poradi_banky:it.poradi_banky || '',")
# ---- Skládání papíru (mod_gv: volitelně cfg.pilotMix) ----
sub_in('function mod_gv(root, cfg){', "$('#' + K + '-start').addEventListener('click', () => { S.mode = 'test'; ST.phase = 'run'; ST.list = cfg.items;",
       "$('#' + K + '-start').addEventListener('click', () => { if (cfg.pilotMix) pilotOrder(cfg.items, K, cfg.pilotMix[0], cfg.pilotMix[1]); S.mode = 'test'; ST.phase = 'run'; ST.list = cfg.items;")
sub_in('function mod_gv(root, cfg){', "poradi:ST.i + 1, polozka:it.id,", "poradi:ST.i + 1, poradi_banky:it.poradi_banky || '', polozka:it.id,")
rep("stopN:3, capFor:() => 75,", "stopN:PILOT_STOP, pilotMix:[3, 6], capFor:() => 75,")
open(p,'w',encoding='utf8').write(s); print('patch4 ok',p)
