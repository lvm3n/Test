import json, copy
G=json.load(open('/mnt/user-data/uploads/gf_v12_pilot_pool_40.json'))
I={it['order']:it for it in G['items']}
def setopts(it, opts, models, correct):
    it['options']=opts; it['option_models']=models; it['correct_index']=correct
log={}
# --- 11: druhá dráha musí ukázat celý barevný cyklus (dřív šlo i o střídání červená/žlutá)
it=I[11]
it['stem']=[{"lane":"A","shape":"circle","color":"blue"},{"lane":"B","shape":"star","color":"red"},{"lane":"A","shape":"square","color":"blue"},{"lane":"B","shape":"star","color":"yellow"},
            {"lane":"A","shape":"triangle","color":"blue"},{"lane":"B","shape":"star","color":"blue"},{"lane":"A","shape":"circle","color":"blue"},None]
setopts(it,[{"lane":"A","shape":"square","color":"blue"},{"lane":"B","shape":"star","color":"blue"},{"lane":"B","shape":"square","color":"red"},{"lane":"B","shape":"star","color":"yellow"},{"lane":"A","shape":"star","color":"red"},{"lane":"B","shape":"star","color":"red"}],
        ["continue_odd","repeat_even","mix_lanes","repeat_even_color","wrong_lane","correct"],5)
log[11]='Dráha B ukazovala jen červenou a žlutou → stejně dobře sedělo střídání (správně by byla červená). Řada prodloužena na 8 polí, dráha B ukáže celý cyklus červená–žlutá–modrá; klíč = červená hvězda.'
# --- 12: horní řada nesmí být pohyb po směru (dřív sedělo i „o roh dál“ = levý dolní)
it=I[12]
it['stem']=[[{"pos":0,"color":"red"},{"pos":2,"color":"red"},{"pos":1,"color":"red"}],[{"pos":2,"color":"blue"},{"pos":1,"color":"blue"},None]]
setopts(it,[{"pos":1,"color":"blue"},{"pos":0,"color":"blue"},{"pos":3,"color":"blue"},{"pos":0,"color":"red"},{"pos":2,"color":"blue"},{"pos":1,"color":"red"}],
        ["no_phase_shift","correct","unused_corner","wrong_color","repeat_earlier","copy_top"],1)
log[12]='Horní řada LH–PH–PD šla číst i jako pohyb o roh po směru hodinek → dole by byl levý dolní (možnost E). Horní řada je teď LH–PD–PH (žádný pohyb), dolní PD–PH–? → LH.'
# --- 16: odstraněna možnost odpovídající pravidlu „tvar→tvar, barva→barva“ (čtverec červený)
it=I[16]; k=it['options'].index({"shape":"square","color":"red"})
it['options'][k]={"shape":"circle","color":"red"}; it['option_models'][k]='color_from_color_only'
log[16]='Dvě ukázky stejně dobře vysvětluje pravidlo „tvar se posune (kruh→čtverec→trojúhelník), barva se přemapuje (červená→modrá, žlutá→červená)“ → čtverec červený (F). Ve 2 ukázkách to nejde vyloučit, proto F nahrazena kruhem červeným.'
# --- 18: druhý řádek s jiným pořadím barev (dřív sedělo „1. barva zůstane, 2. a 3. se prohodí“)
it=I[18]
it['stem'][1]=[{"seq":[["square","blue"],["circle","yellow"],["star","red"]]},{"seq":[["star","yellow"],["circle","blue"],["square","red"]]}]
log[18]='Barvy šlo číst i polohově (1. zůstane, 2. a 3. se prohodí) → správně by byla C. Druhý řádek má teď barvy modrá–žlutá–červená, kde polohové pravidlo nesedí.'
# --- 33: ukázka s výplní A=0 (dřív XOR = „opak výplně B“)
it=I[33]
it['stem'][1]=[{"A":["star","red","diamond","green",0],"B":["circle","purple","square","yellow",0]},{"out":["circle","green","diamond","purple",0]}]
log[33]='Výplň: v obou ukázkách měl A plnou výplň, takže XOR = „opak výplně B“ → správně by byla A. Druhá ukázka má teď obě výplně prázdné (XOR = 0, „opak B“ = 1).'
# --- 34: ukázky nesmí být souměrné při otočení o 180° (dřív nešel rozlišit směr otáčení)
it=I[34]
it['stem'][0]=[{"A":[1,0,0,0],"B":[0,1,0,0]},{"S":[0,1,1,0]}]
it['stem'][1]=[{"A":[0,0,1,0],"B":[0,0,1,1]},{"S":[1,0,0,1]}]
log[34]='Oba výsledky ukázek byly souměrné (1010/0101), takže otočení doprava i doleva dávalo totéž → C (opačný směr) byla také správně. Nové ukázky 1100→0110 a 0011→1001 směr určují.'
# --- 35: v ukázce se musí lišit „přepni výplň nového horního“ od „nastav opak původního horního“
it=I[35]
it['stem'][0]=[{"parts":[["circle",2,"solid"],["triangle",1,"hollow"],["square",3,"hollow"]]},{"parts":[["square",3,"solid"],["circle",2,"solid"],["triangle",1,"hollow"]]}]
log[35]='V obou ukázkách měl nový horní objekt stejnou výplň jako starý horní, takže „nový horní dostane opak výplně starého horního“ dávalo B. V 1. ukázce je teď čtverec prázdný → po přepnutí plný (opak starého horního by byl prázdný).'
# --- 38: přepnutí výplně musí jít jedním směrem i druhým (dřív stejně dobře „prostřední zprázdni“)
it=I[38]
it['stem'][1]=[{"parts":[["hex",3,"solid"],["diamond",2,"hollow"],["star",1,"hollow"]]},{"parts":[["star",1,"hollow"],["diamond",2,"solid"],["hex",3,"solid"]]}]
log[38]='V obou ukázkách se prostřední objekt měnil z plného na prázdný, takže sedělo i „prostřední bude prázdný“ → A. Ve 2. ukázce se teď mění z prázdného na plný.'
# --- 39: první dva bity musí jít rozlišit (dřív ukázky 110/001)
it=I[39]
it['stem'][0]=[{"mode":"input","A":{"shape":"circle","color":"blue","fill":"solid"},"B":{"shape":"square","color":"blue","fill":"solid"}},{"mode":"output","bits":[1,0,0]}]
it['stem'][1]=[{"mode":"input","A":{"shape":"triangle","color":"yellow","fill":"solid"},"B":{"shape":"triangle","color":"red","fill":"hollow"}},{"mode":"output","bits":[0,1,1]}]
setopts(it,[{"mode":"output","bits":[1,1,1]},{"mode":"output","bits":[0,1,1]},{"mode":"output","bits":[1,0,1]},{"mode":"output","bits":[1,0,0]},{"mode":"output","bits":[0,0,1]},{"mode":"output","bits":[1,1,0]}],
        ["mark_all_different","copy_demo2","correct","copy_demo1_or_miss_fill","miss_shape_difference","fill_as_color"],2)
log[39]='Ukázky 110 a 001 neurčily, který z prvních dvou bitů je tvar a který barva → stejně dobře 011 (E). Nové ukázky 100 (jen tvar) a 011 (barva + výplň) určí každý bit.'
G['version']='V12-pilot-pool-40-r1'
for o,t in log.items(): I[o].setdefault('notes','')
json.dump(G,open('/home/claude/m12fix/gf_v12_pilot_pool_40_r1.json','w'),ensure_ascii=False,indent=1)
json.dump(log,open('/home/claude/m12fix/log.json','w'),ensure_ascii=False,indent=1)
print('ok')
