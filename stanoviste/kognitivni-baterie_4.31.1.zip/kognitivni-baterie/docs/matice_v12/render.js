/* ===== Matice V12 – kreslení položek (40 scén; každá scéna má vlastní schéma objektu) ===== */
const M12 = (function(){
  const C = {blue:'#3E6FD6', red:'#DD5B45', yellow:'#F0B83E', green:'#4FA676', purple:'#7E57C2', white:'#FFFFFF', gray:'#5F6B7A', dark:'#2B3440'};
  const col = (c) => C[c] || c || C.dark;
  const INK = '#24303d';
  const poly = (pts) => pts.map(p => p[0].toFixed(2) + ',' + p[1].toFixed(2)).join(' ');
  const reg = (n, r, rot) => Array.from({length:n}, (_, k) => { const a = (rot || -90) * Math.PI / 180 + k * 2 * Math.PI / n; return [r * Math.cos(a), r * Math.sin(a)]; });
  const starPts = (r) => Array.from({length:10}, (_, k) => { const a = -Math.PI / 2 + k * Math.PI / 5, rr = k % 2 ? r * 0.45 : r; return [rr * Math.cos(a), rr * Math.sin(a)]; });
  /* základní tvar se středem 0,0 a „poloměrem“ r (orientace 0 = nahoru) */
  function base(shape, r){
    switch (shape){
      case 'circle': return {c:r * 0.92};
      case 'square': return {p:[[-r * .8, -r * .8], [r * .8, -r * .8], [r * .8, r * .8], [-r * .8, r * .8]]};
      case 'diamond': return {p:[[0, -r], [r * .78, 0], [0, r], [-r * .78, 0]]};
      case 'triangle': return {p:[[0, -r], [r * .95, r * .78], [-r * .95, r * .78]]};
      case 'hex': return {p:reg(6, r * .95, -90)};
      case 'star': return {p:starPts(r)};
      case 'kite': return {p:[[0, -r], [r * .62, -r * .05], [r * .2, r], [-r * .55, r * .35]]};
      case 'flag': return {p:[[-r * .7, -r], [r * .85, -r * .55], [-r * .1, -r * .1], [r * .25, r * .9], [-r * .7, r * .9]]};
      case 'chevron': return {p:[[-r, -r * .55], [0, r * .05], [r, -r * .55], [r * .7, r * .55], [0, r * .05 + r * .25], [-r * .7, r * .55]]};
      case 'notched': return {p:[[0, -r], [r * .55, -r * .45], [r * .3, -r * .35], [r * .38, r * .95], [0, r * .6], [-r * .42, r * .95], [-r * .3, -r * .35], [-r * .55, -r * .45]]};
      case 'fan': return {d:`M0 0 L${(-r * 0).toFixed(2)} ${(-r).toFixed(2)} A${r} ${r} 0 0 1 ${(r * Math.sin(Math.PI / 3)).toFixed(2)} ${(-r * Math.cos(Math.PI / 3) * -1 * -1).toFixed(2)} Z`};
      default: return {c:r * 0.9};
    }
  }
  function shape(sh, cx, cy, r, o){
    o = o || {}; const b = base(sh, r), fill = o.fill === 'hollow' ? '#fff' : col(o.color), stroke = o.fill === 'hollow' ? col(o.color) : INK;
    const sw = o.fill === 'hollow' ? Math.max(2.4, r * .11) : Math.max(1.4, r * .06);
    const tr = `transform="translate(${cx} ${cy}) rotate(${(o.dir || 0) * 45})"`;
    if (b.c) return `<circle cx="${cx}" cy="${cy}" r="${b.c.toFixed(2)}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
    if (b.d) return `<path d="${b.d}" ${tr} fill="${fill}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>`;
    return `<polygon points="${poly(b.p)}" ${tr} fill="${fill}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>`;
  }
  const dot = (x, y, r, c, hollow) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${hollow ? '#fff' : col(c)}" stroke="${hollow ? '#9AA5B1' : INK}" stroke-width="${hollow ? 1.6 : 1.3}"/>`;
  const frame = (k, x, y, w, h, gap) => { let s = ''; for (let j = 0; j < k; j++) s += `<rect x="${x + j * gap}" y="${y + j * gap}" width="${w - 2 * j * gap}" height="${h - 2 * j * gap}" rx="${10 - j * 2}" fill="none" stroke="#5F6B7A" stroke-width="2.4"/>`; return s; };
  const SIZE = {1:.55, 2:.78, 3:1};
  const divider = '<line x1="50" y1="22" x2="50" y2="78" stroke="#C9D1DA" stroke-width="2"/>';
  const petals = (cx, cy, R, mask, c) => { let s = ''; [[0, -1], [1, 0], [0, 1], [-1, 0]].forEach(([dx, dy], k) => { s += `<ellipse cx="${cx + dx * R * .55}" cy="${cy + dy * R * .55}" rx="${dx ? R * .5 : R * .3}" ry="${dx ? R * .3 : R * .5}" fill="${mask === null ? col(c) : mask[k] ? C.green : '#fff'}" stroke="${INK}" stroke-width="1.3"/>`; }); return s + `<circle cx="${cx}" cy="${cy}" r="${R * .14}" fill="#fff" stroke="${INK}" stroke-width="1.3"/>`; };
  const pie = (cx, cy, R, mask) => { let s = ''; const n = mask.length; for (let k = 0; k < n; k++) { const a0 = -Math.PI / 2 + k * 2 * Math.PI / n, a1 = a0 + 2 * Math.PI / n;
      s += `<path d="M${cx} ${cy} L${(cx + R * Math.cos(a0)).toFixed(2)} ${(cy + R * Math.sin(a0)).toFixed(2)} A${R} ${R} 0 0 1 ${(cx + R * Math.cos(a1)).toFixed(2)} ${(cy + R * Math.sin(a1)).toFixed(2)} Z" fill="${mask[k] ? C.purple : '#fff'}" stroke="#8A96A3" stroke-width="1"/>`; }
    return s + `<circle cx="${cx}" cy="${cy}" r="${R}" fill="none" stroke="${INK}" stroke-width="1.6"/>`; };
  const grid4 = (cx, cy, g, mask) => [[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([dx, dy], k) => dot(cx + dx * g, cy + dy * g, g * .55, 'blue', !mask[k])).join('');
  const nested = (cx, cy, R, outer, oc, inner, ic, innerFill) => shape(outer, cx, cy, R, {color:oc}) + shape(inner, cx, cy, R * .45, {color:ic, fill:innerFill === 0 ? 'hollow' : 'solid'});
  const arcPts = [[22, 70], [34, 50], [50, 40], [66, 50], [78, 70], [50, 72]];
  const POS3 = [[50, 26], [27, 70], [73, 70]];
  const SPOT = {L:[25, 50], R:[75, 50], T:[50, 24], B:[50, 76], TL:[27, 27], TR:[73, 27], BL:[27, 73], BR:[73, 73]};
  /* jedna buňka podle scény */
  const S = {
    rounded_token:(o) => shape(o.shape, 50, 50, 30, o),
    paired_emblems:(o) => shape(o.shape, 50, 50, 28, o),
    three_shapes_strip:(o) => shape(o.shape, 50, 50, 28, o),
    dot_arc:(o) => arcPts.slice(0, o.n).map(p => dot(p[0], p[1], 6.5, o.color)).join(''),
    color_petal:(o) => petals(50, 50, 38, null, o.color),
    notched_pointer:(o) => shape('notched', 50, 50, 32, o),
    split_medallion:(o) => `<circle cx="50" cy="50" r="38" fill="#F3F5FA" stroke="#AEB8C7" stroke-width="2"/>` + shape(o.shape, 50, 50, 24, o),
    dot_frame:(o) => frame(o.border, 18, 18, 64, 64, 6) + [[38, 52], [50, 40], [62, 52]].slice(0, o.n).map(p => dot(p[0], p[1], 6, 'blue')).join(''),
    hollow_triptych:(o) => shape(o.shape, 50, 50, 30, o),
    paired_prism:(o) => shape(o.shape, 50, 50, 30, o),
    two_lane_cards:(o) => `<rect x="4" y="4" width="92" height="92" rx="12" fill="${o.lane === 'A' ? '#EEF3FD' : '#FDF2EE'}"/>` + shape(o.shape, 50, 50, 27, o),
    corner_frame:(o) => `<rect x="24" y="24" width="52" height="52" rx="6" fill="none" stroke="#AEB8C7" stroke-width="2.4"/>` + dot([24, 76, 76, 24][o.pos], [24, 24, 76, 76][o.pos], 7.5, o.color),
    asym_fan:(o) => `<g transform="translate(50 52) rotate(${o.dir * 45})"><path d="M0 0 L0 -32 A32 32 0 0 1 27.7 -16 Z" fill="${col(o.color)}" stroke="${INK}" stroke-width="1.8"/><circle r="4.5" fill="#fff" stroke="${INK}" stroke-width="1.5"/></g>`,
    duo_pedestals:(o) => `<line x1="12" y1="82" x2="88" y2="82" stroke="#D3DAE2" stroke-width="3"/><g transform="translate(30 55) rotate(${o.Ldir * 45})"><line x1="0" y1="0" x2="0" y2="-20" stroke="${C.blue}" stroke-width="7" stroke-linecap="round"/><circle r="5" fill="${INK}"/></g>` + shape('triangle', 66, 56, 16, {color:o.Rcolor}),
    balance_boxes:(o) => { const box = (x, n, c) => `<rect x="${x}" y="28" width="38" height="44" rx="7" fill="#fff" stroke="#9AA5B1" stroke-width="2"/>` + [[x + 11, 40], [x + 27, 40], [x + 11, 58], [x + 27, 58]].slice(0, n).map(p => dot(p[0], p[1], 5, c)).join(''); return box(8, o.l, 'green') + box(54, o.r, 'red'); },
    shape_color_codes:(o) => shape(o.shape, 50, 50, 30, o),
    swap_tiles:(o) => shape(o.L[0], 30, 50, 9 + 5 * o.L[2], {color:o.L[1]}) + shape(o.R[0], 72, 50, 9 + 5 * o.R[2], {color:o.R[1]}),
    ordered_triplet:(o) => o.seq.map((p, k) => shape(p[0], 22 + k * 28, 50, 13, {color:p[1]})).join(''),
    sector_xor:(o) => o.S ? pie(50, 50, 30, o.S) : pie(27, 50, 20, o.A) + pie(73, 50, 20, o.B),
    category_level_token:(o) => shape(o.cat === 'A' ? 'circle' : 'triangle', 50, 52, [0, 12, 21, 30][o.level], {color:'dark', fill:'hollow'}),
    operator_transfer_fill:(o) => shape(o.shape, 50, 50, 28, {color:'green', fill:o.fill, dir:o.dir}),
    quantity_operator_dial:(o) => o.S_dir !== undefined ? shape('chevron', 50, 50, 28, {color:'blue', dir:o.S_dir})
      : shape('chevron', 28, 50, 17, {color:'blue', dir:o.A_dir}) + divider + Array.from({length:o.B_count}, (_, k) => dot(64 + k * 11, 50, 4.6, 'yellow')).join(''),
    set_quadrants:(o) => o.S ? grid4(50, 50, 16, o.S) : grid4(27, 50, 10, o.A) + divider + grid4(73, 50, 10, o.B),
    ringed_symbol:(o) => (o.border ? `<circle cx="50" cy="50" r="38" fill="none" stroke="#5F6B7A" stroke-width="2.4"/>` : '') + shape(o.shape, 50, 50, 26, {color:o.color, dir:o.dir}),
    nested_pair_sources:(o) => o.out ? nested(50, 50, 34, o.out[0], o.out[1], o.out[2], o.out[3]) : nested(26, 50, 20, o.A[0], o.A[1], o.A[2], o.A[3]) + divider + nested(74, 50, 20, o.B[0], o.B[1], o.B[2], o.B[3]),
    count_border_token:(o) => frame(o.border, 14, 14, 72, 72, 5) + shape(o.shape, 50, 52, 20, {color:'dark', fill:'hollow'}) + [[42, 56], [58, 56], [50, 44]].slice(0, o.n).map(p => dot(p[0], p[1], 4.5, 'red')).join(''),
    triad_wheel:(o) => `<circle cx="50" cy="56" r="6" fill="#fff" stroke="#9AA5B1" stroke-width="1.6"/>` + o.parts.map((p, k) => shape(p[0], POS3[k][0], POS3[k][1], 13, {color:p[1]})).join(''),
    complement_pair:(o) => `<g transform="translate(50 50) rotate(${o.dir * 45})"><polygon points="0,-28 11,0 0,28 -11,0" fill="${col(o.color)}" stroke="${INK}" stroke-width="1.8"/></g>` + [[24, 24], [76, 24], [24, 76], [76, 76], [50, 14]].slice(0, o.n).map(p => dot(p[0], p[1], 4.5, 'dark')).join(''),
    source_routing:(o) => o.out ? frame(o.out[2], 14, 14, 72, 72, 6) + shape(o.out[0], 50, 50, 22, {color:o.out[1]}) : shape(o.A[0], 27, 50, 17, {color:o.A[1]}) + divider + shape(o.B[0], 73, 50, 17, {color:o.B[1]}),
    relational_vector_gate:(o) => o.mode === 'input'
      ? `<line x1="50" y1="14" x2="50" y2="86" stroke="#E2E7EE" stroke-width="1.5"/><line x1="14" y1="50" x2="86" y2="50" stroke="#E2E7EE" stroke-width="1.5"/>` + shape(o.blue.shape, SPOT[o.blue.pos][0], SPOT[o.blue.pos][1], 12, {color:'blue'}) + shape(o.red.shape, SPOT[o.red.pos][0], SPOT[o.red.pos][1], 12, {color:'red'})
      : `<g transform="translate(50 50) rotate(${o.dir * 45})"><polygon points="-30,-7 10,-7 10,-17 30,0 10,17 10,7 -30,7" fill="${o.fill === 'hollow' ? '#fff' : C.green}" stroke="${INK}" stroke-width="2.4" stroke-linejoin="round"/></g>`,
    conditional_nested_series:(o) => nested(50, 50, 32, o.outer, o.oc, o.inner, o.ic),
    three_positions:(o) => o.parts.map((p, k) => shape(p[0], POS3[k][0], POS3[k][1], 14, {color:p[1], fill:p[2]})).join(''),
    nested_dual_routing_v2:(o) => o.out ? nested(50, 50, 32, o.out[0], o.out[1], o.out[2], o.out[3], o.out[4]) : nested(26, 50, 19, o.A[0], o.A[1], o.A[2], o.A[3], o.A[4]) + divider + nested(74, 50, 19, o.B[0], o.B[1], o.B[2], o.B[3], o.B[4]),
    lobes_union_rotate:(o) => o.S ? petals(50, 50, 36, o.S) : petals(26, 50, 20, o.A) + petals(74, 50, 20, o.B),
    conditional_triad:(o) => o.parts.map((p, k) => shape(p[0], POS3[k][0], POS3[k][1], 6 + 4 * p[1], {color:'green', fill:p[2]})).join(''),
    paired_cross_gate:(o) => o.mode === 'input' ? shape(o.L.shape, 27, 50, 17, {color:o.L.color}) + divider + shape(o.R.shape, 73, 50, 17, {color:o.R.color})
      : frame(o.border, 14, 14, 72, 72, 6) + shape(o.shape, 50, 50, 22, {color:o.color}),
    antiparallel_tracks:(o) => `<g transform="translate(50 50) rotate(${o.dir * 45 - 45})"><line x1="-30" y1="0" x2="30" y2="0" stroke="#C9D1DA" stroke-width="5" stroke-linecap="round"/></g>` + Array.from({length:o.n}, (_, k) => dot(50 + (k - (o.n - 1) / 2) * 11, 50, 5, o.color)).join(''),
    ordinal_triad:(o) => o.parts.map((p, k) => shape(p[0], POS3[k][0], POS3[k][1], 6 + 4 * p[1], {color:'gray', fill:p[2]})).join(''),
    difference_signature:(o) => o.mode === 'output' ? o.bits.map((b, k) => `<rect x="${22 + k * 20}" y="40" width="16" height="16" rx="3" fill="${b ? C.purple : '#fff'}" stroke="${INK}" stroke-width="1.8"/>`).join('')
      : shape(o.A.shape, 27, 50, 17, {color:o.A.color, fill:o.A.fill}) + divider + shape(o.B.shape, 73, 50, 17, {color:o.B.color, fill:o.B.fill}),
    triple_code_medallion:(o) => frame(o.border, 14, 14, 72, 72, 5) + shape(o.shape, 50, 50, 20, {color:o.color})
  };
  function cell(scene, o){ if (!o) return ''; const f = S[scene]; return f ? f(o) : ''; }
  function svg(scene, o, px){ return `<svg viewBox="0 0 100 100" width="${px}" height="${px}" aria-hidden="true">${cell(scene, o)}</svg>`; }
  return {svg, cell, scenes:S};
})();
