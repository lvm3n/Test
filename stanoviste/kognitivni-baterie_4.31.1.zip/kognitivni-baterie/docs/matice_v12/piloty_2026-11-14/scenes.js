    /* od 2026-11-14 (piloty V12-231 až V12-235): pět nových scén, každá pro jeden nový princip (žádná se neopakuje) */
    balloon_sort:(o) => { const X = [13.5, 37.5, 62.5, 86.5], R = {1:5, 2:7.5, 3:10, 4:12.5}, cy = 42;
      return `<line x1="4" y1="90" x2="96" y2="90" stroke="#D3DAE2" stroke-width="1.4"/>` + o.z.map((z, k) => { const r = R[z], x = X[k];
        return `<path d="M${x} ${cy + r + 2} Q${x - 3} ${(cy + r + 90) / 2} ${x} 90" fill="none" stroke="#8A96A3" stroke-width="1.2"/>` +
          `<path d="M${x - 2} ${cy + r + 2.6} L${x + 2} ${cy + r + 2.6} L${x} ${cy + r - .6} Z" fill="${col(o.c[k])}" stroke="${INK}" stroke-width="1"/>` +
          `<circle cx="${x}" cy="${cy}" r="${r}" fill="${col(o.c[k])}" stroke="${INK}" stroke-width="1.5"/>`; }).join(''); },
    arrow_branches:(o) => { const P = [[29, 29], [71, 29], [29, 71], [71, 71]];
      return `<rect x="6" y="6" width="88" height="88" rx="9" fill="#FBFBFD" stroke="#D3DAE2" stroke-width="1.4"/>` +
        o.a.map(([d, c], k) => `<g transform="translate(${P[k][0]} ${P[k][1]}) rotate(${d * 45})"><polygon points="0,-16 10,-4 4,-4 4,14 -4,14 -4,-4 -10,-4" fill="${col(c)}" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/></g>`).join(''); },
    swap_attrs:(o) => [[o.L, 27], [o.R, 73]].map(([x, cx]) => shape(x[0], cx, 50, x[2] === 'big' ? 20 : 10.5, {color:x[1], fill:x[3]})).join(''),
    mirror_side:(o) => { const X = [19, 39.5, 60.5, 81];
      let h = `<rect x="8" y="8" width="84" height="84" rx="6" fill="#FFFFFF" stroke="#C9D1DA" stroke-width="1.4"/>`;
      h += o.v ? `<rect x="${o.g ? 50 : 8}" y="8" width="42" height="84" fill="#E4E8EE"/>` : `<rect x="8" y="${o.g ? 50 : 8}" width="84" height="42" fill="#E4E8EE"/>`;
      h += o.v ? `<line x1="50" y1="5" x2="50" y2="95" stroke="#2B3440" stroke-width="2" stroke-dasharray="5 3.5"/>` : `<line x1="5" y1="50" x2="95" y2="50" stroke="#2B3440" stroke-width="2" stroke-dasharray="5 3.5"/>`;
      return h + o.o.map(([x, y, c, mx, my]) => `<g transform="translate(${X[x]} ${X[y]}) scale(${mx ? -1.25 : 1.25} ${my ? -1.25 : 1.25})"><line x1="-5" y1="-9" x2="-5" y2="9" stroke="${INK}" stroke-width="2.2" stroke-linecap="round"/>` +
        `<polygon points="-5,-9.5 8,-5 -5,-0.5" fill="${col(c)}" stroke="${INK}" stroke-width="1.4" stroke-linejoin="round"/></g>`).join(''); },
    pointing:(o) => { const P = [[50, 22], [20, 76], [80, 76]];
      return o.t.map((t, k) => { const a = Math.atan2(P[t][1] - P[k][1], P[t][0] - P[k][0]) * 180 / Math.PI;
        return `<g transform="translate(${P[k][0]} ${P[k][1]}) rotate(${a.toFixed(2)})"><polygon points="19,0 5,-11 5,-5 -13,-5 -13,5 5,5 5,11" fill="${col(o.c[k])}" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/></g>`; }).join(''); },
