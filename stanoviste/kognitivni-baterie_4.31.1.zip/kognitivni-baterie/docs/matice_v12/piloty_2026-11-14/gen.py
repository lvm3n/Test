# Generátor a kontrola jednoznačnosti nových pilotních položek V12-231..235 (2026-11-14).
# Poučení z V12-221..228 (analýza M12-K35-v2, 14. 11. 2026):
#  - jednokrokové „abstraktní“ převody (počet teček → strany, druhy → tečky, jedinečná barva → cíl, strany → kroky)
#    se ze tří ukázek odhalí pouhou souvislostí a vyšly mnohem lehčí, než se čekalo (221 b −2,6, 225 b −2,1, 224 100 %),
#    s nízkou diskriminací; novost scény sama obtížnost nedělá;
#  - pravidlo, které připouští víc čtení (222 „liší se právě v jedné vlastnosti“), dává jen šum (r 0,06);
#  - fungovaly 226 a 227: jeden jasný vztah, ale se silným a věrohodným lákadlem (nejbližší dvojice, stín dolů),
#    které ukázky vyvracejí – vyšly kolem průměru s a 2,3–2,8;
#  - v pásmu b 0,3–0,9 v bance fungují úlohy, kde se dvě změny vážou na různé věci (místo vs. objekt: 97, 55, 50, 53);
#    nejtěžší úlohy s množinovou operací + další transformací (46, 78, 39_r2) mají a jen kolem 1.
# Proto: každá nová úloha = lákavé „přirozené“ čtení, které ukázky vyvrátí, nebo dvě změny vázané na různé nositele;
# žádné počítání, rychlé provedení, jednoznačnost strojově proti konkurenčním pravidlům.
# Spuštění: python3 gen.py  → vypíše kontrolu a uloží new_items_231_235.json
import json, itertools, copy

REPORT = []
def check(iid, demos, test, rule, hyps, distractors):
    ok = True; msgs = []
    for k, (i, o) in enumerate(demos):
        if rule(i) != o: ok = False; msgs.append(f'pravidlo nesedí na ukázku {k+1}: {rule(i)} vs {o}')
    ans = rule(test); fit = []
    for name, h in hyps.items():
        try: fits = all(h(i) == o for i, o in demos)
        except Exception: fits = False
        if fits:
            try: hv = h(test)
            except Exception: hv = None
            if hv != ans: ok = False; msgs.append(f'konkurenční pravidlo „{name}“ sedí na všechny ukázky a dává jiný výsledek: {hv}')
            else: fit.append(name)
    outs = [ans] + [o for _, o in distractors]
    for a, b in itertools.combinations(range(len(outs)), 2):
        if outs[a] == outs[b]: ok = False; msgs.append(f'shodné možnosti {a} a {b}')
    REPORT.append((iid, ok, len(hyps), fit, msgs)); return ans

def item(**kw):
    base = dict(format='triples_3x2', tier='ceiling', randomize_options_in_deployment=True, pilot=1, source='pilot-2026-11-14',
                complexity={'integration': 'dissociation', 'rule_depth': 2, 'sensory_load': 'low'}, n_rules=2)
    base.update(kw); return base
def finish(it, demos, test, ans, distractors):
    it['stem'] = [[i, o] for i, o in demos] + [[test, None]]
    it['options'] = [ans] + [o for _, o in distractors]
    it['option_models'] = ['correct'] + [n for n, _ in distractors]
    it['correct_index'] = 0; return it
ITEMS = []

# ---------- V12-231 balloon_sort: velikosti se seřadí od nejmenší, barvy zůstanou na svých místech ----------
def r231(i): return {'z': sorted(i['z']), 'c': i['c'][:]}
def whole_sorted(i, rev=False):
    p = sorted(range(4), key=lambda k: i['z'][k], reverse=rev); return {'z': [i['z'][k] for k in p], 'c': [i['c'][k] for k in p]}
H231 = {'seřadit celé balónky': lambda i: whole_sorted(i), 'seřadit celé sestupně': lambda i: whole_sorted(i, True),
        'velikosti sestupně, barvy stojí': lambda i: {'z': sorted(i['z'], reverse=True), 'c': i['c'][:]},
        'obrátit velikosti': lambda i: {'z': i['z'][::-1], 'c': i['c'][:]}, 'obrátit celé': lambda i: {'z': i['z'][::-1], 'c': i['c'][::-1]},
        'barvy podle velikosti, velikosti stojí': lambda i: {'z': i['z'][:], 'c': whole_sorted(i)['c']},
        'posun velikostí doprava': lambda i: {'z': i['z'][-1:] + i['z'][:-1], 'c': i['c'][:]},
        'posun velikostí doleva': lambda i: {'z': i['z'][1:] + i['z'][:1], 'c': i['c'][:]},
        'prohodit krajní velikosti': lambda i: {'z': [i['z'][3]] + i['z'][1:3] + [i['z'][0]], 'c': i['c'][:]},
        'beze změny': lambda i: copy.deepcopy(i)}
D231 = [({'z': [3, 1, 4, 2], 'c': ['blue', 'red', 'yellow', 'green']}, None),
        ({'z': [2, 4, 1, 3], 'c': ['purple', 'yellow', 'blue', 'red']}, None),
        ({'z': [4, 2, 3, 1], 'c': ['green', 'blue', 'red', 'purple']}, None)]
D231 = [(i, r231(i)) for i, _ in D231]
T231 = {'z': [2, 3, 1, 4], 'c': ['red', 'green', 'purple', 'blue']}
dis231 = [('seřazené celé balónky (barvy se stěhují)', whole_sorted(T231)), ('obrácené velikosti', {'z': T231['z'][::-1], 'c': T231['c'][:]}),
          ('sestupně, barvy stojí', {'z': [4, 3, 2, 1], 'c': T231['c'][:]}), ('barvy podle velikosti, velikosti stojí', {'z': T231['z'][:], 'c': whole_sorted(T231)['c']}),
          ('beze změny', copy.deepcopy(T231))]
ans = check('V12-231', D231, T231, r231, H231, dis231)
ITEMS.append(finish(item(id='V12-231', scene='balloon_sort', relation_family='sort_size_colour_bound_to_place', strategy_superfamily='dissociation_place_object',
    principle='Velikosti balónků se seřadí od nejmenšího po největší zleva doprava, ale barvy zůstanou na svých místech (stěhuje se jen velikost, ne celý balónek).',
    active_dimensions=['velikost', 'pořadí', 'barva vázaná na místo'], b_odhad=0.3, pilot_okno=['V12-53', 'V12-97'],
    notes='Pilot 2026-11-14: cíl b 0,2–0,5 na společné škále. Lákadlo „seřaď celé balónky“ (jako 226/227: přirozené čtení, které ukázky vyvracejí). Obrácení ≠ seřazení ve všech ukázkách.'),
    D231, T231, ans, dis231))

# ---------- V12-232 arrow_branches: modré šipky se otočí o 180°, žluté o 90° po směru hodin ----------
# vstup {'a': [[směr 0/2/4/6, barva] × 4]} (pozice 2×2: LH, PH, LD, PD)
def turn(d, k): return (d + k) % 8
def r232(i): return {'a': [[turn(d, 4 if c == 'blue' else 2), c] for d, c in i['a']]}
def by(f): return lambda i: {'a': [[turn(d, f(k, d, c)), c] for k, (d, c) in enumerate(i['a'])]}
H232 = {'všechny o 180°': by(lambda k, d, c: 4), 'všechny o 90° doprava': by(lambda k, d, c: 2), 'všechny o 90° doleva': by(lambda k, d, c: 6),
        'větve prohozené (modré 90°, žluté 180°)': by(lambda k, d, c: 2 if c == 'blue' else 4),
        'modré 180°, žluté 90° doleva': by(lambda k, d, c: 4 if c == 'blue' else 6),
        'modré 180°, žluté stojí': by(lambda k, d, c: 4 if c == 'blue' else 0), 'žluté 90°, modré stojí': by(lambda k, d, c: 0 if c == 'blue' else 2),
        'horní řada 180°, dolní 90°': by(lambda k, d, c: 4 if k < 2 else 2), 'levý sloupec 180°, pravý 90°': by(lambda k, d, c: 4 if k % 2 == 0 else 2),
        'svislé 180°, vodorovné 90°': by(lambda k, d, c: 4 if d in (0, 4) else 2), 'vodorovné 180°, svislé 90°': by(lambda k, d, c: 4 if d in (2, 6) else 2),
        'úhlopříčka 180°': by(lambda k, d, c: 4 if k in (0, 3) else 2), 'beze změny': by(lambda k, d, c: 0)}
B, Y = 'blue', 'yellow'
D232 = [{'a': [[0, B], [2, Y], [6, Y], [0, B]]}, {'a': [[2, Y], [4, B], [2, B], [0, Y]]}, {'a': [[6, B], [6, Y], [4, Y], [2, B]]}]
D232 = [(i, r232(i)) for i in D232]
T232 = {'a': [[4, Y], [2, B], [0, B], [6, Y]]}
dis232 = [('všechny o 180°', H232['všechny o 180°'](T232)), ('všechny o 90° doprava', H232['všechny o 90° doprava'](T232)),
          ('větve prohozené', H232['větve prohozené (modré 90°, žluté 180°)'](T232)), ('žluté 90° doleva', H232['modré 180°, žluté 90° doleva'](T232)),
          ('jen modré, žluté stojí', H232['modré 180°, žluté stojí'](T232))]
ans = check('V12-232', D232, T232, r232, H232, dis232)
ITEMS.append(finish(item(id='V12-232', scene='arrow_branches', relation_family='colour_selects_operation', strategy_superfamily='conditional_by_attribute',
    principle='Každá šipka se otočí podle své barvy: modrá o 180° (obrátí se), žlutá o čtvrt otáčky po směru hodinových ručiček.',
    active_dimensions=['barva', 'otočení', 'dvě větve'], b_odhad=0.5, pilot_okno=['V12-19', 'V12-49'],
    notes='Pilot 2026-11-14: cíl b 0,4–0,7. Dvě operace vázané na barvu (ne na polohu ani na směr šipky – v ukázkách rozvázáno a strojově ověřeno). Lákadla: všechny stejně, prohozené větve, jen jedna barva.'),
    D232, T232, ans, dis232))

# ---------- V12-233 swap_attrs: dva tvary si vymění barvu a velikost; tvar a výplň zůstanou ----------
# objekt [tvar, barva, velikost 'big'/'small', výplň 'solid'/'hollow']; vstup {'L': obj, 'R': obj}
ATTR = ['tvar', 'barva', 'velikost', 'výplň']
def swap(i, ks): L, R = i['L'][:], i['R'][:]
def swapk(i, ks):
    L, R = i['L'][:], i['R'][:]
    for k in ks: L[k], R[k] = i['R'][k], i['L'][k]
    return {'L': L, 'R': R}
def r233(i): return swapk(i, (1, 2))
H233 = {('vymění ' + '+'.join(ATTR[k] for k in ks) if ks else 'beze změny'): (lambda ks: lambda i: swapk(i, ks))(ks)
        for n in range(5) for ks in itertools.combinations(range(4), n) if ks != (1, 2)}
H233.update({'oba převezmou barvu a velikost levého': lambda i: {'L': i['L'][:], 'R': [i['R'][0], i['L'][1], i['L'][2], i['R'][3]]},
             'oba převezmou barvu a velikost pravého': lambda i: {'L': [i['L'][0], i['R'][1], i['R'][2], i['L'][3]], 'R': i['R'][:]},
             'velikost se obrátí, barvy vymění': lambda i: {'L': [i['L'][0], i['R'][1], 'small' if i['L'][2] == 'big' else 'big', i['L'][3]], 'R': [i['R'][0], i['L'][1], 'small' if i['R'][2] == 'big' else 'big', i['R'][3]]}})
D233 = [{'L': ['circle', 'blue', 'big', 'solid'], 'R': ['square', 'red', 'small', 'hollow']},
        {'L': ['triangle', 'green', 'small', 'hollow'], 'R': ['hex', 'yellow', 'big', 'solid']},
        {'L': ['star', 'red', 'big', 'hollow'], 'R': ['diamond', 'purple', 'small', 'hollow']}]
D233 = [(i, r233(i)) for i in D233]
T233 = {'L': ['square', 'yellow', 'small', 'solid'], 'R': ['triangle', 'blue', 'big', 'hollow']}
dis233 = [('celé tvary si vymění místa', swapk(T233, (0, 1, 2, 3))), ('vymění jen barvu', swapk(T233, (1,))), ('vymění jen velikost', swapk(T233, (2,))),
          ('vymění barvu, velikost i výplň', swapk(T233, (1, 2, 3))), ('vymění tvar a výplň (= správné zrcadlově)', swapk(T233, (0, 3)))]
ans = check('V12-233', D233, T233, r233, H233, dis233)
ITEMS.append(finish(item(id='V12-233', scene='swap_attrs', relation_family='swap_two_of_four_attributes', strategy_superfamily='dissociation_place_object',
    principle='Dva tvary si vymění barvu a velikost. Tvar i výplň (plný / obrys) zůstanou na svém místě.',
    active_dimensions=['tvar', 'barva', 'velikost', 'výplň', 'co se stěhuje'], b_odhad=0.4, pilot_okno=['V12-57', 'V12-11_r'],
    notes='Pilot 2026-11-14: cíl b 0,3–0,6. Korespondence: velký modrý „se přestěhuje“ doprava a změní tvar, nebo tvar zůstal a převzal barvu i velikost? Strojově ověřeno proti všem 16 podmnožinám výměny vlastností; lákadlo „celé tvary si vymění místa“ a zrcadlový obraz správné odpovědi.'),
    D233, T233, ans, dis233))

# ---------- V12-234 mirror_side: tvary v šedé polovině se překlopí přes čáru do bílé ----------
# vstup {'v': 1 svislá čára / 0 vodorovná, 'g': 0 šedá vlevo/nahoře, 1 vpravo/dole, 'o': [[sloupec, řádek, barva, zrcadlo_x, zrcadlo_y] ...]} mřížka 4×4
def in_grey(i, x, y): return (x // 2 if i['v'] else y // 2) == i['g']
def norm(o): return sorted([list(t) for t in o])
def refl(i, t, axis_v):
    x, y, c, mx, my = t
    return [3 - x, y, c, 1 - mx, my] if axis_v else [x, 3 - y, c, mx, 1 - my]
def r234(i): return {'v': i['v'], 'g': i['g'], 'o': norm([refl(i, t, i['v']) if in_grey(i, t[0], t[1]) else t for t in i['o']])}
def H(f): return lambda i: {'v': i['v'], 'g': i['g'], 'o': norm(f(i))}
H234 = {'posun místo překlopení': H(lambda i: [([t[0] + (2 if i['g'] == 0 else -2), t[1]] if i['v'] else [t[0], t[1] + (2 if i['g'] == 0 else -2)]) + t[2:] if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'překlopí se všechny': H(lambda i: [refl(i, t, i['v']) for t in i['o']]),
        'překlopí se bílá polovina': H(lambda i: [refl(i, t, i['v']) if not in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'kopie (originál zůstane)': H(lambda i: i['o'] + [refl(i, t, i['v']) for t in i['o'] if in_grey(i, t[0], t[1])]),
        'místo se překlopí, tvar ne': H(lambda i: [(refl(i, t, i['v'])[:3] + t[3:]) if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'tvar se otočí na místě': H(lambda i: [(t[:3] + refl(i, t, i['v'])[3:]) if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'vždy přes svislou čáru': H(lambda i: [refl(i, t, True) if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'vždy přes vodorovnou čáru': H(lambda i: [refl(i, t, False) if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'otočení o 180° kolem středu': H(lambda i: [[3 - t[0], 3 - t[1], t[2], 1 - t[3], 1 - t[4]] if in_grey(i, t[0], t[1]) else t for t in i['o']]),
        'beze změny': H(lambda i: i['o'])}
D234 = [{'v': 1, 'g': 0, 'o': [[0, 0, 'blue', 0, 0], [1, 2, 'red', 0, 0], [3, 3, 'green', 0, 0]]},
        {'v': 0, 'g': 1, 'o': [[1, 3, 'yellow', 0, 0], [2, 2, 'blue', 0, 0], [3, 0, 'red', 0, 0]]},
        {'v': 1, 'g': 1, 'o': [[3, 1, 'purple', 0, 0], [2, 3, 'green', 0, 0], [0, 2, 'yellow', 0, 0]]}]
for d in D234: d['o'] = norm(d['o'])
D234 = [(i, r234(i)) for i in D234]
T234 = {'v': 0, 'g': 0, 'o': norm([[0, 0, 'red', 0, 0], [2, 1, 'green', 0, 0], [3, 3, 'blue', 0, 0]])}
dis234 = [('posun místo překlopení', H234['posun místo překlopení'](T234)), ('kopie (originál zůstane)', H234['kopie (originál zůstane)'](T234)),
          ('místo se překlopí, tvar ne', H234['místo se překlopí, tvar ne'](T234)), ('přes svislou čáru', H234['vždy přes svislou čáru'](T234)),
          ('překlopí se bílá polovina', H234['překlopí se bílá polovina'](T234))]
ans = check('V12-234', D234, T234, r234, H234, dis234)
ITEMS.append(finish(item(id='V12-234', scene='mirror_side', relation_family='reflect_selected_half', strategy_superfamily='spatial_transformation',
    principle='Čárkovaná čára je zrcadlo. Vlaječky v šedé polovině se překlopí přes čáru do bílé poloviny (zrcadlově – změní se místo i to, kam vlaječka ukazuje). Vlaječky v bílé polovině zůstanou.',
    active_dimensions=['výběr poloviny', 'osa zrcadlení', 'zrcadlový obraz'], b_odhad=0.4, pilot_okno=['V12-34_r2', 'V12-52'],
    notes='Pilot 2026-11-14: cíl b 0,3–0,6. Osa se v ukázkách mění (svislá, vodorovná), šedá polovina také; lákadla posun místo zrcadlení, kopie, překlopení jen místa.'),
    D234, T234, ans, dis234))

# ---------- V12-235 pointing: každá šipka převezme barvu té šipky, na kterou ukazuje ----------
# vstup {'c': [barvy 3 šipek: nahoře, vlevo dole, vpravo dole], 't': [na koho která ukazuje]}
def r235(i): return {'c': [i['c'][t] for t in i['t']], 't': i['t'][:]}
def pointed_by(i, k):
    p = [j for j, t in enumerate(i['t']) if t == k]; assert len(p) == 1; return p[0]
H235 = {'převezme barvu té, která ukazuje na ni': lambda i: {'c': [i['c'][pointed_by(i, k)] for k in range(3)], 't': i['t'][:]},
        'barvy po směru hodin': lambda i: {'c': [i['c'][1], i['c'][2], i['c'][0]], 't': i['t'][:]},
        'barvy proti směru hodin': lambda i: {'c': [i['c'][2], i['c'][0], i['c'][1]], 't': i['t'][:]},
        'prohodí se jen dvojice, které na sebe ukazují': lambda i: {'c': [i['c'][i['t'][k]] if i['t'][i['t'][k]] == k else i['c'][k] for k in range(3)], 't': i['t'][:]},
        'všechny barvu té, na kterou se ukazuje nejvíc': lambda i: {'c': [i['c'][max(range(3), key=lambda k: (i['t'].count(k), -k))]] * 3, 't': i['t'][:]},
        'beze změny': lambda i: copy.deepcopy(i),
        'barvu té, na kterou neukazuje': lambda i: {'c': [i['c'][3 - k - i['t'][k]] for k in range(3)], 't': i['t'][:]}}
D235 = [{'c': ['blue', 'red', 'yellow'], 't': [1, 2, 0]},
        {'c': ['green', 'purple', 'blue'], 't': [1, 0, 0]},
        {'c': ['red', 'yellow', 'green'], 't': [2, 2, 1]}]
D235 = [(i, r235(i)) for i in D235]
T235 = {'c': ['purple', 'green', 'yellow'], 't': [1, 2, 1]}   # správně [green, yellow, green]
def inv_any(i):   # obrácený vztah: šipka, na kterou se ukazuje, převezme barvu ukazující (u více ukazujících ta první)
    c = i['c'][:]; out = c[:]
    for k in range(3):
        p = [j for j, t in enumerate(i['t']) if t == k]
        if p: out[k] = c[p[0]]
    return {'c': out, 't': i['t'][:]}
dis235 = [('obrácený vztah (barvu té, která ukazuje na ni)', inv_any(T235)), ('barvy po směru hodin (jen poslední jinak)', H235['barvy po směru hodin'](T235)),
          ('prohodí se jen dvojice, které na sebe ukazují', H235['prohodí se jen dvojice, které na sebe ukazují'](T235)),
          ('všechny barvu nejvíc ukazované', {'c': ['green'] * 3, 't': T235['t'][:]}), ('beze změny', copy.deepcopy(T235))]
ans = check('V12-235', D235, T235, r235, H235, dis235)
ITEMS.append(finish(item(id='V12-235', scene='pointing', relation_family='take_colour_of_target', strategy_superfamily='relational_reference',
    principle='Každá šipka převezme barvu té šipky, na kterou ukazuje (všechny najednou, podle původních barev). Směry šipek se nemění.',
    active_dimensions=['směr vztahu', 'barva', 'současná změna'], b_odhad=0.8, pilot_okno=['V12-11_r', 'V12-50'],
    notes='Pilot 2026-11-14: cíl b 0,6–1,0. Lákadlo obrácený vztah („kdo ukazuje na mě“) a posun barev po kruhu; ukázka 1 je cyklus (posun po kruhu tam sedí), ukázky 2–3 ho vyvracejí. Test cyklus není (dvě šipky ukazují na tutéž), takže pouhý posun barev po kruhu nestačí.'),
    D235, T235, ans, dis235))

for it in ITEMS: it['order'] = 99
for iid, ok, nh, fit, msgs in REPORT:
    print(iid, 'OK' if ok else 'CHYBA', f'hypotéz {nh}, sedí na ukázky (a dávají totéž): {fit}', *msgs, sep=' | ')
json.dump(ITEMS, open(__file__.replace('gen.py', 'new_items_231_235.json'), 'w'), ensure_ascii=False, indent=1)
print('uloženo', len(ITEMS))
