import sys,json,re
p=sys.argv[1]; lang=sys.argv[2]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:100]))
    s=s.replace(a,b)
G=json.load(open('/mnt/user-data/uploads/gf_v12_pilot_pool_40.json'))
PRAC=[{"id":"P1","order":0,"tier":"nacvik","format":"series","scene":"paired_emblems","stem":[{"shape":"star","color":"green"}]*4+[None],
       "options":[{"shape":"circle","color":"green"},{"shape":"star","color":"green"},{"shape":"star","color":"red"},{"shape":"square","color":"green"},{"shape":"star","color":"blue"},{"shape":"triangle","color":"yellow"}],"correct_index":1},
      {"id":"P2","order":0,"tier":"nacvik","format":"series","scene":"paired_emblems","stem":[{"shape":"square","color":"red"},{"shape":"diamond","color":"blue"},{"shape":"square","color":"red"},{"shape":"diamond","color":"blue"},None],
       "options":[{"shape":"diamond","color":"blue"},{"shape":"square","color":"blue"},{"shape":"circle","color":"red"},{"shape":"square","color":"red"},{"shape":"diamond","color":"red"},{"shape":"triangle","color":"yellow"}],"correct_index":3}]
BANK={"version":"M12-40-pilot","items":G['items'],"practice":PRAC}
TX_CZ="""{name:'Matice', blurb:'Doplň chybějící obrázek', read:'Přečíst', back:'Zpět do menu', tryIt:'Vyzkoušet', readyH:'Teď naostro', start:'Začít',
  practice:'Zácvik', done:'Hotovo', option:'Možnost', endH:'Hotovo, děkujeme.', endP:'Tahle část je u konce.', toMenu:'Zpět na výběr testu',
  ok:'Správně.', notYet:'Ještě ne.', correctIs:'Správně je tento obrázek:', cont:'Pokračovat', warn15:'Zbývá 15 sekund.',
  timeTxt:(s) => 'Na úlohu je ' + s + ' sekund.',
  lead:['Najděte pravidlo a vyberte obrázek, který patří na místo otazníku.', 'Najdi pravidlo a vyber obrázek, který patří na místo otazníku.'],
  intro:['V každé úloze se obrázky mění podle nějakého pravidla – v řadě, v řádcích nebo ve dvojicích. Najděte pravidlo a vyberte ze šesti možností obrázek, který patří na místo otazníku. Vybranou možnost potvrďte tlačítkem Hotovo. Úlohy jsou různě těžké a nejdou přesně od nejlehčí po nejtěžší. Nejdřív si to vyzkoušíte na dvou cvičných úlohách.',
         'V každé úloze se obrázky mění podle nějakého pravidla – v řadě, v řádcích nebo ve dvojicích. Najdi pravidlo a vyber ze šesti možností obrázek, který patří na místo otazníku. Vybranou možnost potvrď tlačítkem Hotovo. Úlohy jsou různě těžké a nejdou přesně od nejlehčí po nejtěžší. Nejdřív si to vyzkoušíš na dvou cvičných úlohách.'],
  ready:['Teď už neuvidíte, jestli jste odpověděli správně. Na každou úlohu je 60 sekund; když nestihnete potvrdit, počítá se označená možnost. Některé úlohy jsou velmi těžké – nevadí, když je nevyřešíte.',
         'Teď už neuvidíš, jestli jsi odpověděl správně. Na každou úlohu je 60 sekund; když nestihneš potvrdit, počítá se označená možnost. Některé úlohy jsou velmi těžké – nevadí, když je nevyřešíš.']}"""
TX_EN="""{name:'Matrices', blurb:'Complete the missing picture', read:'Read aloud', back:'Back to menu', tryIt:'Try it', readyH:'Now for real', start:'Start',
  practice:'Practice', done:'Done', option:'Option', endH:'Done, thank you.', endP:'This part is finished.', toMenu:'Back to test selection',
  ok:'Correct.', notYet:'Not yet.', correctIs:'This is the correct picture:', cont:'Continue', warn15:'15 seconds left.',
  timeTxt:(s) => 'Time for this item: ' + s + ' seconds.',
  lead:['Find the rule and choose the picture that belongs in place of the question mark.', 'Find the rule and choose the picture that belongs in place of the question mark.'],
  intro:['In each item the pictures change according to a rule – in a row, in rows or in pairs. Find the rule and choose, from six options, the picture that belongs in place of the question mark. Confirm your choice with Done. The items vary in difficulty and do not go strictly from easiest to hardest. First you will try two practice items.',
         'In each item the pictures change according to a rule – in a row, in rows or in pairs. Find the rule and choose, from six options, the picture that belongs in place of the question mark. Confirm your choice with Done. The items vary in difficulty and do not go strictly from easiest to hardest. First you will try two practice items.'],
  ready:['From now on you will not see whether your answer was correct. You have 60 seconds per item; if you do not confirm in time, the selected option counts. Some items are very hard – it is fine if you cannot solve them.',
         'From now on you will not see whether your answer was correct. You have 60 seconds per item; if you do not confirm in time, the selected option counts. Some items are very hard – it is fine if you cannot solve them.']}"""
render=open('/home/claude/m12/render.js',encoding='utf8').read(); mod=open('/home/claude/m12/module.js',encoding='utf8').read(); css=open('/home/claude/m12/style.css',encoding='utf8').read()
code="const BANK_M12 = "+json.dumps(BANK,ensure_ascii=False,separators=(',',':'))+";\nconst M12_TX = "+(TX_CZ if lang=='cz' else TX_EN)+";\n"+render+"\n"+mod+"\n"
rep("function mod_dedukce(root, B){", code+"function mod_dedukce(root, B){")
rep('<div id="m-pravidla"></div>','<div id="m-pravidla"></div>\n<div id="m-matice12"></div>')
rep(" mod_pravidla(document.getElementById(\"m-pravidla\"), BANK_PRAVIDLA),"," mod_pravidla(document.getElementById(\"m-pravidla\"), BANK_PRAVIDLA),\n mod_matice12(document.getElementById(\"m-matice12\"), BANK_M12, M12_TX),")
k=s.index('</style>'); s=s[:k]+css+s[k:]
if lang=='cz':
    rep("PUBLIC_HIDE = ['stroje', 'zasoba2', 'znalosti2'];","PUBLIC_HIDE = ['stroje', 'zasoba2', 'znalosti2', 'matice'];   // od 3.73.0 místo Matic v10 veřejně Matice V12 (matice12)")
else:
    m=re.search(r"const EN_KEYS = \[([^\]]*)\]",s); keys=m.group(0)
    s=s.replace(keys, keys.replace("'matice',","'matice12',"),1)
open(p,'w',encoding='utf8').write(s); print('patch5 ok',p)
