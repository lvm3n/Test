/* ===== Matice V12 (Gf – indukce, 40 položek, pilotní pool; 6 možností v náhodném pořadí) ===== */
function mod_matice12(root, B, TX){
  const K = 'matice12', VERSION = B.version || 'V12-pilot-pool-40', ITEMS = B.items, PRAC = B.practice, CAP = 60;
  const show = (id) => showIn(root, id), $ = (q) => root.querySelector(q), L = 'ABCDEF';
  const T = (v) => Array.isArray(v) ? (formalAddress() ? v[0] : v[1]) : v;
  root.innerHTML = `
<section class="screen" id="${K}-instr"><div class="wrap" style="max-width:860px">
  <div class="instr"><h1 data-heading>${TX.name}</h1><button class="speak" data-say="instr">${TX.read}</button></div>
  <p class="m12-txt" id="${K}-intro"></p>
  <div class="actions"><button class="btn ghost" data-back>${TX.back}</button><button class="btn" id="${K}-go">${TX.tryIt}</button></div>
</div></section>
<section class="screen" id="${K}-ready"><div class="wrap" style="max-width:860px">
  <h1 data-heading>${TX.readyH}</h1><p class="m12-txt" id="${K}-readytxt"></p>
  <div class="actions"><button class="btn" id="${K}-start">${TX.start}</button></div>
</div></section>
<section class="screen" id="${K}-task"><div class="wrap m12-wrap">
  <div class="progress" aria-hidden="true"><i id="${K}-prog" style="width:0%"></i></div>
  <p class="pill" id="${K}-pill" hidden>${TX.practice}</p>
  <p class="m12-lead" id="${K}-lead"></p>
  <div class="m12-grid">
    <div class="m12-stem" id="${K}-stem"></div>
    <div class="m12-side"><div class="m12-opts" id="${K}-opts" role="group"></div>
      <p class="m12-time" id="${K}-time"></p>
      <div class="actions" style="margin-top:6px"><button class="btn" id="${K}-done" disabled>${TX.done}</button></div>
      <div class="m12-fb" id="${K}-fb" hidden></div></div>
  </div>
</div></section>
<section class="screen" id="${K}-end"><div class="wrap" style="max-width:860px">
  <h1 data-heading>${TX.endH}</h1><p class="m12-txt">${TX.endP}</p>
  <div class="actions"><button class="btn" data-back>${TX.toMenu}</button></div>
</div></section>`;
  root.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', backToMenu));
  bindSpeak(root, {instr:T(TX.intro)});
  let ST = null, it = null, U = null, timer = null, warnT = null;
  const px = () => innerWidth >= 1100 ? 118 : innerWidth >= 700 ? 96 : 66, opx = () => innerWidth >= 1100 ? 120 : innerWidth >= 700 ? 100 : 74;
  const cellBox = (o, size) => `<div class="m12-cell${o ? '' : ' q'}" style="width:${size}px;height:${size}px">${o ? M12.svg(it.scene, o, size - 6) : '?'}</div>`;
  function order(item){                                   // stálé náhodné pořadí možností pro osobu a položku
    let h = 2166136261; const str = pilotSeed(K + item.id);
    for (let k = 0; k < str.length; k++) { h ^= str.charCodeAt(k); h = Math.imul(h, 16777619); }
    const idx = item.options.map((_, k) => k);
    for (let j = idx.length - 1; j > 0; j--) { h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0; const r = h % (j + 1); [idx[j], idx[r]] = [idx[r], idx[j]]; }
    return idx;
  }
  function render(){
    const o = opx(), st = $('#' + K + '-stem'), avail = Math.max(240, (st.clientWidth || 700) - 28);
    const n = it.format === 'series' ? it.stem.length : (it.stem[0] || []).length, s = Math.max(48, Math.min(px(), Math.floor((avail - 8 * (n - 1)) / n)));   // dlouhá řada se nezalomí
    $('#' + K + '-stem').innerHTML = it.format === 'series'
      ? `<div class="m12-row">${it.stem.map(c => cellBox(c, s)).join('')}</div>`
      : it.stem.map(r => `<div class="m12-row">${r.map(c => cellBox(c, s)).join('')}</div>`).join('');
    $('#' + K + '-opts').innerHTML = U.ord.map((oi, k) => `<button type="button" class="m12-opt${U.sel === k ? ' sel' : ''}" data-k="${k}" aria-pressed="${U.sel === k}" aria-label="${TX.option} ${L[k]}"${U.done ? ' disabled' : ''}><span class="m12-let">${L[k]}</span>${M12.svg(it.scene, it.options[oi], o - 14)}</button>`).join('');
    root.querySelectorAll('.m12-opt').forEach(b => b.addEventListener('click', () => {
      if (U.done) return; const k = +b.dataset.k; if (U.tFirst === null) U.tFirst = Math.round(performance.now() - U.t0);
      if (U.sel !== null && U.sel !== k) U.changes++; U.sel = k; render(); }));
    $('#' + K + '-done').disabled = U.done || U.sel === null;
  }
  function load(item, phase){
    it = item; U = {phase, sel:null, done:false, t0:performance.now(), tFirst:null, changes:0, ord:phase === 'tut' ? item.options.map((_, k) => k) : order(item)};
    $('#' + K + '-pill').hidden = phase !== 'tut';
    $('#' + K + '-prog').style.width = phase === 'tut' ? '0%' : Math.round(100 * ST.i / ITEMS.length) + '%';
    $('#' + K + '-lead').textContent = T(TX.lead);
    $('#' + K + '-fb').hidden = true; $('#' + K + '-time').textContent = '';
    clearTimeout(timer); clearTimeout(warnT);
    if (phase === 'test' && !S.untimed) {
      $('#' + K + '-time').textContent = TX.timeTxt(CAP);
      warnT = setTimeout(() => { if (!U.done && it === item) { $('#' + K + '-time').textContent = TX.warn15; $('#' + K + '-time').classList.add('warn'); } }, (CAP - 15) * 1000);
      timer = setTimeout(() => { if (!U.done && it === item && CUR && CUR.key === K) submit(true); }, CAP * 1000);
    }
    $('#' + K + '-time').classList.remove('warn');
    render(); show(K + '-task'); window.scrollTo(0, 0);
  }
  function submit(timeout){
    if (U.done) return; U.done = true; clearTimeout(timer); clearTimeout(warnT);
    const oi = U.sel === null ? -1 : U.ord[U.sel], ok = oi === it.correct_index;   // i po limitu platí označená volba
    S.rows.push({test:K, forma:VERSION, faze:U.phase === 'tut' ? 'nacvik' : 'test', poradi:U.phase === 'tut' ? '' : ST.i + 1, poradi_banky:it.poradi_banky || it.order || '',
      polozka:it.id, id:it.id, format:it.format, uroven:it.tier || '', rodina:it.relation_family || '', superrodina:it.strategy_superfamily || '',
      reseni:L[it.correct_index], odpoved:oi < 0 ? '' : L[oi], pozice_volby:U.sel === null ? '' : L[U.sel], poradi_moznosti:U.ord.map(i => L[i]).join(''),
      chyba_typ:oi < 0 ? '' : (it.option_models || [])[oi] || '', spravne:ok ? 1 : 0, skore:ok ? 1 : 0, rt_ms:Math.round(performance.now() - U.t0),
      prvni_akce_ms:U.tFirst === null ? '' : U.tFirst, zmeny:U.changes, timeout:timeout ? 1 : 0, time_limit_ms:U.phase === 'tut' || S.untimed ? 0 : CAP * 1000,
      vstup:S.lastPointer || '', cas:new Date().toISOString()});
    save();
    if (U.phase === 'tut') return feedback(ok);
    ST.res[ST.i] = ok ? 1 : 0; ST.run = ok ? 0 : ST.run + 1; ST.i++;
    if (ST.run >= PILOT_STOP) return finish('ukončeno po ' + PILOT_STOP + ' chybách v řadě');
    if (ST.i >= ITEMS.length) return finish('všechny položky');
    load(ITEMS[ST.i], 'test');
  }
  function feedback(ok){
    render();
    const fb = $('#' + K + '-fb'); fb.hidden = false;
    fb.innerHTML = (ok ? `<p class="good"><b>${TX.ok}</b></p>` : `<p class="bad"><b>${TX.notYet}</b> ${TX.correctIs}</p>` + `<div class="m12-row">${cellBox(it.options[it.correct_index], opx())}</div>`) +
      `<div class="actions"><button class="btn" id="${K}-next">${TX.cont}</button></div>`;
    $('#' + K + '-next').onclick = () => { ST.t++; if (ST.t < PRAC.length) load(PRAC[ST.t], 'tut'); else { $('#' + K + '-readytxt').textContent = T(TX.ready); show(K + '-ready'); } };
  }
  function finish(reason){
    clearTimeout(timer); clearTimeout(warnT);
    const raw = ST.res.filter(x => x === 1).length;
    S.scores[K] = {hruby:raw, spravne_administrovane:raw, pripsane:0, administrovano:ST.res.filter(x => x !== undefined).length, start:1, polozek:ITEMS.length, konec:reason, forma:VERSION,
      poradi:'pilot: 5 snadných v pevném pořadí, pak bloky po 6 promíchané'};
    save(); show(K + '-end');
  }
  $('#' + K + '-done').onclick = () => { if (U && U.sel !== null) submit(false); };
  $('#' + K + '-go').onclick = () => { ST = {t:0, i:0, res:[], run:0}; S.mode = 'nacvik'; load(PRAC[0], 'tut'); };
  const begin = () => { pilotOrder(ITEMS, K, 5, 6); ST = Object.assign(ST || {}, {i:0, res:[], run:0}); S.mode = 'test'; load(ITEMS[0], 'test'); };
  $('#' + K + '-start').onclick = begin;
  return {key:K, name:TX.name, blurb:TX.blurb, group:'gf', version:VERSION, show,
    icon:'<svg viewBox="0 0 48 48"><rect x="4" y="4" width="18" height="18" rx="4" fill="#3E6FD6"/><rect x="26" y="4" width="18" height="18" rx="4" fill="#DD5B45"/><rect x="4" y="26" width="18" height="18" rx="4" fill="#F0B83E"/><rect x="26" y="26" width="18" height="18" rx="4" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="4 3"/></svg>',
    prepare(){ CUR.formLabel = VERSION; },
    runSelf(){ $('#' + K + '-intro').textContent = T(TX.intro); if (S.nacvik) show(K + '-instr'); else { $('#' + K + '-readytxt').textContent = T(TX.ready); show(K + '-ready'); } },
    formLabel:''};
}
