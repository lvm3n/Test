    /* od 2026-11-10 (piloty V12-221 až V12-228): osm nových scén, každá pro jeden nový princip (žádná se neopakuje) */
    dots_in_shape:(o) => { if (o.n !== undefined || o.shape) {   // výstup: mnohoúhelník s o.n stranami (nebo kruh / hvězda)
        if (o.shape) return shape(o.shape, 50, 50, 28, {color:'blue'});
        return `<polygon points="${poly(reg(o.n, 28, o.n === 4 ? -45 : -90))}" transform="translate(50 50)" fill="${C.blue}" stroke="${INK}" stroke-width="1.8" stroke-linejoin="round"/>`; }
      let h = shape(o.sh, 50, 50, 30, {color:'gray', fill:'hollow'}).replace(/stroke-width="[0-9.]+"/, 'stroke-width="2.6"');
      return h + (o.in || []).concat(o.out || []).map(([x, y]) => dot(x, y, 4.2, 'dark')).join(''); },
    odd_one:(o) => { if (o.o) return shape(o.o[0], 50, 50, 24, {color:o.o[1], fill:o.o[2]});   // výstup: jeden objekt
      return `<rect x="4" y="30" width="92" height="40" rx="9" fill="#F7F8FA" stroke="#D3DAE2" stroke-width="1.4"/>` + o.r.map((q, k) => shape(q[0], 17 + 22 * k, 50, 8.5, {color:q[1], fill:q[2]})).join(''); },
    type_count:(o) => { if (o.n !== undefined) { const x0 = 50 - (o.n - 1) * 7; return `<rect x="8" y="36" width="84" height="28" rx="8" fill="#F3F5FA" stroke="#AEB8C7" stroke-width="1.8"/>` + Array.from({length:o.n}, (_, k) => dot(x0 + 14 * k, 50, 5, 'dark')).join(''); }
      const SL = [[25, 32], [50, 32], [75, 32], [25, 68], [50, 68], [75, 68]];
      return `<rect x="8" y="12" width="84" height="76" rx="10" fill="#FBF6EC" stroke="#CDBE9E" stroke-width="1.6"/>` + o.o.map(([sh, c, k]) => shape(sh, SL[k][0], SL[k][1], 10.5, {color:c})).join(''); },
    arrow_target:(o) => { const P = (k) => [50 + 36 * Math.sin(k * Math.PI / 4), 50 - 36 * Math.cos(k * Math.PI / 4)];
      let h = `<circle cx="50" cy="50" r="36" fill="none" stroke="#E3E7ED" stroke-width="1.6"/>`;
      h += o.p.map(([k, c]) => { const p = P(k); return dot(p[0].toFixed(2), p[1].toFixed(2), 6.5, c); }).join('');
      return h + `<g transform="translate(50 50) rotate(${o.d * 45})"><polygon points="0,-24 9,-10 4,-10 4,14 -4,14 -4,-10 -9,-10" fill="#2B3440" stroke="#FFFFFF" stroke-width="1.2" stroke-linejoin="round"/></g>`; },
    ring_polygon:(o) => { const P = (k) => [50 + 35 * Math.sin(k * Math.PI / 4), 50 - 35 * Math.cos(k * Math.PI / 4)];
      let h = `<circle cx="50" cy="50" r="35" fill="none" stroke="#D3DAE2" stroke-width="2.2"/>`;
      for (let k = 0; k < 8; k++) { const p = P(k); h += `<circle cx="${p[0].toFixed(2)}" cy="${p[1].toFixed(2)}" r="3.2" fill="#C9D1DA"/>`; }
      h += `<polygon points="${poly(reg(o.n, 17, o.n === 4 ? -45 : -90))}" transform="translate(50 50)" fill="#FFFFFF" stroke="#2B3440" stroke-width="2.4" stroke-linejoin="round"/>`;
      const p = P(o.k); return h + dot(p[0].toFixed(2), p[1].toFixed(2), 7.5, 'green'); },
    connect_pairs:(o) => { let h = `<rect x="6" y="6" width="88" height="88" rx="8" fill="#FBFBFD" stroke="#D3DAE2" stroke-width="1.4"/>`;
      if (o.l && o.l.length === 2) { const a = o.p[o.l[0]], b = o.p[o.l[1]]; h += `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#2B3440" stroke-width="3" stroke-linecap="round"/>`; }
      return h + o.p.map(([x, y, c]) => dot(x, y, 6.5, c)).join(''); },
    shadow:(o) => { const Q = (k, r) => [50 + r * Math.sin(k * Math.PI / 4), 50 - r * Math.cos(k * Math.PI / 4)];
      const s = Q(o.sun, 40); let h = `<circle cx="${s[0].toFixed(2)}" cy="${s[1].toFixed(2)}" r="6" fill="${C.yellow}" stroke="#D99A1E" stroke-width="1.6"/>`;
      [0, 1, 2, 3, 4, 5, 6, 7].forEach(k => { const a = k * Math.PI / 4; h += `<line x1="${(s[0] + 8 * Math.sin(a)).toFixed(2)}" y1="${(s[1] - 8 * Math.cos(a)).toFixed(2)}" x2="${(s[0] + 11 * Math.sin(a)).toFixed(2)}" y2="${(s[1] - 11 * Math.cos(a)).toFixed(2)}" stroke="#D99A1E" stroke-width="1.4" stroke-linecap="round"/>`; });
      if (o.sh !== undefined) { const p = Q(o.sh, 15); h += shape(o.shs || o.s, p[0], p[1], 14, {color:'#515C68'}).replace(/stroke="[^"]+"/, 'stroke="#3B4552"'); }
      return h + (o.ghost ? '' : shape(o.s, 50, 50, 14, {color:o.c})); },
    halves:(o) => { const half = (sh, c, side, cx) => { const b = base(sh, 24); let d;
        if (b.c) { const r = b.c.toFixed(2); d = side === 'L' ? `M0 ${-r} A${r} ${r} 0 0 0 0 ${r} Z` : `M0 ${-r} A${r} ${r} 0 0 1 0 ${r} Z`; }
        else { const pts = b.p, out = []; const inside = (p) => side === 'L' ? p[0] <= 0 : p[0] >= 0;   // ořez mnohoúhelníku svislou osou
          for (let k = 0; k < pts.length; k++) { const a = pts[k], q = pts[(k + 1) % pts.length];
            if (inside(a)) out.push(a); if (inside(a) !== inside(q)) { const t = a[0] / (a[0] - q[0]); out.push([0, a[1] + t * (q[1] - a[1])]); } }
          d = 'M' + out.map(p => p[0].toFixed(2) + ' ' + p[1].toFixed(2)).join(' L') + ' Z'; }
        return `<path d="${d}" transform="translate(${cx} 50)" fill="${col(c)}" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/>`; };
      if (o.h) return half(o.h[0][0], o.h[0][1], o.h[0][2], 50) + half(o.h[1][0], o.h[1][1], o.h[1][2], 50) + `<line x1="50" y1="24" x2="50" y2="76" stroke="#FFFFFF" stroke-width="1.2"/>`;
      return shape(o.L[0], 26, 50, 19, {color:o.L[1]}) + divider + shape(o.R[0], 74, 50, 19, {color:o.R[1]}); },
