# Generátor a kontrola jednoznačnosti nových pilotních položek V12-221..228 (2026-11-10).
# Spuštění: python3 gen.py  → vypíše kontrolu a uloží new_items_221_228.json
import json, itertools, math

REPORT = []
def check(iid, demos, test, rule, hyps, distractors):
    """demos: [(in, out)], test: in, rule: in->out, hyps: {name: in->out|None}, distractors: [(name, out)]"""
    ok = True; msgs = []
    for k, (i, o) in enumerate(demos):
        if rule(i) != o: ok = False; msgs.append(f'pravidlo nesedí na ukázku {k+1}: {rule(i)} vs {o}')
    ans = rule(test)
    fit = []
    for name, h in hyps.items():
        try: fits = all(h(i) == o for i, o in demos)
        except Exception: fits = False
        if fits:
            try: hv = h(test)
            except Exception: hv = None
            if hv != ans: ok = False; msgs.append(f'konkurenční pravidlo „{name}“ sedí na všechny ukázky a dává jiný výsledek: {hv}')
            else: fit.append(name)
    outs = [ans] + [o for _, o in distractors]
    for a, b in itertools.combinations(range(len(outs)), 2):
        if outs[a] == outs[b]: ok = False; msgs.append(f'shodné možnosti {a} a {b}')
    REPORT.append((iid, ok, len(hyps), fit, msgs))
    return ans

def item(**kw):
    base = dict(format='triples_3x2', tier='high', randomize_options_in_deployment=True, pilot=1, source='pilot-2026-11-10',
                complexity={'integration': 'single', 'rule_depth': 2, 'sensory_load': 'low'}, n_rules=1)
    base.update(kw); return base

def finish(it, demos, test, ans, distractors):
    it['stem'] = [[i, o] for i, o in demos] + [[test, None]]
    it['options'] = [ans] + [o for _, o in distractors]
    it['option_models'] = ['correct'] + [n for n, _ in distractors]
    it['correct_index'] = 0
    return it

ITEMS = []

# ---------- V12-221 dots_in_shape: tolik stran, kolik teček uvnitř obrysu ----------
# vstup: {'sh': obrys, 'in': [[x,y],...], 'out': [[x,y],...]}  výstup: {'n': počet stran} nebo {'shape': 'circle'/'star'}
def r221(i): return {'n': len(i['in'])}
H221 = {'všechny tečky': lambda i: {'n': len(i['in']) + len(i['out'])},
        'jen vnější': lambda i: {'n': len(i['out'])},
        'uvnitř − vně': lambda i: {'n': len(i['in']) - len(i['out'])},
        'opsat obrys': lambda i: {'shape': i['sh']} if i['sh'] == 'circle' else {'n': {'square': 4, 'triangle': 3, 'hex': 6}[i['sh']]},
        'uvnitř + 1': lambda i: {'n': len(i['in']) + 1},
        'uvnitř − 1': lambda i: {'n': len(i['in']) - 1}}
D221 = [({'sh': 'square', 'in': [[42, 42], [58, 44], [48, 58]], 'out': [[88, 14]]}, {'n': 3}),
        ({'sh': 'triangle', 'in': [[50, 48], [40, 62], [60, 62], [50, 70], [45, 56]], 'out': []}, {'n': 5}),
        ({'sh': 'hex', 'in': [[40, 42], [60, 42], [40, 58], [60, 58], [50, 50], [50, 68]], 'out': [[12, 12]]}, {'n': 6})]
T221 = {'sh': 'circle', 'in': [[40, 44], [60, 44], [40, 58], [60, 58]], 'out': [[12, 88], [88, 12]]}
dis221 = [('všechny tečky (6)', {'n': 6}), ('uvnitř + 1', {'n': 5}), ('uvnitř − 1', {'n': 3}), ('opsat obrys', {'shape': 'circle'}), ('hvězda', {'shape': 'star'})]
ans = check('V12-221', D221, T221, r221, H221, dis221)
ITEMS.append(finish(item(id='V12-221', scene='dots_in_shape', relation_family='count_inside_to_sides', strategy_superfamily='relational_abstraction',
    principle='Výsledný mnohoúhelník má tolik stran, kolik teček je uvnitř obrysu. Tečky vně obrysu se nepočítají, tvar obrysu nehraje roli.',
    active_dimensions=['počet', 'uvnitř/vně', 'počet stran'], pilot_okno=['V12-52', 'V12-55'],
    notes='Pilot 2026-11-10: horní pásmo (cíl b 0,4–0,8 na společné škále, české +1,2 až +1,9). Obtížnost z objevu „uvnitř“ a „počet → strany“, provedení ~10 s.'),
    D221, T221, ans, dis221))

# ---------- V12-222 odd_one: ten, kdo se od většiny liší právě v jedné vlastnosti ----------
# objekt: [tvar, barva, výplň]; vstup {'r': [4 objekty]}; výstup {'o': objekt}
def majority(objs):
    from collections import Counter
    c = Counter(tuple(o) for o in objs); m, n = c.most_common(1)[0]; assert n >= 2; return list(m)
def ndiff(a, b): return sum(x != y for x, y in zip(a, b))
def r222(i):
    m = majority(i['r']); c = [o for o in i['r'] if ndiff(o, m) == 1]; assert len(c) == 1; return {'o': c[0]}
def uniq_attr(i, k):
    from collections import Counter
    c = Counter(o[k] for o in i['r']); u = [o for o in i['r'] if c[o[k]] == 1]
    return {'o': u[0]} if len(u) == 1 else None
H222 = {'liší se nejvíc': lambda i: {'o': max(i['r'], key=lambda o: ndiff(o, majority(i['r'])))},
        'většinový objekt': lambda i: {'o': majority(i['r'])},
        'jedinečný tvar': lambda i: uniq_attr(i, 0), 'jedinečná barva': lambda i: uniq_attr(i, 1), 'jedinečná výplň': lambda i: uniq_attr(i, 2),
        'vždy první': lambda i: {'o': i['r'][0]}, 'vždy poslední': lambda i: {'o': i['r'][3]}, 'vždy třetí': lambda i: {'o': i['r'][2]},
        'liší se tvarem od většiny': lambda i: (lambda m: {'o': [o for o in i['r'] if o[0] != m[0] and ndiff(o, m) == 1][0]} if any(o[0] != m[0] and ndiff(o, m) == 1 for o in i['r']) else None)(majority(i['r'])),
        'liší se barvou od většiny': lambda i: (lambda m: {'o': [o for o in i['r'] if o[1] != m[1] and ndiff(o, m) == 1][0]} if any(o[1] != m[1] and ndiff(o, m) == 1 for o in i['r']) else None)(majority(i['r']))}
S, H = 'solid', 'hollow'
D222 = [({'r': [['circle', 'blue', S], ['circle', 'red', S], ['circle', 'blue', S], ['square', 'red', S]]}, {'o': ['circle', 'red', S]}),          # liší se barvou
        ({'r': [['triangle', 'green', H], ['triangle', 'green', S], ['hex', 'red', S], ['triangle', 'green', S]]}, {'o': ['triangle', 'green', H]}),  # liší se výplní
        ({'r': [['square', 'yellow', S], ['circle', 'yellow', H], ['star', 'yellow', S], ['square', 'yellow', S]]}, {'o': ['star', 'yellow', S]})]  # liší se tvarem
T222 = {'r': [['hex', 'purple', H], ['hex', 'blue', S], ['hex', 'purple', S], ['hex', 'purple', S]]}   # správně: modrý plný hex (liší se barvou); fialový dutý = liší se jen výplní? ne – ten se liší v 1 taky!
# oprava testu: většina = fialový plný hex; kandidáti s 1 rozdílem musí být jen jeden → dutý fialový nahradíme dvěma rozdíly
T222 = {'r': [['triangle', 'blue', H], ['hex', 'blue', S], ['hex', 'purple', S], ['hex', 'purple', S]]}   # většina fialový plný hex; modrý plný hex = 1 rozdíl (správně); modrý dutý trojúhelník = 3 rozdíly
dis222 = [('liší se nejvíc', {'o': ['triangle', 'blue', H]}), ('většinový objekt', {'o': ['hex', 'purple', S]}),
          ('správný objekt, jiná výplň', {'o': ['hex', 'blue', H]}), ('většina v jiné barvě', {'o': ['hex', 'red', S]}),
          ('tvar odlišného, barva většiny', {'o': ['triangle', 'purple', S]})]
ans = check('V12-222', D222, T222, r222, H222, dis222)
ITEMS.append(finish(item(id='V12-222', scene='odd_one', relation_family='differs_in_exactly_one', strategy_superfamily='relational_abstraction',
    principle='Ve čtveřici jsou dva stejné objekty (většina). Výstup je ten objekt, který se od nich liší právě v jedné vlastnosti (tvar, barva nebo výplň). Objekt, který se liší ve více vlastnostech, je návnada.',
    active_dimensions=['tvar', 'barva', 'výplň', 'počet rozdílů'], pilot_okno=['V12-52', 'V12-55'],
    notes='Pilot 2026-11-10: horní pásmo. V každé ukázce rozhoduje jiná vlastnost (barva, výplň, tvar) a návnada je jinde; „liší se nejvíc“ i „jedinečná barva/tvar“ ukázky vylučují.'),
    D222, T222, ans, dis222))

# ---------- V12-223 type_count: tolik teček, kolik druhů tvarů ----------
# vstup {'o': [[tvar, barva, slot], ...]}  výstup {'n': k}
def r223(i): return {'n': len({o[0] for o in i['o']})}
from collections import Counter
H223 = {'počet tvarů': lambda i: {'n': len(i['o'])}, 'počet barev': lambda i: {'n': len({o[1] for o in i['o']})},
        'počet jedinečných tvarů': lambda i: {'n': sum(1 for v in Counter(o[0] for o in i['o']).values() if v == 1)},
        'počet opakovaných druhů': lambda i: {'n': sum(1 for v in Counter(o[0] for o in i['o']).values() if v > 1)},
        'největší skupina': lambda i: {'n': max(Counter(o[0] for o in i['o']).values())},
        'tvary − barvy': lambda i: {'n': len(i['o']) - len({o[1] for o in i['o']})},
        'počet jedinečných barev': lambda i: {'n': sum(1 for v in Counter(o[1] for o in i['o']).values() if v == 1)}}
D223 = [({'o': [['circle', 'blue', 0], ['square', 'red', 1], ['circle', 'yellow', 2], ['square', 'blue', 3], ['circle', 'green', 4]]}, {'n': 2}),   # 5 tvarů, 2 druhy, 4 barvy
        ({'o': [['triangle', 'red', 0], ['hex', 'red', 2], ['star', 'blue', 3], ['circle', 'blue', 5]]}, {'n': 4}),                              # 4 tvary, 4 druhy, 2 barvy
        ({'o': [['square', 'purple', 0], ['triangle', 'green', 1], ['square', 'yellow', 2], ['triangle', 'blue', 3], ['star', 'red', 4], ['square', 'green', 5]]}, {'n': 3})]  # 6, 3 druhy, 5 barev
T223 = {'o': [['hex', 'blue', 0], ['circle', 'red', 1], ['star', 'blue', 2], ['hex', 'yellow', 3], ['triangle', 'red', 4], ['square', 'yellow', 5]]}   # 6 tvarů, 5 druhů, 3 barvy
dis223 = [('počet tvarů', {'n': 6}), ('počet barev', {'n': 3}), ('počet jedinečných tvarů', {'n': 4}), ('největší skupina / opakované', {'n': 2}), ('jedna', {'n': 1})]
ans = check('V12-223', D223, T223, r223, H223, dis223)
ITEMS.append(finish(item(id='V12-223', scene='type_count', relation_family='count_of_kinds', strategy_superfamily='relational_abstraction',
    principle='Výstup má tolik teček, kolik je ve vstupu druhů tvarů. Barvy ani počet kusů nehrají roli.',
    active_dimensions=['druh', 'počet'], pilot_okno=['V12-52', 'V12-55'],
    notes='Pilot 2026-11-10: horní pásmo. Objev abstrakce „druh“ místo „kus“; barvy jako lákadlo; provedení ~10 s.'),
    D223, T223, ans, dis223))

# ---------- V12-224 arrow_target: šipka se otočí na tečku, která je jediná své barvy ----------
# vstup {'d': směr šipky (osminy, 0 nahoru), 'p': [[pozice 0-7, barva], ...]}  výstup {'d': nový směr, 'p': tečky}
def r224(i):
    c = Counter(col for _, col in i['p']); u = [k for k, col in i['p'] if c[col] == 1]; assert len(u) == 1
    return {'d': u[0], 'p': i['p']}
def angdist(a, b): d = abs(a - b) % 8; return min(d, 8 - d)
def nearest(i):
    ks = [k for k, _ in i['p']]; m = min(angdist(i['d'], k) for k in ks); c = [k for k in ks if angdist(i['d'], k) == m]
    return {'d': c[0], 'p': i['p']} if len(c) == 1 else None
def farthest(i):
    ks = [k for k, _ in i['p']]; m = max(angdist(i['d'], k) for k in ks); c = [k for k in ks if angdist(i['d'], k) == m]
    return {'d': c[0], 'p': i['p']} if len(c) == 1 else None
def colpick(i, col):
    c = [k for k, x in i['p'] if x == col]; return {'d': c[0], 'p': i['p']} if len(c) == 1 else None
H224 = {'nejbližší tečka': nearest, 'nejvzdálenější tečka': farthest, 'červená': lambda i: colpick(i, 'red'), 'modrá': lambda i: colpick(i, 'blue'),
        'otočí se o 90°': lambda i: {'d': (i['d'] + 2) % 8, 'p': i['p']}, 'otočí se o 180°': lambda i: {'d': (i['d'] + 4) % 8, 'p': i['p']},
        'beze změny': lambda i: dict(i), 'první tečka po směru': lambda i: {'d': min(((k - i['d']) % 8 or 8, k) for k, _ in i['p'])[1], 'p': i['p']},
        'tečka v menšině (více menšin)': lambda i: (lambda c: {'d': [k for k, x in i['p'] if c[x] == min(c.values())][0], 'p': i['p']} if sum(1 for k, x in i['p'] if c[x] == min(c.values())) == 1 else None)(Counter(x for _, x in i['p']))}
D224 = [({'d': 0, 'p': [[1, 'blue'], [3, 'blue'], [5, 'red'], [6, 'blue'], [7, 'blue']]}, {'d': 5, 'p': [[1, 'blue'], [3, 'blue'], [5, 'red'], [6, 'blue'], [7, 'blue']]}),
        ({'d': 2, 'p': [[0, 'red'], [1, 'blue'], [4, 'red'], [6, 'red'], [7, 'red']]}, {'d': 1, 'p': [[0, 'red'], [1, 'blue'], [4, 'red'], [6, 'red'], [7, 'red']]}),
        ({'d': 6, 'p': [[0, 'yellow'], [2, 'yellow'], [3, 'green'], [5, 'yellow'], [7, 'yellow']]}, {'d': 3, 'p': [[0, 'yellow'], [2, 'yellow'], [3, 'green'], [5, 'yellow'], [7, 'yellow']]})]
T224 = {'d': 4, 'p': [[0, 'red'], [1, 'red'], [3, 'red'], [5, 'blue'], [7, 'red']]}   # nejbližší: 3 nebo 5 → shoda vzdálenosti; sjednotit: nejbližší jednoznačně 3? vzdálenost 4→3 =1, 4→5 =1 → nejednoznačné. Upravit:
T224 = {'d': 4, 'p': [[0, 'red'], [1, 'red'], [3, 'red'], [6, 'blue'], [7, 'red']]}   # správně 6 (jediná modrá); nejbližší = 3; nejvzdálenější = 0; 180° = 0; 90° = 6 → koliduje se správnou! změnit směr
T224 = {'d': 2, 'p': [[0, 'red'], [1, 'red'], [3, 'red'], [6, 'blue'], [7, 'red']]}   # správně 6; nejbližší 1 nebo 3 → shoda; 90° = 4 (žádná tečka); 180° = 6 koliduje. Znovu:
T224 = {'d': 1, 'p': [[0, 'red'], [2, 'red'], [3, 'red'], [6, 'blue'], [7, 'red']]}   # správně 6; nejbližší 0 nebo 2 (shoda → hypotéza nedává odpověď); +90° = 3; +180° = 5 (prázdno); nejvzdálenější = 5 (prázdno)
P224 = T224['p']
dis224 = [('nejbližší tečka (vpravo)', {'d': 2, 'p': P224}), ('nejbližší tečka (vlevo)', {'d': 0, 'p': P224}), ('otočí se o 90°', {'d': 3, 'p': P224}),
          ('otočí se o 180°', {'d': 5, 'p': P224}), ('beze změny', {'d': 1, 'p': P224})]
ans = check('V12-224', D224, T224, r224, H224, dis224)
ITEMS.append(finish(item(id='V12-224', scene='arrow_target', relation_family='point_to_unique_colour', strategy_superfamily='relational_selection',
    principle='Šipka se otočí na tu tečku, která je jediná své barvy. Vzdálenost ani konkrétní barva nehrají roli.',
    active_dimensions=['barva', 'jedinečnost', 'směr'], pilot_okno=['V12-52', 'V12-55'],
    notes='Pilot 2026-11-10: horní pásmo. Výběr cíle podle jedinečnosti barvy; ukázky mění barvy i polohy, nejbližší tečka nikdy není cíl.'),
    D224, T224, ans, dis224))

# ---------- V12-225 ring_polygon: tečka se posune o tolik míst, kolik má mnohoúhelník stran ----------
# vstup {'k': pozice tečky 0-7, 'n': počet stran}  výstup {'k': nová pozice, 'n': n}
SIDES = {'triangle': 3, 'square': 4, 'pent': 5, 'hex': 6}
def r225(i): return {'k': (i['k'] + i['n']) % 8, 'n': i['n']}
H225 = {'o 1': lambda i: {'k': (i['k'] + 1) % 8, 'n': i['n']}, 'o 2': lambda i: {'k': (i['k'] + 2) % 8, 'n': i['n']},
        'o strany − 1': lambda i: {'k': (i['k'] + i['n'] - 1) % 8, 'n': i['n']}, 'o strany + 1': lambda i: {'k': (i['k'] + i['n'] + 1) % 8, 'n': i['n']},
        'proti směru o strany': lambda i: {'k': (i['k'] - i['n']) % 8, 'n': i['n']}, 'na protější místo': lambda i: {'k': (i['k'] + 4) % 8, 'n': i['n']},
        'na pevné místo': lambda i: {'k': 2, 'n': i['n']}, 'o 8 − strany': lambda i: {'k': (i['k'] + 8 - i['n']) % 8, 'n': i['n']}}
D225 = [({'k': 0, 'n': 3}, {'k': 3, 'n': 3}), ({'k': 5, 'n': 4}, {'k': 1, 'n': 4}), ({'k': 2, 'n': 6}, {'k': 0, 'n': 6})]
T225 = {'k': 6, 'n': 5}   # správně 3
dis225 = [('o strany − 1 (4 kroky)', {'k': 2, 'n': 5}), ('o strany + 1', {'k': 4, 'n': 5}), ('proti směru o strany', {'k': 1, 'n': 5}),
          ('na protější místo', {'k': 2 if False else 0, 'n': 5}), ('beze změny', {'k': 6, 'n': 5})]
# pozn.: 'na protější místo' = (6+4)%8 = 2 → shodné s 'o strany − 1'; nahrazeno 'o 2' = 0
ans = check('V12-225', D225, T225, r225, H225, dis225)
ITEMS.append(finish(item(id='V12-225', scene='ring_polygon', relation_family='sides_control_steps', strategy_superfamily='operator_control',
    principle='Tečka se posune po kruhu po směru hodinových ručiček o tolik míst, kolik má mnohoúhelník uprostřed stran (přes začátek se pokračuje dál).',
    active_dimensions=['počet stran', 'posun po kruhu'], pilot_okno=['V12-50', 'V12-78'], tier='ceiling',
    notes='Pilot 2026-11-10: cíl b ≈ 1,0–1,2 na společné škále (české +2,5). Počet stran jako skrytý operátor, přechod přes začátek kruhu; provedení ~15 s.'),
    D225, T225, ans, dis225))
ITEMS[-1]['option_models'][4] = 'o 2 místa'

# ---------- V12-226 connect_pairs: čára spojí dvě tečky stejné barvy ----------
# vstup {'p': [[x,y,barva], ...]}  výstup {'p': tečky, 'l': [a, b] indexy}
def r226(i):
    c = Counter(p[2] for p in i['p']); idx = [k for k, p in enumerate(i['p']) if c[p[2]] == 2]; assert len(idx) == 2
    return {'p': i['p'], 'l': idx}
def dist(a, b): return math.hypot(a[0] - b[0], a[1] - b[1])
def nearest_pair(i):
    best = min(((dist(a, b), k, m) for (k, a), (m, b) in itertools.combinations(enumerate(i['p']), 2)))
    ties = [x for x in ((dist(a, b), k, m) for (k, a), (m, b) in itertools.combinations(enumerate(i['p']), 2)) if abs(x[0] - best[0]) < 1e-6]
    return {'p': i['p'], 'l': [best[1], best[2]]} if len(ties) == 1 else None
H226 = {'dvě nejbližší': nearest_pair, 'první a poslední': lambda i: {'p': i['p'], 'l': [0, len(i['p']) - 1]},
        'dvě nejvzdálenější': lambda i: (lambda w: {'p': i['p'], 'l': [w[1], w[2]]})(max(((dist(a, b), k, m) for (k, a), (m, b) in itertools.combinations(enumerate(i['p']), 2)))),
        'bez čáry': lambda i: {'p': i['p'], 'l': []}, 'dvě modré': lambda i: (lambda ix: {'p': i['p'], 'l': ix} if len(ix) == 2 else None)([k for k, p in enumerate(i['p']) if p[2] == 'blue']),
        'dvě červené': lambda i: (lambda ix: {'p': i['p'], 'l': ix} if len(ix) == 2 else None)([k for k, p in enumerate(i['p']) if p[2] == 'red'])}
D226 = [({'p': [[22, 22, 'blue'], [78, 22, 'blue'], [50, 50, 'red'], [22, 78, 'green'], [78, 78, 'yellow']]}, {'p': None, 'l': [0, 1]}),
        ({'p': [[22, 22, 'red'], [50, 22, 'green'], [78, 22, 'blue'], [50, 50, 'yellow'], [50, 78, 'green']]}, {'p': None, 'l': [1, 4]}),
        ({'p': [[22, 22, 'yellow'], [78, 22, 'green'], [50, 50, 'blue'], [22, 78, 'red'], [78, 78, 'yellow']]}, {'p': None, 'l': [0, 4]})]
for d in D226: d[1]['p'] = d[0]['p']
T226 = {'p': [[22, 22, 'green'], [78, 22, 'red'], [22, 78, 'blue'], [50, 50, 'yellow'], [78, 50, 'green']]}   # správně 0–4 (zelené); nejbližší 3–4 (žlutá–zelená, 28); nejvzdálenější 1–2 (červená–modrá)
P226 = T226['p']
dis226 = [('dvě nejbližší', {'p': P226, 'l': [3, 4]}), ('zelená a jiná barva', {'p': P226, 'l': [0, 1]}), ('druhá zelená a jiná', {'p': P226, 'l': [1, 4]}),
          ('bez čáry', {'p': P226, 'l': []}), ('dvě nejvzdálenější', {'p': P226, 'l': [1, 2]})]
# kontrola: nejvzdálenější dvojice v T226? spočítá se níže
ans = check('V12-226', D226, T226, r226, H226, dis226)
ITEMS.append(finish(item(id='V12-226', scene='connect_pairs', relation_family='connect_same_colour', strategy_superfamily='relational_selection', tier='low',
    principle='Čára spojí ty dvě tečky, které mají stejnou barvu. Ostatní tečky zůstanou nespojené.',
    active_dimensions=['barva', 'spojení'], pilot_okno=['V12-07', 'V12-15'],
    notes='Pilot 2026-11-10: dolní pásmo (cíl b −2,3 až −1,5 na společné škále). Jediný vztah; dvojice má v každé ukázce jinou barvu a polohu; nejbližší dvojice nikdy není stejná barva.'),
    D226, T226, ans, dis226))

# ---------- V12-227 shadow: stín na opačné straně, než je slunce ----------
# vstup {'s': tvar, 'c': barva, 'sun': směr slunce 0-7}  výstup {'s','c','sun','sh': směr stínu, 'ghost': 0/1 (objekt zmizel)}
def r227(i): return {'s': i['s'], 'c': i['c'], 'sun': i['sun'], 'sh': (i['sun'] + 4) % 8}
H227 = {'stín u slunce': lambda i: {'s': i['s'], 'c': i['c'], 'sun': i['sun'], 'sh': i['sun']}, 'stín vždy dole': lambda i: {'s': i['s'], 'c': i['c'], 'sun': i['sun'], 'sh': 4},
        'stín vpravo': lambda i: {'s': i['s'], 'c': i['c'], 'sun': i['sun'], 'sh': 2}, 'stín o 90°': lambda i: {'s': i['s'], 'c': i['c'], 'sun': i['sun'], 'sh': (i['sun'] + 2) % 8}}
D227 = [({'s': 'triangle', 'c': 'blue', 'sun': 7}, {'s': 'triangle', 'c': 'blue', 'sun': 7, 'sh': 3}),
        ({'s': 'circle', 'c': 'red', 'sun': 2}, {'s': 'circle', 'c': 'red', 'sun': 2, 'sh': 6}),
        ({'s': 'square', 'c': 'green', 'sun': 4}, {'s': 'square', 'c': 'green', 'sun': 4, 'sh': 0})]
T227 = {'s': 'hex', 'c': 'yellow', 'sun': 1}   # správně stín 5 (vlevo dole)
dis227 = [('stín u slunce', {'s': 'hex', 'c': 'yellow', 'sun': 1, 'sh': 1}), ('stín vždy dole', {'s': 'hex', 'c': 'yellow', 'sun': 1, 'sh': 4}),
          ('stín jiného tvaru', {'s': 'hex', 'c': 'yellow', 'sun': 1, 'sh': 5, 'shs': 'circle'}), ('jen stín, objekt zmizel', {'s': 'hex', 'c': 'yellow', 'sun': 1, 'sh': 5, 'ghost': 1}),
          ('bez stínu', {'s': 'hex', 'c': 'yellow', 'sun': 1})]
ans = check('V12-227', D227, T227, r227, H227, dis227)
ITEMS.append(finish(item(id='V12-227', scene='shadow', relation_family='shadow_opposite_light', strategy_superfamily='physical_relation', tier='low',
    principle='Slunce vrhá stín: tmavá silueta stejného tvaru leží na opačné straně objektu, než je slunce.',
    active_dimensions=['směr', 'tvar'], pilot_okno=['V12-07', 'V12-15'],
    notes='Pilot 2026-11-10: dolní pásmo. Jediný vztah (slunce → opačná strana); tvar, barva i poloha slunce se v ukázkách mění.'),
    D227, T227, ans, dis227))

# ---------- V12-228 halves: levá půlka levého + pravá půlka pravého ----------
# vstup {'L': [tvar, barva], 'R': [tvar, barva]}  výstup {'h': [[tvar, barva, 'L'|'R' která půlka tvaru], [tvar, barva, 'L'|'R']]} (levá část výsledku, pravá část výsledku)
def r228(i): return {'h': [[i['L'][0], i['L'][1], 'L'], [i['R'][0], i['R'][1], 'R']]}
H228 = {'prohozené půlky': lambda i: {'h': [[i['R'][0], i['R'][1], 'L'], [i['L'][0], i['L'][1], 'R']]},
        'celý levý': lambda i: {'h': [[i['L'][0], i['L'][1], 'L'], [i['L'][0], i['L'][1], 'R']]}, 'celý pravý': lambda i: {'h': [[i['R'][0], i['R'][1], 'L'], [i['R'][0], i['R'][1], 'R']]},
        'tvary správně, barvy prohozené': lambda i: {'h': [[i['L'][0], i['R'][1], 'L'], [i['R'][0], i['L'][1], 'R']]},
        'levý tvar ve dvou barvách': lambda i: {'h': [[i['L'][0], i['L'][1], 'L'], [i['L'][0], i['R'][1], 'R']]}}
D228 = [({'L': ['circle', 'blue'], 'R': ['square', 'red']}, {'h': [['circle', 'blue', 'L'], ['square', 'red', 'R']]}),
        ({'L': ['triangle', 'green'], 'R': ['circle', 'yellow']}, {'h': [['triangle', 'green', 'L'], ['circle', 'yellow', 'R']]}),
        ({'L': ['hex', 'purple'], 'R': ['triangle', 'blue']}, {'h': [['hex', 'purple', 'L'], ['triangle', 'blue', 'R']]})]
T228 = {'L': ['square', 'red'], 'R': ['hex', 'green']}
dis228 = [('prohozené půlky', {'h': [['hex', 'green', 'L'], ['square', 'red', 'R']]}), ('celý levý', {'h': [['square', 'red', 'L'], ['square', 'red', 'R']]}),
          ('celý pravý', {'h': [['hex', 'green', 'L'], ['hex', 'green', 'R']]}), ('tvary správně, barvy prohozené', {'h': [['square', 'green', 'L'], ['hex', 'red', 'R']]}),
          ('levý tvar ve dvou barvách', {'h': [['square', 'red', 'L'], ['square', 'green', 'R']]})]
ans = check('V12-228', D228, T228, r228, H228, dis228)
ITEMS.append(finish(item(id='V12-228', scene='halves', relation_family='compose_halves', strategy_superfamily='part_whole', tier='low',
    principle='Výsledek se složí z levé půlky levého tvaru a pravé půlky pravého tvaru (každá ve své barvě).',
    active_dimensions=['část/celek', 'tvar', 'barva'], pilot_okno=['V12-07', 'V12-15'],
    notes='Pilot 2026-11-10: dolní pásmo. Jediný vztah část–celek; chybné odpovědi = celý jeden tvar nebo prohozené půlky.'),
    D228, T228, ans, dis228))

for it in ITEMS: it['order'] = 99
for iid, ok, nh, fit, msgs in REPORT:
    print(iid, 'OK' if ok else 'CHYBA', f'hypotéz {nh}, sedí na ukázky (a dávají totéž): {fit}', *msgs, sep=' | ')
json.dump(ITEMS, open('new_items_221_228.json', 'w'), ensure_ascii=False, indent=1)
print('uloženo', len(ITEMS))
