import sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:90], s.count(old)); s = s.replace(old, new)
rep("  function svg(paths, w, h, u, outline, W, H, seams){",
    "  function svg(paths, w, h, u, outline, W, H, seams, plain){   // plain: díl bez černých okrajů (jako tvar bez viditelných hranic)")
rep("""paths.forEach(p => { s += `<path d="${p.d}" fill="${p.fill}" stroke="${outline && !seams ? p.fill : '#1d232b'}" stroke-width="${outline ? (1.2 / u).toFixed(4) : sw}" stroke-linejoin="round"/>`; });""",
    """paths.forEach(p => { s += `<path d="${p.d}" fill="${p.fill}" stroke="${(outline && !seams) || plain ? p.fill : '#1d232b'}" stroke-width="${outline || plain ? (1.2 / u).toFixed(4) : sw}" stroke-linejoin="round"/>`; });""")
rep("""    if (outline) s += `<path d="${outline}" fill="none" stroke="#1d232b\"""",
    """    if (outline && seams) s += `<path d="${outline}" fill="none" stroke="#1d232b\"""")
rep("const optRender = (it, o) => { const u = unit(it), b = box(); return svg(o.paths, o.w, o.h, u, null, b.ow, b.oh); };",
    "const optRender = (it, o) => { const u = unit(it), b = box(); return svg(o.paths, o.w, o.h, u, null, b.ow, b.oh, false, !it.target.seams); };   // od SK36-W3s: okraje dílů jen tam, kde má okraje i tvar")
rep("version:'SK36-W3r', pickN:3,", "version:'SK36-W3s', pickN:3,")
rep("['SK36-W3', 'SK36-W3r']],", "['SK36-W3', 'SK36-W3r', 'SK36-W3s']],")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
