import json, re, math, itertools
b = json.load(open('/tmp/sk.json'))
def polys(d):
    out = []
    for sub in re.split(r'(?=M)', d.strip()):
        if not sub.strip(): continue
        nums = list(map(float, re.findall(r'-?\d*\.?\d+(?:e-?\d+)?', sub)))
        pts = [(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]
        if len(pts) > 1 and pts[0] == pts[-1]: pts = pts[:-1]
        out.append(pts)
    return out
def area(p): return 0.5 * sum(p[i][0]*p[(i+1)%len(p)][1] - p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))
def shape_area(o):  # součet ploch cest (díry jako opačně orientované podcesty)
    tot = 0
    for pa in o['paths']:
        ps = polys(pa['d'])
        a = [area(p) for p in ps]
        if len(a) == 1: tot += abs(a[0])
        else:   # vnější + díry: největší kladně, ostatní se znaménkem vůči němu
            s = 1 if a[max(range(len(a)), key=lambda i: abs(a[i]))] > 0 else -1
            tot += abs(sum(x * s for x in a))
    return tot
def target_area(t):
    if t.get('outline'):
        ps = polys(t['outline']); a = [area(p) for p in ps]
        if len(a) == 1: return abs(a[0])
        s = 1 if a[max(range(len(a)), key=lambda i: abs(a[i]))] > 0 else -1
        return abs(sum(x * s for x in a))
    return shape_area(t)
# tvar dílu kvůli shodnosti: posloupnost (délka hrany, úhel) – po zjednodušení kolineárních bodů
def simplify(p):
    q = p[:]
    changed = True
    while changed and len(q) > 3:
        changed = False
        for i in range(len(q)):
            a, b_, c = q[i-1], q[i], q[(i+1) % len(q)]
            cr = (b_[0]-a[0])*(c[1]-b_[1]) - (b_[1]-a[1])*(c[0]-b_[0])
            if abs(cr) < 1e-7: q.pop(i); changed = True; break
    return q
def sig(p):
    p = simplify(p)
    if area(p) < 0: p = p[::-1]
    n = len(p); s = []
    for i in range(n):
        a, b_, c = p[i-1], p[i], p[(i+1) % n]
        L = math.hypot(c[0]-b_[0], c[1]-b_[1])
        ang = math.atan2((b_[0]-a[0])*(c[1]-b_[1]) - (b_[1]-a[1])*(c[0]-b_[0]), (b_[0]-a[0])*(c[0]-b_[0]) + (b_[1]-a[1])*(c[1]-b_[1]))
        s.append((L, ang))
    return s
def same(s1, s2, tol=0.02):
    if len(s1) != len(s2): return False
    n = len(s1)
    for k in range(n):
        if all(abs(s1[i][0] - s2[(i+k) % n][0]) < tol and abs(s1[i][1] - s2[(i+k) % n][1]) < 0.03 for i in range(n)): return True
    return False
def mirror(p): return [(-x, y) for x, y in p]
def single_poly(o):
    ps = [pp for pa in o['paths'] for pp in polys(pa['d'])]
    return ps[0] if len(ps) == 1 else None
def colors(o): return tuple(sorted(pa.get('fill', '') for pa in o['paths']))
for it in b['practice'] + b['items']:
    TA = target_area(it['target']); opts = it['options']; A = [shape_area(o) for o in opts]
    key = sorted(it['answerIdx']); keyA = sum(A[i] for i in key)
    sizes = range(2, 5) if it.get('free') else [it['pick'] or len(key)]
    cand = [c for k in sizes for c in itertools.combinations(range(len(opts)), k) if abs(sum(A[i] for i in c) - TA) / TA < 0.015]
    alt = [c for c in cand if list(c) != key]
    notes = []
    if abs(keyA - TA) / TA > 0.01: notes.append(f'PLOCHA KLÍČE {keyA:.4f} ≠ CÍL {TA:.4f}')
    # shodnost / zrcadla
    P = [single_poly(o) for o in opts]
    for i, j in itertools.combinations(range(len(opts)), 2):
        if P[i] is None or P[j] is None: continue
        si, sj = sig(P[i]), sig(P[j])
        if same(si, sj):
            same_col = colors(opts[i]) == colors(opts[j])
            notes.append(f'SHODNÉ díly {i},{j}' + (' (i barva)' if same_col else ' (jiná barva)') + (' – oba v klíči' if i in key and j in key else ' – jeden v klíči!' if (i in key) != (j in key) else ''))
        elif same(si, sig(mirror(P[j]))) and ((i in key) != (j in key)):
            # zrcadlo: je zrcadlo souměrného dílu? (pak by bylo shodné – výše); zkontroluj „téměř shodné“
            if same(si, sj, tol=0.06): notes.append(f'zrcadlo {i},{j} TÉMĚŘ SHODNÉ')
    print(f"{it['id']:8s} pick={it['pick']} key={key} area cíl={TA:.4f} klíč={keyA:.4f} | jiné podmnožiny se stejnou plochou: {alt} {'; '.join(notes)}")
