import json, re, math, itertools, sys, time
import numpy as np
from matplotlib.path import Path
from scipy import ndimage
b = json.load(open('/tmp/sk.json'))
R = int(sys.argv[2]) if len(sys.argv) > 2 else 90
def polys(d):
    out = []
    for sub in re.split(r'(?=M)', d.strip()):
        if not sub.strip(): continue
        nums = list(map(float, re.findall(r'-?\d*\.?\d+(?:e-?\d+)?', sub)))
        pts = [(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]
        if len(pts) > 1 and pts[0] == pts[-1]: pts = pts[:-1]
        out.append(np.array(pts))
    return out
def shape_polys(o, base_only=True):
    f0 = o['paths'][0].get('fill')
    out = []
    for pa in o['paths']:
        if base_only and pa.get('fill') != f0: continue
        out.append(polys(pa['d']))
    return out   # list of paths; each path = list of subpaths (even-odd within path, OR across paths)
def raster(paths, ang, step):
    c, s = math.cos(ang), math.sin(ang)
    rot = [[sp @ np.array([[c, s], [-s, c]]) for sp in p] for p in paths]
    allp = np.vstack([sp for p in rot for sp in p])
    x0, y0 = allp.min(0); x1, y1 = allp.max(0)
    nx = int(math.ceil((x1 - x0) / step)) + 1; ny = int(math.ceil((y1 - y0) / step)) + 1
    xs = x0 + (np.arange(nx) + 0.5) * step; ys = y0 + (np.arange(ny) + 0.5) * step
    X, Y = np.meshgrid(xs, ys); P = np.c_[X.ravel(), Y.ravel()]
    m = np.zeros(len(P), bool)
    for p in rot:
        mm = np.zeros(len(P), bool)
        for sp in p: mm ^= Path(sp).contains_points(P)
        m |= mm
    return m.reshape(ny, nx)
def edge_angles(paths, minlen):
    out = []
    for p in paths:
        for sp in p:
            for i in range(len(sp)):
                a, bb = sp[i], sp[(i+1) % len(sp)]
                L = math.hypot(*(bb - a))
                if L >= minlen: out.append(math.atan2(bb[1]-a[1], bb[0]-a[0]))
    return out
def solve(it, maxsol=4, timeout=60):
    step = 1.0 / R
    t = it['target']
    tpaths = [polys(t['outline'])] if t.get('outline') else shape_polys(t, base_only=False)
    T = raster(tpaths, 0, step); TN = T.sum()
    opts = it['options']; OP = [shape_polys(o) for o in opts]
    tang = edge_angles(tpaths, 0.06)
    cache = {}
    def angles(i):
        pa = edge_angles(OP[i], 0.06); cand = set(round(math.degrees(k * math.pi / 2)) % 360 for k in range(4))
        for ta in tang:
            for a in pa:
                for flip in (0, math.pi): cand.add(round(math.degrees(ta - a + flip), 1) % 360)
        out = []
        for a in sorted(cand):
            if all(min(abs(a - b_), 360 - abs(a - b_)) > 0.6 for b_ in out): out.append(a)
        return out
    ANG = [angles(i) for i in range(len(opts))]
    def pm(i, a):
        k = (i, a)
        if k not in cache:
            m = raster(OP[i], math.radians(a), step); ys, xs = np.nonzero(m)
            j = np.lexsort((xs, ys))[0]; cache[k] = (m, ys[j], xs[j], m.sum())
        return cache[k]
    sizes = [it['pick']] if it.get('pick') else [2, 3, 4]
    sols = []; qual = {}; t0 = time.time()
    def dfs(cov, used, badsum=0):
        if time.time() - t0 > timeout: return
        unc = T & ~cov
        if unc.sum() <= 0.04 * TN:
            if len(used) in sizes: sols.append(tuple(sorted(used))); qual.setdefault(tuple(sorted(used)), []).append(round((unc.sum() + badsum) / TN * 100, 2))
            return
        if len(used) >= max(sizes): return
        er = ndimage.binary_opening(unc, iterations=1)
        if not er.any(): er = unc
        ys, xs = np.nonzero(er); j = np.lexsort((xs, ys))[0]; py, px = ys[j], xs[j]
        for i in range(len(opts)):
            if i in used or (used and i < min(used) and False): continue
            for a in ANG[i]:
                m, fy, fx, n = pm(i, a)
                best = None
                for dy in range(-5, 6):
                    for dx in range(-10, 11):
                        oy, ox = py - fy + dy, px - fx + dx
                        if oy < -2 or ox < -2 or oy + m.shape[0] > T.shape[0] + 2 or ox + m.shape[1] > T.shape[1] + 2: continue
                        # vložit do plátna
                        yy0, xx0 = max(0, oy), max(0, ox); yy1, xx1 = min(T.shape[0], oy + m.shape[0]), min(T.shape[1], ox + m.shape[1])
                        sub = m[yy0 - oy:yy1 - oy, xx0 - ox:xx1 - ox]
                        inside = sub.sum(); outside = n - inside
                        bad = outside + (sub & ~T[yy0:yy1, xx0:xx1]).sum() + (sub & cov[yy0:yy1, xx0:xx1]).sum()
                        ly, lx = py - yy0, px - xx0
                        if not (0 <= ly < sub.shape[0] and 0 <= lx < sub.shape[1] and sub[ly, lx]): continue
                        if bad <= 0.025 * n and (best is None or bad < best[0]): best = (bad, yy0, yy1, xx0, xx1, sub)
                if best:
                    _, yy0, yy1, xx0, xx1, sub = best
                    nc = cov.copy(); nc[yy0:yy1, xx0:xx1] |= sub
                    dfs(nc, used + [i], badsum + best[0])
                    if len(set(sols)) >= maxsol: return
    dfs(np.zeros_like(T), [])
    return sorted(set(sols)), time.time() - t0, {k: min(v) for k, v in qual.items()}
if __name__ == '__main__':
    ids = sys.argv[1].split(',')
    for it in b['practice'] + b['items']:
        if it['id'] not in ids: continue
        s, dt, na = solve(it)
        key = tuple(sorted(it['answerIdx']))
        print(f"{it['id']:8s} key={key} řešení={s} {'OK' if s == [key] else 'KLÍČ NENALEZEN' if key not in s else 'VÍCE ŘEŠENÍ!'} ({dt:.1f}s) nesoulad % {na}", flush=True)
