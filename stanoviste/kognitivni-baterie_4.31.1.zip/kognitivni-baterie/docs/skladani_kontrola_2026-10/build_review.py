import json, re, math, html
OLD = json.load(open('/tmp/sk.json')); NEW = json.load(open('/tmp/sk_r2.json'))
def item(b, iid): return [i for i in b['practice'] + b['items'] if i['id'] == iid][0]
L = 'ABCDEF'; DARK = '#1d232b'
def svg_paths(paths, w, h, u, mode, outline=None, seams=False, pad=6):
    # mode: 'target' | 'opt' ; nový styl: bez černých okrajů, pokud tvar nemá viditelné hranice
    W, H = w * u + 2 * pad, h * u + 2 * pad
    s = f'<svg width="{W:.0f}" height="{H:.0f}" viewBox="{-pad/u:.4f} {-pad/u:.4f} {W/u:.4f} {H/u:.4f}" role="img">'
    for p in paths:
        plain = not seams
        st = p['fill'] if plain else DARK
        sw = (1.2 if plain else 1.6) / u
        s += f'<path d="{p["d"]}" fill="{p["fill"]}" stroke="{st}" stroke-width="{sw:.4f}" stroke-linejoin="round"/>'
    if mode == 'target' and outline and seams:
        s += f'<path d="{outline}" fill="none" stroke="{DARK}" stroke-width="{1.6/u:.4f}" stroke-linejoin="round"/>'
    return s + '</svg>'
def svg_old(paths, w, h, u, mode, outline=None, seams=False, pad=6):
    W, H = w * u + 2 * pad, h * u + 2 * pad
    s = f'<svg width="{W:.0f}" height="{H:.0f}" viewBox="{-pad/u:.4f} {-pad/u:.4f} {W/u:.4f} {H/u:.4f}" role="img">'
    for p in paths:
        st = p['fill'] if (mode == 'target' and not seams) else DARK
        sw = (1.2 if mode == 'target' else 1.6) / u
        s += f'<path d="{p["d"]}" fill="{p["fill"]}" stroke="{st}" stroke-width="{sw:.4f}" stroke-linejoin="round"/>'
    if mode == 'target' and outline:
        s += f'<path d="{outline}" fill="none" stroke="{DARK}" stroke-width="{1.6/u:.4f}" stroke-linejoin="round"/>'
    return s + '</svg>'
def unit(it, big=1.0):
    t = it['target']; mw = max(o['w'] for o in it['options']); mh = max(o['h'] for o in it['options'])
    return min(300 * big / t['w'], 210 * big / t['h'], 130 / mw, 110 / mh)
def rot_path(d, ang, cx, cy):
    nums = list(map(float, re.findall(r'-?\d*\.?\d+', d))); a = math.radians(ang); out = []
    pts = [(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]
    rp = [(cx + (x-cx)*math.cos(a) - (y-cy)*math.sin(a), cy + (x-cx)*math.sin(a) + (y-cy)*math.cos(a)) for x, y in pts]
    xs = [p[0] for p in rp]; ys = [p[1] for p in rp]
    return rp, min(xs), min(ys), max(xs), max(ys)
def card(it, note='', marks=None, style='new', hl=None):
    marks = marks or {}; f = svg_paths if style == 'new' else svg_old
    t = it['target']; u = unit(it); seams = bool(t.get('seams'))
    s = f'<div class="item"><div class="tgt"><div class="lbl">Tvar</div>{f(t["paths"], t["w"], t["h"], u, "target", t.get("outline"), seams)}</div><div class="opts">'
    key = it['answerIdx']
    for k, o in enumerate(it['options']):
        cls = 'opt' + (' key' if k in key else '') + (' hl' if hl and k in hl else '')
        tag = marks.get(k, 'klíč' if k in key else '')
        s += f'<div class="{cls}"><span class="let">{L[k]}</span>{f(o["paths"], o["w"], o["h"], u, "opt", None, seams)}<span class="kind">{html.escape(tag)}</span></div>'
    return s + '</div></div>' + (f'<p class="note">{note}</p>' if note else '')
sec = []
# 1) SKW_06 – před a po
o6, n6 = item(OLD, 'SKW_06'), item(NEW, 'SKW_06_r')
D = o6['options'][3]; base = D['paths'][0]['d']
nums = list(map(float, re.findall(r'-?\d*\.?\d+', base))); cx = sum(nums[0::2]) / (len(nums)/2); cy = sum(nums[1::2]) / (len(nums)/2)
rp = []
for p in D['paths']:
    pts, *_ = rot_path(p['d'], -45, cx, cy); rp.append(pts)
allp = [q for pts in rp for q in pts]; x0 = min(q[0] for q in allp); y0 = min(q[1] for q in allp)
rpaths = [{'d': 'M' + ' L'.join(f'{x-x0:.4f} {y-y0:.4f}' for x, y in pts) + 'Z', 'fill': p['fill']} for pts, p in zip(rp, D['paths'])]
u6 = unit(o6); B = o6['options'][1]
twin = (f'<div class="twin"><div class="opt key"><span class="let">B</span>{svg_old(B["paths"], B["w"], B["h"], u6, "opt")}<span class="kind">správný díl</span></div>'
        f'<div class="eq">=</div><div class="opt hl"><span class="let">D</span>{svg_old(rpaths, max(q[0] for q in allp)-x0, max(q[1] for q in allp)-y0, u6, "opt")}<span class="kind">„špatný vzor“ otočený o 45°</span></div></div>')
sec.append(('SKW_06: dvě správné odpovědi (opraveno)',
    '<h3>Dosud (SK36-W3)</h3>' + card(o6, 'Klíč je B + C + F. Díl D („špatný vzor“) je ale stejný díl jako B, jen otočený o 45°, takže tvar jde složit i z D + C + F. Ta odpověď se počítala jako chyba.', {3: 'špatný vzor?'}, 'old', hl=[3]) + twin +
    '<h3>Nově (SKW_06_r)</h3>' + card(n6, 'Výseč na dílu D je posunutá podél hrany až k rohu. Žádným otočením se s B nekryje (neshoda 14 %).', {3: 'špatný vzor (opraveno)'}, 'new', hl=[3])))
# 2) SKW_09 – slabý distraktor nahrazen
o9 = item(json.load(open('/tmp/sk_r.json')), 'SKW_09'); n9 = item(NEW, 'SKW_09_r')
sec.append(('SKW_09: slabý distraktor E (opraveno)',
    '<h3>Dosud</h3>' + card(o9, 'Distraktor E měl uprostřed fialové plochy tenkou žlutou čárku – na první pohled bylo jasné, že nemůže být součástí řešení.', {4: 'slabý distraktor'}, 'new', hl=[4]) +
    '<h3>Nově (SKW_09_r)</h3>' + card(n9, 'E je zrcadlo správného dílu D: stejný trojúhelník se stejnou výsečí, ale výseč je na druhé odvěsně. Otočením ho na D převést nejde (neshoda 12 %), ale vypadá věrohodně – je potřeba zjistit, kterou hranu kruh v tvaru protíná.', {4: 'zrcadlo D'}, 'new', hl=[4])))
# 3) záměrné blízké distraktory stropu
ov = open('/home/claude/review/sko_overlay.b64').read()
sec.append(('Blízké distraktory stropu (záměrné, v pořádku)',
    card(item(NEW, 'SKO_1'), 'SKO_1: D není zrcadlo – je to díl B s jiným výběžkem ornamentu. Když D otočíme a přiložíme na B, liší se jen na jednom místě (obrázek vpravo: modrá = shoda, zelená = jen B, oranžová = jen D). Do tvaru proto sedí jen B.', {}, 'new', hl=[3]) +
    f'<div class="ov"><img src="data:image/png;base64,{ov}" alt="Překryv dílu B a otočeného dílu D" width="300"><span>B a D přes sebe (D otočený o 175°)</span></div>' +
    card(item(NEW, 'SKS_07'), 'SKS_07: sestava s B místo D se liší jen tím, že má čep místo jamky. V pořádku.', {}, 'new', hl=[1])))
# 4) položky, které můj řešič nezávisle neověřil
txt = 'Můj rastrový skladač u této položky nenašel ani správné složení (tenké nebo šikmé díly), nezávisle ji tedy neověřuje. Ověřoval ji řešič z dřívějších verzí; plocha klíče sedí.'
sec.append(('Položky bez nezávislého ověření', ''.join(card(item(NEW, i), f'{i}: {txt}') for i in ('SKW_04', 'SKW_15', 'SKW_16', 'SKL_2', 'SKB_5'))))
# 5) okraje před a po
it9 = item(NEW, 'SKW_09_r')
sec.append(('Okraje dílů: dosud a nově',
    '<h3>Dosud</h3>' + card(it9, 'Díly měly černý okraj kolem celého dílu i kolem barevného vzoru, tvar nahoře jen kolem obrysu.', {}, 'old') +
    '<h3>Nově (od SK36-W3s)</h3>' + card(it9, 'U položek bez viditelných hranic jsou tvar i díly bez černých okrajů. U úvodních položek, kde tvar hranice dílů ukazuje, zůstávají okraje všude.', {}, 'new')))
body = ''.join(f'<section><h2>{h}</h2>{c}</section>' for h, c in sec)
page = f'''<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Skládání tvarů – problematické položky</title><style>
:root{{--bg:#f3f5f7;--card:#ffffff;--ink:#1f2933;--muted:#5f6b7a;--line:#d5dbe2;--key:#2e8b57;--hl:#d97706;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#14181d;--card:#f7f8fa;--ink:#e8ecf0;--muted:#a9b3bf;--line:#3a434e}}}}
:root[data-theme="dark"]{{--bg:#14181d;--card:#f7f8fa;--ink:#e8ecf0;--muted:#a9b3bf;--line:#3a434e}}
html{{scroll-padding-top:env(safe-area-inset-top,0px)}}
body{{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.45}}
main{{max-width:1100px;margin:0 auto;padding:20px 16px 40px}}
h1{{font-size:26px;margin:4px 0 6px}} h2{{font-size:20px;margin:0 0 10px}} h3{{font-size:16px;margin:14px 0 6px;color:var(--muted)}}
section{{border:1px solid var(--line);border-radius:14px;padding:14px;margin:16px 0;overflow-x:auto}}
.item{{display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap}}
.tgt{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:8px;text-align:center}}
.lbl{{font-weight:700;color:#1f2933;font-size:14px}}
.opts{{display:grid;grid-template-columns:repeat(3,minmax(0,auto));gap:8px}}
.opt{{position:relative;background:var(--card);border:2px solid var(--line);border-radius:12px;padding:16px 6px 18px;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:120px;min-height:120px}}
.opt.key{{border-color:var(--key)}} .opt.hl{{border-color:var(--hl);box-shadow:0 0 0 2px var(--hl)}}
.let{{position:absolute;top:4px;left:8px;font-weight:700;font-size:13px;color:#5f6b7a}}
.kind{{position:absolute;bottom:3px;left:0;right:0;text-align:center;font-size:11px;color:#2e8b57}}
.opt.hl .kind{{color:var(--hl)}}
.note{{color:var(--muted);margin:8px 0 4px;max-width:900px}}
.twin{{display:flex;gap:12px;align-items:center;margin-top:10px;flex-wrap:wrap}} .eq{{font-size:30px;font-weight:700}}
svg{{max-width:100%;height:auto}}
.legend{{color:var(--muted);font-size:14px}} .ov{{display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin:8px 0 14px;color:var(--muted);font-size:13px}} .ov img{{background:#fff;border:1px solid var(--line);border-radius:10px;image-rendering:auto}} .legend b.k{{color:var(--key)}} .legend b.h{{color:var(--hl)}}
</style></head><body><main><h1>Skládání tvarů – problematické položky</h1>
<p class="legend">Verze pluginu 3.81.0 / 1.42.0. <b class="k">Zelený rámeček</b> = správný díl (klíč), <b class="h">oranžový</b> = díl, o kterém je řeč.</p>{body}</main></body></html>'''
open('/mnt/user-data/outputs/skladani_problematicke.html', 'w', encoding='utf-8').write(page)
print(len(page))
