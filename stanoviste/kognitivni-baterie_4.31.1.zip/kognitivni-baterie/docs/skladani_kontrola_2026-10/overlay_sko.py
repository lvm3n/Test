import json, math, numpy as np, sys, base64, io
sys.argv=['x','','200']
exec(open('/home/claude/sk/rotdup.py').read().split("for it in b['practice']")[0].replace("step=1/80","step=1/200"))
from PIL import Image
b=json.load(open('/tmp/sk_r.json')); it=[i for i in b['items'] if i['id']=='SKO_1'][0]
B,D=it['options'][1],it['options'][3]
A=lab(B,0)>0; best=(1,None,None,None)
for a in np.arange(170,180.5,0.5):
    Dm=lab(D,math.radians(a))>0
    H=max(A.shape[0],Dm.shape[0])+20; W=max(A.shape[1],Dm.shape[1])+20
    CA=np.zeros((H,W),bool); CA[10:10+A.shape[0],10:10+A.shape[1]]=A
    for dy in range(-10,11):
        for dx in range(-10,11):
            yy,xx=10+dy,10+dx
            if yy<0 or xx<0 or yy+Dm.shape[0]>H or xx+Dm.shape[1]>W: continue
            CB=np.zeros((H,W),bool); CB[yy:yy+Dm.shape[0],xx:xx+Dm.shape[1]]=Dm
            m=(CA^CB).sum()/(CA|CB).sum()
            if m<best[0]: best=(m,a,CA.copy(),CB.copy())
m,a,CA,CB=best; print('best',round(m*100,2),'% at',a)
img=np.full(CA.shape+(3,),255,np.uint8)
img[CA&CB]=(62,143,212); img[CA&~CB]=(46,139,87); img[CB&~CA]=(217,119,6)
im=Image.fromarray(img); bio=io.BytesIO(); im.save(bio,'PNG'); open('/home/claude/review/sko_overlay.b64','w').write(base64.b64encode(bio.getvalue()).decode())
im.save('/tmp/sko_overlay.png')
