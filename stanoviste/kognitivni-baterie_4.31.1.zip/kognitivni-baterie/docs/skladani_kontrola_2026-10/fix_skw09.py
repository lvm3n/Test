import json, re, math, sys
import numpy as np
sys.argv=['x','','80']
exec(open('/home/claude/sk/rotdup.py').read().split("for it in b['practice']")[0])
b=json.load(open('/tmp/sk_r.json'))
it=[i for i in b['items'] if i['id']=='SKW_09'][0]
D=it['options'][3]; W=D['w']
def tr(o, f):
    o=json.loads(json.dumps(o))
    for p in o['paths']:
        nums=[float(x) for x in re.findall(r'-?\d*\.?\d+',p['d'])]
        pts=[f(nums[i],nums[i+1]) for i in range(0,len(nums),2)]
        p['d']='M'+' L'.join(f'{x:.4f} {y:.4f}'.replace('-0.0000','0.0000') for x,y in pts)+'Z'
    return o
H=D['h']
E=tr(D, lambda x,y:(W-x, y))              # zrcadlo dílu D
E=tr(E, lambda x,y:(H-y, x))              # a otočit o 90° (jiná poloha než D na obrazovce)
E['w'],E['h']=H,W; E['kind']='zrcadlo dílu (výseč na druhé odvěsně)'; E['correct']=False
new=json.loads(json.dumps(it)); new['options'][4]=E; new['id']='SKW_09_r'; new['revised_from']='SKW_09'
new['facety']=dict(it['facety']); new['facety']['oprava']='r: distraktor E (tenká žlutá čárka) nahrazen zrcadlem dílu D'
# kontrola: E nesmí být otočením žádného správného dílu
for k in new['answerIdx']:
    K=lab(new['options'][k],0); m=min(mis(K,lab(E,math.radians(a))) for a in range(0,360,5))
    print('E vs klíč',k,'neshoda',round(m*100,1),'%')
json.dump(new,open('skw09_r.json','w'),ensure_ascii=False)
print(D['paths'][1]['d'][:80]); print(E['paths'][1]['d'][:80])
