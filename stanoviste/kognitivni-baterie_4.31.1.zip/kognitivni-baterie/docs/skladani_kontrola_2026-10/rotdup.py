import json, math, numpy as np, sys
sys.argv=['x','','80']
src=open('/home/claude/sk/solver.py').read().split("def solve(")[0]; exec(src)
step=1/80
def lab(o, ang):
    c,s=math.cos(ang),math.sin(ang); M=np.array([[c,s],[-s,c]])
    groups={}
    for pa in o['paths']: groups.setdefault(pa.get('fill'),[]).append(polys(pa['d']))
    allp=np.vstack([sp@M for g in groups.values() for p in g for sp in p]); x0,y0=allp.min(0); x1,y1=allp.max(0)
    nx=int(math.ceil((x1-x0)/step))+1; ny=int(math.ceil((y1-y0)/step))+1
    xs=x0+(np.arange(nx)+.5)*step; ys=y0+(np.arange(ny)+.5)*step; X,Y=np.meshgrid(xs,ys); P=np.c_[X.ravel(),Y.ravel()]
    L=np.zeros(len(P),int)
    for gi,(f,g) in enumerate(groups.items()):   # pozdější barvy kreslené přes dřívější
        m=np.zeros(len(P),bool)
        for p in g:
            mm=np.zeros(len(P),bool)
            for sp in p: mm^=Path(sp@M).contains_points(P)
            m|=mm
        L[m]=hash(f)%997+1
    return L.reshape(ny,nx)
def mis(A,B):
    best=1; H=max(A.shape[0],B.shape[0])+6; W=max(A.shape[1],B.shape[1])+6
    CA=np.zeros((H,W),int); CA[3:3+A.shape[0],3:3+A.shape[1]]=A
    for dy in range(-3,4):
        for dx in range(-3,4):
            yy,xx=3+dy,3+dx
            if yy<0 or xx<0 or yy+B.shape[0]>H or xx+B.shape[1]>W: continue
            CB=np.zeros((H,W),int); CB[yy:yy+B.shape[0],xx:xx+B.shape[1]]=B
            u=((CA>0)|(CB>0)).sum(); best=min(best,(CA!=CB).sum()/u)
    return best
for it in b['practice']+b['items']:
    key=it['answerIdx']; opts=it['options']; KL={k:lab(opts[k],0) for k in key}
    for j,o in enumerate(opts):
        if j in key: continue
        best=(1,None,None)
        for a in range(0,360,5):
            Lj=lab(o,math.radians(a))
            for k in key:
                if abs(Lj.sum()>0) and abs((Lj>0).sum()-(KL[k]>0).sum())>0.15*(KL[k]>0).sum(): continue
                m=mis(KL[k],Lj)
                if m<best[0]: best=(m,k,a)
        if best[0]<0.08: print(f"{it['id']:8s} distraktor {j} ({o.get('kind')}) ≈ klíčový díl {best[1]} otočený o {best[2]}°: neshoda {best[0]*100:.1f} %", flush=True)
print('hotovo')
