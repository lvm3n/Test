import json, re, sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
NEW = json.load(open('/home/claude/sk/skw06_r.json'))
m = re.search(r'^const BANK_SK48 = (.*);\s*$', s, re.M); b = json.loads(m.group(1))
assert b['verze'] == 'SK36-W3'
k = [i for i, it in enumerate(b['items']) if it['id'] == 'SKW_06']; assert len(k) == 1
b['items'][k[0]] = NEW; b['verze'] = 'SK36-W3r'
s = s[:m.start(1)] + json.dumps(b, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
def rep(old, new):
    global s
    assert s.count(old) == 1, (old, s.count(old)); s = s.replace(old, new)
rep("version:'SK36-W3', pickN:3,", "version:'SK36-W3r', pickN:3,")
rep("['SK31-W2'], ['SK36-W3']],", "['SK31-W2'], ['SK36-W3', 'SK36-W3r']],")   # jen jeden distraktor → stejná skupina srovnání
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
