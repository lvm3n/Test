import json, re, math, numpy as np
def pts(d): n=list(map(float,re.findall(r'-?\d*\.?\d+',d))); return np.array(n).reshape(-1,2)
def clip(poly, x0, y0, x1, y1):
    def edge(P, inside, inter):
        out=[]
        for i in range(len(P)):
            a, b = P[i-1], P[i]
            if inside(b):
                if not inside(a): out.append(inter(a, b))
                out.append(b)
            elif inside(a): out.append(inter(a, b))
        return out
    P=[tuple(p) for p in poly]
    for k, v, sgn in ((0, x0, 1), (0, x1, -1), (1, y0, 1), (1, y1, -1)):
        ins=lambda p, k=k, v=v, sgn=sgn: (p[k]-v)*sgn >= 0
        def inter(a, b, k=k, v=v):
            t=(v-a[k])/(b[k]-a[k]); return (a[0]+t*(b[0]-a[0]), a[1]+t*(b[1]-a[1]))
        P=edge(P, ins, inter)
    return np.array(P)
def d_of(P): return 'M' + ' L'.join(f'{x:.4f} {y:.4f}'.replace('-0.0000','0.0000') for x, y in P) + 'Z'
def make(bank):
    it=[i for i in bank['items'] if i['id']=='SKW_06'][0]
    o1, o3 = it['options'][1], it['options'][3]
    B1, P1 = pts(o1['paths'][0]['d']), pts(o1['paths'][1]['d']); B3 = pts(o3['paths'][0]['d'])
    print('P1 x range', P1[:,0].min().round(3), P1[:,0].max().round(3), 'y', P1[:,1].min().round(3), P1[:,1].max().round(3))
    Q = P1 + np.array([0.17, 0.0])                    # výseč posunutá podél hrany ke rohu
    Q = clip(Q, 0, 0, 0.7071, 0.7071)
    c1, c3 = B1.mean(0), B3.mean(0); a = math.radians(315)
    R = np.array([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])
    N3 = (Q - c1) @ R + c3                            # do stejné polohy (kosočtverec) jako dosavadní možnost 3
    new = json.loads(json.dumps(it)); new['id'] = 'SKW_06_r'; new['revised_from'] = 'SKW_06'
    new['options'][3]['paths'][1]['d'] = d_of(N3)
    new['options'][3]['kind'] = 'špatný vzor (výseč posunutá ke rohu)'
    new['facety'] = dict(it['facety']); new['facety']['oprava'] = 'r: dosavadní „špatný vzor“ byl jen otočený správný díl (dvě správné odpovědi)'
    return it, new
if __name__ == '__main__':
    b = json.load(open('/tmp/sk.json')); old, new = make(b)
    json.dump(new, open('skw06_r.json', 'w'), ensure_ascii=False)
