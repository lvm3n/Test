import json, re, sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
NEW = json.load(open('/home/claude/sk/skw09_r.json'))
m = re.search(r'^const BANK_SK48 = (.*);\s*$', s, re.M); b = json.loads(m.group(1))
k = [i for i, it in enumerate(b['items']) if it['id'] == 'SKW_09']; assert len(k) == 1
b['items'][k[0]] = NEW; b['verze'] = 'SK36-W3t'
s = s[:m.start(1)] + json.dumps(b, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
def rep(old, new):
    global s
    assert s.count(old) == 1, (old, s.count(old)); s = s.replace(old, new)
rep("version:'SK36-W3s', pickN:3,", "version:'SK36-W3t', pickN:3,")
rep("['SK36-W3', 'SK36-W3r', 'SK36-W3s']],", "['SK36-W3', 'SK36-W3r', 'SK36-W3s', 'SK36-W3t']],")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
