"""CZ 4.31.0 / EN 1.90.0 – Přetahovaná 2.0 (PV-49-v1, klíče pretah2 / pretah2b), nový test Gv Oblouky (OB-17-v1), vývojová sada PF-24 skrytá z menu."""
import os, json, csv, io, shutil, sys
W = os.path.dirname(os.path.abspath(__file__)); V = os.path.join(W, '..', 'v4')
CZ = os.path.join(V, 'cz', 'kognitivni-baterie') + '/'; EN = os.path.join(V, 'en', 'cognitive-battery-en') + '/'
import zipfile
U = '/root/.claude/uploads/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/'
for z, t in (('182e5394-kognitivni-baterie_4.30.5.zip', 'cz'), ('fdc54f99-cognitive-battery-en_1.89.5.zip', 'en')):   # vždy z čistých zipů
    shutil.rmtree(os.path.join(V, t), ignore_errors=True); zipfile.ZipFile(U + z).extractall(os.path.join(V, t))
def rep(p, a, b, n=1):
    s = open(p, encoding='utf8').read(); assert s.count(a) == n, (p, a[:90], s.count(a)); open(p, 'w', encoding='utf8').write(s.replace(a, b))
PV = json.load(open(W + '/PV49.json', encoding='utf8')); OB = json.load(open(W + '/BANK_OB.json', encoding='utf8')); OBTX = json.load(open(W + '/OB_TX.json', encoding='utf8'))
J = lambda x: json.dumps(x, ensure_ascii=False, separators=(',', ':'))
PT2TX = {CZ: ({"name": "Přetahovaná 2.0", "blurb": "Nové úlohy · 12 až 19 úloh",
  "intro": ["Připravili jsme novou Přetahovanou s novými úlohami a pomůže nám, když je vyzkoušíte. Panáčci se přetahují lanem. Každý má pořád stejnou sílu a síly panáčků v jednom týmu se sčítají. Silnější tým vyhraje, stejně silné týmy remizují. Podívejte se, jak dopadly zápasy, a seřaďte panáčky od nejsilnějšího po nejslabšího: klepejte na ně dole v pořadí od nejsilnějšího (vlevo je nejsilnější, vpravo nejslabší). Poslední se doplní sám, klepnutím na obsazené místo panáčka vrátíte. Úlohy jdou od lehčích po těžší a test po chybách nekončí. Nejdřív dvě cvičné úlohy.",
            "Připravili jsme novou Přetahovanou s novými úlohami a pomůže nám, když je vyzkoušíš. Panáčci se přetahují lanem. Každý má pořád stejnou sílu a síly panáčků v jednom týmu se sčítají. Silnější tým vyhraje, stejně silné týmy remizují. Podívej se, jak dopadly zápasy, a seřaď panáčky od nejsilnějšího po nejslabšího: klepej na ně dole v pořadí od nejsilnějšího (vlevo je nejsilnější, vpravo nejslabší). Poslední se doplní sám, klepnutím na obsazené místo panáčka vrátíš. Úlohy jdou od lehčích po těžší a test po chybách nekončí. Nejdřív dvě cvičné úlohy."],
  "ready": ["Už neuvidíte, jestli jste odpověděli správně. Na každou úlohu máte 45 až 75 sekund podle její obtížnosti; když se čas krátí, objeví se nahoře pruh. Úlohy jsou nové a ke konci těžké – to je v pořádku. Řadí se od nejsilnějšího (vlevo) po nejslabšího (vpravo).",
            "Už neuvidíš, jestli jsi odpověděl správně. Na každou úlohu máš 45 až 75 sekund podle její obtížnosti; když se čas krátí, objeví se nahoře pruh. Úlohy jsou nové a ke konci těžké – to je v pořádku. Řadí se od nejsilnějšího (vlevo) po nejslabšího (vpravo)."],
  "endP": "Děkujeme – vaše odpovědi pomohou novou Přetahovanou doladit."},
  {"name": "Přetahovaná 2.0 – 2. část", "blurb": "12 až 13 dalších úloh",
   "ready": ["Druhá část: další nové úlohy, stejná pravidla jako minule. Na každou úlohu máte 45 až 75 sekund. Řadí se od nejsilnějšího (vlevo) po nejslabšího (vpravo).",
             "Druhá část: další nové úlohy, stejná pravidla jako minule. Na každou úlohu máš 45 až 75 sekund. Řadí se od nejsilnějšího (vlevo) po nejslabšího (vpravo)."]},
  "`<section class=\"card res-card\"><h2>${MODULES[k].name}</h2><p style=\"font-size:20px\">Vyřešeno <b>${raw}</b> z ${n} úloh.</p><p class=\"muted\" style=\"font-size:15px\">Novou Přetahovanou teprve kalibrujeme, proto výsledek zatím s nikým nesrovnáváme. Děkujeme – vaše odpovědi nám pomohou vybrat nejlepší úlohy.${k === 'pretah2' && !(S.scores && S.scores.pretah2b) ? ' V menu teď najdete i 2. část s dalšími úlohami.' : ''}</p></section>`"),
 EN: ({"name": "Tug of War 2.0", "blurb": "New items · 12 to 19 items",
  "intro": ["We have prepared a new Tug of War with new items, and it helps us a lot when people try them. The figures play tug of war. Each figure always has the same strength, and the strengths of figures in one team add up. The stronger team wins; equally strong teams draw. Look at how the matches ended and rank the figures from strongest to weakest: tap them below in order, starting with the strongest (strongest on the left, weakest on the right). The last one fills in by itself; tap a filled place to take a figure back. Items go from easier to harder and the test does not stop after errors. First two practice items."] * 2,
  "ready": ["From now on you will not see whether your answer was correct. You have 45 to 75 seconds per item, depending on its difficulty; a bar appears at the top when time is running out. The items are new and the last ones are hard – that is fine. Rank from strongest (left) to weakest (right)."] * 2,
  "endP": "Thank you – your answers help us fine-tune the new Tug of War."},
  {"name": "Tug of War 2.0 – part 2", "blurb": "12 to 13 more items",
   "ready": ["Part 2: more new items, same rules as before. You have 45 to 75 seconds per item. Rank from strongest (left) to weakest (right)."] * 2},
  "`<section class=\"card res-card\"><h2>${MODULES[k].name}</h2><p style=\"font-size:20px\">You solved <b>${raw}</b> of ${n} items.</p><p class=\"muted\" style=\"font-size:15px\">The new Tug of War is still being calibrated, so we do not compare results yet. Thank you – your answers help us choose the best items.${k === 'pretah2' && !(S.scores && S.scores.pretah2b) ? ' Part 2 with more items is now in the menu.' : ''}</p></section>`")}
GR = {CZ: ("{key:'vyvoj', title:'Nový test ve vývoji', sub:'Pomozte nám vyvinout nový test kvantitativního usuzování. Výsledek zatím s nikým nesrovnáváme.'}",
           "{key:'vyvoj', title:'Nová Přetahovaná', sub:'Nová verze testu kvantitativního usuzování s novými úlohami. Výsledek zatím s nikým nesrovnáváme.'}"),
      EN: ("{key:'vyvoj', title:'New test in development', sub:'Help us develop a new quantitative reasoning test. Results are not compared with others yet.'}",
           "{key:'vyvoj', title:'New Tug of War', sub:'A new version of the quantitative reasoning test with new items. Results are not compared with others yet.'}")}
QA = {CZ: ("'novy-test':'ptvyvoj', 'vyvoj':'ptvyvoj',", "'novy-test':'pretah2', 'vyvoj':'pretah2', 'pretahovana2':'pretah2', 'pretahovana-2':'pretah2', 'nova-pretahovana':'pretah2', oblouky:'oblouky',"),
      EN: ("'new-test':'ptvyvoj', 'develop':'ptvyvoj',", "'new-test':'pretah2', 'develop':'pretah2', 'tug-of-war-2':'pretah2', 'new-tug-of-war':'pretah2', arcs:'oblouky', oblouky:'oblouky',")}
CSS = '''
/* Oblouky (od CZ 4.31.0 / EN 1.90.0) */
.ob-lay{display:flex;gap:18px;align-items:flex-start;justify-content:center;flex-wrap:wrap}
.ob-card{background:#fff;border-radius:14px;padding:12px;box-shadow:0 1px 3px rgba(0,0,0,.08);text-align:center}
.ob-model{display:flex;align-items:center;justify-content:center;min-width:150px;min-height:120px}
.ob-cnt{font-size:14px;margin:6px 0 0}
.ob-timed{font-size:14px;font-weight:700;color:#B3261E;margin:6px 0 0}
.ob-board{display:inline-grid;gap:0;background:#e9ebee;border-radius:6px;touch-action:manipulation}
.ob-cell{border:1px dashed #c3c8cf;background:#eef0f3;cursor:pointer;padding:0;margin:0;border-radius:0}
.ob-cell.on{border:1px solid #c9ccd1;background:#fff}
.ob-cell svg{display:block;width:100%;height:100%}
.ob-pal{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-top:12px;max-width:400px;margin-left:auto;margin-right:auto}
.ob-pal button{width:min(52px,calc((100vw - 110px) / 6));height:min(52px,calc((100vw - 110px) / 6));border:3px solid var(--line);border-radius:10px;background:#fff;padding:3px;cursor:pointer;font-size:20px}
.ob-pal button.sel{border-color:#2B3440;box-shadow:0 0 0 4px color-mix(in srgb,var(--focus) 40%,transparent)}
.ob-pal button svg{display:block;width:100%;height:100%}
.ob-timebar{display:none;height:6px;background:#E8590C;border-radius:3px;transform-origin:left center;margin:4px 0 8px}
.ob-demo-row{display:flex;gap:10px;align-items:center;justify-content:center;flex-wrap:wrap;margin:10px 0}
.ob-demo-t{display:inline-block;width:46px;height:46px}.ob-demo-t svg{display:block;width:100%;height:100%}'''
for d, lang in ((CZ, 'cz'), (EN, 'en')):
    app = d + 'assets/app.html'
    tx1, tx2, card = PT2TX[d]
    js = open(W + '/pt2.js', encoding='utf8').read()
    for k, v in (('__ANCHORS__', J(PV['kotvy'])), ('__BLOCKS__', J(PV['bloky'])), ('__ITEMS__', J(PV['items'])), ('__TX1__', json.dumps(tx1, ensure_ascii=False)), ('__TX2__', json.dumps(tx2, ensure_ascii=False)), ('__CARD__', card)):
        assert js.count(k) == 1, k; js = js.replace(k, v)
    ob = open(W + '/oblouky.js', encoding='utf8').read()
    for k, v in (('__BANK__', J(OB)), ('__TX__', json.dumps(OBTX[lang], ensure_ascii=False))):
        assert ob.count(k) == 1, k; ob = ob.replace(k, v)
    rep(app, "#m-pretahovana .pt-ends span{color:#2B5D1E;font-weight:700}", "#m-pretahovana .pt-ends span{color:#2B5D1E;font-weight:700}" + CSS)
    rep(app, '<div id="m-ptvyvoj2"></div>', '<div id="m-ptvyvoj2"></div>\n<div id="m-pretah2"></div>\n<div id="m-pretah2b"></div>\n<div id="m-oblouky"></div>')
    # stejné vzhledové styly Přetahované i pro nové kořeny
    s = open(app, encoding='utf8').read(); lines = s.split('\n'); out = []; n = 0
    for l in lines:
        out.append(l)
        if l.startswith('#m-pretahovana ') and '{' in l:
            sel, body = l.split('{', 1); parts = [p.strip() for p in sel.split(',')]
            out.append(','.join(p.replace('#m-pretahovana', r) for r in ('#m-pretah2', '#m-pretah2b') for p in parts) + '{' + body); n += 1
    assert n > 10, n; open(app, 'w', encoding='utf8').write('\n'.join(out))
    rep(app, GR[d][0], GR[d][1])
    rep(app, "const KB_SUM_EXCL = ['pretahovana', 'stanoviste'];", "const KB_SUM_EXCL = ['pretahovana', 'stanoviste', 'oblouky'];   // Oblouky (od CZ 4.31.0 / EN 1.90.0): nový test, zatím mimo souhrn Gv")
    rep(app, "const menuMain = (g) => g === 'gf' ? null :", "const menuMain = (g) => (g === 'gf' || g === 'gv') ? null :")
    rep(app, "const ptvHidden = (k) => k === 'ptvyvoj2' && !ptvDone1();",
        "const ptvHidden = (k) => PTV_KEYS.includes(k) || (k === 'pretah2b' && !pt2Done1());   // od CZ 4.31.0 / EN 1.90.0: vývojová sada PF-24 už v menu není (výsledky zůstávají ve Výsledcích); 2. část Přetahované 2.0 až po 1. části")
    rep(app, "if (CF && it.vyvoj_role) Object.assign(S.rows[S.rows.length - 1], {vyvoj_role:it.vyvoj_role, vyvoj_cast:it.vyvoj_cast || '', navrh:it.navrh || '', b_odhad:it.b_odhad ?? ''});",
        "if (CF && it.vyvoj_role) Object.assign(S.rows[S.rows.length - 1], {vyvoj_role:it.vyvoj_role, vyvoj_cast:it.vyvoj_cast || '', navrh:it.navrh || '', b_odhad:it.b_odhad ?? ''}, it.uroven !== undefined ? {uroven_uvahy:it.uroven, typ_uvahy:it.typ || ''} : {});")
    rep(app, "const PTV_CF = {key:'ptvyvoj',", js + "const KB_DEV_KEYS = PTV_KEYS.concat(PT2_KEYS);\nconst PTV_CF = {key:'ptvyvoj',")
    rep(app, ' mod_pretahovana(document.getElementById("m-ptvyvoj2"), BANK_PT, PTV2_TX, PTV2_CF),',
        ' mod_pretahovana(document.getElementById("m-ptvyvoj2"), BANK_PT, PTV2_TX, PTV2_CF),\n mod_pretahovana(document.getElementById("m-pretah2"), BANK_PT, PT2_TX, PT2_CF),\n mod_pretahovana(document.getElementById("m-pretah2b"), BANK_PT, PT2B_TX, PT2B_CF),')
    rep(app, ' mod_skladani48(document.getElementById("m-skladani"), BANK_SK48, SK48_TX),', ' mod_skladani48(document.getElementById("m-skladani"), BANK_SK48, SK48_TX),\n mod_oblouky(document.getElementById("m-oblouky"), BANK_OB, OB_TX),')
    rep(app, "\nfunction mod_skladani(root, BANK){", "\n" + ob + "\nfunction mod_skladani(root, BANK){")
    rep(app, QA[d][0], QA[d][1])
    rep(app, "const PT_SKIP_KEYS = ['ceiling', 'ptvyvoj', 'ptvyvoj2',", "const PT_SKIP_KEYS = ['ceiling', 'ptvyvoj', 'ptvyvoj2', 'pretah2', 'pretah2b',")
    rep(app, "const KB_G_SKIP = ['kolecka', 'ceiling', 'ptvyvoj', 'ptvyvoj2'];", "const KB_G_SKIP = ['kolecka', 'ceiling', 'ptvyvoj', 'ptvyvoj2', 'pretah2', 'pretah2b', 'oblouky'];")
    rep(app, "  if (PTV_KEYS.includes(k)) return ptvCard(k, raw);", "  if (PT2_KEYS.includes(k)) return pt2Card(k, raw);   // Přetahovaná 2.0: kalibrace, bez srovnání\n  if (PTV_KEYS.includes(k)) return ptvCard(k, raw);")
    rep(app, "KB_SUM_G[m.group] && !PTV_KEYS.includes(m.key)", "KB_SUM_G[m.group] && !KB_DEV_KEYS.includes(m.key)")
    rep(app, "!mine[k] || PTV_KEYS.includes(k)) continue;", "!mine[k] || KB_DEV_KEYS.includes(k)) continue;")
    rep(app, "  skladani:[['SK-v1', 'SK-v1t'],", "  oblouky:[['OB-17-v1'], ['OB-17-v2']],\n  skladani:[['SK-v1', 'SK-v1t'],")
    for f in ('includes/rest.php', 'includes/admin.php'):
        p = d + f; s = open(p, encoding='utf8').read(); c = s.count("'skladani', 'rds'"); assert c >= 1 or f.endswith('admin.php'), (p, c)
        open(p, 'w', encoding='utf8').write(s.replace("'skladani', 'rds'", "'skladani', 'oblouky', 'rds'")); print(f, c)
    rep(d + 'includes/teststats.php', "'skladani', 'pretahovana', 'ptvyvoj', 'ptvyvoj2',", "'skladani', 'oblouky', 'pretahovana', 'ptvyvoj', 'ptvyvoj2', 'pretah2', 'pretah2b',")
    rep(d + 'includes/admin.php', "'skladani' => 'Skládání tvarů')", "'skladani' => 'Skládání tvarů', 'oblouky' => 'Oblouky')")
    rep(d + 'includes/admin.php', "'ptvyvoj' => 'Vývoj PF-24 (1. část)',", "'pretah2' => 'Přetahovaná 2.0 (1. část)', 'pretah2b' => 'Přetahovaná 2.0 (2. část)', 'ptvyvoj' => 'Vývoj PF-24 (1. část)',")
    # kódovník
    cb = d + 'assets/codebook.csv'; rows = list(csv.reader(io.StringIO(open(cb, encoding='utf-8-sig').read()), delimiter=';'))
    FN = {'circle': 'kruh', 'square': 'čtverec', 'triangle': 'trojúhelník', 'diamond': 'kosočtverec', 'pentagon': 'pětiúhelník'}
    def side(v, f): return ' + '.join((('%d× ' % c) if c > 1 else '') + FN[f[i]] for i, c in enumerate(v) if c)
    blk = {i: b for b, ids in PV['bloky'].items() for i in ids}
    body = [r for r in rows[1:] if r and not (r[0] in ('pretah2', 'oblouky'))]
    for k, it in enumerate(PV['items']):
        zn = ' ; '.join(side(c['left'], it['figures']) + ' ' + {'tie': '=', 'left': '>', 'right': '<'}[c['result']] + ' ' + side(c['right'], it['figures']) for c in it['clues'])
        lvl = ('úroveň %d (%s), odhad b %.2f' % (it['uroven'], it['typ'], it['b_odhad'])) if 'uroven' in it else 'pilot k nové kalibraci, b z linkingu %.2f (N %d)' % (it['b_pilot_linking'], it['N_pilot'])
        body.append(['pretah2', 'PV-49-v1', k + 1, it['id'], zn, ' > '.join(FN[x] for x in it['answer_order']), lvl, '',
                     '%d figurky; %d zápasy; kombinovat %d dvojic; blok %s; limit %d s; klíč pretah2 (1. část) i pretah2b (2. část)' % (it['n_shapes'], it['n_clues'], it['pairs_needing_combination'], blk[it['id']], it['limit_s'])])
    for k, it in enumerate(OB['practice'] + OB['items']):
        body.append(['oblouky', OB['verze'], k + 1, it['id'], it['nazev'] + ': ' + ' / '.join(it['grid']), 'stavba shodná se vzorem (i posunutá)', 'nácvik' if not it['level'] else 'úroveň %d' % it['level'], '',
                     ('volná plocha 6×6' if it.get('free') else 'mřížka %d×%d' % (len(it['grid']), len(it['grid']))) + ('; smíšené kostky' if it.get('mix') else '') + ('; hranice kostek ve vzoru' if it.get('lines') else '') + ('; limit %d s' % it['cap'] if it.get('cap') else '') + ('' if not it['level'] else '; na čas: 0 nebo 4–7 bodů podle času' if it.get('bonus') else '; silová: 0 nebo 4 body')])
    o = io.StringIO(); w = csv.writer(o, delimiter=';', lineterminator='\n'); w.writerow(rows[0]); w.writerows(body); open(cb, 'w', encoding='utf-8-sig').write(o.getvalue())
rep(EN + 'assets/app.html', "'pretahovana', 'ptvyvoj', 'ptvyvoj2', 'stanoviste', 'papir', 'skladani',", "'pretahovana', 'ptvyvoj', 'ptvyvoj2', 'pretah2', 'pretah2b', 'stanoviste', 'papir', 'skladani', 'oblouky',")
rep(CZ + 'assets/app.html', "${k === 'ptvyvoj' && !(S.scores && S.scores.ptvyvoj2) ? ' V menu teď najdete i 2. část s 12 dalšími úlohami.' : ''}", " Na tento vývojový test navazuje Přetahovaná 2.0 – najdete ji v menu úplně nahoře.")
rep(EN + 'assets/app.html', "${k === 'ptvyvoj' && !(S.scores && S.scores.ptvyvoj2) ? ' Part 2 with 12 more items is now available in the menu.' : ''}", " This development test is now followed by Tug of War 2.0 – you will find it at the top of the menu.")
U2 = '/root/.claude/uploads/b37472aa-91c0-5f5d-a3a7-19dad55e31c4/'
dd = CZ + 'docs/pretahovana/'
shutil.copy(W + '/PV49.json', dd + 'pretahovana_PV-49-v1.json'); shutil.copy(U2 + 'aa088c9c-nahled_PV-49-v1.html', dd + 'nahled_PV-49-v1.html'); shutil.copy(U2 + '66510b4f-pretahovana_linking_20261115.csv', dd + 'pretahovana_linking_20261115.csv')
os.makedirs(dd + 'generator_PV-49-v1', exist_ok=True)
for f in os.listdir(os.path.join(V, 'gen')): shutil.copy(os.path.join(V, 'gen', f), dd + 'generator_PV-49-v1/' + f)
shutil.copy(W + '/pt2.js', dd + 'pt2_PV-49-v1.js')
do = CZ + 'docs/oblouky/'; os.makedirs(do, exist_ok=True)
for f in ('BANK_OB.json', 'OB_TX.json', 'build_data.py', 'oblouky.js', 'patch_v431.py'): shutil.copy(W + '/' + f, do + f)
def prepend(p, txt): s = open(p, encoding='utf8').read(); open(p, 'w', encoding='utf8').write(txt + s)
prepend(CZ + 'readme-cz.txt', """4.31.0 (2026-11-15)
– Přetahovaná 2.0 (PV-49-v1): nová sekce úplně nahoře v menu „Nová Přetahovaná“ s testem „Přetahovaná 2.0“ (klíč pretah2) a po jeho dokončení „Přetahovaná 2.0 – 2. část“ (pretah2b). Kalibrační banka: 38 nových úloh PV01–PV38 v 7 úrovních podle typu úvahy + 11 slibných pilotů (PN/PF) k nové kalibraci, 4 bloky A–D (13 + 12 + 12 + 12).
– 1. část: kotvy PR11, PR16, PR17, PR32, PR33, PR45 (kdo už dělal Přetahovanou, kotvy nedostane – má je v datech) + první blok; 2. část: druhý blok, bez kotev a bez zácviku. Dvojice bloků AB, BC, CD, DA se losuje podle osoby a zůstává stálá. Uvnitř části jde první nejlehčí úloha, dál úlohy mírně stoupají, promíchané v okně ±1 úrovně (pořadí stálé pro osobu).
– Limit podle položky (45 / 60 / 75 s), bez ukončení po chybách a bez sond. Výsledek = počet správně vyřešených úloh bloku (kotvy se nepočítají), zatím bez srovnání; do souhrnů ani do g se nepočítá, po testu se neptáme na úsilí.
– Řádky navíc: vyvoj_role (kotva / nova / opakovana), vyvoj_cast (blok A–D), b_odhad, uroven_uvahy, typ_uvahy. Ve výsledku vyvoj_cast, vyvoj_bloky (např. A+B), varianta (kotvy+A, bez-kotev+A, cast2-B), hruby_kotvy, kotev, polozky, poradi.
– Vývojová sada PF-24 („Pomozte s vývojem nového testu“, ptvyvoj a ptvyvoj2) už v menu není. Moduly i data zůstávají: kdo ji dělal, najde výsledek dál ve Výsledcích; v administraci jsou oba klíče dál v exportech. Odkazy ?test=novy-test a ?test=vyvoj vedou na Přetahovanou 2.0 (nově i ?test=pretahovana2). Původní Přetahovaná (PR-29-v1) v sekci Gf se nemění.
– Nový test v sekci Prostorová představivost: Oblouky (klíč oblouky, OB-17-v1) – obdoba Kostek s neznámým materiálem. Vzor se skládá z kostek: bílá, červená, kostka s vypouklou čtvrtkruhovou výsečí a červená kostka s vykousnutou výsečí (po 4 natočeních). Vybere se kostka v paletě a klepne se na políčko; položka končí sama, jakmile stavba odpovídá vzoru (i posunutá), po limitu nebo tlačítkem „Nevím, další úloha“.
– 2 cvičné + 17 úloh: 2×2 (první s hranicemi kostek, 45 s) → 3×3 (75 s) → 4×4 (120 s) → volná plocha 6×6, kde vzor není čtverec a bílá splývá s pozadím (120 s) → dvě úlohy se smíšenými kostkami (přibudou kostky půlené úhlopříčkou). Do 8 let od první úlohy, starší od OB05 (4 úlohy se připíší; při chybě v prvních dvou návrat). Konec po 3 chybách v řadě.
– Skór = počet správně složených vzorů (bez bonusu za rychlost). V řádcích čas, první tah, počet tahů, průběh tahů a typy chyb (chyby_natoceni, chyby_vypoukla_vyduta, chyby_jine, chybejici, navic); ve výsledku medián času správných.
– Oblouky se zatím nepočítají do souhrnu Gv ani do g (pořadí úloh je jen odhad, bez dat). V sekci Gv jsou všechny testy vidět rovnou. Kódovník má řádky pretah2 (PV-49-v1) a oblouky (OB-17-v1); podklady v docs/pretahovana a docs/oblouky.

""")
prepend(EN + 'readme-cz.txt', """1.90.0 (2026-11-15)
– Tug of War 2.0 (PV-49-v1, klíče pretah2 a pretah2b) v sekci úplně nahoře „New Tug of War“; vývojová sada PF-24 (ptvyvoj, ptvyvoj2) už v menu není, výsledky zůstávají ve Výsledcích. Odkazy ?test=new-test a ?test=develop vedou na Tug of War 2.0. Stejné jako česká 4.31.0.
– Nový test Arcs (klíč oblouky, OB-17-v1) v sekci Spatial ability, zatím mimo souhrn Gv a g. Stejné jako česká 4.31.0.

""")
prepend(CZ + 'readme-cz.txt', """4.31.1 (2026-11-15)
– Oblouky OB-17-v2: skórování po vzoru WISC Kostek – nejdřív silové položky, pak položky na čas. OB01–OB09 (2×2 a 3×3) jsou silové: 0 nebo 4 body. OB10–OB17 (4×4, volná plocha, smíšené kostky; limit 120 s) jsou na čas: 0 nebo 4–7 bodů podle času správného složení (71–120 s 4 body, 51–70 s 5, 31–50 s 6, do 30 s 7). U časových položek je pod vzorem nápis „Na čas“ a instrukce před testem to vysvětluje.
– Hrubý skór = body (max. 92); položky připsané pod startem se počítají za 4 body. Ve výsledku jsou zvlášť spravne_pocet, body_bez_bonusu a casovy_bonus, v řádcích body, max_body a na_cas – skór bez bonusu jde tedy kdykoli spočítat. Při vypnutých limitech se bonus nedává.
– Pásma času jsou převzatá z WISC (fyzické kostky); po prvních datech je potřeba je ověřit pro klepání na obrazovce. OB-17-v2 je nová skupina srovnání (jiný skór než OB-17-v1). Položky, limity, start ani ukončení po 3 chybách se nemění.

""")
prepend(EN + 'readme-cz.txt', """1.90.1 (2026-11-15)
– Arcs OB-17-v2: silové položky OB01–OB09 za 0/4 body, časové OB10–OB17 za 0/4–7 bodů podle času (jako WISC Kostky). Stejné jako česká 4.31.1.

""")
rep(CZ + 'kognitivni-baterie.php', '4.30.5', '4.31.1', 2); rep(EN + 'cognitive-battery-en.php', '1.89.5', '1.90.1', 2)
print('ok')
