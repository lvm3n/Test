"""Pořadí na mřížce (Corsi, postupné žetony) – pevná banka s vyváženou geometrií. Mřížka 5×5, n = 2…12, 3 položky na úroveň."""
import random, math, json, statistics
G = 5
LEVELS = range(2, 13)
def rc(c): return divmod(c, G)
def ok(seq):
    P = [rc(c) for c in seq]; n = len(seq)
    adj = sum(1 for a, b in zip(P, P[1:]) if max(abs(a[0]-b[0]), abs(a[1]-b[1])) == 1)
    if adj > n // 4: return False                                             # sousední políčka po sobě – nejvýš výjimečně
    for a, b, c in zip(P, P[1:], P[2:]):                                       # tři místa po sobě v jedné přímce
        if (b[0]-a[0]) * (c[1]-b[1]) - (b[1]-a[1]) * (c[0]-b[0]) == 0: return False
    for k in range(G):
        if sum(1 for p in P if p[0] == k) > math.ceil(n / G) + 1 or sum(1 for p in P if p[1] == k) > math.ceil(n / G) + 1: return False
    run = 1                                                                    # pořadí čtení (zleva doprava, shora dolů)
    for a, b in zip(seq, seq[1:]):
        run = run + 1 if b > a else 1
        if run >= 4: return False
    return True
def stats(seq):
    P = [rc(c) for c in seq]
    steps = [math.hypot(a[0]-b[0], a[1]-b[1]) for a, b in zip(P, P[1:])]
    turns = 0
    for a, b, c in zip(P, P[1:], P[2:]):
        v1 = (b[0]-a[0], b[1]-a[1]); v2 = (c[0]-b[0], c[1]-b[1])
        ang = math.degrees(math.acos(max(-1, min(1, (v1[0]*v2[0] + v1[1]*v2[1]) / (math.hypot(*v1) * math.hypot(*v2))))))
        turns += ang
    return statistics.mean(steps), turns / max(1, len(seq) - 2)
r = random.Random(20261008)
bank, starts = [], []
for n in LEVELS:
    cands = []
    for _ in range(60000):
        seq = r.sample(range(G * G), n)
        if ok(seq): cands.append(seq)
        if len(cands) >= 600: break
    st = [stats(c) for c in cands]
    ms, mt = statistics.median(s[0] for s in st), statistics.median(s[1] for s in st)
    ss, stt = statistics.pstdev(s[0] for s in st) or 1, statistics.pstdev(s[1] for s in st) or 1
    order = sorted(range(len(cands)), key=lambda i: ((st[i][0]-ms)/ss) ** 2 + ((st[i][1]-mt)/stt) ** 2)
    chosen = []
    for i in order:
        c = cands[i]
        if starts and c[0] == starts[-1]: continue                             # jiný začátek než předchozí položka
        if any(len(set(c[:3]) & set(x[:3])) >= 2 for x in chosen): continue    # různé začátky v rámci úrovně
        chosen.append(c); starts.append(c[0])
        if len(chosen) == 3: break
    for j, c in enumerate(chosen):
        s = stats(c)
        bank.append({'id': f'CO_N{n:02d}_{j+1}', 'n': n, 'g': G, 'seq': c, 'krok': round(s[0], 2), 'otoceni': round(s[1], 1)})
for it in bank:
    if it['id'] == 'CO_N02_3': it['seq'] = [20, 8]          # n = 2: vodorovně, svisle, úhlopříčně
prac = [{'id': 'CO_P1', 'n': 2, 'g': G, 'seq': [6, 18]}, {'id': 'CO_P2', 'n': 3, 'g': G, 'seq': [3, 20, 12]}]
for p in prac: assert ok(p['seq']), p
for it in bank: print(it['id'], it['seq'], it['krok'], it['otoceni'])
json.dump({'verze': 'CO-5x5-v1', 'test': bank, 'nacvik': prac}, open('corsi_bank.json', 'w'))
