import sys, json
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
BANK = json.load(open('/home/claude/co/corsi_bank.json'))
if CZ:
    T = dict(name='Pořadí na mřížce', blurb='Zopakuj, v jakém pořadí se políčka rozsvítila', read='Přečíst', back='Zpět do menu', go='Zahájit subtest',
        instr='Na mřížce se budou jedno po druhém rozsvěcovat políčka. Až se rozsvítí všechna, klepni na ta samá políčka ve stejném pořadí, v jakém se rozsvítila. Řady se budou postupně prodlužovat. Když se spleteš, tlačítkem Opravit vrátíš poslední klepnutí. Na odpověď máš čas, rychlost se nepočítá.',
        how='Jak to funguje', replay='Přehrát znovu', trysolo='Zkusit sám', ready='Teď naostro', start='Začít', done='Hotovo', backm='Zpět do menu',
        d1='Políčka se rozsvítí jedno po druhém.', d2='Teď klepneme na stejná políčka ve stejném pořadí.', d3='Nejdřív první, pak druhé, pak třetí.',
        watch='Za chvíli se rozsvítí políčka.', look='Rozsvěcují se políčka…', undo='Opravit', ok='Pokračovat', pill='Nácvik',
        hint='Klepni na políčka ve stejném pořadí.', good='Správně.', bad='Takhle to bylo správně – pořadí je zeleně.',
        doneTxt='Hotovo. Nejdelší řada, kterou se ti podařilo zopakovat: ${s}.', cell='Políčko')
else:
    T = dict(name='Spatial Span', blurb='Repeat the order in which squares lit up', read='Read aloud', back='Back to menu', go='Start',
        instr='Squares on the grid will light up one after another. When they have all lit up, tap the same squares in the same order in which they lit up. The sequences will gradually get longer. If you make a mistake, the Undo button removes your last tap. Take your time – speed does not count.',
        how='How it works', replay='Replay', trysolo='Try it yourself', ready='Now for real', start='Start', done='Done', backm='Back to menu',
        d1='The squares light up one after another.', d2='Now we tap the same squares in the same order.', d3='First the first one, then the second, then the third.',
        watch='The squares will light up in a moment.', look='Squares are lighting up…', undo='Undo', ok='Continue', pill='Practice',
        hint='Tap the squares in the same order.', good='Correct.', bad='This is how it was – the order is shown in green.',
        doneTxt='Done. The longest sequence you repeated: ${s}.', cell='Square')
MOD = r"""
/* ---------- Gwm (vizuálně-prostorová): Pořadí na mřížce (CO-5x5-v1, Corsiho test s postupně se rozsvěcujícími políčky) ----------
   Pevná mřížka 5×5, políčka se rozsvěcují jedno po druhém (700 ms rozsvíceno + 300 ms pauza = 1 místo za sekundu), stejná barva,
   bez čísel (žádný slovní obsah). Potom člověk klepe na políčka ve stejném pořadí (Opravit / Pokračovat, bez časového limitu).
   Délky řad n = 2…12, na každou délku VŽDY 3 položky (pilot – reliabilita); konec, když jsou všechny 3 položky úrovně špatně
   (stejně jako u číselných testů). Pevná banka s vyváženou geometrií (generátor docs/poradi_mrizka/): žádná tři místa po sobě
   v přímce, sousední políčka po sobě jen výjimečně, žádné řady/sloupce přeplněné, nejvýš 3 místa v pořadí čtení, podobná délka
   kroku a míra otáčení; různé začátky.
   Skóre: hruby = počet správně zopakovaných řad (jako celkové skóre u opakování čísel); vazby = správná místa na správném
   pořadí (součet); rozsah = nejdelší řada se 2 ze 3 správně; nejdelsi_spravna = nejdelší aspoň jednou správně. */
const CO_BANK = __BANK__;
function mod_corsi(root){
  const T = __T__, show = (id) => showIn(root, id), $ = (s) => root.querySelector(s), H = gwmShared();
  const ON = 700, OFF = 300;
  root.innerHTML = `
<section class="screen" id="co-instr"><div class="wrap" style="max-width:820px">
  <div class="instr"><h1 data-heading>${T.name}</h1><button class="speak" data-say="instr">${T.read}</button></div>
  <p style="font-size:22px">${T.instr}</p>
  <div class="actions"><button class="btn ghost" data-back>${T.back}</button><button class="btn" id="co-go">${T.go}</button></div>
</div></section>
<section class="screen" id="co-demo"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.how}</h1>
  <div id="co-demo-stage"></div>
  <p style="font-size:20px" id="co-demo-cap"></p>
  <div class="actions"><button class="btn ghost" id="co-demo-replay">${T.replay}</button><button class="btn" id="co-demo-next" disabled>${T.trysolo}</button></div>
</div></section>
<section class="screen" id="co-trial"><div class="wrap" style="max-width:820px">
  <p class="pill" id="co-pill" hidden>${T.pill}</p>
  <p class="mr-hint" id="co-hint"></p>
  <div id="co-stage"></div>
  <div class="actions mr-acts" id="co-acts"><button class="btn ghost" id="co-undo" type="button">← ${T.undo}</button><button class="btn" id="co-ok" type="button" disabled>${T.ok}</button></div>
  <div class="feedback" id="co-fb" role="status"></div>
</div></section>
<section class="screen" id="co-ready"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.ready}</h1><p style="font-size:22px">${PRETEST_MEM}</p>
  <div class="actions"><button class="btn" id="co-start">${T.start}</button></div>
</div></section>
<section class="screen" id="co-done"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.done}</h1><p style="font-size:20px" id="co-done-text"></p>
  <div class="actions"><button class="btn" data-back>${T.backm}</button></div>
</div></section>`;
  bindSpeak(root, {instr:T.instr});
  root.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', backToMenu));
  const ST = {i:0, levels:{}, exact:0, bind:0, adm:0, practice:0, practErr:0, it:null, resp:[], locked:true, endReason:''};
  const BANK = CO_BANK.test, PRAC = CO_BANK.nacvik;
  function grid(g, lit, resp, fbSeq){
    const mk = {}; (resp || []).forEach((c, k) => { mk[c] = k + 1; });
    const ok = {}; (fbSeq || []).forEach((c, k) => { ok[c] = k + 1; });
    let h = `<div class="mr-grid co-grid" style="--g:${g}">`;
    for (let c = 0; c < g * g; c++) {
      let cls = 'mr-cell', inner = '';
      if (c === lit) cls += ' lit';
      if (mk[c]) { cls += ' mk'; inner = `<span class="mr-badge">${mk[c]}</span>`; }
      if (ok[c]) { cls += ' ok'; inner = ok[c] + (mk[c] && mk[c] !== ok[c] ? `<span class="mr-badge">${mk[c]}</span>` : ''); }
      h += `<button type="button" class="${cls}" data-c="${c}" aria-label="${T.cell} ${c + 1}">${inner}</button>`;
    }
    return h + '</div>';
  }
  function bindCells(){
    $('#co-stage').querySelectorAll('.mr-cell').forEach(b => b.addEventListener('click', () => {
      S.inputMode = S.lastPointer || 'touch';
      const it = ST.it, c = parseInt(b.dataset.c, 10);
      if (ST.locked || ST.resp.includes(c) || ST.resp.length >= it.n) return;
      if (ST.tFirst === null) ST.tFirst = Math.round(performance.now() - ST.t0);
      ST.resp.push(c); drawResp();
    }));
  }
  function drawResp(){ $('#co-stage').innerHTML = grid(ST.it.g, -1, ST.resp); bindCells(); $('#co-ok').disabled = ST.resp.length !== ST.it.n; $('#co-undo').disabled = !ST.resp.length; }
  const alive = () => document.body.classList.contains('in-test') && CUR && CUR.key === 'corsi';   // po odchodu z testu nepokračovat
  async function playSeq(stage, it, demo){
    for (const c of it.seq) { if (!demo && !alive()) return false; stage.innerHTML = grid(it.g, c); await sleep(ON); stage.innerHTML = grid(it.g, -1); await sleep(OFF); }
    return true;
  }
  async function runTrial(it){
    ST.it = it; ST.resp = []; ST.locked = true; ST.tFirst = null; ST.undo = 0;
    $('#co-acts').style.visibility = 'hidden'; $('#co-fb').innerHTML = '';
    $('#co-hint').textContent = T.watch; $('#co-stage').innerHTML = grid(it.g, -1); show('co-trial');
    await sleep(1000); if (!alive()) return;
    $('#co-hint').textContent = T.look;
    if (!(await playSeq($('#co-stage'), it)) || !alive()) return;
    $('#co-hint').textContent = T.hint;
    ST.locked = false; ST.t0 = performance.now(); $('#co-acts').style.visibility = ''; drawResp();
  }
  $('#co-undo').addEventListener('click', () => { if (ST.locked || !ST.resp.length) return; ST.resp.pop(); ST.undo++; drawResp(); });
  $('#co-ok').addEventListener('click', () => { if (ST.locked || ST.resp.length !== ST.it.n) return; ST.locked = true; evaluate(ST.it, ST.resp.slice()); });
  function evaluate(it, resp){
    const rt = Math.round(performance.now() - ST.t0), bind = it.seq.reduce((a, c, k) => a + (resp[k] === c ? 1 : 0), 0), exact = bind === it.n ? 1 : 0;
    H.logRow({polozka:it.id, id:it.id, format:'corsi-forward', k:it.n, delka:it.n, typ:'5x5', mrizka:it.g + 'x' + it.g,
      reseni:it.seq.map(c => c + 1).join('-'), odpoved:resp.map(c => c + 1).join('-'), spravne:exact, exact_correct:exact,
      skore:bind, max_skore:it.n, vazby:bind, rozsviceni_ms:ON, pauza_ms:OFF, rt_ms:rt, prvni_akce_ms:ST.tFirst, upravy:ST.undo,
      delka_kroku:it.krok ?? '', otaceni:it.otoceni ?? ''});
    if (S.mode === 'nacvik') {
      ST.practice++; if (!exact) ST.practErr++;
      $('#co-acts').style.visibility = 'hidden';
      if (exact) $('#co-fb').innerHTML = '<span class="mark ok">' + CHECK + '</span> ' + T.good;
      else { $('#co-stage').innerHTML = grid(it.g, -1, resp, it.seq); $('#co-fb').innerHTML = '<span class="mark no">' + CROSS + '</span> ' + T.bad; }
      setTimeout(() => { if (!alive()) return; $('#co-fb').innerHTML = ''; if (ST.practice < PRAC.length) runTrial(PRAC[ST.practice]); else show('co-ready'); }, exact ? 1100 : 2800);
      return;
    }
    const lv = 'n' + it.n, L = (ST.levels[lv] = ST.levels[lv] || []);
    L.push(exact); ST.adm++; ST.exact += exact; ST.bind += bind; ST.i++;
    const nLv = BANK.filter(x => x.n === it.n).length;
    if (L.length === nLv && L.every(x => x === 0)) { ST.endReason = lv + ': 0/' + nLv + ' správně'; return finish(); }
    if (ST.i >= BANK.length) { ST.endReason = 'všechny úrovně'; return finish(); }
    setTimeout(() => { if (alive()) runTrial(BANK[ST.i]); }, 600);
  }
  function finish(){
    const lv = Object.entries(ST.levels).map(([k, v]) => [parseInt(k.slice(1), 10), v]);
    const span = lv.filter(([, v]) => v.filter(x => x).length >= 2).reduce((m, [n]) => Math.max(m, n), 0);
    const best = lv.filter(([, v]) => v.some(x => x)).reduce((m, [n]) => Math.max(m, n), 0);
    S.scores[CUR.key] = {hruby:ST.exact, spravne_administrovane:ST.exact, pripsane:0, administrovano:ST.adm, start:2, polozek:BANK.length,
      konec:ST.endReason, forma:'CO-5x5-v1 (n 2–12, 3 položky na úroveň)', vazby:ST.bind, rozsah:span, nejdelsi_spravna:best, nacvik_chyby:ST.practErr,
      po_urovnich:lv.map(([n, v]) => 'n' + n + ':' + v.join('')).join(' ')};
    save();
    $('#co-done-text').textContent = `__DONE__`;
    show('co-done');
  }
  async function runDemo(){
    const st = $('#co-demo-stage'), cap = $('#co-demo-cap'), it = {g:5, n:3, seq:[7, 19, 15]};
    $('#co-demo-next').disabled = true; $('#co-demo-replay').disabled = true;
    st.innerHTML = grid(5, -1); cap.textContent = T.d1; await sleep(900);
    await playSeq(st, it, true);
    cap.textContent = T.d2; await sleep(1500);
    cap.textContent = T.d3;
    for (let k = 1; k <= 3; k++) { st.innerHTML = grid(5, -1, it.seq.slice(0, k)); await sleep(900); }
    $('#co-demo-next').disabled = false; $('#co-demo-replay').disabled = false;
  }
  $('#co-go').addEventListener('click', () => {
    if (S.nacvik) { S.mode = 'nacvik'; $('#co-pill').hidden = false; show('co-demo'); runDemo(); } else show('co-ready');
  });
  $('#co-demo-replay').addEventListener('click', runDemo);
  $('#co-demo-next').addEventListener('click', () => { S.mode = 'nacvik'; ST.practice = 0; ST.practErr = 0; $('#co-pill').hidden = false; runTrial(PRAC[0]); });
  $('#co-start').addEventListener('click', () => { S.mode = 'test'; ST.i = 0; ST.levels = {}; ST.exact = 0; ST.bind = 0; ST.adm = 0; $('#co-pill').hidden = true; runTrial(BANK[0]); });
  return {key:'corsi', name:T.name, blurb:T.blurb, group:'gwm', version:'CO-5x5-v1',
    icon:'<svg viewBox="0 0 48 48"><g fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="12" height="12" rx="2"/><rect x="18" y="4" width="12" height="12" rx="2"/><rect x="32" y="4" width="12" height="12" rx="2"/><rect x="4" y="18" width="12" height="12" rx="2"/><rect x="18" y="18" width="12" height="12" rx="2"/><rect x="32" y="18" width="12" height="12" rx="2"/><rect x="4" y="32" width="12" height="12" rx="2"/><rect x="18" y="32" width="12" height="12" rx="2"/><rect x="32" y="32" width="12" height="12" rx="2"/></g><rect x="20" y="6" width="8" height="8" rx="2" fill="#0072B2"/><rect x="6" y="34" width="8" height="8" rx="2" fill="#0072B2" opacity=".55"/><rect x="34" y="20" width="8" height="8" rx="2" fill="#0072B2" opacity=".3"/></svg>',
    show,
    prepare(){ ST.i = 0; ST.levels = {}; ST.exact = 0; ST.bind = 0; ST.adm = 0; CUR.formLabel = 'CO-5x5-v1: mřížka 5×5, n 2–12, 3 položky na úroveň, 1 místo/s'; },
    runSelf(){ show('co-instr'); }, formLabel:''};
}
""".replace('__BANK__', json.dumps(BANK, separators=(',', ':'))).replace('__T__', json.dumps(T, ensure_ascii=False)).replace('__DONE__', T['doneTxt'].replace('${s}', '${best}'))
rep("/* ---------- Gwm 3: Pořadí obrázků ---------- */", MOD.strip('\n') + "\n\n/* ---------- Gwm 3: Pořadí obrázků ---------- */")
rep('<div id="m-por"></div>', '<div id="m-por"></div>\n<div id="m-corsi"></div>')
rep(' mod_por(document.getElementById("m-por"), BANK_POR, POR_ICONS),', ' mod_por(document.getElementById("m-por"), BANK_POR, POR_ICONS),\n mod_corsi(document.getElementById("m-corsi")),')
rep(".pb-stack{display:flex;", """.mr-hint{font-size:20px;line-height:1.3;text-align:center;margin:4px 0 10px;min-height:2.6em;display:flex;align-items:center;justify-content:center}
.mr-grid{display:grid;grid-template-columns:repeat(var(--g),minmax(0,1fr));grid-template-rows:repeat(var(--g),minmax(0,1fr));gap:6px;width:min(92vw,440px,calc(100vh - 430px));width:min(92vw,440px,calc(100dvh - 430px));min-width:220px;aspect-ratio:1/1;margin:0 auto}
.mr-cell{position:relative;background:#fff;border:2px solid var(--line);border-radius:10px;padding:0;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:calc(min(92vw,440px) / var(--g) * .42);color:#1f2933;cursor:pointer;-webkit-tap-highlight-color:transparent;font-variant-numeric:tabular-nums}
.mr-cell.lit{background:#0072B2;border-color:#0072B2}
.mr-cell.mk{background:#e8f1fb;border-color:var(--focus)}
.mr-cell.ok{border-color:#2e8b57;color:#2e8b57;background:#eaf6ef}
.mr-badge{font-size:calc(min(92vw,440px) / var(--g) * .34);color:var(--focus);font-weight:800}
.mr-cell.ok .mr-badge{position:absolute;right:4px;bottom:2px;font-size:calc(min(92vw,440px) / var(--g) * .22);color:#b42318}
.mr-acts{justify-content:center;margin-top:12px}
.pb-stack{display:flex;""")
if not CZ:
    rep("'zpetna', 'por', ", "'zpetna', 'por', 'corsi', ", 2)
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
