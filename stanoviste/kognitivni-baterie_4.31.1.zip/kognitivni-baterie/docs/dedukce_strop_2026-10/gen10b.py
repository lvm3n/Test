import random, json, sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from gen import rand_net
from sac import *
seed=int(sys.argv[1]); N=int(sys.argv[2]); n0,n1,m0,m1=map(int,sys.argv[3:7])
rng=random.Random(seed); out=[]; tries=0; st={}
while tries<N:
    tries+=1
    n=rng.randint(n0,n1); m=rng.randint(m0,m1)
    cons,val=rand_net(rng,n,m)
    if not cons: continue
    nodes=list(val); rng.shuffle(nodes)
    r=rng.randint(0,2); rev={x:val[x] for x in nodes[:r]}; t=nodes[r]
    if len(target_values(cons,rev,t))!=1: continue
    if level_of(cons,rev,t)!='SAC': continue
    rd=sac_profile(cons,rev,t); st[rd]=st.get(rd,0)+1
    if not rd: continue
    nec=all(len(target_values(cons[:j]+cons[j+1:],rev,t))!=1 for j in range(len(cons)))
    if not nec: continue
    out.append(dict(cons=cons,reveals=rev,target=t,answer=val[t],rounds=rd))
print(seed,n0,n1,m0,m1,'tries',tries,st,'kept',len(out))
json.dump(out,open(f'h2_{seed}.json','w'))
