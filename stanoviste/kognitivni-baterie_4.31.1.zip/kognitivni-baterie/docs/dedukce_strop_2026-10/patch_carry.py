import sys
PATH, LANG = sys.argv[1], sys.argv[2]
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
CZ = LANG == 'cz'
# ---- menu: nabídka doplnit jen nové / opravené úlohy
rep("if (sc && !S.scores[m.key] && sc.version && m.version && !curV.includes(sc.version)) { ext = pub ? extensionFor(m.key, done[m.key]) : null; sc = null; novy = true; }",
    "if (sc && !S.scores[m.key] && sc.version && m.version && !curV.includes(sc.version)) { ext = pub ? extensionFor(m.key, done[m.key]) : null; sc = null; novy = true; }\n"
    "      const carry = (novy && pub && !ext) ? carryFor(m.key, done[m.key]) : null;   // položkové testy: převzít dřívější odpovědi, zadat jen nové")
if CZ:
    rep("${sc ? 'Hotovo' : ext ? ext.n + ' nových úloh – stačí doplnit je' : novy ?",
        "${sc ? 'Hotovo' : ext ? ext.n + ' nových úloh – stačí doplnit je' : carry ? carry.todo.length + ' ' + (carry.todo.length === 1 ? 'nová úloha' : carry.todo.length < 5 ? 'nové úlohy' : 'nových úloh') + ' – stačí doplnit jen ' + (carry.todo.length === 1 ? 'ji' : 'je') : novy ?")
else:
    rep("${sc ? 'Done' : ext ? ext.n + ' new items – just add these' : novy ?",
        "${sc ? 'Done' : ext ? ext.n + ' new items – just add these' : carry ? carry.todo.length + (carry.todo.length === 1 ? ' new item – just add it' : ' new items – just add these') : novy ?")
rep("b.addEventListener('click', () => ext ? runExtension(m.key, done[m.key]) : runModule(m.key));",
    "b.addEventListener('click', () => ext ? runExtension(m.key, done[m.key]) : carry ? runCarry(m.key, carry) : runModule(m.key));")
# ---- jádro: převzetí odpovědí podle ID položky
ASK = ("Do testu jsme přidali nebo opravili ' + c.todo.length + ' ' + (c.todo.length === 1 ? 'úlohu' : c.todo.length < 5 ? 'úlohy' : 'úloh') + '. Odpovědi na ' + c.carried + ' úloh, které se nezměnily, se převezmou z minula – vyplníte jen ty nové. Výsledek se pak porovná s ostatními podle nové verze testu."
       if CZ else "We have added or corrected ' + c.todo.length + ' item' + (c.todo.length === 1 ? '' : 's') + ' in this test. Your answers to the ' + c.carried + ' unchanged items are carried over from last time – you only take the new ones. Your result is then compared with others on the new version of the test.")
B0, B1, H = (('Zpět', 'Vyplnit nové úlohy', 'Nové a opravené úlohy') if CZ else ('Back', 'Take the new items', 'New and corrected items'))
CORE = r"""
/* ===== Převzetí odpovědí podle ID položky (položkové testy) =====
   Kdo už starší verzi testu dělal, nemusí ji opakovat celou: odpovědi na položky se stejným ID se převezmou
   (server je vrací v /progress jako items: {id: 0/1}) a zadají se jen nové nebo opravené položky (nové ID, např. _r).
   - Starší verze test prošla celá → zadají se všechny nové/opravené položky.
   - Starší verze skončila ukončením po chybách → zadají se jen opravené verze položek, které tehdy řešil (stejný základ ID);
     položky, ke kterým nedošel, zůstávají nezadané jako dřív (platí pravidlo ukončení).
   Výsledek = převzaté správné + nové správné, uloží se jako nová verze (srovnání s ostatními podle nové verze).
   CARRY_FROM: z kterých verzí lze převzít (stejné časové limity a podání položek). */
const CARRY_FROM = {matice12:/^(M12-40|V12-)/, dedukce:/^DED-24-v2\.4$/, papir:/^Gv-PAP-v13e?$/, stanoviste:/^ST-v7/, pravidla:/^HP-36-v1\.4$/};
const CARRY_BANK = {matice12:() => BANK_M12.items, dedukce:() => BANK_DED.items, papir:() => BANK_GV.papir, stanoviste:() => BANK_STAN.items, pravidla:() => BANK_PRAVIDLA.items};
const carryBase = (id) => String(id).replace(/_r\d*$/, '');
function carryFor(key, prev){
  if (!CARRY_FROM[key] || !prev || !prev.items || typeof prev.items !== 'object' || !CARRY_FROM[key].test(prev.version || '')) return null;
  const full = /všechny položky|konec položek/.test(prev.konec || ''), stopped = /ukončeno po/.test(prev.konec || '');
  if (!full && !stopped) return null;
  const a = CARRY_BANK[key](), ids = (a._puvodni || a._full || a).map(it => it.id);
  const has = (id) => Object.prototype.hasOwnProperty.call(prev.items, id);
  const seenBase = new Set(Object.keys(prev.items).map(carryBase));
  const carried = ids.filter(has), fresh = ids.filter(id => !has(id));
  const todo = full ? fresh : fresh.filter(id => seenBase.has(carryBase(id)));
  if (!carried.length || !todo.length) return null;
  return {key, todo, carried:carried.length, carriedIds:carried, correct:carried.filter(id => +prev.items[id] === 1).length,
    notReached:fresh.length - todo.length, total:ids.length, fromVersion:prev.version, fromEnd:full ? 'cely' : 'ukonceno', fromKonec:prev.konec || ''};
}
function carryAsk(c){
  return new Promise(res => {
    const d = document.createElement('div'); d.className = 'mx-modal';
    d.innerHTML = `<div class="mx-box"><h2 style="margin-top:0">__H__</h2><p style="font-size:19px">${'__ASK__'}</p>
      <div class="actions" style="justify-content:center"><button class="btn ghost" type="button" data-a="0">__B0__</button><button class="btn" type="button" data-a="1">__B1__</button></div></div>`;
    document.body.appendChild(d);
    d.querySelectorAll('button').forEach(b => b.addEventListener('click', () => { d.remove(); res(b.dataset.a === '1'); }));
  });
}
async function runCarry(key, c){
  if (!(await carryAsk(c))) return;
  S.carry = Object.assign({nacvik:S.nacvik}, c); S.nacvik = false;          // test už zná – bez zácviku
  S.rows.push({test:key, polozka:'prevzato', faze:'prevzato', chyby:'převzaty odpovědi na ' + c.carried + ' položek z verze ' + c.fromVersion + ' (správně ' + c.correct + ', dřívější test ' + (c.fromEnd === 'cely' ? 'dokončen celý' : 'ukončen po chybách') + '); zadány jen nové/opravené: ' + c.todo.join(' ') + (c.notReached ? '; nezadáno (nedošel k nim): ' + c.notReached : ''), odpoved_text:c.carriedIds.join(' '), cas:new Date().toISOString()});
  ckClear(key); runModuleFresh(key);
}
/* banka položek pro běh s převzetím: ponechá jen položky k zadání (pilotOrder volá na konci; Tvarové klíče při startu) */
function carryFilter(arr, key){
  if (arr._full && !arr._puvodni) arr.splice(0, arr.length, ...arr._full);   // vrátit plnou banku (moduly bez pilotOrder)
  const c = S.carry && S.carry.key === key ? S.carry : null;
  if (!c) return arr;
  if (!arr._puvodni && !arr._full) arr._full = arr.slice();
  arr.splice(0, arr.length, ...arr.filter(it => c.todo.includes(it.id)));
  return arr;
}
function carryRestore(key){                    // po běhu s převzetím vrátit bance plný rozsah
  try { const a = CARRY_BANK[key] && CARRY_BANK[key](); if (!a) return; const f = a._puvodni || a._full; if (f) a.splice(0, a.length, ...f); } catch (e) {}
}
/* po dokončení: připočíst převzaté odpovědi (volá save()) */
function carryApply(){
  const c = S.carry; if (!c) return;
  const sc = S.scores && S.scores[c.key]; if (!sc || sc.prevzato !== undefined) return;
  if (!/přerušeno/.test(sc.konec || '')) {
    sc.hruby_nove = sc.hruby; sc.hruby = (+sc.hruby || 0) + c.correct; sc.spravne_administrovane = (+sc.spravne_administrovane || 0) + c.correct;
    sc.administrovano_nove = sc.administrovano; sc.administrovano = (+sc.administrovano || 0) + c.carried; sc.polozek = c.total;
    sc.prevzato = c.carried; sc.prevzato_spravne = c.correct; sc.prevzato_z = c.fromVersion; sc.nezadano_ukonceni = c.notReached; sc.rozsireni = 1;
    if (c.fromEnd === 'ukonceno') { sc.konec_doplneni = sc.konec; sc.konec = c.fromKonec + ' (převzato z ' + c.fromVersion + '); doplněny opravené položky'; }   // ukončení platí dál
  }
  S.nacvik = c.nacvik; S.carry = null; S.carryEnded = c.key;
}
"""
CORE = CORE.replace('__H__', H).replace('__B0__', B0).replace('__B1__', B1).replace("'__ASK__'", "'" + ASK + "'")
rep("/* Rozšíření testu o nové položky:", CORE.strip('\n') + "\n/* Rozšíření testu o nové položky:")
rep("function save(){\n  markTimeouts();", "function save(){\n  carryApply();\n  markTimeouts();")
rep("function ckSave(k, data){ try {", "function ckSave(k, data){ if (S.carry && S.carry.key === k) return; try {")
rep("  arr.splice(0, arr.length, ...out);\n  return arr;\n}", "  arr.splice(0, arr.length, ...out);\n  carryFilter(arr, key);\n  return arr;\n}")
rep("route:!(+S.vek && +S.vek < 9), routed:false}; testLoad(0); });", "route:!(+S.vek && +S.vek < 9), routed:false}; carryFilter(ITEMS, K); testLoad(0); });")
rep("route:!(+S.vek && +S.vek < 9), routed:false}; testLoad(0); } },", "route:!(+S.vek && +S.vek < 9), routed:false}; carryFilter(ITEMS, K); testLoad(0); } },")
rep("function backToMenu(){\n", "function backToMenu(){\n  if (S.carry && !(S.scores && S.scores[S.carry.key])) { S.nacvik = S.carry.nacvik; S.carryEnded = S.carry.key; S.carry = null; }   // nedokončený běh s převzetím\n  if (S.carryEnded) { carryRestore(S.carryEnded); S.carryEnded = null; }\n")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
