import random, json, sys
sys.path.insert(0,'/home/claude/dedv2')
from solver import *
from gen import rand_net
from sac import *
seed=int(sys.argv[1]); N=int(sys.argv[2])
rng=random.Random(seed); out=[]; tries=0; stats={}
while tries<N:
    tries+=1
    n=rng.randint(int(sys.argv[3]),int(sys.argv[4])); m=rng.randint(int(sys.argv[5]),int(sys.argv[6]))
    cons,val=rand_net(rng,n,m)
    if not cons: continue
    nodes=list(val); rng.shuffle(nodes)
    r=rng.randint(0,2); rev={x:val[x] for x in nodes[:r]}; t=nodes[r]
    if len(target_values(cons,rev,t))!=1: continue
    lv=level_of(cons,rev,t); stats[lv]=stats.get(lv,0)+1
    if lv!='DEEP': continue
    nec=all(len(target_values(cons[:j]+cons[j+1:],rev,t))!=1 for j in range(len(cons)))
    out.append(dict(cons=cons,reveals=rev,target=t,answer=val[t],n=n,m=m,nec=nec,sacc=sac_cands(cons,rev,t)))
print(seed,'tries',tries,stats,'deep',len(out),'nec',sum(o['nec'] for o in out))
json.dump(out,open(f'deep_{seed}.json','w'))
