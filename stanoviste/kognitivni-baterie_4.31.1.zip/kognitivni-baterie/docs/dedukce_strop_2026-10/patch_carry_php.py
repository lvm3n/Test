import sys
PATH, P = sys.argv[1], sys.argv[2]   # P = 'kb' nebo 'kben'
s = open(PATH, encoding='utf-8').read()
old = "    return array('tests' => $out);\n}\n"
assert s.count(old) == 1
new = ("    /* položkové testy: odpovědi na jednotlivé položky (ID → 0/1) ze všech dokončených běhů – aplikace podle nich\n"
       "       nabídne doplnit jen nové / opravené položky (převzetí odpovědí) */\n"
       "    foreach (array('matice12', 'dedukce', 'papir', 'stanoviste', 'pravidla') as $k) {\n"
       "        if (isset($out[$k])) { $out[$k]['items'] = " + P + "_answered_items($pid, $k); }\n"
       "    }\n"
       "    return array('tests' => $out);\n}\n\n"
       "function " + P + "_answered_items($pid, $key) {\n"
       "    global $wpdb;\n"
       "    $sids = $wpdb->get_col($wpdb->prepare(\"SELECT DISTINCT session_id FROM \" . " + P + "_table('scores') . \" WHERE participant_id = %d AND test_key = %s AND raw_score IS NOT NULL\", $pid, $key));\n"
       "    $items = array();\n"
       "    if (!$sids) { return (object) $items; }\n"
       "    $in = implode(',', array_map('intval', $sids));\n"
       "    $rows = $wpdb->get_results($wpdb->prepare(\"SELECT data FROM \" . " + P + "_table('rows') . \" WHERE session_id IN ($in) AND test_key = %s ORDER BY id ASC\", $key));\n"
       "    foreach ($rows as $x) {\n"
       "        $d = json_decode((string) $x->data, true);\n"
       "        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }      // jen ostré odpovědi (ne nácvik, ne sondy)\n"
       "        $id = isset($d['polozka']) ? (string) $d['polozka'] : '';\n"
       "        if ($id === '' || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }\n"
       "        $items[$id] = intval($d['spravne']) ? 1 : 0;                                            // pozdější odpověď přepíše dřívější\n"
       "    }\n"
       "    return (object) $items;\n"
       "}\n")
s = s.replace(old, new)
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
