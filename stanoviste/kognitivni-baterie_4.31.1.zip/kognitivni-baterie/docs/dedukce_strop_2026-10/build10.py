import json, sys, itertools
sys.path.insert(0,'/home/claude/dedv2')
from solver import *; from sac import *; from iso import iso_struct, iso
from layout import layout
cls=json.load(open('classes.json')); C5=json.load(open('h2_5rel.json'))
picks=[cls[1],cls[2],cls[3],C5[8]]
want=['A','C','E','D']
SH=lambda v,k: S[(S.index(v)+k)%5]
def partial_min(cons,rev,t):
    best=5
    for k in range(1,len(cons)):
        for sub in itertools.combinations(cons,k):
            sub=list(sub)
            if t not in nodes_of(sub): continue
            r2={n:v for n,v in rev.items() if n in nodes_of(sub)}
            best=min(best,len(target_values(sub,r2,t)))
    return best
out=[]
for i,(g,w) in enumerate(zip(picks,want)):
    k=(S.index(w)-S.index(g['answer']))%5
    rev={n:SH(v,k) for n,v in g['reveals'].items()}; cons=g['cons']; t=g['target']
    assert target_values(cons,rev,t)=={w}
    assert level_of(cons,rev,t)=='SAC' and sac_profile(cons,rev,t)==1 and not direct_refutable(cons,rev,t)
    assert all(len(target_values(cons[:j]+cons[j+1:],rev,t))!=1 for j in range(len(cons)))
    m=metrics(cons,rev,t); rc=refute_core(cons,rev,t)
    L=None; seed=65+i
    while L is None: L=layout(cons,seed=seed); seed+=100
    item={'id':'D%02d'%(65+i),'tier':10,'target':t,'reveals':rev,'answer':w,'cap':120,'cons':cons,'nc':L['nc'],'j':L['j'],
          'metriky':{'used':m['used'],'entry':m['entry'],'local':m['local'],'maxopen':m['maxopen'],'nodes':m['nodes'],'rels':m['rels'],'revealed':m['revealed'],
                     'spor':m.get('spor'),'refutation_core':rc['core_min'],'branching':rc['zbyva'],'partial_min':partial_min(cons,rev,t),
                     'hypotezy_ve_sledu':2,'primo_na_cili':False}}
    print(item['id'],'ans',w,'layout eval',L['eval'],item['metriky'])
    out.append(item)
b=json.load(open('/tmp/ded.json'))
allit=b['items']+out
for x,y in itertools.combinations(out,2): assert not iso_struct(x,y)
for x in out:
    for y in b['items']: assert not iso_struct(x,y), (x['id'],y['id'])
json.dump(out,open('ceiling.json','w'),ensure_ascii=False)
from collections import Counter; print(Counter(i['answer'] for i in allit))
