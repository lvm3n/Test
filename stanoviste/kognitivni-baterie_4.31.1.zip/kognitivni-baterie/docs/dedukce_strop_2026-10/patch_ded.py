import json, re, sys
PATH = sys.argv[1]
s = open(PATH, encoding='utf-8').read()
NEW = json.load(open('/home/claude/dedv2/ceiling.json'))
m = re.search(r'^const BANK_DED = (.*);$', s, re.M); b = json.loads(m.group(1))
assert len(b['items']) == 24 and b['items'][-1]['id'] == 'D59'
b['items'] += NEW
s = s[:m.start(1)] + json.dumps(b, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
def rep(old, new):
    global s
    assert s.count(old) == 1, (old, s.count(old)); s = s.replace(old, new)
rep("group:'gf', version:'DED-24-v2.4',", "group:'gf', version:'DED-28-v3.0',")
rep("'DED-24-v2.3', 'DED-24-v2.4'],", "'DED-24-v2.3', 'DED-24-v2.4'], ['DED-28-v3.0'],")
rep("show, prepare(){ CUR.formLabel = 'DED-24-v2.3'; },", "show, prepare(){ CUR.formLabel = 'DED-28-v3.0'; },")
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
