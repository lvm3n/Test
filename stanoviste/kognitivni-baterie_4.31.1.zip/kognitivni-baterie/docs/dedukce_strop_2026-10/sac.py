import sys; sys.path.insert(0,'/home/claude/dedv2')
from solver import *
def AC(cons, dom):
    dom={k:set(v) for k,v in dom.items()}
    while True:
        ch=False
        for c in cons:
            for m in c:
                w=rel_cands(c,dom,m)&dom[m]
                if w!=dom[m]: dom[m]=w; ch=True
                if not w: return None
        if not ch: return dom
def init(cons,rev): return {n:({rev[n]} if n in rev else set(S)) for n in nodes_of(cons)}
def SAC(cons, dom):
    dom=AC(cons,dom)
    if dom is None: return None
    rounds=0
    while True:
        ch=False
        for n in dom:
            if len(dom[n])<2: continue
            for v in sorted(dom[n]):
                d2=dict(dom); d2[n]={v}
                if AC(cons,d2) is None:
                    dom[n]=dom[n]-{v}; ch=True
            dom=AC(cons,dom)
            if dom is None: return None
        rounds+=1
        if not ch: return dom
def level_of(cons,rev,t):
    d=init(cons,rev); a=AC(cons,d)
    if len(a[t])==1: return 'AC'
    s=SAC(cons,d)
    if len(s[t])==1: return 'SAC'
    return 'DEEP'
def sac_cands(cons,rev,t):
    return len(SAC(cons,init(cons,rev))[t])
def direct_refutable(cons,rev,t):
    d=AC(cons,init(cons,rev)); true=target_values(cons,rev,t)
    for v in d[t]-true:
        d2=dict(d); d2[t]={v}
        if AC(cons,d2) is not None: return False
    return True
def sac_profile(cons,rev,t):
    """kolik kol jednoduchých hypotéz (mimo cíl) je třeba, než jde cíl vyvrátit přímo"""
    d=AC(cons,init(cons,rev)); rounds=0
    while True:
        true=target_values(cons,rev,t)
        ok=True
        for v in d[t]-true:
            d2=dict(d); d2[t]={v}
            if AC(cons,d2) is not None: ok=False
        if ok: return rounds
        ch=False
        for n in d:
            if n==t or len(d[n])<2: continue
            for v in sorted(d[n]):
                d2=dict(d); d2[n]={v}
                if AC(cons,d2) is None: d[n]=d[n]-{v}; ch=True
        d=AC(cons,d)
        if not ch: return None
        rounds+=1
