import sys
d = sys.argv[1]
def rep(path, old, new, count=1):
    s = open(path, encoding='utf-8').read(); n = s.count(old); assert n == count, (path, old[:60], n); open(path, 'w', encoding='utf-8').write(s.replace(old, new))
rep(d + '/includes/admin.php', "'por' => 'Pořadí obrázků'),", "'por' => 'Pořadí obrázků', 'mrizka' => 'Mřížka čísel'),")
if 'kognitivni' in d:
    rep(d + '/includes/rest.php', "'zpetna', 'por',", "'zpetna', 'por', 'mrizka',")
else:
    rep(d + '/includes/admin.php', "'zpetna', 'por',", "'zpetna', 'por', 'mrizka',")
print('ok', d)
