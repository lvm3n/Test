import sys, json
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
BANK = json.load(open('/home/claude/mr/mr_bank.json'))
if CZ:
    T = dict(name='Mřížka čísel', blurb='Zapamatuj si, kde byla která čísla', read='Přečíst', back='Zpět do menu', go='Zahájit subtest',
        instr='Na mřížce se na chvíli objeví čísla 1, 2, 3… – každé na jiném políčku. Potom zmizí. Klepni na políčka, kde čísla byla, ve správném pořadí: nejdřív tam, kde byla 1, potom kde byla 2, a tak dál. Čísel bude postupně přibývat. Když se spleteš, tlačítkem Opravit vrátíš poslední klepnutí. Na odpověď máš čas, rychlost se nepočítá.',
        how='Jak to funguje', replay='Přehrát znovu', trysolo='Zkusit sám', ready='Teď naostro', start='Začít', done='Hotovo', backm='Zpět do menu',
        d1='Na mřížce se objeví čísla 1, 2 a 3.', d2='Čísla zmizí.', d3='Klepneme tam, kde byla 1…', d4='…potom kde byla 2 a nakonec 3.',
        watch='Za chvíli se objeví čísla.', undo='Opravit', ok='Pokračovat', pill='Nácvik',
        hint1='Klepni, kde byla čísla ', hint2=', popořadě.', two='1 a 2', upto='1 až ',
        good='Správně.', bad='Takhle to bylo správně – čísla jsou zeleně.',
        doneTxt='Hotovo. Nejvíc čísel, které se ti podařilo zapamatovat: ${s}.', cell='Políčko')
else:
    T = dict(name='Number Grid', blurb='Remember where each number was', read='Read aloud', back='Back to menu', go='Start',
        instr='Numbers 1, 2, 3… will briefly appear on a grid, each in a different square. Then they disappear. Tap the squares where the numbers were, in the right order: first where 1 was, then where 2 was, and so on. The number of numbers will gradually increase. If you make a mistake, the Undo button removes your last tap. Take your time – speed does not count.',
        how='How it works', replay='Replay', trysolo='Try it yourself', ready='Now for real', start='Start', done='Done', backm='Back to menu',
        d1='Numbers 1, 2 and 3 appear on the grid.', d2='The numbers disappear.', d3='We tap where 1 was…', d4='…then where 2 was and finally 3.',
        watch='The numbers will appear in a moment.', undo='Undo', ok='Continue', pill='Practice',
        hint1='Tap where the numbers ', hint2=' were, in order.', two='1 and 2', upto='1 to ',
        good='Correct.', bad='This is how it was – the numbers are shown in green.',
        doneTxt='Done. The most numbers you remembered: ${s}.', cell='Square')
MOD = r"""
/* ---------- Gwm (vizuálně-prostorová): Mřížka čísel (SOB-v2, Spatial Order Binding) ----------
   Na mřížce se současně objeví čísla 1…n (každé v jiném políčku), po expozici 1,2 s + 0,4 s × n zmizí, maska 300 ms,
   pak člověk klepe na políčka v pořadí 1 → n. Před čísly se nejdřív na chvíli ukáže prázdná mřížka (1 s, při změně
   velikosti 1,6 s). Mřížky rostou s n (3×3 → 4×4 → 5×5 → 6×6) s překryvem (4: 3×3 i 4×4, 6: 4×4 i 5×5, 8–9: 5×5 i 6×6),
   obsazenost zhruba 22–44 %. Úrovně n = 2…16 po 3 položkách, pravidlo 2 ze 3: po dvou správných se postupuje (třetí
   položka se připíše), po dvou chybných test končí, při 1:1 rozhodne třetí položka. Pevná banka s vyváženou geometrií (bez řad, úhlopříček a souměrností, nanejvýš pár sousedících čísel
   po sobě, žádné čtyři čísla v pořadí čtení, podobná délka dráhy 1→n a vzdálenost nejbližšího souseda).
   Skóre: hruby = přesně správné položky + připsané (nezadané třetí položky prošlých úrovní); vazby = správné pozice na správném pořadí; nejvice_spravne = největší n celé správně.
   Bez zpětné vazby a bez časového limitu na odpověď (RT se jen ukládá). */
const MR_BANK = __BANK__;
function mod_mrizka(root){
  const T = __T__, show = (id) => showIn(root, id), $ = (s) => root.querySelector(s), H = gwmShared();
  root.innerHTML = `
<section class="screen" id="mr-instr"><div class="wrap" style="max-width:820px">
  <div class="instr"><h1 data-heading>${T.name}</h1><button class="speak" data-say="instr">${T.read}</button></div>
  <p style="font-size:22px">${T.instr}</p>
  <div class="actions"><button class="btn ghost" data-back>${T.back}</button><button class="btn" id="mr-go">${T.go}</button></div>
</div></section>
<section class="screen" id="mr-demo"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.how}</h1>
  <div id="mr-demo-stage"></div>
  <p style="font-size:20px" id="mr-demo-cap"></p>
  <div class="actions"><button class="btn ghost" id="mr-demo-replay">${T.replay}</button><button class="btn" id="mr-demo-next" disabled>${T.trysolo}</button></div>
</div></section>
<section class="screen" id="mr-trial"><div class="wrap" style="max-width:820px">
  <p class="pill" id="mr-pill" hidden>${T.pill}</p>
  <p class="mr-hint" id="mr-hint"></p>
  <div id="mr-stage"></div>
  <div class="actions mr-acts" id="mr-acts"><button class="btn ghost" id="mr-undo" type="button">← ${T.undo}</button><button class="btn" id="mr-ok" type="button" disabled>${T.ok}</button></div>
  <div class="feedback" id="mr-fb" role="status"></div>
</div></section>
<section class="screen" id="mr-ready"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.ready}</h1><p style="font-size:22px">${PRETEST_MEM}</p>
  <div class="actions"><button class="btn" id="mr-start">${T.start}</button></div>
</div></section>
<section class="screen" id="mr-done"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${T.done}</h1><p style="font-size:20px" id="mr-done-text"></p>
  <div class="actions"><button class="btn" data-back>${T.backm}</button></div>
</div></section>`;
  bindSpeak(root, {instr:T.instr});
  root.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', backToMenu));
  const ST = {i:0, levels:{}, exact:0, credit:0, bind:0, span:0, best:0, practice:0, practErr:0, it:null, resp:[], locked:true, endReason:'', lastG:0};
  const BANK = MR_BANK.test, PRAC = MR_BANK.nacvik;
  function grid(it, mode, resp, target){
    const g = it.g, pos = {}; it.cells.forEach((c, k) => { pos[c] = k + 1; });
    const mk = {}; (resp || []).forEach((c, k) => { mk[c] = k + 1; });
    let h = `<div class="mr-grid${mode === 'mask' ? ' mask' : ''}" style="--g:${g}">`;
    for (let c = 0; c < g * g; c++) {
      let cls = 'mr-cell', inner = '';
      if (mode === 'show' && pos[c]) { cls += ' on'; inner = pos[c]; }
      if ((mode === 'resp' || mode === 'fb') && mk[c]) { cls += ' mk'; inner = `<span class="mr-badge">${mk[c]}</span>`; }
      if (mode === 'fb' && pos[c]) { cls += ' ok'; inner = pos[c] + (mk[c] && mk[c] !== pos[c] ? `<span class="mr-badge">${mk[c]}</span>` : ''); }
      if (mode === 'mask') cls += ' m' + ((c * 7 + (c >> 2)) % 3);
      h += `<button type="button" class="${cls}" data-c="${c}" aria-label="${T.cell} ${c + 1}">${inner}</button>`;
    }
    return h + '</div>';
  }
  function bindCells(){
    $('#mr-stage').querySelectorAll('.mr-cell').forEach(b => b.addEventListener('click', () => {
      S.inputMode = S.lastPointer || 'touch';
      const it = ST.it, c = parseInt(b.dataset.c, 10);
      if (ST.locked || ST.resp.includes(c) || ST.resp.length >= it.n) return;
      if (ST.tFirst === null) ST.tFirst = Math.round(performance.now() - ST.t0);
      ST.resp.push(c); drawResp();
    }));
  }
  function drawResp(){ $('#mr-stage').innerHTML = grid(ST.it, 'resp', ST.resp); bindCells(); $('#mr-ok').disabled = ST.resp.length !== ST.it.n; $('#mr-undo').disabled = !ST.resp.length; }
  async function runTrial(it){
    ST.it = it; ST.resp = []; ST.locked = true; ST.tFirst = null; ST.undo = 0;
    $('#mr-acts').style.visibility = 'hidden'; $('#mr-fb').innerHTML = '';
    $('#mr-hint').textContent = T.watch; $('#mr-stage').innerHTML = grid(it, 'blank'); show('mr-trial');
    await sleep(it.g !== ST.lastG ? 1600 : 1000);            // nejdřív prázdná mřížka – při změně velikosti déle
    ST.lastG = it.g;
    $('#mr-stage').innerHTML = grid(it, 'show'); await sleep(it.expo_ms);
    $('#mr-stage').innerHTML = grid(it, 'mask'); await sleep(300);
    $('#mr-hint').textContent = T.hint1 + (it.n === 2 ? T.two : T.upto + it.n) + T.hint2;
    ST.locked = false; ST.t0 = performance.now(); $('#mr-acts').style.visibility = ''; drawResp();
  }
  $('#mr-undo').addEventListener('click', () => { if (ST.locked || !ST.resp.length) return; ST.resp.pop(); ST.undo++; drawResp(); });
  $('#mr-ok').addEventListener('click', () => { if (ST.locked || ST.resp.length !== ST.it.n) return; ST.locked = true; evaluate(ST.it, ST.resp.slice()); });
  function evaluate(it, resp){
    const rt = Math.round(performance.now() - ST.t0), bind = it.cells.reduce((a, c, k) => a + (resp[k] === c ? 1 : 0), 0), exact = bind === it.n ? 1 : 0;
    H.logRow({polozka:it.id, id:it.id, format:'spatial-order-binding', k:it.n, delka:it.n, typ:it.g + 'x' + it.g, mrizka:it.g + 'x' + it.g,
      reseni:it.cells.map(c => c + 1).join('-'), odpoved:resp.map(c => c + 1).join('-'), spravne:exact, exact_correct:exact,
      skore:bind, max_skore:it.n, vazby:bind, expozice_ms:it.expo_ms, rt_ms:rt, prvni_akce_ms:ST.tFirst, upravy:ST.undo,
      obsazenost:it.obsazenost ?? '', delka_drahy:it.path ?? '', nejblizsi_soused:it.nn ?? ''});
    if (S.mode === 'nacvik') {
      ST.practice++; if (!exact) ST.practErr++;
      $('#mr-acts').style.visibility = 'hidden';
      if (exact) $('#mr-fb').innerHTML = '<span class="mark ok">' + CHECK + '</span> ' + T.good;
      else { $('#mr-stage').innerHTML = grid(it, 'fb', resp); $('#mr-fb').innerHTML = '<span class="mark no">' + CROSS + '</span> ' + T.bad; }
      setTimeout(() => { $('#mr-fb').innerHTML = ''; if (ST.practice < PRAC.length) runTrial(PRAC[ST.practice]); else show('mr-ready'); }, exact ? 1100 : 2800);
      return;
    }
    const lv = 'n' + it.n, L = (ST.levels[lv] = ST.levels[lv] || []);
    L.push(exact); ST.n_adm = (ST.n_adm || 0) + 1;
    ST.exact += exact; ST.bind += bind; if (exact) ST.best = Math.max(ST.best, it.n);
    const good = L.filter(x => x).length, bad = L.length - good, nLv = BANK.filter(x => x.n === it.n).length;
    let next = ST.i + 1;
    if (good >= 2) {                                          // úroveň prošla (2 ze 3) → nezadané položky úrovně se připíšou
      ST.credit += nLv - L.length; ST.span = Math.max(ST.span, it.n);
      next = BANK.findIndex(x => x.n > it.n); if (next < 0) next = BANK.length;
    } else if (bad >= 2) { ST.i = next; ST.endReason = lv + ': ' + good + '/' + L.length + ' správně'; return finish(); }
    ST.i = next;
    if (ST.i >= BANK.length) { ST.endReason = 'všechny úrovně'; return finish(); }
    setTimeout(() => runTrial(BANK[ST.i]), 600);
  }
  function finish(){
    S.scores[CUR.key] = {hruby:ST.exact + ST.credit, spravne_administrovane:ST.exact, pripsane:ST.credit, administrovano:ST.n_adm || 0, start:2, polozek:BANK.length,
      konec:ST.endReason, forma:'SOB-v2 (n 2–16, 3 položky na úroveň, 2 ze 3, mřížky 3×3–6×6)', vazby:ST.bind, nejvice_spravne:ST.span, nejvetsi_spravna_polozka:ST.best, nacvik_chyby:ST.practErr,
      po_urovnich:Object.entries(ST.levels).map(([k, v]) => k + ':' + v.join('')).join(' ')};
    save();
    $('#mr-done-text').textContent = `__DONE__`;
    show('mr-done');
  }
  async function runDemo(){
    const st = $('#mr-demo-stage'), cap = $('#mr-demo-cap'), it = {g:3, n:3, cells:[2, 3, 7]};
    $('#mr-demo-next').disabled = true; $('#mr-demo-replay').disabled = true;
    st.innerHTML = grid(it, 'show'); cap.textContent = T.d1; await sleep(2400);
    st.innerHTML = grid(it, 'blank'); cap.textContent = T.d2; await sleep(1500);
    st.innerHTML = grid(it, 'resp', [2]); cap.textContent = T.d3; await sleep(1500);
    st.innerHTML = grid(it, 'resp', [2, 3]); cap.textContent = T.d4; await sleep(900);
    st.innerHTML = grid(it, 'resp', [2, 3, 7]); await sleep(300);
    $('#mr-demo-next').disabled = false; $('#mr-demo-replay').disabled = false;
  }
  $('#mr-go').addEventListener('click', () => {
    if (S.nacvik) { S.mode = 'nacvik'; $('#mr-pill').hidden = false; show('mr-demo'); runDemo(); } else show('mr-ready');
  });
  $('#mr-demo-replay').addEventListener('click', runDemo);
  $('#mr-demo-next').addEventListener('click', () => { S.mode = 'nacvik'; ST.practice = 0; ST.practErr = 0; $('#mr-pill').hidden = false; runTrial(PRAC[0]); });
  $('#mr-start').addEventListener('click', () => { S.mode = 'test'; ST.i = 0; ST.levels = {}; ST.exact = 0; ST.credit = 0; ST.bind = 0; ST.span = 0; ST.best = 0; ST.n_adm = 0; ST.lastG = 0; $('#mr-pill').hidden = true; runTrial(BANK[0]); });
  return {key:'mrizka', name:T.name, blurb:T.blurb, group:'gwm', version:'SOB-v2',
    icon:'<svg viewBox="0 0 48 48"><g fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="12" height="12" rx="2"/><rect x="18" y="4" width="12" height="12" rx="2"/><rect x="32" y="4" width="12" height="12" rx="2"/><rect x="4" y="18" width="12" height="12" rx="2"/><rect x="18" y="18" width="12" height="12" rx="2"/><rect x="32" y="18" width="12" height="12" rx="2"/><rect x="4" y="32" width="12" height="12" rx="2"/><rect x="18" y="32" width="12" height="12" rx="2"/><rect x="32" y="32" width="12" height="12" rx="2"/></g><text x="24" y="14" text-anchor="middle" font-size="10" font-weight="700" fill="#0072B2">1</text><text x="10" y="42" text-anchor="middle" font-size="10" font-weight="700" fill="#0072B2">2</text><text x="38" y="28" text-anchor="middle" font-size="10" font-weight="700" fill="#0072B2">3</text></svg>',
    show,
    prepare(){ ST.i = 0; ST.levels = {}; ST.exact = 0; ST.credit = 0; ST.bind = 0; ST.span = 0; ST.best = 0; ST.n_adm = 0; ST.lastG = 0; CUR.formLabel = 'SOB-v2: n 2–16, 3 položky na úroveň (2 ze 3), mřížky 3×3–6×6 s překryvem'; },
    runSelf(){ show('mr-instr'); }, formLabel:''};
}
""".replace('__BANK__', json.dumps(BANK, separators=(',', ':'))).replace('__T__', json.dumps(T, ensure_ascii=False)).replace('__DONE__', T['doneTxt'].replace('${e}', '${ST.exact}').replace('${s}', '${ST.span}'))
rep("/* ---------- Gwm 3: Pořadí obrázků ---------- */", MOD.strip('\n') + "\n\n/* ---------- Gwm 3: Pořadí obrázků ---------- */")
rep('<div id="m-por"></div>', '<div id="m-por"></div>\n<div id="m-mrizka"></div>')
rep(' mod_por(document.getElementById("m-por"), BANK_POR, POR_ICONS),', ' mod_por(document.getElementById("m-por"), BANK_POR, POR_ICONS),\n mod_mrizka(document.getElementById("m-mrizka")),')
rep(".pb-stack{display:flex;", """.mr-hint{font-size:20px;text-align:center;margin:4px 0 10px;min-height:28px}
.mr-grid{display:grid;grid-template-columns:repeat(var(--g),minmax(0,1fr));grid-template-rows:repeat(var(--g),minmax(0,1fr));gap:6px;width:min(92vw,440px,calc(100vh - 290px));width:min(92vw,440px,calc(100dvh - 290px));min-width:230px;aspect-ratio:1/1;margin:0 auto}
.mr-cell{position:relative;background:#fff;border:2px solid var(--line);border-radius:10px;padding:0;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:calc(min(92vw,440px) / var(--g) * .48);color:#1f2933;cursor:pointer;-webkit-tap-highlight-color:transparent;font-variant-numeric:tabular-nums}
.mr-cell.mk{background:#e8f1fb;border-color:var(--focus)}
.mr-cell.ok{border-color:#2e8b57;color:#2e8b57;background:#eaf6ef}
.mr-badge{font-size:calc(min(92vw,440px) / var(--g) * .34);color:var(--focus);font-weight:800}
.mr-cell.ok .mr-badge{position:absolute;right:4px;bottom:2px;font-size:calc(min(92vw,440px) / var(--g) * .22);color:#b42318}
.mr-grid.mask .mr-cell.m0{background:repeating-linear-gradient(45deg,#3b4048 0 4px,#d7dce2 4px 8px)}
.mr-grid.mask .mr-cell.m1{background:repeating-linear-gradient(-45deg,#3b4048 0 3px,#d7dce2 3px 7px)}
.mr-grid.mask .mr-cell.m2{background:repeating-linear-gradient(90deg,#3b4048 0 4px,#d7dce2 4px 9px)}
.mr-acts{justify-content:center;margin-top:12px}
.pb-stack{display:flex;""")
if not CZ:
    rep("'zpetna', 'por', ", "'zpetna', 'por', 'mrizka', ", 2)
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
