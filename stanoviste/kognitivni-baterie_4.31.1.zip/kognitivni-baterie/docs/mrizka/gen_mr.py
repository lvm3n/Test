"""Mřížka čísel (Spatial Order Binding) – pevná banka s vyváženou geometrií.
Úrovně n = 2…16, 3 položky na úroveň (2 ze 3); mřížky s překryvem: 4 → 3×3 i 4×4, 6 → 4×4 i 5×5, 8–9 → 5×5 i 6×6."""
import random, math, json, itertools, statistics
PLAN = {2: [3, 3, 3], 3: [3, 3, 3], 4: [3, 4, 4], 5: [4, 4, 4], 6: [4, 5, 5], 7: [5, 5, 5], 8: [5, 6, 6], 9: [5, 6, 6]}
for n in range(10, 17): PLAN[n] = [6, 6, 6]
PRAC = [(2, 3), (2, 3)]
def rc(c, g): return divmod(c, g)
def ok(cells, g, n):
    P = [rc(c, g) for c in cells]
    adj = sum(1 for a, b in zip(P, P[1:]) if max(abs(a[0]-b[0]), abs(a[1]-b[1])) == 1)
    if adj > max(1, n // 4): return False                                # sousední po sobě jdoucí čísla – nejvýš pár
    for a, b, c in zip(P, P[1:], P[2:]):                                  # tři po sobě jdoucí čísla v přímce se stejným krokem
        if (b[0]-a[0], b[1]-a[1]) == (c[0]-b[0], c[1]-b[1]): return False
        if (b[0]-a[0]) * (c[1]-b[1]) - (b[1]-a[1]) * (c[0]-b[0]) == 0: return False   # ani kolineární obecně
    cap = math.ceil(n / g) + 1
    for k in range(g):                                                    # žádná přeplněná řada / sloupec
        if sum(1 for p in P if p[0] == k) > cap or sum(1 for p in P if p[1] == k) > cap: return False
    if n >= 4 and len({p[0] for p in P}) < min(g, n) - 1: return False
    if n >= 4 and len({p[1] for p in P}) < min(g, n) - 1: return False
    corners = {(0, 0), (0, g-1), (g-1, 0), (g-1, g-1)}
    if sum(1 for p in P if p in corners) > max(1, n // 4): return False
    S = set(P)                                                            # souměrnost rozložení
    for f in (lambda r, c: (r, g-1-c), lambda r, c: (g-1-r, c), lambda r, c: (g-1-r, g-1-c), lambda r, c: (c, r)):
        if {f(*p) for p in S} == S: return False
    run = 1                                                               # čísla v pořadí čtení (zleva doprava, shora dolů)
    for a, b in zip(cells, cells[1:]):
        run = run + 1 if b > a else 1
        if run >= 4: return False
    return True
def stats(cells, g):
    P = [rc(c, g) for c in cells]
    d = lambda a, b: math.hypot(a[0]-b[0], a[1]-b[1])
    path = sum(d(a, b) for a, b in zip(P, P[1:])) / max(1, len(P)-1) / g
    nn = statistics.mean(min(d(a, b) for b in P if b != a) for a in P) / g
    return path, nn
def pick(g, n, k, r, avoid):
    cands = []
    for _ in range(30000):
        cells = r.sample(range(g * g), n)
        if ok(cells, g, n): cands.append(cells)
        if len(cands) >= 400: break
    assert cands, (g, n)
    st = [stats(c, g) for c in cands]
    mp, mn = statistics.median(s[0] for s in st), statistics.median(s[1] for s in st)
    sp = statistics.pstdev(s[0] for s in st) or 1; sn = statistics.pstdev(s[1] for s in st) or 1
    order = sorted(range(len(cands)), key=lambda i: ((st[i][0]-mp)/sp) ** 2 + ((st[i][1]-mn)/sn) ** 2)
    out = []
    for i in order:
        if any(set(cands[i]) == set(a) for a in avoid + out): continue
        out.append(cands[i])
        if len(out) == k: break
    return out, [stats(c, g) for c in out]
r = random.Random(2026)
bank = []
for n, grids in PLAN.items():
    used = []
    for j, g in enumerate(grids):
        (cells,), (s,) = pick(g, n, 1, r, used)
        used.append(cells)
        bank.append({'id': f'MR_N{n:02d}_{j+1}', 'n': n, 'g': g, 'cells': cells, 'expo_ms': 1200 + 400 * n,
                     'path': round(s[0], 3), 'nn': round(s[1], 3), 'obsazenost': round(n / g / g, 2)})
prac = []
for j, (n, g) in enumerate(PRAC):
    (cells,), _ = pick(g, n, 1, r, [p['cells'] for p in prac])
    prac.append({'id': f'MR_P{j+1}', 'n': n, 'g': g, 'cells': cells, 'expo_ms': 1200 + 400 * n})
for it in bank: print(it['id'], it['g'], 'x', it['g'], it['cells'], it['path'], it['nn'], it['obsazenost'])
json.dump({'verze': 'SOB-v2', 'test': bank, 'nacvik': prac}, open('mr_bank.json', 'w'))
