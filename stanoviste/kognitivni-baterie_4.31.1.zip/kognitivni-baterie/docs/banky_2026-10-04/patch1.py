import sys,re
p=sys.argv[1]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:90]))
    s=s.replace(a,b)
# 1) Skládání – na PC výrazně větší
rep("  const box = () => { if (innerWidth >= 900) return {tw:320, th:240, ow:168, oh:138};",
    "  const box = () => { if (innerWidth >= 1280) return {tw:560, th:400, ow:270, oh:220};   // velká obrazovka\n    if (innerWidth >= 900) return {tw:440, th:320, ow:220, oh:180};")
k=s.index('</style>')
s=s[:k]+"\n/* Skládání tvarů: na PC širší rozvržení, aby se vešly větší obrázky */\n@media (min-width:900px){#m-skladani .wrap{max-width:1420px!important}}\n"+s[k:]
open(p,'w',encoding='utf8').write(s); print('ok',p)
