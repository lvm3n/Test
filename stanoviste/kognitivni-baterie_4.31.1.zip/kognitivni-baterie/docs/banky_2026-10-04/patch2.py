import sys,re,json
p=sys.argv[1]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:100]))
    s=s.replace(a,b)
def bank_get(n):
    i=s.index('const '+n+' = ')+len('const '+n+' = '); v,e=json.JSONDecoder().raw_decode(s[i:]); return v,i,i+e
def bank_put(n,v):
    global s
    _,i,j=bank_get(n); s=s[:i]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[j:]
# ---------- MATICE 60 s ----------
rep("S.mxCap = 90;   // od v10-56t90 všechny úrovně 90 s (dříve 9–11: 120 s)","S.mxCap = 60;   // od v10-56t60 všechny úrovně 60 s (dříve 90 s); po limitu se počítá označená volba")
rep("version:'v10-56t90',","version:'v10-56t60',")
rep("['v10-56', 'v10-56t', 'v10-56t90']]","['v10-56', 'v10-56t', 'v10-56t90', 'v10-56t60']]")
# ---------- VÁHY 45 s, těžší bloky 60 s; po limitu se hodnotí rozpracovaná odpověď ----------
V,_,_=bank_get('BANK_VAHY')
for it in V['test']:
    it['time_limit_ms']=60000 if (it.get('time_limit_ms') or 0)>=75000 else 45000
bank_put('BANK_VAHY',V)
rep("version:'v2-39-ui3-bl3',","version:'v2-39-ui3-bl4',")
rep("'v2-39-ui3-bl2', 'v2-39-ui3-bl3']]","'v2-39-ui3-bl2', 'v2-39-ui3-bl3', 'v2-39-ui3-bl4']]")
rep("""  const it = S.item, ans = countOf(S.placed);
  logRow({ reseni:fmt(it.ans), odpoved:S.placed.length ? fmt(ans) : '', spravne:0, time_limit_ms:""","""  const it = S.item, ans = countOf(S.placed), okT = S.placed.length > 0 && sameCount(ans, it.ans);   // po limitu se hodnotí rozpracovaná odpověď
  logRow({ reseni:fmt(it.ans), odpoved:S.placed.length ? fmt(ans) : '', spravne:okT ? 1 : 0, time_limit_ms:""")
rep("""    timeout:1, spravne_v_limitu:0, id:it.id || '', faze_banky:it.faze || '',""","""    timeout:1, spravne_v_limitu:okT ? 1 : 0, id:it.id || '', faze_banky:it.faze || '',""")
k=s.index('function timeUp(){'); k2=s.index('return afterTestItem(false);',k)
s=s[:k2]+'return afterTestItem(okT);'+s[k2+len('return afterTestItem(false);'):]
# ---------- DEDUKCE 75 s; po limitu se hodnotí označená volba ----------
D,_,_=bank_get('BANK_DED')
for it in D['items']: it['cap']=75
bank_put('BANK_DED',D)
rep("const ok = !timeout && U.choice === it.answer, rt = Math.round(performance.now() - U.t0);","const ok = U.choice === it.answer, rt = Math.round(performance.now() - U.t0);   // i po limitu platí označená volba")
rep("reseni:it.answer, odpoved:timeout ? '' : (U.choice || ''),","reseni:it.answer, odpoved:U.choice || '',")
rep("version:'DED-24-v2.3',","version:'DED-24-v2.4',")
rep("'DED-24-v2.2', 'DED-24-v2.3']","'DED-24-v2.2', 'DED-24-v2.3', 'DED-24-v2.4']")
# ---------- PAPÍR 75 s; GV obecně: po limitu se hodnotí rozpracovaná odpověď ----------
rep("const ok = !ST.timedOut && cfg.correct(it, ST.resp);","const ok = cfg.correct(it, ST.resp);   // i po limitu se hodnotí to, co je označené")
m=re.search(r"capFor:\(it\) => \(it\.level \|\| 1\) <= 5 \? 45 : it\.level === 10 \? 120 : it\.level === 6 \|\| it\.level === 9 \? 90 : 60,",s)
s=s.replace(m.group(0),"capFor:() => 75, /* jednotně 75 s */")
# ---------- PICK (Skládání, Rotace): po limitu platí označené díly ----------
rep("ok = (hits === need && ST.sel.length === need && !ST.timedOut) ? 1 : 0;","ok = (hits === need && ST.sel.length === need) ? 1 : 0;   // i po limitu platí označené díly")
# ---------- ŠKOLNÍ TESTY: po limitu platí zadaná odpověď ----------
rep("ok = !S.scTimedOut && oi === cfg.answer(it);","ok = oi === cfg.answer(it);")
rep("ok = !S.scTimedOut && !vals.some(x => !x) && cfg.score(it, vals);","ok = !vals.some(x => !x) && cfg.score(it, vals);")
# ---------- PRAVIDLA 60 s (bank limits nastaví patch3) ----------
# ---------- STANOVIŠTĚ: po limitu platí umístěný cíl ----------
rep("const ok = !timeout && U.place[it.target] === it.answer;","const ok = U.place[it.target] === it.answer;   // i po limitu platí umístěný cíl")
open(p,'w',encoding='utf8').write(s); print('patch2 ok',p)
