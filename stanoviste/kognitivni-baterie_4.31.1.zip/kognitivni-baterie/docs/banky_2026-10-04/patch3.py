import sys,re,json
sys.path.insert(0,'/home/claude/v3/cz/kognitivni-baterie/docs/papir_v6')
from paper import answer as pap_answer
p=sys.argv[1]; s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    if c!=n: raise SystemExit('FAIL(%d) %s'%(c,a[:100]))
    s=s.replace(a,b)
def bank_get(n):
    i=s.index('const '+n+' = ')+len('const '+n+' = '); v,e=json.JSONDecoder().raw_decode(s[i:]); return v,i,i+e
def bank_put(n,v):
    global s
    _,i,j=bank_get(n); s=s[:i]+json.dumps(v,ensure_ascii=False,separators=(',',':'))+s[j:]
# ===== Stanoviště v7.1: jeden klik = pozice cíle =====
cur,_,_=bank_get('BANK_STAN'); N=json.load(open('/home/claude/v3/st/stanoviste_v7_1_bank.json'))
NB={'verze':'ST-v7.1-35','caps':{str(k):75 for k in range(1,9)},'practice':cur['practice'],'items':N['items'],'scoring':N['scoring']}
bank_put('BANK_STAN',NB)
i=s.index('function mod_stanoviste'); j=s.index('\nfunction ',i+20); g=s[i:j]
def rg(a,b):
    global g
    c=g.count(a)
    if c!=1: raise SystemExit('FAIL-ST(%d) %s'%(c,a[:100]))
    g=g.replace(a,b)
rg("""    const order = [it.target].concat(it.free.filter(t => t !== it.target));
    const tray = order.filter(t => U.place[t] === undefined);
    $('#' + K + '-tray').innerHTML = tray.length ? tray.map(t => `<button type="button" class="st-tok${U.sel === t ? ' sel' : ''}${t === it.target ? ' tgt' : ''}" data-t="${t}" aria-pressed="${U.sel === t}" aria-label="${TX.nom[t]}${t === it.target ? ' – ' + TX.targetWord : ''}"${U.done ? ' disabled' : ''}>${tokIcon(t, t === it.target ? 56 : 40, t === it.target)}</button>`).join('')
      : `<span class="st-tray-empty">${TX.trayEmpty}</span>`;
    root.querySelectorAll('.st-tok').forEach(b => b.addEventListener('click', () => { if (U.done) return; const t = b.dataset.t; U.sel = U.sel === t ? null : t; act('vyber', t); draw(); }));""",
"""    /* od ST-v7.1: odpovídá se jen polohou cíle (jeden klik na stanoviště); ostatní volné objekty jsou součástí úlohy,
       ale nepřesouvají se – ukazují se jako neaktivní. */
    const others = it.free.filter(t => t !== it.target);
    $('#' + K + '-tray').innerHTML = (U.place[it.target] === undefined ? `<button type="button" class="st-tok sel tgt" data-t="${it.target}" aria-pressed="true" aria-label="${TX.nom[it.target]} – ${TX.targetWord}"${U.done ? ' disabled' : ''}>${tokIcon(it.target, 56, true)}</button>` : '') +
      others.map(t => `<span class="st-tok latent" aria-label="${TX.nom[t]}">${tokIcon(t, 40, false)}</span>`).join('');""")
rg("""    $('#' + K + '-hint').innerHTML = U.done ? '' : fillTxt(U.sel ? T(TX.hintPlace).replace('{X}', '{' + U.sel + '}') : T(TX.hintPick));""",
   """    $('#' + K + '-hint').innerHTML = U.done ? '' : fillTxt(T(TX.hintPlace).replace('{X}', '{' + it.target + '}'));""")
a=g.index("  function station(v){"); b=g.index("    draw();\n  }\n",a)+len("    draw();\n  }\n")
g=g[:a]+"""  function station(v){
    if (U.done) return;
    const o = occ(v);
    if (o && o !== it.target) return;                                   // obsazeno pevným objektem
    if (o === it.target) { delete U.place[it.target]; act('zpet', it.target, v); }   // druhé klepnutí = zrušit
    else { U.place = {}; U.place[it.target] = v; act('poloz', it.target, v); U.moves++; }
    U.sel = null; draw();
  }
"""+g[b:]
s=s[:i]+g+s[j:]
k=s.index('</style>'); s=s[:k]+"\n#m-stanoviste .st-tok.latent{opacity:.5;cursor:default;pointer-events:none}\n"+s[k:]
# ===== Hledání pravidla v1.4, limit 60 s =====
P=json.load(open('/mnt/user-data/uploads/pravidla_HP-36-v1_4_bank.json'))
cur,_,_=bank_get('BANK_PRAVIDLA')
NP={'practice':P['practice'],'items':P['items'],'limits':{str(k):60 for k in range(1,6)}}
bank_put('BANK_PRAVIDLA',NP)
rep("VERSION = 'HP-36-v1.2'","VERSION = 'HP-36-v1.4'")
rep("  pravidla:[['HP-36-v1.0', 'HP-36-v1.1', 'HP-36-v1.2']],","  pravidla:[['HP-36-v1.0', 'HP-36-v1.1', 'HP-36-v1.2'], ['HP-36-v1.4']],")
# ===== Skládání papíru v13 (36 položek bez 4, které potřebují nové kreslení okrajových výstřihů) =====
G,_,_=bank_get('BANK_GV')
Q=json.load(open('/mnt/user-data/uploads/papir_v13_final40.json'))
keep=[]
for x in Q:
    if x.get('renderer_compatibility')=='requires_v12_edge_corner': continue
    y={k:x[k] for k in ('id','level','n','folds','holes','shapes','facety','poradi_v1','obtiznost_odhad') if k in x}
    y['answer']=pap_answer(x['n'],x['folds'],x['holes'])
    y['poradi_v13']=x.get('final_order_v13_40'); y['markerType']=x.get('markerType')
    keep.append(y)
G['papir']=keep; bank_put('BANK_GV',G)
rep("version:'Gv-PAP-v8',","version:'Gv-PAP-v13',")
rep("['Gv-PAP-v7'], ['Gv-PAP-v8']]","['Gv-PAP-v7'], ['Gv-PAP-v8'], ['Gv-PAP-v13']]")
open(p,'w',encoding='utf8').write(s); print('patch3 ok',p,'papír',len(keep),'stanoviště',len(N['items']),'pravidla',len(P['items']))
