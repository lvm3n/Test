Stanoviste v7.1 (v7 + 5 polozek)

Puvodnich 30 polozek V7 nebylo obsahove zmeneno. Kontrola JSON: 30/30 puvodnich item objektu je presne shodnych.

Pridane polozky:
- S53 - uroven 2, vlozena po S02, candidate curve 3->2->1
- S54 - uroven 4, vlozena po S19, candidate curve 4->3->2->1
- S55 - uroven 5, vlozena po S38, candidate curve 4->4->4->3->1
- S56 - uroven 7, vlozena po S46, candidate curve 5->5->5->5->1
- S57 - uroven 8, vlozena po S52, candidate curve 5->5->5->5->1

Vsechny nove polozky:
- maji jednu cilovou odpoved / jeden klik;
- maji jednoznacnou cilovou pozici;
- kazde pravidlo je nutne k jednoznacnemu urceni cile;
- kazda chybna cilova pozice ma alespon jednu konfiguraci porusujici pouze jedno pravidlo;
- pouzivaji novou topologii neizomorfni s dosavadnimi v7 topologiemi;
- zachovavaji pilotni cap 75 s.
