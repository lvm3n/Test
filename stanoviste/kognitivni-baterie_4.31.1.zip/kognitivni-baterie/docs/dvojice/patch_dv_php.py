import sys
d = sys.argv[1]
def rep(path, old, new, count=1):
    s = open(path, encoding='utf-8').read(); n = s.count(old); assert n == count, (path, old[:60], n); open(path, 'w', encoding='utf-8').write(s.replace(old, new))
rep(d + '/includes/admin.php', "'prohozene' => 'Prohozené barvy'", "'prohozene' => 'Prohozené barvy', 'dvojice' => 'Dvojice'")
if 'kognitivni' in d:
    rep(d + '/includes/rest.php', "'rady', 'prohozene'", "'rady', 'prohozene', 'dvojice'")
else:
    rep(d + '/includes/admin.php', "'symboly', 'rady', 'prohozene');", "'symboly', 'rady', 'prohozene', 'dvojice');")
print('ok', d)
