import sys, json
PATH, LANG = sys.argv[1], sys.argv[2]; CZ = LANG == 'cz'
s = open(PATH, encoding='utf-8').read()
def rep(old, new, count=1):
    global s
    n = s.count(old); assert n == count, (old[:90], n); s = s.replace(old, new)
BANK = json.load(open('/home/claude/dv/dv_bank.json')); ICONS = json.load(open('/home/claude/dv/dv_icons.json'))
# ---- mod_speed: výběr více možností (cfg.multi), u Dvojic 2 obrázky
rep("""    $('#' + K + '-stage').innerHTML = cfg.render(it, H); $('#' + K + '-stage').style.visibility = '';
    root.querySelectorAll('.sp-opt').forEach(b => b.addEventListener('click', () => { S.inputMode = S.lastPointer || 'touch'; answer(parseInt(b.dataset.i, 10)); }));""",
"""    $('#' + K + '-stage').innerHTML = cfg.render(it, H); $('#' + K + '-stage').style.visibility = '';
    ST.sel = []; ST.busy = false; ST.tFirst = null;
    root.querySelectorAll('.sp-opt').forEach(b => b.addEventListener('click', () => { S.inputMode = S.lastPointer || 'touch';
      const i = parseInt(b.dataset.i, 10);
      if (!cfg.multi) { answer(i); return; }
      if (ST.busy) return;                                     // výběr více možností (cfg.multi): druhé klepnutí na tutéž výběr zruší
      const at = ST.sel.indexOf(i);
      if (at >= 0) { ST.sel.splice(at, 1); b.classList.remove('sel'); b.setAttribute('aria-pressed', 'false'); return; }
      if (ST.tFirst === null) ST.tFirst = Math.round(performance.now() - ST.tItem);
      ST.sel.push(i); b.classList.add('sel'); b.setAttribute('aria-pressed', 'true');
      if (ST.sel.length >= cfg.multi) { ST.busy = true; answer(ST.sel.slice().sort((x, y) => x - y)); }
    }));""")
rep("""    const ok = k === it.correct, rt = Math.round(performance.now() - ST.tItem);""",
    """    const ok = cfg.multi ? (Array.isArray(k) && k.join('+') === it.pair.join('+')) : k === it.correct, rt = Math.round(performance.now() - ST.tItem);""")
rep("""      reseni:String(it.correct + 1), odpoved:String(k + 1), spravne:ok ? 1 : 0, rt_ms:rt, pozice:it.correct + 1,""",
    """      reseni:cfg.multi ? it.correct : String(it.correct + 1), odpoved:cfg.multi ? k.map(x => x + 1).join('+') : String(k + 1), spravne:ok ? 1 : 0, rt_ms:rt, pozice:cfg.multi ? it.correct : it.correct + 1,
      ...(cfg.multi ? {rt_prvni_ms:ST.tFirst, kategorie:it.cat || '', obrazky:(it.tiles || []).join(' ')} : {}),""")
rep("""    fb.innerHTML = ok ? '<span class="mark ok">' + CHECK + '</span> """,
    """    if (cfg.multi && !ok && it.pair) it.pair.forEach(q => { const el = root.querySelector('#' + K + '-stage .sp-opt[data-i="' + q + '"]'); if (el) el.classList.add('hint'); });   // nácvik: ukázat správnou dvojici
    fb.innerHTML = ok ? '<span class="mark ok">' + CHECK + '</span> """)
# ---- nový test
if CZ:
    T = {"name": "Dvojice", "blurb": "Najdi dva obrázky ze stejné skupiny", "pic": "Obrázek",
         "instr": "Uvidíš šest obrázků. Dva z nich patří do stejné skupiny – třeba dvě zvířata nebo dva hudební nástroje. Každý z ostatních obrázků je z jiné skupiny. Klepni na oba obrázky, které k sobě patří (když se spleteš, dalším klepnutím výběr zrušíš). Po druhém obrázku se hned ukáže další úloha. Na celý test máš 2 minuty. Cílem je správně vyřešit co nejvíc úloh. Pracuj svižně.",
         "demoSay": "Uvidíš šest obrázků. Banán a jahoda jsou obojí ovoce, takže patří k sobě. Klepneme na banán a potom na jahodu. Hned potom přijde další úloha.",
         "d1": "Tady je šest obrázků.", "d2": "Banán a jahoda jsou obojí ovoce – patří k sobě.", "d3": "Klepneme na banán…", "d4": "…a na jahodu. Hned potom se ukáže další úloha.",
         "wrongHint": "Hledej dva obrázky ze stejné skupiny – třeba dvě zvířata nebo dva nástroje. Správná dvojice je zeleně.",
         "remedialHint": "Ještě dvě zkusíme spolu. Najdi dva obrázky, které patří do stejné skupiny."}
else:
    T = {"name": "Pairs", "blurb": "Find two pictures from the same group", "pic": "Picture",
         "instr": "You will see six pictures. Two of them belong to the same group – for example two animals or two musical instruments. Each of the other pictures is from a different group. Tap both pictures that belong together (if you make a mistake, tap a picture again to deselect it). After the second picture the next task appears right away. You have 2 minutes for the whole test. The goal is to solve as many tasks correctly as you can. Work quickly.",
         "demoSay": "You will see six pictures. The banana and the strawberry are both fruit, so they belong together. We tap the banana and then the strawberry. The next task appears right away.",
         "d1": "Here are six pictures.", "d2": "The banana and the strawberry are both fruit – they belong together.", "d3": "We tap the banana…", "d4": "…and the strawberry. The next task appears right away.",
         "wrongHint": "Look for two pictures from the same group – for example two animals or two instruments. The correct pair is shown in green.",
         "remedialHint": "Let us try two more together. Find two pictures that belong to the same group."}
MOD = """
/* ---------- Gs: Dvojice (DV-6x2-v2) – šest obrázků ve dvou sloupcích po třech, vybrat dva ze stejné kategorie ----------
   Pevná sada pro všechny: 160 úloh (DV-001 … DV-160) + 8 nácvikových (DV-N001 …). Obrázky: vlastní kresby, 10 kategorií po 6
   (ovoce, zelenina, zvířata, doprava, oblečení, nářadí, hudební nástroje, nábytek, nádobí, sport). Rušivé obrázky jsou
   každý z jiné „rodiny“ než dvojice i než ostatní (ovoce + zelenina = jídlo, nábytek + nádobí = domácnost), takže dvojice je
   jednoznačná. Vzhledově podobné dvojice (míče, vidlička + lžíce) nejsou cílové. Nácvik jen z nejzřetelnějších kategorií. Skór = počet správně za 120 s. */
const DV_ICONS = __ICONS__;
const DV_BANK = __BANK__;
function mod_dvojice(rootEl){
  const T = __T__;
  const tile = (n, i, cls) => `<button type="button" class="sp-opt dv-tile${cls || ''}" data-i="${i}" aria-pressed="false" aria-label="${T.pic} ${i + 1}"><svg viewBox="0 0 100 100" aria-hidden="true">${DV_ICONS[n]}</svg></button>`;
  return mod_speed(rootEl, {
    key:'dvojice', name:T.name, blurb:T.blurb, group:'gs', version:'DV-6x2-v2', kind:'kategorie', multi:2,
    seconds:120, nPrac:4, pracOffset:160, itiMs:100,
    icon:'<svg viewBox="0 0 48 48"><rect x="4" y="4" width="18" height="18" rx="4" fill="none" stroke="currentColor" stroke-width="2"/><rect x="26" y="4" width="18" height="18" rx="4" fill="none" stroke="#2e8b57" stroke-width="3"/><rect x="4" y="26" width="18" height="18" rx="4" fill="none" stroke="#2e8b57" stroke-width="3"/><rect x="26" y="26" width="18" height="18" rx="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="35" cy="13" r="5" fill="#E43D3D"/><circle cx="13" cy="35" r="5" fill="#F6D03A"/></svg>',
    instr:T.instr, demoSay:T.demoSay, wrongHint:T.wrongHint, remedialHint:T.remedialHint,
    nOpts:() => 6,
    build(){ return {stream:DV_BANK.test.concat(DV_BANK.nacvik), label:'DV 6 obrázků, pevná sada'}; },
    render(it){ return `<div class="dv-grid">${it.tiles.map((n, i) => tile(n, i)).join('')}</div>`; },
    async demo(root, H2, done){
      const st = root.querySelector('#dvojice-demo-stage'), cap = root.querySelector('#dvojice-demo-cap');
      root.querySelector('#dvojice-demo-next').disabled = true; root.querySelector('#dvojice-demo-replay').disabled = true;
      const tiles = ['banan', 'kladivo', 'trumpeta', 'jahoda', 'kolo', 'sova'];
      const draw = (sel) => { st.innerHTML = `<div class="dv-grid dv-demo">` + tiles.map((n, i) => tile(n, i, sel.includes(i) ? ' sel' : '')).join('') + `</div>`; };
      draw([]); cap.textContent = T.d1; await sleep(1800);
      cap.textContent = T.d2; await sleep(2200);
      draw([0]); cap.textContent = T.d3; await sleep(1400);
      draw([0, 3]); cap.textContent = T.d4; await sleep(400);
      done();
    }
  });
}
""".replace('__ICONS__', json.dumps(ICONS, ensure_ascii=False, separators=(',', ':'))).replace('__BANK__', json.dumps(BANK, ensure_ascii=False, separators=(',', ':'))).replace('__T__', json.dumps(T, ensure_ascii=False))
rep("function mod_prohozene(rootEl){", MOD.strip('\n') + "\n\nfunction mod_prohozene(rootEl){")
rep('<div id="m-prohozene"></div>', '<div id="m-prohozene"></div>\n<div id="m-dvojice"></div>')
rep(' mod_prohozene(document.getElementById("m-prohozene")),', ' mod_prohozene(document.getElementById("m-prohozene")),\n mod_dvojice(document.getElementById("m-dvojice")),')
rep(".pb-stack{display:flex;", """.dv-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;width:100%;max-width:min(440px,calc((100vh - 230px) * 2 / 3));max-width:min(440px,calc((100dvh - 230px) * 2 / 3));min-width:240px;margin:0 auto}
.dv-tile{aspect-ratio:1/1;background:#fff;border:2px solid var(--line);border-radius:16px;padding:9%;display:flex;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent}
.dv-tile svg{width:100%;height:100%;display:block}
.dv-tile.sel{border-color:var(--focus);box-shadow:0 0 0 4px var(--focus)}
.dv-tile.hint{border-color:#2e8b57;box-shadow:0 0 0 4px #2e8b57}
.dv-demo .dv-tile{cursor:default}
.pb-stack{display:flex;""")
if not CZ:
    rep("'symboly', 'rady', 'prohozene', 'sr", "'symboly', 'rady', 'prohozene', 'dvojice', 'sr", 2)
open(PATH, 'w', encoding='utf-8').write(s); print('ok', PATH)
