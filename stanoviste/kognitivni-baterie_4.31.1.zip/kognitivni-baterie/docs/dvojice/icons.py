# Piktogramy pro test „Dvojice ze stejné kategorie“ – jednotný styl: viewBox 0 0 100 100, plné barvy, tmavý obrys 3 px.
O = '#2b2b2b'
def g(inner): return f'<g stroke="{O}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">{inner}</g>'
def circ(cx, cy, r, f): return f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{f}"/>'
def ell(cx, cy, rx, ry, f, extra=''): return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{f}" {extra}/>'
def rect(x, y, w, h, f, rx=0, extra=''): return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{f}" {extra}/>'
def path(d, f='none', extra=''): return f'<path d="{d}" fill="{f}" {extra}/>'
def line(x1, y1, x2, y2, w=3, c=O): return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{c}" stroke-width="{w}"/>'
ICONS = {}
CATS = {}
def add(cat, name, cz, inner):
    ICONS[name] = (cat, cz, g(inner)); CATS.setdefault(cat, []).append(name)

# ---------- OVOCE ----------
add('ovoce', 'banan', 'banán',
    path('M20 28 Q20 66 52 80 Q74 88 88 76 Q86 72 80 72 Q56 70 40 52 Q30 40 30 26 Z', '#F6D03A') +
    path('M30 30 Q34 52 52 64', 'none', 'stroke-width="2"') + rect(19, 16, 10, 12, '#7A5230', 2) + circ(88, 75, 2, O))
add('ovoce', 'jahoda', 'jahoda',
    path('M50 90 Q18 70 20 46 Q22 30 50 32 Q78 30 80 46 Q82 70 50 90 Z', '#E43D3D') +
    ''.join(ell(x, y, 2, 3, '#FCE38A', 'stroke-width="1"') for x, y in [(36,46),(50,44),(64,46),(42,58),(58,58),(50,70),(34,62),(66,62)]) +
    path('M30 32 L42 28 L50 14 L58 28 L70 32 L58 38 L50 33 L42 38 Z', '#3DA35D'))
add('ovoce', 'hrozny', 'hrozny',
    path('M50 22 Q50 12 56 6', 'none', 'stroke="#7A5230" stroke-width="4"') + path('M55 12 Q68 4 76 12 Q66 20 55 12 Z', '#3DA35D') +
    ''.join(circ(x, y, 9.5, '#7B4FA6') for x, y in [(30,30),(50,30),(70,30),(40,46),(60,46),(30,62),(70,62),(50,62),(40,78),(60,78),(50,93)][:10]) +
    ''.join(circ(x - 3, y - 3, 2.2, '#B79AD6', ) .replace('stroke', 'x') for x, y in []))
add('ovoce', 'citron', 'citron',
    path('M14 52 Q18 28 50 26 Q82 28 86 52 Q82 76 50 78 Q18 76 14 52 Z', '#F7E04B') + circ(11, 52, 3, '#F7E04B') + circ(89, 52, 3, '#F7E04B') +
    path('M30 42 Q38 36 48 36', 'none', 'stroke="#fff8c4" stroke-width="4"'))
add('ovoce', 'meloun', 'meloun',
    path('M10 34 A40 40 0 0 0 90 34 Z', '#3DA35D') + path('M16 34 A34 34 0 0 0 84 34 Z', '#F4F8E8', 'stroke-width="0"') +
    path('M20 34 A30 30 0 0 0 80 34 Z', '#EF4D5A') +
    ''.join(ell(x, y, 2, 3.5, O, 'stroke-width="0"') for x, y in [(36,44),(50,40),(64,44),(43,54),(57,54),(50,64)]))
add('ovoce', 'ananas', 'ananas',
    path('M50 38 L36 10 L46 26 L50 4 L54 26 L64 10 Z', '#3DA35D') + ell(50, 64, 22, 28, '#F2B233') +
    path('M34 50 L62 82 M42 40 L70 72 M30 66 L46 86 M66 46 L34 82 M58 38 L28 72 M70 62 L54 88', 'none', 'stroke-width="2"'))
# ---------- ZELENINA ----------
add('zelenina', 'mrkev', 'mrkev',
    path('M60 24 L80 44 L28 90 Q20 94 18 86 Z', '#F28C28') + path('M40 52 L48 58 M50 42 L56 48 M32 66 L38 70', 'none', 'stroke-width="2"') +
    path('M68 30 Q66 12 76 6 Q78 20 74 28 Q86 16 94 20 Q88 32 76 36 Z', '#3DA35D'))
add('zelenina', 'kukurice', 'kukuřice',
    ell(50, 44, 18, 34, '#F7D547') + ''.join(f'<circle cx="{x}" cy="{y}" r="3" fill="#E8B92F" stroke="#C99A1E" stroke-width="1"/>' for x in (42,50,58) for y in range(20, 74, 8)) +
    path('M36 48 Q22 76 50 94 Q38 72 44 52 Z', '#57B05A') + path('M64 48 Q78 76 50 94 Q62 72 56 52 Z', '#4A9C4E'))
add('zelenina', 'brokolice', 'brokolice',
    path('M42 56 L58 56 L64 90 L36 90 Z', '#9BD27A') +
    circ(34, 46, 14, '#2E8B57') + circ(66, 46, 14, '#2E8B57') + circ(50, 34, 17, '#2E8B57') + circ(42, 56, 11, '#3A9D66') + circ(58, 56, 11, '#3A9D66'))
add('zelenina', 'paprika', 'paprika',
    path('M26 42 Q24 30 38 30 Q44 26 50 32 Q56 26 62 30 Q76 30 74 42 Q78 72 64 88 Q57 92 50 86 Q43 92 36 88 Q22 72 26 42 Z', '#E23B3B') +
    path('M50 32 Q50 18 60 12', 'none', 'stroke="#3DA35D" stroke-width="6"') + path('M40 32 Q50 24 60 32 Q50 38 40 32 Z', '#3DA35D') +
    path('M36 46 Q34 60 38 72', 'none', 'stroke="#ff8a80" stroke-width="4"'))
add('zelenina', 'hrasek', 'hrášek',
    path('M8 62 Q26 26 92 34 Q76 74 8 62 Z', '#7BC043') + ''.join(circ(x, y, 7, '#A5D96A') for x, y in [(30,50),(46,46),(62,44),(77,42)]) +
    path('M92 34 Q98 26 94 18', 'none', 'stroke-width="3"'))
add('zelenina', 'lilek', 'lilek',
    path('M44 28 Q20 46 24 70 Q30 94 56 88 Q80 82 74 58 Q70 40 58 28 Z', '#6A3D9A') +
    path('M40 30 Q50 18 62 30 Q56 40 50 34 Q44 40 40 30 Z', '#3DA35D') + path('M51 22 L54 8', 'none', 'stroke="#3DA35D" stroke-width="6"') +
    path('M36 56 Q36 70 44 78', 'none', 'stroke="#9b72c4" stroke-width="4"'))
# ---------- ZVÍŘATA ----------
add('zvirata', 'snek', 'šnek',
    path('M10 82 Q12 70 24 70 L82 72 Q92 80 82 84 Z', '#B8D98C') + path('M18 74 Q12 56 20 50 Q28 50 28 72 Z', '#B8D98C') +
    line(20, 52, 14, 38) + line(24, 51, 28, 37) + circ(14, 37, 3, O) + circ(28, 36, 3, O) +
    circ(58, 50, 24, '#D9A066') + path('M58 50 m0 -4 a4 4 0 1 1 -4 4 a10 10 0 0 1 10 -10 a14 14 0 0 1 14 14 a18 18 0 0 1 -18 18', 'none', 'stroke-width="3"'))
add('zvirata', 'beruska', 'beruška',
    circ(50, 58, 30, '#E23B3B') + path('M36 32 A16 16 0 0 1 64 32 Z', O) + circ(50, 30, 13, O) + line(50, 30, 50, 88) +
    ''.join(circ(x, y, 5, O) for x, y in [(36,50),(64,50),(34,70),(66,70),(44,82),(56,82)]) + line(44, 20, 36, 8) + line(56, 20, 64, 8) +
    circ(45, 26, 2.5, '#ffffff') + circ(55, 26, 2.5, '#ffffff'))
add('zvirata', 'motyl', 'motýl',
    ell(30, 36, 20, 18, '#F28C28', 'transform="rotate(-20 30 36)"') + ell(70, 36, 20, 18, '#F28C28', 'transform="rotate(20 70 36)"') +
    ell(33, 68, 14, 13, '#5DADE2', 'transform="rotate(20 33 68)"') + ell(67, 68, 14, 13, '#5DADE2', 'transform="rotate(-20 67 68)"') +
    circ(28, 34, 5, '#FCE38A') + circ(72, 34, 5, '#FCE38A') + ell(50, 52, 5, 26, O) + line(48, 28, 40, 12) + line(52, 28, 60, 12) + circ(40, 12, 2.5, O) + circ(60, 12, 2.5, O))
add('zvirata', 'zelva', 'želva',
    rect(24, 62, 12, 18, '#A3D977', 5) + rect(60, 62, 12, 18, '#A3D977', 5) + path('M14 66 L8 70', 'none') +
    circ(84, 58, 10, '#A3D977') + circ(87, 55, 2, O) + path('M14 66 Q16 28 48 28 Q80 28 82 66 Z', '#4CA64C') +
    path('M30 64 L36 46 L48 40 L60 46 L66 64 M36 46 L26 50 M60 46 L72 50 M48 40 L48 30', 'none', 'stroke-width="2.5"'))
add('zvirata', 'prase', 'prase',
    path('M24 30 L20 10 L40 22 Z', '#F38BA0') + path('M76 30 L80 10 L60 22 Z', '#F38BA0') + circ(50, 54, 32, '#F7A8B8') +
    ell(50, 64, 15, 11, '#F38BA0') + ell(44, 64, 3, 4, O) + ell(56, 64, 3, 4, O) + circ(38, 46, 4, O) + circ(62, 46, 4, O))
add('zvirata', 'sova', 'sova',
    path('M26 28 L22 12 L38 22 Z', '#8A5A2B') + path('M74 28 L78 12 L62 22 Z', '#8A5A2B') + ell(50, 56, 30, 36, '#A0703D') + ell(50, 66, 18, 22, '#D9B48A') +
    circ(38, 42, 11, '#ffffff') + circ(62, 42, 11, '#ffffff') + circ(38, 42, 5, O) + circ(62, 42, 5, O) + path('M46 50 L54 50 L50 58 Z', '#F2A33A') +
    path('M40 64 Q44 68 48 64 M52 72 Q56 76 60 72 M40 78 Q44 82 48 78', 'none', 'stroke-width="2"'))
# ---------- DOPRAVA ----------
add('doprava', 'kolo', 'kolo',
    circ(24, 66, 17, 'none') + circ(76, 66, 17, 'none') + circ(24, 66, 3, O) + circ(76, 66, 3, O) +
    path('M24 66 L48 66 L38 38 Z M38 38 L66 38 L48 66 M66 38 L76 66', 'none', 'stroke="#E23B3B" stroke-width="6"') +
    path('M30 33 L44 33', 'none', 'stroke-width="6"') + path('M66 38 L62 26 L72 24', 'none', 'stroke-width="4"'))
add('doprava', 'vrtulnik', 'vrtulník',
    line(14, 22, 78, 22, 5) + line(46, 22, 46, 34, 4) + rect(62, 46, 30, 8, '#F2B233', 3) + path('M90 40 L90 60', 'none', 'stroke-width="4"') +
    ell(42, 52, 26, 18, '#F2B233') + path('M22 50 Q24 38 38 36 L38 52 Z', '#9FD3F0') + line(24, 80, 62, 80, 4) + line(32, 70, 30, 80) + line(52, 70, 54, 80))
add('doprava', 'nakladak', 'náklaďák',
    rect(6, 28, 56, 40, '#5DADE2', 3) + path('M62 40 L80 40 L92 56 L92 68 L62 68 Z', '#E23B3B') + path('M66 44 L78 44 L86 56 L66 56 Z', '#BFE6FA') +
    circ(24, 72, 10, '#555555') + circ(76, 72, 10, '#555555') + circ(24, 72, 3, '#cccccc') + circ(76, 72, 3, '#cccccc'))
add('doprava', 'kolobezka', 'koloběžka',
    path('M18 80 L70 80', 'none', 'stroke="#2BAE9F" stroke-width="8"') + path('M70 80 L62 18', 'none', 'stroke="#2BAE9F" stroke-width="6"') +
    path('M52 18 L74 16', 'none', 'stroke-width="6"') + circ(18, 82, 9, '#555555') + circ(74, 82, 9, '#555555'))
add('doprava', 'raketa', 'raketa',
    path('M34 60 L18 80 L34 76 Z', '#E23B3B') + path('M66 60 L82 80 L66 76 Z', '#E23B3B') + path('M42 76 L50 96 L58 76 Z', '#F2A33A') +
    path('M50 6 Q68 24 66 56 L66 78 L34 78 L34 56 Q32 24 50 6 Z', '#ECEFF1') + circ(50, 40, 8, '#5DADE2') + path('M38 18 Q50 8 62 18', 'none'))
add('doprava', 'traktor', 'traktor',
    rect(16, 18, 32, 34, '#3DA35D', 3) + rect(22, 24, 20, 16, '#BFE6FA', 2) + rect(46, 38, 40, 24, '#3DA35D', 3) + line(74, 38, 74, 20, 5) +
    circ(32, 68, 22, '#444444') + circ(32, 68, 9, '#F2B233') + circ(78, 74, 12, '#444444') + circ(78, 74, 5, '#F2B233'))
# ---------- OBLEČENÍ ----------
add('obleceni', 'tricko', 'tričko',
    path('M34 16 L20 22 L6 40 L20 50 L28 42 L28 88 L72 88 L72 42 L80 50 L94 40 L80 22 L66 16 Q58 28 50 28 Q42 28 34 16 Z', '#5DADE2'))
add('obleceni', 'kalhoty', 'kalhoty',
    path('M26 10 L74 10 L80 90 L58 90 L50 38 L42 90 L20 90 Z', '#3B5BA5') + line(26, 20, 74, 20) + path('M32 20 Q32 30 40 32 M68 20 Q68 30 60 32', 'none', 'stroke-width="2"'))
add('obleceni', 'saty', 'šaty',
    path('M36 8 L42 8 Q50 18 58 8 L64 8 L64 34 L84 90 L16 90 L36 34 Z', '#D96BA8') + line(36, 36, 64, 36, 4) +
    path('M32 60 Q34 74 30 88 M50 50 L50 88 M68 60 Q66 74 70 88', 'none', 'stroke="#b04c86" stroke-width="2"'))
add('obleceni', 'rukavice', 'rukavice',
    path('M28 74 L28 44 Q28 16 50 16 Q72 16 72 44 L72 74 Z', '#E23B3B') + path('M30 54 Q12 52 12 40 Q14 30 24 34 Q28 36 30 44', '#E23B3B') +
    rect(26, 72, 48, 18, '#F4F4F4', 3) + path('M34 72 L34 90 M42 72 L42 90 M50 72 L50 90 M58 72 L58 90 M66 72 L66 90', 'none', 'stroke-width="2"'))
add('obleceni', 'kravata', 'kravata',
    path('M42 8 L58 8 L55 22 L45 22 Z', '#C0392B') + path('M45 22 L55 22 L66 76 L50 94 L34 76 Z', '#C0392B') +
    path('M40 40 L60 34 M38 54 L62 46 M36 68 L64 58', 'none', 'stroke="#F6D03A" stroke-width="3"'))
add('obleceni', 'sukne', 'sukně',
    rect(28, 16, 44, 10, '#6C3FB0', 2) + path('M28 26 L72 26 L88 82 L12 82 Z', '#8E5BC7') +
    path('M38 26 L30 82 M50 26 L50 82 M62 26 L70 82', 'none', 'stroke-width="2"'))
# ---------- NÁŘADÍ ----------
add('naradi', 'kladivo', 'kladivo',
    rect(44, 30, 12, 62, '#B5651D', 3) + path('M14 14 L70 14 Q84 16 88 30 L70 26 L70 32 L14 32 Z', '#8E9AA6'))
add('naradi', 'sroubovak', 'šroubovák',
    rect(36, 6, 28, 38, '#F2B233', 8) + path('M44 12 L44 38 M50 12 L50 38 M56 12 L56 38', 'none', 'stroke-width="2"') + rect(44, 44, 12, 6, '#8E9AA6') +
    rect(47, 50, 6, 34, '#BFC5CC') + path('M47 84 L50 94 L53 84 Z', '#BFC5CC'))
add('naradi', 'pila', 'pila',
    path('M34 30 L94 48 L94 58 L34 64 Z', '#BFC5CC') + path('M38 64 L42 70 L46 64 L50 70 L54 63 L58 69 L62 62 L66 68 L70 61 L74 67 L78 60 L82 66 L86 59 L90 65 L94 58', 'none', 'stroke-width="2"') +
    path('M8 24 L36 24 L36 70 L8 70 Z', '#B5651D') + rect(16, 34, 12, 26, '#ffffff', 6))
add('naradi', 'klic', 'maticový klíč',
    '<g transform="rotate(-40 50 50)">' + rect(44, 34, 12, 50, '#8E9AA6', 3) +
    path('M30 28 Q28 8 43 6 L43 20 L57 20 L57 6 Q72 8 70 28 Q66 40 50 40 Q34 40 30 28 Z', '#8E9AA6') +
    circ(50, 88, 10, '#8E9AA6') + circ(50, 88, 4, '#ffffff') + '</g>')
add('naradi', 'kleste', 'kleště',
    path('M44 50 Q34 70 30 92', 'none', 'stroke="#E23B3B" stroke-width="9"') + path('M56 50 Q66 70 70 92', 'none', 'stroke="#E23B3B" stroke-width="9"') +
    path('M42 52 L38 14 Q44 6 50 18 L50 52 Z', '#8E9AA6') + path('M58 52 L62 14 Q56 6 50 18 L50 52 Z', '#8E9AA6') + circ(50, 50, 6, '#5f6b7a'))
add('naradi', 'hrabe', 'hrábě',
    line(50, 6, 50, 66, 6) + line(50, 6, 50, 66, 2) + rect(18, 64, 64, 8, '#8E9AA6', 2) +
    ''.join(line(x, 72, x, 92, 4) for x in range(22, 82, 9)))
# ---------- HUDBA ----------
add('hudba', 'kytara', 'kytara',
    rect(46, 4, 8, 40, '#7A5230', 2) + rect(42, 2, 16, 10, '#5A3A1F', 3) + circ(50, 70, 24, '#D98C3A') + circ(50, 46, 17, '#D98C3A') +
    path('M33 52 Q50 60 67 52', 'none', 'stroke="#D98C3A" stroke-width="6"') + circ(50, 62, 7, O) + rect(42, 80, 16, 4, '#5A3A1F') +
    path('M48 10 L48 82 M52 10 L52 82', 'none', 'stroke="#EDEDED" stroke-width="1"'))
add('hudba', 'trumpeta', 'trumpeta',
    path('M26 50 L66 50 M26 62 L58 62 Q64 62 64 56', 'none', 'stroke="#E0A526" stroke-width="7"') + path('M66 40 L92 26 L92 74 L66 60 Z', '#F2C14E') +
    rect(32, 34, 6, 14, '#E0A526', 1) + rect(42, 34, 6, 14, '#E0A526', 1) + rect(52, 34, 6, 14, '#E0A526', 1) + rect(10, 46, 14, 8, '#E0A526', 2))
add('hudba', 'housle', 'housle',
    path('M84 14 L18 80', 'none', 'stroke="#555" stroke-width="2"') +
    path('M50 30 Q32 30 33 44 Q38 52 33 58 Q30 82 50 84 Q70 82 67 58 Q62 52 67 44 Q68 30 50 30 Z', '#B5651D') +
    rect(47, 6, 6, 26, O) + circ(50, 6, 4, O) + path('M42 52 Q40 58 42 64 M58 52 Q60 58 58 64', 'none', 'stroke-width="2"') + rect(43, 72, 14, 4, O))
add('hudba', 'klavesy', 'klávesy',
    rect(6, 28, 88, 46, '#ffffff', 3) +
    ''.join(line(6 + 88 / 7 * i, 28, 6 + 88 / 7 * i, 74, 2) for i in range(1, 7)) +
    ''.join(rect(6 + 88 / 7 * i - 4, 28, 8, 26, O) for i in (1, 2, 4, 5, 6)))
add('hudba', 'xylofon', 'xylofon',
    ''.join(rect(10 + i * 16, 20 + i * 6, 12, 64 - i * 12, c, 2) for i, c in enumerate(['#E23B3B', '#F28C28', '#F6D03A', '#3DA35D', '#5DADE2'])) +
    line(60, 92, 86, 66, 4) + circ(86, 64, 6, '#E8E8E8'))
add('hudba', 'fletna', 'flétna',
    '<g transform="rotate(35 50 50)">' + path('M44 8 L56 8 L58 92 L42 92 Z', '#F0D9B5') + path('M44 8 L56 8 L55 18 L45 18 Z', '#D9BC8C') +
    ''.join(circ(50, y, 3, O) for y in (32, 44, 56, 68, 80)) + '</g>')
# ---------- NÁBYTEK ----------
add('nabytek', 'stul', 'stůl',
    rect(8, 34, 84, 12, '#B5651D', 2) + rect(14, 46, 9, 44, '#9A5418') + rect(77, 46, 9, 44, '#9A5418'))
add('nabytek', 'postel', 'postel',
    rect(10, 26, 12, 62, '#9A5418', 3) + rect(22, 54, 70, 18, '#B5651D', 2) + path('M40 52 L92 52 L92 64 L40 64 Z', '#5DADE2') +
    ell(32, 48, 10, 6, '#ffffff') + rect(84, 66, 8, 22, '#9A5418'))
add('nabytek', 'skrin', 'skříň',
    rect(22, 6, 56, 82, '#B5651D', 3) + line(50, 6, 50, 88) + circ(44, 48, 3, '#F2C14E') + circ(56, 48, 3, '#F2C14E') + rect(26, 88, 8, 6, '#7A3E10') + rect(66, 88, 8, 6, '#7A3E10'))
add('nabytek', 'gauc', 'gauč',
    rect(16, 30, 68, 30, '#E8665A', 8) + rect(18, 54, 64, 18, '#E8665A', 4) + rect(6, 44, 16, 32, '#D9534F', 7) + rect(78, 44, 16, 32, '#D9534F', 7) +
    line(50, 56, 50, 72, 2) + rect(12, 76, 6, 10, O) + rect(82, 76, 6, 10, O))
add('nabytek', 'knihovna', 'knihovna',
    rect(14, 8, 72, 84, '#B5651D', 3) + line(14, 36, 86, 36) + line(14, 64, 86, 64) +
    ''.join(rect(x, 14, 7, 22, c, 1) for x, c in [(20,'#E23B3B'),(28,'#5DADE2'),(36,'#F6D03A'),(46,'#3DA35D')]) +
    ''.join(rect(x, 42, 7, 22, c, 1) for x, c in [(54,'#8E5BC7'),(62,'#F28C28'),(70,'#5DADE2')]) + ''.join(rect(x, 70, 7, 22, c, 1) for x, c in [(22,'#3DA35D'),(30,'#E23B3B')]))
add('nabytek', 'stolicka', 'stolička',
    ell(50, 30, 30, 10, '#D98C3A') + path('M30 36 L22 90 M70 36 L78 90 M50 40 L50 90', 'none', 'stroke="#9A5418" stroke-width="7"') + line(30, 66, 70, 66, 4))
# ---------- NÁDOBÍ ----------
add('nadobi', 'hrnec', 'hrnec',
    rect(20, 42, 60, 44, '#9AA5B1', 6) + rect(6, 48, 14, 8, '#5f6b7a', 3) + rect(80, 48, 14, 8, '#5f6b7a', 3) + ell(50, 40, 34, 8, '#BFC5CC') + rect(44, 26, 12, 8, O, 3))
add('nadobi', 'panev', 'pánev',
    circ(40, 54, 30, '#4a4f55') + circ(40, 54, 22, '#6b7178') + rect(68, 50, 28, 9, '#B5651D', 4))
add('nadobi', 'vidlicka', 'vidlička',
    path('M38 8 L38 30 Q38 42 50 42 Q62 42 62 30 L62 8', '#BFC5CC') + path('M46 8 L46 30 M54 8 L54 30', 'none') + rect(46, 42, 8, 50, '#BFC5CC', 4))
add('nadobi', 'lzice', 'lžíce',
    ell(50, 26, 14, 20, '#BFC5CC') + rect(46, 44, 8, 50, '#BFC5CC', 4))
add('nadobi', 'konvice', 'konvice',
    path('M28 58 L10 38 L16 36 L32 50', '#E8665A') + path('M72 46 Q92 46 88 62 Q84 74 70 72', 'none', 'stroke-width="6"') +
    ell(50, 60, 28, 24, '#E8665A') + path('M34 40 Q50 28 66 40 Z', '#D9534F') + circ(50, 30, 5, '#D9534F'))
add('nadobi', 'struhadlo', 'struhadlo',
    path('M38 28 Q36 8 50 8 Q64 8 62 28', 'none', 'stroke-width="6"') + path('M30 26 L70 26 L82 90 L18 90 Z', '#BFC5CC') +
    ''.join(f'<path d="M{x-3} {y} q3 -4 6 0" fill="none" stroke="{O}" stroke-width="2"/>' for y in (40, 52, 64, 76) for x in range(34 - (y - 40) // 6, 70 + (y - 40) // 6, 9)))
# ---------- SPORT ----------
add('sport', 'fotbal', 'fotbalový míč',
    circ(50, 50, 38, '#ffffff') + path('M50 36 L63 45 L58 61 L42 61 L37 45 Z', O) +
    path('M50 36 L50 14 M63 45 L84 38 M58 61 L70 80 M42 61 L30 80 M37 45 L16 38', 'none') +
    path('M38 16 L50 12 L62 16 Z M82 30 L88 44 L84 52 Z M74 78 L62 86 L68 74 Z M26 78 L38 86 L32 74 Z M12 52 L16 30 L18 44 Z', O))
add('sport', 'basketbal', 'basketbalový míč',
    circ(50, 50, 38, '#F28C28') + line(12, 50, 88, 50) + line(50, 12, 50, 88) + path('M24 22 Q40 50 24 78 M76 22 Q60 50 76 78', 'none'))
add('sport', 'tenis', 'tenisová raketa',
    '<g transform="rotate(-35 50 50)">' + rect(46, 62, 8, 34, '#5f6b7a', 3) + ell(50, 34, 24, 30, '#ffffff', 'stroke-width="5" stroke="#E23B3B"') +
    ''.join(line(x, 8, x, 60, 1) for x in (38, 44, 50, 56, 62)) + ''.join(line(28, y, 72, y, 1) for y in (18, 26, 34, 42, 50)) + '</g>' + circ(82, 80, 9, '#D7E84A'))
add('sport', 'hokejka', 'hokejka',
    path('M34 6 L60 78 L88 80 L88 90 L54 90 Z', '#F2B233') + line(42, 26, 48, 24, 3) + ell(26, 84, 14, 5, O))
add('sport', 'cinka', 'činka',
    line(10, 50, 90, 50, 6) + rect(16, 26, 12, 48, '#4a4f55', 3) + rect(72, 26, 12, 48, '#4a4f55', 3) + rect(6, 34, 10, 32, '#4a4f55', 3) + rect(84, 34, 10, 32, '#4a4f55', 3))
add('sport', 'pinpong', 'pálka na stolní tenis',
    '<g transform="rotate(30 50 50)">' + rect(44, 64, 12, 30, '#B5651D', 4) + circ(50, 38, 28, '#E23B3B') + '</g>' + circ(82, 18, 7, '#ffffff'))

FAMILY = {'ovoce': 'jidlo', 'zelenina': 'jidlo', 'nabytek': 'domacnost', 'nadobi': 'domacnost'}
CAT_CZ = {'ovoce': 'Ovoce', 'zelenina': 'Zelenina', 'zvirata': 'Zvířata', 'doprava': 'Dopravní prostředky', 'obleceni': 'Oblečení',
          'naradi': 'Nářadí', 'hudba': 'Hudební nástroje', 'nabytek': 'Nábytek', 'nadobi': 'Nádobí', 'sport': 'Sport'}
def svg(name, size=None):
    cat, cz, inner = ICONS[name]
    wh = f' width="{size}" height="{size}"' if size else ''
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"{wh}><title>{cz}</title>{inner}</svg>'
