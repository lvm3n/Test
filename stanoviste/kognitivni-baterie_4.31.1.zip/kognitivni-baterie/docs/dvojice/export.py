import sys, os, csv, random, zipfile
sys.path.insert(0,'/home/claude/ico')
from icons import *
out='/home/claude/ico/piktogramy_kategorie'; os.makedirs(out, exist_ok=True)
FAM_CZ={'jidlo':'Jídlo','domacnost':'Domácnost'}
rows=[]
for i,(cat,names) in enumerate(CATS.items(),1):
    os.makedirs(f'{out}/{i:02d}_{cat}', exist_ok=True)
    for j,n in enumerate(names,1):
        fn=f'{i:02d}_{cat}/{j:02d}_{n}.svg'; open(f'{out}/{fn}','w',encoding='utf-8').write(svg(n))
        rows.append([f'{cat}_{j}', CAT_CZ[cat], FAM_CZ.get(FAMILY.get(cat,''), CAT_CZ[cat]), ICONS[n][1], fn])
with open(f'{out}/manifest.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f); w.writerow(['id','kategorie','rodina','nazev','soubor']); w.writerows(rows)
SIMILAR=[('fotbal','basketbal'),('vidlicka','lzice')]
open(f'{out}/README.txt','w',encoding='utf-8').write('''Piktogramy pro test „Dvojice ze stejné kategorie“ (Gs) – vlastní kresba, bez licencí třetích stran.
60 obrázků: 10 kategorií po 6. Jednotný styl: viewBox 0 0 100 100, plné barvy, tmavý obrys 3 px.

Kategorie: Ovoce, Zelenina, Zvířata, Dopravní prostředky, Oblečení, Nářadí, Hudební nástroje, Nábytek, Nádobí, Sport.
Rodiny (sloupec „rodina“): Ovoce + Zelenina = Jídlo, Nábytek + Nádobí = Domácnost, ostatní samy za sebe.

Pravidla pro sestavení úloh:
- V úloze je právě jedna dvojice ze stejné kategorie; každý rušivý obrázek je z JINÉ RODINY než dvojice i než ostatní rušivé
  (jinak by šlo za dvojici považovat třeba banán + mrkev jako jídlo).
- Jako cílovou dvojici nepoužívat vzhledově podobné obrázky (šlo by je spárovat podle vzhledu, ne podle kategorie):
  fotbalový + basketbalový míč, vidlička + lžíce.
- Vzhledově podobné obrázky z různých kategorií (pánev × pálka na stolní tenis) jsou v pořádku jako rušivé.
- Obrázky se nepřekrývají s Pořadím obrázků (žádné jablko, hruška, třešně, pes, kočka, ryba, auto, vlak, letadlo, loď,
  autobus, slunce, mrak, strom, květina, čepice, ponožka, bota, židle, dort, hrnek, buben…).
''')
random.seed(7)
fams=lambda c: FAMILY.get(c,c)
def trial(k=6):
    cats=list(CATS); a=random.choice(cats)
    while True:
        p=random.sample(CATS[a],2)
        if tuple(sorted(p)) not in [tuple(sorted(x)) for x in SIMILAR]: break
    others=[c for c in cats if fams(c)!=fams(a)]; random.shuffle(others); used=set(); ds=[]
    for c in others:
        if fams(c) in used: continue
        used.add(fams(c)); ds.append(random.choice(CATS[c]))
        if len(ds)==k-2: break
    tiles=p+ds; random.shuffle(tiles); return a,p,tiles
tri=[trial() for _ in range(3)]
CSS=open('/home/claude/ico/style.css').read()
h=f'<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Piktogramy – Dvojice ze stejné kategorie</title><style>{CSS}</style></head><body><main>'
h+='<h1>Piktogramy pro „Dvojice ze stejné kategorie“</h1><p class="note">60 vlastních obrázků, 10 kategorií po 6, jednotný styl. Ovoce a zelenina tvoří rodinu „jídlo“, nábytek a nádobí rodinu „domácnost“ – v jedné úloze se z jedné rodiny nikdy nesejdou dva rušivé obrázky.</p>'
for cat,names in CATS.items():
    fam=FAMILY.get(cat)
    h+=f'<h2>{CAT_CZ[cat]}' + (f' <span class="fam">· rodina {FAM_CZ[fam].lower()}</span>' if fam else '') + '</h2><div class="grid">'
    h+=''.join(f'<div class="ic">{svg(n)}{ICONS[n][1]}</div>' for n in names)+'</div>'
h+='<h2>Jak by vypadaly úlohy</h2><p class="note">Najdi dva obrázky ze stejné kategorie. Zeleně je vyznačená správná dvojice.</p>'
for a,p,tiles in tri:
    h+='<div class="trial">'+''.join(f'<div class="ic{" key" if t in p else ""}">{svg(t)}</div>' for t in tiles)+f'</div><p class="note">Dvojice: {ICONS[p[0]][1]} + {ICONS[p[1]][1]} ({CAT_CZ[a].lower()})</p>'
h+='<h2>Na co dát pozor</h2><p class="note">Jako cílovou dvojici nepoužívat vzhledově podobné obrázky (fotbalový a basketbalový míč, vidlička a lžíce) – dala by se spárovat podle vzhledu. Pánev a pálka na stolní tenis si jsou podobné, ale patří do různých kategorií, takže jako rušivé obrázky úlohu zpřísní a jednoznačnost nenaruší.</p></main></body></html>'
open('/mnt/user-data/outputs/piktogramy_nahled.html','w',encoding='utf-8').write(h)
z='/mnt/user-data/outputs/piktogramy_kategorie_60.zip'
if os.path.exists(z): os.remove(z)
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zf:
    for root,_,files in os.walk(out):
        for f in files: zf.write(os.path.join(root,f), os.path.relpath(os.path.join(root,f), os.path.dirname(out)))
print(len(rows))
