import sys, json, random, itertools
sys.path.insert(0, '/home/claude/ico')
from icons import ICONS, CATS, FAMILY
SIMILAR = {tuple(sorted(p)) for p in [('fotbal', 'basketbal'), ('vidlicka', 'lzice')]}
fam = lambda c: FAMILY.get(c, c)
CATL = list(CATS)
POS = list(itertools.combinations(range(6), 2))            # 15 rozmístění dvojice v mřížce 2 × 3
def gen(n, seed, prefix, targets=None):
    r = random.Random(seed)
    use = {k: 0 for k in ICONS}
    pairs = {c: [p for p in itertools.combinations(CATS[c], 2) if tuple(sorted(p)) not in SIMILAR] for c in CATL}
    pair_use = {c: {p: 0 for p in pairs[c]} for c in CATL}
    cats = []
    while len(cats) < n:
        block = list(targets or CATL); r.shuffle(block)
        for c in block:
            if cats and cats[-1] == c: continue
            cats.append(c)
    cats = cats[:n]
    pos_seq = []
    while len(pos_seq) < n:
        b = POS[:]; r.shuffle(b)
        if pos_seq and b[0] == pos_seq[-1]: b = b[1:] + b[:1]
        pos_seq += b
    items, prev = [], set()
    for i, c in enumerate(cats):
        # cílová dvojice: nejméně použitá, bez obrázků z předchozí úlohy
        cand = sorted(pairs[c], key=lambda p: (pair_use[c][p], use[p[0]] + use[p[1]], r.random()))
        p = next((q for q in cand if not (set(q) & prev)), cand[0]); pair_use[c][p] += 1
        others = [x for x in CATL if fam(x) != fam(c)]
        famsel, ds = set(), []
        r.shuffle(others)
        others.sort(key=lambda x: min(use[k] for k in CATS[x]))
        for x in others:
            if fam(x) in famsel: continue
            pool = sorted([k for k in CATS[x] if k not in prev], key=lambda k: (use[k], r.random()))
            if not pool: continue
            famsel.add(fam(x)); ds.append(pool[0])
            if len(ds) == 4: break
        a, b = pos_seq[i]
        tiles = [None] * 6; tiles[a], tiles[b] = p[0], p[1]
        rest = [k for k in range(6) if tiles[k] is None]
        for k, d in zip(rest, ds): tiles[k] = d
        for k in tiles: use[k] += 1
        prev = set(tiles)
        items.append({'id': prefix + str(i + 1).zfill(3), 'cat': c, 'tiles': tiles, 'pair': [a, b], 'correct': f'{a + 1}+{b + 1}', 'lure': c, 'L': ''})
    return items, use
test, use = gen(160, 2026, 'DV-')
prac, _ = gen(8, 77, 'DV-N', ['ovoce', 'zvirata', 'doprava', 'hudba', 'obleceni'])   # nácvik jen z nejzřetelnějších kategorií
# kontroly
for it in test + prac:
    cs = [next(c for c in CATS if t in CATS[c]) for t in it['tiles']]
    fs = [fam(c) for c in cs]
    a, b = it['pair']
    assert cs[a] == cs[b] == it['cat']
    others = [fs[k] for k in range(6) if k not in (a, b)]
    assert len(set(others)) == 4 and fam(it['cat']) not in others, it
    assert len(set(it['tiles'])) == 6
from collections import Counter
print('cat', Counter(i['cat'] for i in test)); print('pos', Counter(tuple(i['pair']) for i in test).most_common(3), len(set(tuple(i['pair']) for i in test)))
print('icon use min/max', min(use.values()), max(use.values()))
print('consecutive overlap', sum(bool(set(test[k]['tiles']) & set(test[k-1]['tiles'])) for k in range(1, len(test))))
json.dump({'verze': 'DV-6x2-v2', 'test': test, 'nacvik': prac}, open('dv_bank.json', 'w'), ensure_ascii=False)
icons = {k: ICONS[k][2] for k in ICONS}
json.dump(icons, open('dv_icons.json', 'w'), ensure_ascii=False)
print(len(json.dumps(icons)) // 1024, 'kB ikon')
