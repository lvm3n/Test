Piktogramy pro test „Dvojice ze stejné kategorie“ (Gs) – vlastní kresba, bez licencí třetích stran.
60 obrázků: 10 kategorií po 6. Jednotný styl: viewBox 0 0 100 100, plné barvy, tmavý obrys 3 px.

Kategorie: Ovoce, Zelenina, Zvířata, Dopravní prostředky, Oblečení, Nářadí, Hudební nástroje, Nábytek, Nádobí, Sport.
Rodiny (sloupec „rodina“): Ovoce + Zelenina = Jídlo, Nábytek + Nádobí = Domácnost, ostatní samy za sebe.

Pravidla pro sestavení úloh:
- V úloze je právě jedna dvojice ze stejné kategorie; každý rušivý obrázek je z JINÉ RODINY než dvojice i než ostatní rušivé
  (jinak by šlo za dvojici považovat třeba banán + mrkev jako jídlo).
- Jako cílovou dvojici nepoužívat vzhledově podobné obrázky (šlo by je spárovat podle vzhledu, ne podle kategorie):
  fotbalový + basketbalový míč, vidlička + lžíce.
- Vzhledově podobné obrázky z různých kategorií (pánev × pálka na stolní tenis) jsou v pořádku jako rušivé.
- Obrázky se nepřekrývají s Pořadím obrázků (žádné jablko, hruška, třešně, pes, kočka, ryba, auto, vlak, letadlo, loď,
  autobus, slunce, mrak, strom, květina, čepice, ponožka, bota, židle, dort, hrnek, buben…).
