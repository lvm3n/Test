<?php
/**
 * Plugin Name: Kognitivní baterie
 * Description: Počítačová testová baterie (administrace, veřejná verze, ukládání výsledků po položkách, rozložení výsledků).
 * Version: 4.31.1
 * Author: (doplnit)
 * Text Domain: kognitivni-baterie
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }

define('KB_VERSION', '4.31.1');
define('KB_DB_VERSION', '1');
define('KB_DIR', plugin_dir_path(__FILE__));
define('KB_URL', plugin_dir_url(__FILE__));

require_once KB_DIR . 'includes/db.php';
require_once KB_DIR . 'includes/rest.php';
require_once KB_DIR . 'includes/teststats.php';   // od 4.30.0: medián doby a reliabilita pro menu
require_once KB_DIR . 'includes/norm-filter.php';   // od 4.27.0: čištění théty pro normy (společné s EN baterií a Přehledem)
require_once KB_DIR . 'includes/irt.php';
require_once KB_DIR . 'includes/admin.php';
require_once KB_DIR . 'includes/backfill.php';

register_activation_hook(__FILE__, 'kb_activate');
function kb_activate() {
    kb_install_tables();                         // tabulky se jen vytvoří / rozšíří, data se nikdy nemažou
    add_option('kb_settings', array(
        'notify_email'   => get_option('admin_email'),
        'notify'         => 'finished',          // none | finished
        'min_n'          => 30,
        'public_enabled' => 1,
    ));
}
function kb_setting($key, $default = '') {
    $s = get_option('kb_settings', array());
    return (isset($s[$key]) && $s[$key] !== '') ? $s[$key] : $default;
}
add_action('plugins_loaded', function () {
    if (get_option('kb_db_version') !== KB_DB_VERSION) { kb_install_tables(); }
    if (get_option('kb_adhd_means') !== '1') { kb_adhd_means_backfill(); }   // jednorázový přepočet průměrů ADHD
});

/**
 * Krátké kódy:
 *   [kognitivni_baterie]            veřejná verze (souhlas, demografie, anonymní identifikátor)
 *   [kognitivni_baterie_admin]      administrátorská verze (jen pro přihlášené s oprávněním)
 */
function kb_app_params($mode, $page = '') {
    return array(
        'mode'    => $mode,
        'api'     => esc_url_raw(rest_url('kb/v1/')),
        'nonce'   => ($mode === 'admin') ? wp_create_nonce('wp_rest') : '',
        'page'    => esc_url_raw($page ? $page : home_url('/?kognitivni-baterie=1')),
        'privacy' => esc_url_raw(kb_setting('privacy_url', function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '')),
        'v'       => KB_VERSION,
    );
}
function kb_iframe($mode, $atts = array()) {
    $atts = shortcode_atts(array('sirka' => 'cela', 'vyska' => '100dvh', 'test' => ''), $atts);
    $params = kb_app_params($mode, get_permalink());
    // jeden test: atribut krátkého kódu [… test="matice"] nebo parametr adresy stránky ?test=matice (od 4.1.0 / EN 1.62.0)
    $qt = $atts['test'] !== '' ? $atts['test'] : (isset($_GET['test']) ? wp_unslash($_GET['test']) : '');
    $qt = substr(preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $qt)), 0, 40);
    if ($qt !== '') { $params['test'] = $qt; }
    $pro = isset($_GET['pro']) ? substr(preg_replace('/[^a-z0-9]/', '', strtolower((string) wp_unslash($_GET['pro']))), 0, 20) : '';   // kód hodnoceného (pohled blízkého, od 4.4.1)
    if ($pro !== '') { $params['pro'] = $pro; }
    $src = add_query_arg($params, KB_URL . 'assets/app.html');
    // „cela“ = přes celou šířku okna bez ohledu na šířku obsahu v šabloně
    $wrap = ($atts['sirka'] === 'cela')
        ? 'width:100vw;max-width:100vw;position:relative;left:50%;right:50%;margin-left:-50vw;margin-right:-50vw;'
        : 'width:100%;max-width:1200px;margin:0 auto;';
    $h = preg_replace('/[^0-9a-z%.]/i', '', $atts['vyska']);
    $fid = 'kbframe' . wp_rand(1000, 9999);
    $full = home_url('/?kognitivni-baterie=' . ($mode === 'admin' ? 'admin' : '1') . '&resume=1') . ($qt !== '' ? '&test=' . $qt : '') . ($pro !== '' ? '&pro=' . $pro : '');
    return '<div class="kb-wrap" style="' . esc_attr($wrap) . '">'
         . '<iframe id="' . esc_attr($fid) . '" src="' . esc_url($src) . '" title="Kognitivní baterie" '
         . 'style="display:block;width:100%;height:' . esc_attr($h) . ';min-height:600px;border:0;background:#F3F5F7" '
         . 'allow="autoplay; fullscreen" loading="eager"></iframe>'
         . '<p style="text-align:center;font-size:14px;margin:6px 0"><a href="' . esc_url($full) . '" target="_top" onclick="var f=document.getElementById(\'' . esc_attr($fid) . '\');var r=f&&(f.requestFullscreen||f.webkitRequestFullscreen);if(r){r.call(f);return false;}">Otevřít na celou obrazovku</a></p></div>';
}
/* samostatná adresa bez šablony webu: /?kognitivni-baterie=1 (veřejná) a /?kognitivni-baterie=admin (jen po přihlášení) */
add_action('template_redirect', function () {
    if (!isset($_GET['kognitivni-baterie'])) { return; }
    if ($_GET['kognitivni-baterie'] === 'nahled') {   // náhled výsledků účastníka pro administrátora (jen čtení, od 2026-10-27)
        if (!current_user_can('edit_posts')) { auth_redirect(); exit; }
        $id = isset($_GET['id']) ? strtolower((string) wp_unslash($_GET['id'])) : '';
        /* od 2026-10-28: ID zkopírované z e-mailu/Redditu (mezery, zalomení řádku, pomlčky – —, velká písmena) se očistí na 32 hex znaků a znovu složí */
        $hex = preg_replace('/[^0-9a-f]/', '', $id);
        if (strlen($hex) === 32) { $id = substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20); }
        if (!kb_valid_uuid($id)) { wp_die('Neplatný identifikátor účastníka: po očištění nemá 32 znaků 0–9 a a–f (zkontrolujte, že je zkopírovaný celý).'); }
        { global $wpdb; if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('participants') . " WHERE anon_id = %s", $id))) { wp_die('Identifikátor ' . esc_html($id) . ' v datech této verze baterie není. Účastník mohl test dělat v jiné verzi (česká / anglická / dětská / gifted) – zkuste náhled tam.'); } }
        $params = kb_app_params('public'); $params['nahled'] = $id;
        wp_redirect(add_query_arg($params, KB_URL . 'assets/app.html')); exit;
    }
    $mode = ($_GET['kognitivni-baterie'] === 'admin') ? 'admin' : 'public';
    if ($mode === 'admin' && !current_user_can('edit_posts')) { auth_redirect(); exit; }
    if ($mode === 'public') { $s = get_option('kb_settings', array()); if (empty($s['public_enabled'])) { wp_die('Test je momentálně nedostupný.'); } }
    $params = kb_app_params($mode);
    if (!empty($_GET['resume'])) { $params['resume'] = '1'; }
    if (!empty($_GET['test'])) { $params['test'] = substr(preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) wp_unslash($_GET['test']))), 0, 40); }
    if (!empty($_GET['pro'])) { $params['pro'] = substr(preg_replace('/[^a-z0-9]/', '', strtolower((string) wp_unslash($_GET['pro']))), 0, 20); }
    wp_redirect(add_query_arg($params, KB_URL . 'assets/app.html'));
    exit;
});
add_shortcode('kognitivni_baterie', function ($atts) {
    $s = get_option('kb_settings', array());
    if (empty($s['public_enabled'])) { return '<p>Test je momentálně nedostupný.</p>'; }
    return kb_iframe('public', (array) $atts);
});
add_shortcode('kognitivni_baterie_admin', function ($atts) {
    if (!current_user_can('edit_posts')) { return '<p>Administrátorská verze je dostupná jen po přihlášení.</p>'; }
    return kb_iframe('admin', (array) $atts);
});
