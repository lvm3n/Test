<?php
if (!defined('ABSPATH')) { exit; }

add_action('rest_api_init', function () {
    $ns = 'kb/v1';
    register_rest_route($ns, '/session', array('methods' => 'POST', 'callback' => 'kb_rest_session', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/rows', array('methods' => 'POST', 'callback' => 'kb_rest_rows', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/score', array('methods' => 'POST', 'callback' => 'kb_rest_score', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/profile', array('methods' => 'POST', 'callback' => 'kb_rest_profile', 'permission_callback' => '__return_true'));   // od 4.27.0: doplnění údajů o zkušenosti s testy
    register_rest_route($ns, '/distribution', array('methods' => 'GET', 'callback' => 'kb_rest_distribution', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/progress', array('methods' => 'GET', 'callback' => 'kb_rest_progress', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/correlations', array('methods' => 'GET', 'callback' => 'kb_rest_correlations', 'permission_callback' => '__return_true'));
});

function kb_now() { return current_time('mysql', true); }
function kb_valid_uuid($s) { return is_string($s) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $s); }
function kb_clean_key($s) { return substr(preg_replace('/[^a-z0-9_\-]/i', '', (string) $s), 0, 40); }
function kb_err($msg, $code = 400) { return new WP_Error('kb_error', $msg, array('status' => $code)); }

/* jednoduché omezení frekvence bez ukládání IP (jen krátkodobý hash v transientu) */
function kb_rate_ok($bucket, $limit, $seconds) {
    $ip  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $key = 'kb_rl_' . $bucket . '_' . substr(hash('sha256', $ip . wp_salt('nonce')), 0, 20);
    $n   = (int) get_transient($key);
    if ($n >= $limit) { return false; }
    set_transient($key, $n + 1, $seconds);
    return true;
}

function kb_session_by_token($sid, $token) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kb_table('sessions') . " WHERE id = %d", $sid));
    if (!$row || !hash_equals($row->token, (string) $token)) { return null; }
    return $row;
}

/* POST /session – založí (nebo najde) účastníka a nové sezení */
function kb_rest_session(WP_REST_Request $r) {
    global $wpdb;
    if (!kb_rate_ok('sess', 30, HOUR_IN_SECONDS)) { return kb_err('Příliš mnoho požadavků.', 429); }
    $p    = $r->get_json_params();
    $mode = (isset($p['mode']) && $p['mode'] === 'admin') ? 'admin' : 'public';
    if ($mode === 'admin' && !current_user_can('edit_posts')) { return kb_err('Nepřihlášený uživatel.', 403); }
    $anon = isset($p['anon_id']) ? $p['anon_id'] : '';
    if (!kb_valid_uuid($anon)) { return kb_err('Neplatný identifikátor.'); }
    if ($mode === 'public' && empty($p['consent']['gdpr'])) { return kb_err('Chybí souhlas se zpracováním údajů.'); }

    $pt  = kb_table('participants');
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM $pt WHERE anon_id = %s", $anon));
    $age = isset($p['age']) ? max(0, min(120, intval($p['age']))) : null;
    $demo = isset($p['demographics']) ? wp_json_encode($p['demographics']) : null;
    $cons = isset($p['consent']) ? wp_json_encode($p['consent']) : null;
    $code = isset($p['code']) ? sanitize_text_field(substr($p['code'], 0, 60)) : '';
    if (!$pid) {
        $wpdb->insert($pt, array('anon_id' => $anon, 'created' => kb_now(), 'mode' => $mode, 'code' => $code,
            'age' => $age, 'demographics' => $demo, 'consent' => $cons));
        $pid = $wpdb->insert_id;
    } else {
        $wpdb->update($pt, array('age' => $age, 'demographics' => $demo, 'consent' => $cons, 'code' => $code), array('id' => $pid));
    }
    $token = wp_generate_password(40, false, false);
    $wpdb->insert(kb_table('sessions'), array(
        'participant_id' => $pid, 'token' => $token, 'started' => kb_now(), 'last_seen' => kb_now(),
        'battery_version' => sanitize_text_field(isset($p['battery_version']) ? $p['battery_version'] : ''),
        'settings' => isset($p['settings']) ? wp_json_encode($p['settings']) : null,
        'device'   => isset($p['device']) ? wp_json_encode($p['device']) : null));
    return array('session_id' => (int) $wpdb->insert_id, 'token' => $token);
}

/* od 4.27.0: POST /profile – doplní k demografii účastníka údaje z dotazníku o zkušenosti s testy (bez nového sezení).
   Jen povolené klíče a krátké hodnoty; ostatní demografie zůstává. */
function kb_profile_keys() { return array('zeme', 'testy_2r', 'priprava', 'vysetreni_rok', 'zk_v', 'zk_cas'); }
function kb_rest_profile(WP_REST_Request $r) {
    global $wpdb;
    if (!kb_rate_ok('prof', 30, HOUR_IN_SECONDS)) { return kb_err('Příliš mnoho požadavků.', 429); }
    $p = $r->get_json_params();
    $s = kb_session_by_token(isset($p['session_id']) ? intval($p['session_id']) : 0, isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kb_err('Neplatné sezení.', 403); }
    $in = isset($p['demographics']) && is_array($p['demographics']) ? $p['demographics'] : array();
    $pt = kb_table('participants');
    $cur = json_decode((string) $wpdb->get_var($wpdb->prepare("SELECT demographics FROM $pt WHERE id = %d", $s->participant_id)), true); if (!is_array($cur)) { $cur = array(); }
    foreach (kb_profile_keys() as $k) { if (array_key_exists($k, $in) && is_scalar($in[$k])) { $cur[$k] = sanitize_text_field(substr((string) $in[$k], 0, 40)); } }
    $wpdb->update($pt, array('demographics' => wp_json_encode($cur)), array('id' => $s->participant_id));
    return array('ok' => 1);
}

/* POST /rows – dávka řádků (každá odpověď s časy v ms) */
function kb_rest_rows(WP_REST_Request $r) {
    global $wpdb;
    if (!kb_rate_ok('rows', 3000, HOUR_IN_SECONDS)) { return kb_err('Příliš mnoho požadavků.', 429); }
    $p = $r->get_json_params();
    $s = kb_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kb_err('Neplatné sezení.', 403); }
    $rows = isset($p['rows']) && is_array($p['rows']) ? array_slice($p['rows'], 0, 500) : array();
    $saved = 0;
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $json = wp_json_encode($row);
        if (strlen($json) > 30000) { continue; }
        $seq = isset($row['_seq']) ? intval($row['_seq']) : 0;
        // INSERT IGNORE: opakované odeslání téže dávky nevytvoří duplicitu
        $ok = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO " . kb_table('rows') . " (session_id, test_key, client_seq, created, data) VALUES (%d, %s, %d, %s, %s)",
            $s->id, kb_clean_key(isset($row['test']) ? $row['test'] : ''), $seq, kb_now(), $json));
        if ($ok) { $saved++; }
    }
    $wpdb->update(kb_table('sessions'), array('last_seen' => kb_now()), array('id' => $s->id));
    return array('saved' => $saved);
}

/* POST /score – výsledek jednoho testu (pro rozložení a e-mail) */
function kb_rest_score(WP_REST_Request $r) {
    global $wpdb;
    $p = $r->get_json_params();
    $s = kb_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kb_err('Neplatné sezení.', 403); }
    $pt  = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kb_table('participants') . " WHERE id = %d", $s->participant_id));
    $key = kb_clean_key(isset($p['test_key']) ? $p['test_key'] : '');
    if ($key === '') { return kb_err('Chybí test.'); }
    $raw = (isset($p['raw_score']) && is_numeric($p['raw_score'])) ? floatval($p['raw_score']) : null;
    $ver = sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : '');
    // pojistka proti duplicitám: aplikace posílá výsledek testu v jednom sezení jen jednou; opakované odeslání se ignoruje
    $rep = (isset($p['score']) && is_array($p['score']) && isset($p['score']['opakovani'])) ? intval($p['score']['opakovani']) : 0;   // opakování testu (retest)
    foreach ($wpdb->get_col($wpdb->prepare("SELECT data FROM " . kb_table('scores') . " WHERE session_id = %d AND test_key = %s AND test_version = %s", $s->id, $key, $ver)) as $dj) {
        $dd = json_decode((string) $dj, true);
        if ((is_array($dd) && isset($dd['opakovani']) ? intval($dd['opakovani']) : 0) === $rep) { return array('ok' => true, 'duplicate' => true); }
    }
    $ins = $wpdb->insert(kb_table('scores'), array(
        'session_id' => $s->id, 'participant_id' => $s->participant_id, 'test_key' => $key,
        'test_version' => sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : ''),
        'raw_score' => $raw, 'valid' => empty($p['valid']) ? 0 : 1, 'age' => $pt ? $pt->age : null,
        'mode' => $pt ? $pt->mode : 'public', 'created' => kb_now(),
        'data' => wp_json_encode(isset($p['score']) ? $p['score'] : null)));
    if ($ins === false) { return kb_err('Výsledek se nepodařilo uložit.', 500); }   // od 2026-11-03: aplikace to zkusí znovu (dřív se ztratil)
    if (function_exists('kb_ner_last') && $raw !== null && !in_array($key, array('gcslovni', 'gcznalosti'), true) && kb_ner_last($s->id, $key, isset($p['score']['administrovano']) && is_numeric($p['score']['administrovano']) ? intval($p['score']['administrovano']) : 0)) {   // od 2026-10-28: test jen otevřený → neplatný, další pokus bude první
        $nid = $wpdb->insert_id; $dd = isset($p['score']) && is_array($p['score']) ? $p['score'] : array();
        $dd['neresil'] = 1; $dd['ner_v'] = 2; $dd['valid_puvodni'] = empty($p['valid']) ? 0 : 1;
        $wpdb->update(kb_table('scores'), array('valid' => 0, 'data' => wp_json_encode($dd)), array('id' => $nid));
    }
    kb_maybe_notify($s, $pt, $key, $raw);
    return array('ok' => true);
}

/* Výběr výsledku osoby pro srovnání a korelace (od 3.85.0): v rámci skupiny verzí platí PRVNÍ výsledek NEJNOVĚJŠÍ verze,
   kterou osoba dělala. Opakování téže verze se nepočítá (člověk úlohy zná); když se ale test mezitím změnil (opravené
   úlohy, nové úrovně, jiné časové limity) a člověk udělal novou verzi, počítá se první výsledek nové verze. */
function kb_ceil_rules() { return array(); }   // (dřívější seznam testů s rozšířeným stropem – už se nepoužívá)
function kb_ceil_pick($rows, $rule = null) {      // řádky seřazené podle id → jeden řádek na osobu
    $pick = array(); $seen = array();
    foreach ($rows as $x) {
        $pid = $x->participant_id; $v = (string) $x->test_version;
        if (!isset($pick[$pid])) { $pick[$pid] = $x; $seen[$pid] = array($v => 1); continue; }
        if (!isset($seen[$pid][$v])) { $seen[$pid][$v] = 1; $pick[$pid] = $x; }   // první výsledek nové verze nahradí starší
    }
    return array_values($pick);
}

/* zaklad=puvodni: srovnání výsledků přepočtených po zkrácení časových limitů – PŮVODNÍ výsledek (před přepočtem) jen mezi
   výsledky, které vznikly za původních podmínek (mají příznak přepočtu). Vrací null, když řádek do tohoto srovnání nepatří. */
function kb_orig_value($data) {
    $d = json_decode((string) $data, true);
    if (!is_array($d) || !(isset($d['prepocet_limity']) || isset($d['prepocet']))) { return null; }
    $pv = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : (isset($d['hruby_puvodni']) ? $d['hruby_puvodni'] : null);
    return is_numeric($pv) ? floatval($pv) : null;
}

/* GET /distribution?test=...&version=...&age_min=&age_max= – jen souhrnné údaje, nikdy data jednotlivců */
function kb_rest_distribution(WP_REST_Request $r) {
    global $wpdb;
    if ($r->get_param('zaklad') === 'theta') { return kb_theta_distribution($r); }   // théta (od 2026-10-27)
    $key = kb_clean_key($r->get_param('test'));
    $ver = sanitize_text_field((string) $r->get_param('version'));
    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));
    $orig = $r->get_param('zaklad') === 'puvodni';      // srovnání za původních časových limitů
    $sql = "SELECT sc.raw_score, sc.test_version, sc.data FROM " . kb_table('scores') . " sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL"
         . " AND sc.id = (SELECT MIN(s2.id) FROM " . kb_table('scores') . " s2 WHERE s2.participant_id = sc.participant_id AND s2.test_key = sc.test_key AND s2.valid >= 1 AND s2.raw_score IS NOT NULL)";   // jedna (první) hodnota na osobu; valid 2 = odvozené hodnoty škál
    $args = array($key);
    if ($ver !== '') {                         // jedna verze nebo skupina srovnatelných verzí oddělená „|“
        $vs = array_values(array_filter(array_map('trim', explode('|', $ver)), 'strlen'));
        $vs = array_slice($vs, 0, 20);
        $in = implode(',', array_fill(0, count($vs), '%s'));
        $sql = str_replace('s2.raw_score IS NOT NULL)', 's2.raw_score IS NOT NULL AND s2.test_version IN (' . $in . '))', $sql);   // první výsledek v rámci skupiny verzí
        foreach ($vs as $v) { $args[] = $v; }
        $sql .= ' AND sc.test_version IN (' . $in . ')';
        foreach ($vs as $v) { $args[] = $v; }
    }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    $vals = array();
    $rule = kb_ceil_rules();
    if (!empty($vs)) {                                      // první výsledek nejnovější verze (viz *_ceil_pick)
        $sql = preg_replace('/ AND sc\.id = \(SELECT MIN\(s2\.id\).*?\)\)/s', '', $sql, 1);
        array_splice($args, 1, count($vs));
        $sql = str_replace('SELECT sc.raw_score,', 'SELECT sc.id, sc.participant_id, sc.raw_score,', $sql) . ' ORDER BY sc.id ASC';
        $res = kb_ceil_pick(kb_scr_filter((array) $wpdb->get_results($wpdb->prepare($sql, $args)), kb_table('scores'), $key));   // od 4.27.0: bez výsledků „nechaný běžet“ (screening)
    } else {
        /* od 4.27.0: screening – první platný výsledek osoby, který screening nevyřadil (pak platí další pokus) */
        $sql = preg_replace('/ AND sc\.id = \(SELECT MIN\(s2\.id\) FROM [^()]*\)/s', '', $sql, 1);
        $sql = str_replace('SELECT sc.raw_score,', 'SELECT sc.id, sc.participant_id, sc.raw_score,', $sql) . ' ORDER BY sc.id ASC';
        $res = array(); foreach (kb_scr_filter((array) $wpdb->get_results($wpdb->prepare($sql, $args)), kb_table('scores'), $key) as $x) { if (!isset($res[$x->participant_id])) { $res[$x->participant_id] = $x; } }
    }
    foreach ($res as $x) {
        $v = floatval($x->raw_score);
        if ($orig) { $ov = kb_orig_value($x->data); if ($ov !== null) { $vals[] = $ov; } continue; }
        // SRCE: hlavní skór je „správně − chybně“; jen verze v08 ukládala jako hlavní skór počet správně → přepočet
        if ($key === 'srce' && $x->test_version === 'SRCE-v08') {
            $d = json_decode((string) $x->data, true);
            if (is_array($d) && isset($d['spravne_minus_chybne']) && is_numeric($d['spravne_minus_chybne'])) { $v = floatval($d['spravne_minus_chybne']); }
            elseif (is_array($d) && isset($d['spravne_administrovane'], $d['chybne'])) { $v = floatval($d['spravne_administrovane']) - floatval($d['chybne']); }
        }
        $vals[] = $v;
    }
    /* od 4.10.31: bez výsledků z anglické verze (kb_en_values se pro normy nepoužívá) */
    $vals = array_merge($vals, kb_parent_values($key, isset($vs) ? $vs : array(), $amin, $amax, $orig));   // + rodiče z dětské verze
    if (!in_array($key, array('matice', 'matice12'), true)) { $vals = array_merge($vals, kb_gifted_values($key, isset($vs) ? $vs : array(), $amin, $amax, $orig)); }   // od 4.10.32: + gifted verze, kromě Matic
    $set  = get_option('kb_settings', array());
    $minn = isset($set['min_n']) ? intval($set['min_n']) : 30;
    $n = count($vals);
    if ($n === 0) { return array('n' => 0, 'min_n' => $minn, 'bins' => array()); }
    // zaokrouhlené hodnoty s četnostmi (dostatečné pro graf, neidentifikují jednotlivce)
    $counts = array();
    foreach ($vals as $v) { $k = (string) round($v, 1); $counts[$k] = isset($counts[$k]) ? $counts[$k] + 1 : 1; }
    ksort($counts, SORT_NUMERIC);
    $bins = array();
    foreach ($counts as $k => $c) { $bins[] = array('x' => floatval($k), 'n' => $c); }
    return array('n' => $n, 'min_n' => $minn, 'bins' => $bins);
}

/* od 4.10.32: výsledky z gifted verze (r/gifted, tabulky wp_kbgf_*) – jazykově nezávislé testy kromě Matic, jedna (první) hodnota na osobu */
function kb_gifted_values($key, $vs, $amin, $amax, $orig = false) {
    global $wpdb;
    if (!in_array($key, array('vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka'), true)) { return array(); }
    $T = $wpdb->prefix . 'kbgf_scores';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $T)) !== $T) { return array(); }
    $args = array($key);
    $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $T sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL AND sc.mode NOT IN ('cz', 'en')";   // od 4.10.37: bez kopií importovaných do gifted z CZ a EN
    if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    $rows = (array) $wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args));
    $rows = kb_scr_filter($rows, $T, $key);   // od 4.27.0: screening
    if ($vs) { $rows = kb_ceil_pick($rows); }
    else { $f = array(); foreach ($rows as $x) { if (!isset($f[$x->participant_id])) { $f[$x->participant_id] = $x; } } $rows = array_values($f); }
    $out = array();
    foreach ($rows as $x) { if ($orig) { $ov = kb_orig_value($x->data); if ($ov !== null) { $out[] = $ov; } } else { $out[] = floatval($x->raw_score); } }
    return $out;
}

/* Výsledky z anglického pluginu (Cognitive Battery EN, tabulky wp_kben_*) pro srovnání na české stránce – jen čtení, živě.
   Jen jazykově nezávislé testy se stejnými verzemi; vynechávají se české výsledky importované do EN (mode = cz), aby se
   nikdo nepočítal dvakrát. Jedna (první) hodnota na osobu. */
function kb_en_values($key, $vs, $amin, $amax, $orig = false) {
    global $wpdb;
    if (!in_array($key, array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka'), true)) { return array(); }
    $T = $wpdb->prefix . 'kben_scores';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $T)) !== $T) { return array(); }
    $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $T sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL AND sc.mode <> 'cz'"
         . " AND sc.id = (SELECT MIN(s2.id) FROM $T s2 WHERE s2.participant_id = sc.participant_id AND s2.test_key = sc.test_key AND s2.valid >= 1 AND s2.raw_score IS NOT NULL)";
    $args = array($key);
    if ($vs) {
        $in = implode(',', array_fill(0, count($vs), '%s'));
        $sql = str_replace('s2.raw_score IS NOT NULL)', 's2.raw_score IS NOT NULL AND s2.test_version IN (' . $in . '))', $sql);
        foreach ($vs as $v) { $args[] = $v; }
        $sql .= ' AND sc.test_version IN (' . $in . ')'; foreach ($vs as $v) { $args[] = $v; }
    }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    if ($vs) {
        $sql = preg_replace('/ AND sc\.id = \(SELECT MIN\(s2\.id\).*?\)\)/s', '', $sql, 1);
        array_splice($args, 1, count($vs));
        $res = kb_ceil_pick($wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args)));
    } else {
        $res = $wpdb->get_results($wpdb->prepare($sql, $args));
    }
    $out = array();
    foreach ($res as $x) { if ($orig) { $ov = kb_orig_value($x->data); if ($ov !== null) { $out[] = $ov; } } else { $out[] = floatval($x->raw_score); } }
    return $out;
}

/* Rodiče z dětské verze (tabulky wp_kbd_*) – dospělí se stejnými verzemi testů; jen výsledky, u kterých je uložený věk 18+
   (podle věku u výsledku, ne podle role v profilu: rodič a dítě můžou sdílet zařízení a tedy i anonymní ID). Jen čtení, živě. */
function kb_kbd_live() { global $wpdb; $t = $wpdb->prefix . 'kbd_scores'; return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t; }
function kb_parent_values($key, $vs, $amin, $amax, $orig = false) {
    global $wpdb;
    if (!in_array($key, array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka'), true) || !kb_kbd_live()) { return array(); }
    $T = $wpdb->prefix . 'kbd_scores'; $args = array($key);
    $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $T sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL AND sc.age >= 18";
    if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    $rows = (array) $wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args));
    $rows = kb_scr_filter($rows, $T, $key);   // od 4.27.0: screening
    if ($vs) { $rows = kb_ceil_pick($rows); }
    else { $f = array(); foreach ($rows as $x) { if (!isset($f[$x->participant_id])) { $f[$x->participant_id] = $x; } } $rows = array_values($f); }
    $out = array();
    foreach ($rows as $x) { if ($orig) { $ov = kb_orig_value($x->data); if ($ov !== null) { $out[] = $ov; } } else { $out[] = floatval($x->raw_score); } }
    return $out;
}

/* GET /progress?anon_id=... – co už účastník dokončil (pro návrat do baterie) */
function kb_rest_progress(WP_REST_Request $r) {
    global $wpdb;
    $anon = $r->get_param('anon_id');
    if (!kb_valid_uuid($anon)) { return kb_err('Neplatný identifikátor.'); }
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('participants') . " WHERE anon_id = %s", $anon));
    if (!$pid) { return array('tests' => array()); }
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT test_key, test_version, raw_score, valid, created, data FROM " . kb_table('scores') . " WHERE participant_id = %d ORDER BY created ASC", $pid));
    $out = array();
    foreach ($rows as $x) {
        if ($x->raw_score === null && (int) $x->valid === 0) { continue; }   // přerušený test – lze zopakovat
        $d = json_decode((string) $x->data, true);
        if ((int) $x->valid === 0 && is_array($d) && !empty($d['neresil'])) { continue; }   // od 2026-10-28: test jen otevřený – jako by nebyl, další pokus je první
        $pok = isset($out[$x->test_key]['pokusy']) ? $out[$x->test_key]['pokusy'] : 0;
        $out[$x->test_key] = array('pokusy' => $x->raw_score === null ? $pok : $pok + 1, 'version' => $x->test_version, 'raw_score' => $x->raw_score === null ? null : floatval($x->raw_score),
                                   'valid' => (int) $x->valid, 'date' => $x->created, 'konec' => is_array($d) && isset($d['konec']) ? (string) $d['konec'] : '');
        if (is_array($d) && !empty($d['opakovani'])) {   // opakování testu → popisek v grafu výsledku
            $out[$x->test_key]['opakovani'] = intval($d['opakovani']);
            if (isset($d['predchozi_skore']) && is_numeric($d['predchozi_skore'])) { $out[$x->test_key]['predchozi'] = floatval($d['predchozi_skore']); }
            if (isset($d['predchozi_verze'])) { $out[$x->test_key]['predchozi_verze'] = (string) $d['predchozi_verze']; }
        }
        if (is_array($d) && (isset($d['hruby_pred_upravou']) || isset($d['hruby_puvodni'])) && (isset($d['prepocet_limity']) || isset($d['prepocet']))) {   // přepočet podle časových limitů
            $pred = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : $d['hruby_puvodni'];
            if (is_numeric($pred) && $x->raw_score !== null && floatval($pred) != floatval($x->raw_score)) { $out[$x->test_key]['raw_pred'] = floatval($pred); }
        }
    }
    /* položkové testy: odpovědi na jednotlivé položky (ID → 0/1) ze všech dokončených běhů – aplikace podle nich
       nabídne doplnit jen nové / opravené položky (převzetí odpovědí) */
    /* historie pokusů (datum, body) a théta spočítaná živě ze všech odpovědí osoby (od 2026-10-27) */
    foreach ($rows as $x) {
        if ($x->raw_score === null || !isset($out[$x->test_key])) { continue; }
        $d = json_decode((string) $x->data, true);
        $out[$x->test_key]['hist'][] = array('version' => $x->test_version, 'raw_score' => floatval($x->raw_score), 'valid' => (int) $x->valid, 'date' => $x->created,
                                             'dokonceno' => is_array($d) && isset($d['dokonceno']) ? (string) $d['dokonceno'] : '');
    }
    foreach (kb_irt_keys() as $k) {
        if (!isset($out[$k]) || $out[$k]['raw_score'] === null) { continue; }
        $e = kb_irt_eap($k, kb_irt_resp($pid, $k));
        if ($e) { $out[$k]['theta'] = $e['theta']; $out[$k]['theta_se'] = $e['se']; $out[$k]['theta_n'] = $e['n']; $out[$k]['theta_v'] = kb_irt()['version']; }
    }
    foreach (array('matice12', 'dedukce', 'papir', 'stanoviste', 'pravidla', 'vahy', 'skladani', 'gcslovni', 'gcznalosti', 'ceiling') as $k) {
        if (isset($out[$k])) { $out[$k]['items'] = kb_answered_items($pid, $k); }
    }
    /* dotazníky (od 4.11.0 Škála ADHD): dřívější odpovědi (ID → 0–4 / 'X') → aplikace nabídne doplnit jen nové položky */
    foreach (array('adhd') as $k) {
        if (isset($out[$k])) { $out[$k]['items'] = kb_answered_scale($pid, $k); }
    }
    /* odvozené výsledky (théta bez dokončeného testu) se od 4.12.1 / 1.71.1 lidem nevracejí – slouží jen k normám (*_theta_pool) */
    $res = array('tests' => $out);
    $res['age'] = ($ag = $wpdb->get_var($wpdb->prepare("SELECT age FROM " . kb_table('participants') . " WHERE id = %d", $pid))) !== null ? intval($ag) : null;
    return $res;
}

function kb_answered_items($pid, $key) {
    global $wpdb;
    $sids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT session_id FROM " . kb_table('scores') . " WHERE participant_id = %d AND test_key = %s AND raw_score IS NOT NULL", $pid, $key));
    $items = array();
    if (!$sids) { return (object) $items; }
    $in = implode(',', array_map('intval', $sids));
    $rows = $wpdb->get_results($wpdb->prepare("SELECT session_id, test_key, data FROM " . kb_table('rows') . " WHERE session_id IN ($in) AND test_key = %s ORDER BY id ASC", $key));
    $ner = function_exists('kb_ner_sessions') ? kb_ner_sessions($rows) : array(); $RK = function_exists('kb_runs') ? kb_runs($rows) : array();   // od 2026-10-28: test jen otevřený se nepřebírá
    foreach ($rows as $ri => $x) {
        if (isset($RK[$ri]) && isset($ner[$RK[$ri]])) { continue; }
        $d = json_decode((string) $x->data, true);
        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }      // jen ostré odpovědi (ne nácvik, ne sondy)
        $id = isset($d['polozka']) ? (string) $d['polozka'] : '';
        if ($id === '' || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
        $items[$id] = intval($d['spravne']) ? 1 : ((!empty($d['castecne']) && isset($d['skore']) && is_numeric($d['skore'])) ? floatval($d['skore']) : 0);   // pozdější odpověď přepíše dřívější; částečný kredit (Matice V12)
    }
    return (object) $items;
}

function kb_answered_scale($pid, $key) {
    global $wpdb;
    $sids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT session_id FROM " . kb_table('scores') . " WHERE participant_id = %d AND test_key = %s", $pid, $key));
    $items = array();
    if (!$sids) { return (object) $items; }
    $in = implode(',', array_map('intval', $sids));
    $rows = $wpdb->get_results($wpdb->prepare("SELECT data FROM " . kb_table('rows') . " WHERE session_id IN ($in) AND test_key = %s ORDER BY id ASC", $key));
    foreach ($rows as $x) {
        $d = json_decode((string) $x->data, true);
        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'dotaznik') { continue; }
        $id = isset($d['polozka']) ? (string) $d['polozka'] : '';
        if ($id === '' || $id === 'ODHAD_ADHD' || !isset($d['odpoved']) || $d['odpoved'] === '') { continue; }
        $v = (string) $d['odpoved'];
        $items[$id] = is_numeric($v) ? floatval($v) : ($v === 'X' ? 'X' : null);   // pozdější odpověď (oprava) přepíše dřívější
        if ($items[$id] === null) { unset($items[$id]); }
    }
    return (object) $items;
}

function kb_maybe_notify($s, $pt, $key, $raw) {
    $set = get_option('kb_settings', array());
    if (empty($set['notify']) || $set['notify'] === 'none' || empty($set['notify_email'])) { return; }
    $who = $pt ? (($pt->code !== '' ? $pt->code : substr($pt->anon_id, 0, 8)) . ', věk ' . $pt->age . ', ' . $pt->mode) : '?';
    wp_mail($set['notify_email'], 'Kognitivní baterie: dokončen test ' . $key,
        "Účastník: $who\nTest: $key\nHrubý skór: " . ($raw === null ? '-' : $raw) . "\nSezení: " . $s->id . "\n");
}

/* GET /correlations – Pearsonovy korelace mezi testy (poslední platný výsledek každého účastníka); jen souhrn, žádná data jednotlivců */
function kb_correlation_matrix($allow = null, $minOverride = null) {
    global $wpdb;
    $seenV = array();
    $rows = $wpdb->get_results("SELECT sc.id, sc.valid, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, sc.data, p.mode, p.code, p.anon_id FROM " . kb_table('scores') . " sc JOIN " . kb_table('participants') . " p ON p.id = sc.participant_id WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) ORDER BY sc.id ASC");
    $by = array();
    $FKEYS = array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka');
    $FT = $wpdb->prefix . 'kben_scores'; $FP = $wpdb->prefix . 'kben_participants';
    $czLive = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $FT)) === $FT;
    $scrT = array();   // od 4.27.0: screening – výsledky „nechaný běžet“ se do korelací nepočítají (stejně jako EN 1.80.0)
    $isScr = function ($r, $ST) use (&$scrT) { if (!function_exists('kb_scr_ids') || !isset($r->id) || intval($r->valid) === 2) { return false; }
        if (!isset($scrT[$ST][$r->test_key])) { $scrT[$ST][$r->test_key] = kb_scr_ids(substr($ST, 0, -6), $r->test_key); } return isset($scrT[$ST][$r->test_key][intval($r->id)]); };
    $add = function ($r, $pk) use (&$by, &$seenV, $allow) {
        // jen testy a verze, které aplikace posílá jako současné (starší verze a zrušené testy se vynechají)
        if (is_array($allow)) {
            if (!isset($allow[$r->test_key]) || !in_array($r->test_version, (array) $allow[$r->test_key], true)) { return; }
        }
        // u opakovaného testu platí PRVNÍ dokončený výsledek (resp. první výsledek nové verze)
        if (!isset($by[$pk][$r->test_key])) { $by[$pk][$r->test_key] = floatval($r->raw_score); $seenV[$pk][$r->test_key] = array($r->test_version => 1); }
        elseif (!isset($seenV[$pk][$r->test_key][$r->test_version])) { $seenV[$pk][$r->test_key][$r->test_version] = 1; $by[$pk][$r->test_key] = floatval($r->raw_score); }
    };
    foreach ($rows as $r) {
        if ($isScr($r, kb_table('scores'))) { continue; }
        // osoba = všechna její sezení dohromady (vaše verze podle kódu)
        $add($r, function_exists('kb_person_key') ? kb_person_key($r->mode, $r->code, $r->anon_id) : $r->participant_id);
    }
    /* + výsledky z anglické verze (tabulky wp_kben_*; bez českých výsledků do ní importovaných) – jen jazykově nezávislé testy (od 3.98.0 / EN 1.59.0) */
    if ($czLive) {
        $fin = "'" . implode("','", $FKEYS) . "'";
        $fr = $wpdb->get_results("SELECT sc.id, sc.valid, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, fp.mode, fp.code, fp.anon_id FROM $FT sc JOIN $FP fp ON fp.id = sc.participant_id WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) AND sc.test_key IN ($fin) AND (fp.mode IS NULL OR fp.mode <> 'cz') ORDER BY sc.id ASC");
        foreach ((array) $fr as $r) { if ($isScr($r, $FT)) { continue; } $add($r, 'en:' . (function_exists('kb_person_key') ? kb_person_key($r->mode, $r->code, $r->anon_id) : $r->participant_id)); }
    }
    /* + rodiče z dětské verze (wp_kbd_*; jen výsledky s věkem 18+) – jazykově nezávislé testy (od CZ 4.10.21 / EN 1.70.28) */
    if (kb_kbd_live()) {
        $KT = $wpdb->prefix . 'kbd_scores'; $kin = "'" . implode("','", $FKEYS) . "'";
        $kr = $wpdb->get_results("SELECT sc.id, sc.valid, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score FROM $KT sc WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) AND sc.age >= 18 AND sc.test_key IN ($kin) ORDER BY sc.id ASC");
        foreach ((array) $kr as $r) { if ($isScr($r, $KT)) { continue; } $add($r, 'kbd:' . $r->participant_id); }
    }
    $set = get_option('kb_settings', array());
    $minn = $minOverride !== null ? intval($minOverride) : (isset($set['min_n']) ? intval($set['min_n']) : 30);
    $count = array();
    foreach ($by as $pid => $t) { foreach ($t as $k => $v) { $count[$k] = isset($count[$k]) ? $count[$k] + 1 : 1; } }
    $keys = array();
    foreach ($count as $k => $c) { if ($c >= $minn) { $keys[] = $k; } }
    sort($keys);
    $R = array(); $N = array();
    foreach ($keys as $i => $a) {
        foreach ($keys as $j => $b) {
            $x = array(); $y = array();
            foreach ($by as $t) { if (isset($t[$a]) && isset($t[$b])) { $x[] = $t[$a]; $y[] = $t[$b]; } }
            $n = count($x); $N[$i][$j] = $n; $R[$i][$j] = null;
            if ($i === $j || $n < $minn) { continue; }
            $mx = array_sum($x) / $n; $my = array_sum($y) / $n; $sxy = 0; $sxx = 0; $syy = 0;
            for ($q = 0; $q < $n; $q++) { $dx = $x[$q] - $mx; $dy = $y[$q] - $my; $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy; }
            $R[$i][$j] = ($sxx > 0 && $syy > 0) ? round($sxy / sqrt($sxx * $syy), 3) : null;
        }
    }
    return array('keys' => $keys, 'r' => $R, 'n' => $N, 'min_n' => $minn);
}
function kb_rest_correlations(WP_REST_Request $r) {
    $allow = null; $raw = $r->get_param('allow');
    if (is_string($raw) && $raw !== '') {
        $dec = json_decode(wp_unslash($raw), true);
        if (is_array($dec)) {
            $allow = array();
            foreach ($dec as $k => $vs) { $k = sanitize_key($k); if ($k === '' || !is_array($vs)) { continue; }
                $allow[$k] = array_slice(array_map('sanitize_text_field', array_map('strval', $vs)), 0, 20); }
        }
    }
    $ck = 'kb_corr_' . md5(wp_json_encode($allow));
    $cached = get_transient($ck);
    if ($cached) { return $cached; }
    $m = kb_correlation_matrix($allow);
    set_transient($ck, $m, 10 * MINUTE_IN_SECONDS);
    return $m;
}
