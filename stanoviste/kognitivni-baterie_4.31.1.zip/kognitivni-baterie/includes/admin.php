<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    add_menu_page('Kognitivní baterie', 'Kognitivní baterie', 'edit_posts', 'kb-overview', 'kb_admin_overview', 'dashicons-chart-bar', 58);
    add_submenu_page('kb-overview', 'Nastavení', 'Nastavení', 'manage_options', 'kb-settings', 'kb_admin_settings');
});

/* export CSV (spouští se přes admin-post.php, aby se neposílala HTML hlavička) */
add_action('admin_post_kb_export', function () {
    if (!current_user_can('edit_posts')) { wp_die('Nedostatečná oprávnění.'); }
    check_admin_referer('kb_export');
    $what = isset($_GET['what']) ? sanitize_key($_GET['what']) : 'rows';
    if ($what === 'items') {
        $test = isset($_GET['test']) ? kb_clean_key(wp_unslash($_GET['test'])) : '';
        kb_export_items($test, !empty($_GET['sondy']));
        exit;
    }
    kb_export_csv($what === 'scores' ? 'scores' : 'rows');
    exit;
});

function kb_export_csv($what) {
    global $wpdb;
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=kb_' . $what . '_' . gmdate('Ymd_His') . '.csv');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");            // BOM pro Excel
    $P = kb_table('participants'); $S = kb_table('sessions');
    if ($what === 'scores') {
        $rows = $wpdb->get_results("SELECT sc.*, p.anon_id, p.code, p.demographics FROM " . kb_table('scores') . " sc JOIN $P p ON p.id = sc.participant_id ORDER BY sc.id", ARRAY_A);
        $base = array('id', 'session_id', 'anon_id', 'code', 'mode', 'age', 'test_key', 'test_version', 'raw_score', 'valid', 'created');
        $keys = array();
        foreach ($rows as $r) { $d = json_decode((string) $r['data'], true); if (is_array($d)) { foreach ($d as $k => $v) { $keys['score_' . $k] = 1; } }
                               $m = json_decode((string) $r['demographics'], true); if (is_array($m)) { foreach ($m as $k => $v) { $keys['demo_' . $k] = 1; } } }
        $cols = array_merge($base, array_keys($keys));
        fputcsv($out, $cols, ';');
        foreach ($rows as $r) {
            $line = array(); foreach ($base as $b) { $line[] = $r[$b]; }
            $d = json_decode((string) $r['data'], true); $m = json_decode((string) $r['demographics'], true);
            foreach (array_keys($keys) as $k) {
                if (strpos($k, 'score_') === 0) { $kk = substr($k, 6); $v = is_array($d) && isset($d[$kk]) ? $d[$kk] : ''; }
                else { $kk = substr($k, 5); $v = is_array($m) && isset($m[$kk]) ? $m[$kk] : ''; }
                $line[] = is_scalar($v) ? $v : wp_json_encode($v);
            }
            fputcsv($out, $line, ';');
        }
        fclose($out); return;
    }
    // řádky odpovědí: nejdřív zjistit všechny sloupce (po dávkách), pak zapsat
    $T = kb_table('rows'); $keys = array(); $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $T WHERE id > %d ORDER BY id LIMIT 2000", $last), ARRAY_A);
        foreach ($chunk as $c) { $last = $c['id']; $d = json_decode($c['data'], true); if (is_array($d)) { foreach ($d as $k => $v) { $keys[$k] = 1; } } }
    } while (count($chunk) === 2000);
    $base = array('row_id', 'session_id', 'anon_id', 'code', 'mode', 'age', 'saved');
    $cols = array_keys($keys);
    fputcsv($out, array_merge($base, $cols), ';');
    $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare(
            "SELECT r.id, r.session_id, r.created, r.data, p.anon_id, p.code, p.mode, p.age FROM $T r JOIN $S s ON s.id = r.session_id JOIN $P p ON p.id = s.participant_id WHERE r.id > %d ORDER BY r.id LIMIT 2000", $last), ARRAY_A);
        foreach ($chunk as $c) {
            $last = $c['id']; $d = json_decode($c['data'], true);
            $line = array($c['id'], $c['session_id'], $c['anon_id'], $c['code'], $c['mode'], $c['age'], $c['created']);
            foreach ($cols as $k) { $v = is_array($d) && isset($d[$k]) ? $d[$k] : ''; $line[] = is_scalar($v) ? $v : wp_json_encode($v); }
            fputcsv($out, $line, ';');
        }
    } while (count($chunk) === 2000);
    fclose($out);
}

/* Export po položkách pro jeden test (široký formát): řádek = sezení, sloupec = položka, hodnota = body (HS) za položku.
   Jen ostré položky (faze = test); nácvik vynechán; sondy volitelně jako sloupce „sonda_ID“. Nezadaná položka = prázdné pole
   (připsané položky se nevyplňují – jsou ve sloupci HS_celkem / pripsane). Hodnota: skore, jinak spravne, jinak odpoved. */
/* Klíč osoby: veřejná verze = anonymní identifikátor prohlížeče; vaše verze (admin) = zadaný kód osoby (každé sezení má nový
   identifikátor, proto se slučuje podle kódu); bez kódu = identifikátor. */
function kb_test_meta() {
    static $M = null;
    if ($M !== null) { return $M; }
    $M = array();
    $groups = array(
        'Rychlé řešení problémů' => array('rychly' => 'Rychlý test'),
        'Gf – usuzování' => array('matice12' => 'Matice V12', 'matice' => 'Matice (v10)', 'vahy' => 'Váhy', 'dedukce' => 'Tvarové klíče', 'pravidla' => 'Hledání pravidla', 'pretahovana' => 'Přetahovaná', 'pretah2' => 'Přetahovaná 2.0 (1. část)', 'pretah2b' => 'Přetahovaná 2.0 (2. část)', 'ptvyvoj' => 'Vývoj PF-24 (1. část)', 'ptvyvoj2' => 'Vývoj PF-24 (2. část)', 'stanoviste' => 'Stanoviště', 'stroje' => 'Seřaďte stroje'),
        'Gc – znalosti' => array('gcslovni' => 'Jak se to nazývá', 'gcznalosti' => 'Všeobecné znalosti', 'gcanalogie' => 'Analogie', 'synonyma' => 'Slova stejného významu', 'pojmy' => 'Pojmy', 'zasoba2' => 'Slovní zásoba (MC)', 'znalosti2' => 'Znalosti (MC)'),
        'Gv – prostorové' => array('papir' => 'Skládání papíru', 'rotace' => 'Mentální rotace', 'kostky' => 'Pohled na stavbu', 'skladani' => 'Skládání tvarů', 'oblouky' => 'Oblouky'),
        'Gwm – pracovní paměť' => array('zpetna' => 'Čísla pozpátku', 'rds' => 'Poslední čísla', 'por' => 'Pořadí obrázků', 'corsi' => 'Pořadí na mřížce'),
        'Gs – rychlost' => array('symboly' => 'Symboly a čísla', 'rady' => 'Shodné řady', 'prohozene' => 'Prohozené barvy', 'dvojice' => 'Dvojice'),
        'Gt – rychlost reakce' => array('reakce' => 'Jednoduchá reakce', 'volba' => 'Reakce s volbou', 'kolecka' => 'Kolečka (go/no-go)'),
        'Školní dovednosti' => array('pocitani' => 'Počítání', 'ulohy' => 'Slovní úlohy', 'cteni' => 'Porozumění textu (st.)', 'cteni2' => 'Porozumění textu', 'srce' => 'Efektivita čtení'),
        'Škály' => array('adhd_inf' => 'ADHD – pohled blízkého', 'adhdp_nepozornost' => 'ADHD nepozornost', 'adhdp_hyperaktivita' => 'ADHD hyperaktivita', 'adhdp_impulzivita' => 'ADHD impulzivita', 'adhdp_exekutivni' => 'ADHD exekutiva', 'adhdp_emocni' => 'ADHD emoce',
                          'mask_zahlazovani' => 'Maskování: zahlazování', 'mask_potlacovani' => 'Maskování: potlačování', 'mask_predstirani' => 'Maskování: předstírání', 'mask_zatez' => 'Maskování: zátěž', 'adhd' => 'Škála ADHD', 'masking' => 'Škála maskování'));
    $r = 0;
    foreach ($groups as $g => $list) { foreach ($list as $k => $lab) { $M[$k] = array('rank' => $r++, 'group' => $g, 'label' => $lab); } }
    return $M;
}
function kb_test_rank($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['rank'] : 1000 + crc32($k) % 1000; }
function kb_test_group($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['group'] : 'Ostatní'; }
function kb_test_label($k) { $M = kb_test_meta(); return isset($M[$k]) ? $M[$k]['label'] : $k; }
/* v přehledu mezi současnými verzemi skrýt odvozené/pomocné klíče (DSM počty, staré subškály ADHD) */
function kb_test_hidden($k) { return (bool) preg_match('/^(adhd_dsm_|adhd_(nepozornost|hyperaktivita|impulzivita|exekutivni|emocni)$|gcnapis$)/', $k); }
function kb_corr_hidden($k) { return kb_test_hidden($k) || in_array($k, array('matice', 'dvojice', 'rotace', 'adhd', 'adhd_inf', 'masking', 'stroje', 'zasoba2', 'znalosti2'), true); }

function kb_person_key($mode, $code, $anon) {
    $code = trim((string) $code);
    return ($mode === 'admin' && $code !== '') ? 'kod:' . $code : 'id:' . $anon;
}

function kb_export_items($test, $withProbes) {
    global $wpdb;
    if ($test === '') { wp_die('Chybí test.'); }
    $T = kb_table('rows'); $S = kb_table('sessions'); $P = kb_table('participants'); $SC = kb_table('scores');
    $data = array(); $meta = array(); $items = array(); $last = 0;
    do {
        $chunk = $wpdb->get_results($wpdb->prepare(
            "SELECT r.id, r.session_id, r.data, p.anon_id, p.code, p.mode, p.age, p.demographics FROM $T r JOIN $S s ON s.id = r.session_id JOIN $P p ON p.id = s.participant_id WHERE r.test_key = %s AND r.id > %d ORDER BY r.id LIMIT 2000",
            $test, $last), ARRAY_A);
        foreach ($chunk as $c) {
            $last = $c['id']; $d = json_decode($c['data'], true); if (!is_array($d)) { continue; }
            $faze = isset($d['faze']) ? $d['faze'] : '';
            if ($faze === 'sonda') { if (!$withProbes) { continue; } $pref = 'sonda_'; }
            elseif ($faze === 'test' || $faze === 'dotaznik' || $faze === '') { $pref = ''; }
            else { continue; }
            $id = isset($d['id']) && $d['id'] !== '' ? $d['id'] : (isset($d['polozka']) ? $d['polozka'] : '');
            if ($id === '' || (isset($d['typ']) && $d['typ'] === 'workspace')) { continue; }
            $v = '';
            foreach (array('skore', 'spravne', 'odpoved') as $k) { if (isset($d[$k]) && $d[$k] !== '' && is_numeric($d[$k])) { $v = $d[$k] + 0; break; } }
            // vypršel limit a nebylo nic označeno → „T“ (nestihl/a), aby se to nepletlo s nezadanou položkou (prázdné pole)
            $odp = isset($d['odpoved']) ? (string) $d['odpoved'] : '';
            if (((isset($d['timeout']) && (string) $d['timeout'] === '1') || (isset($d['chyby']) && $d['chyby'] === 'timeout')) && ($odp === '' || $odp === '[]' || $odp === 'T')) { $v = 'T'; }
            $col = $pref . $id; $items[$col] = 1;
            $sid = kb_person_key($c['mode'], $c['code'], $c['anon_id']);   // jedna osoba = jeden řádek (sezení se slučují)
            if (!isset($data[$sid][$col])) { $data[$sid][$col] = $v; }       // při opakování položky platí PRVNÍ pokus
            if (!isset($meta[$sid])) {
                $m = json_decode((string) $c['demographics'], true);
                $meta[$sid] = array('anon' => $c['anon_id'], 'code' => $c['code'], 'mode' => $c['mode'], 'age' => $c['age'], 'sessions' => array(),
                    'pohlavi' => is_array($m) && isset($m['pohlavi']) ? $m['pohlavi'] : '', 'forma' => isset($d['forma']) ? $d['forma'] : '');
            }
            $meta[$sid]['sessions'][$c['session_id']] = 1;
        }
    } while (count($chunk) === 2000);
    $cols = array_keys($items); natsort($cols); $cols = array_values($cols);
    usort($cols, function ($a, $b) { $pa = strpos($a, 'sonda_') === 0; $pb = strpos($b, 'sonda_') === 0; if ($pa !== $pb) { return $pa ? 1 : -1; } return strnatcmp($a, $b); });
    $hs = array();
    foreach ($wpdb->get_results($wpdb->prepare("SELECT sc.raw_score, sc.data, p.anon_id, p.code, p.mode FROM $SC sc JOIN $P p ON p.id = sc.participant_id WHERE sc.test_key = %s ORDER BY sc.id", $test), ARRAY_A) as $r) {
        $k = kb_person_key($r['mode'], $r['code'], $r['anon_id']);
        if (isset($hs[$k])) { continue; }                                 // první dokončený výsledek osoby
        $d = json_decode((string) $r['data'], true);
        $hs[$k] = array($r['raw_score'], is_array($d) && isset($d['pripsane']) ? $d['pripsane'] : '', is_array($d) && isset($d['konec']) ? $d['konec'] : '');
    }
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=kb_polozky_' . $test . '_' . gmdate('Ymd_His') . '.csv');
    $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_merge(array('osoba', 'anon_id', 'code', 'mode', 'age', 'pohlavi', 'forma', 'sezeni', 'HS_celkem', 'pripsane', 'konec', 'zadano_polozek'), $cols), ';');
    foreach ($data as $sid => $vals) {
        $m = $meta[$sid]; $h = isset($hs[$sid]) ? $hs[$sid] : array('', '', '');
        $n = 0; foreach ($vals as $k => $v) { if (strpos($k, 'sonda_') !== 0) { $n++; } }
        $line = array($sid, $m['anon'], $m['code'], $m['mode'], $m['age'], $m['pohlavi'], $m['forma'], implode(' ', array_keys($m['sessions'])), $h[0], $h[1], $h[2], $n);
        foreach ($cols as $c) { $line[] = isset($vals[$c]) ? $vals[$c] : ''; }
        fputcsv($out, $line, ';');
    }
    fclose($out);
}


/* Přepočet Tvarových klíčů (DED-24) podle nových časových limitů po úrovních (verze DED-24-v1.3):
   1: 30 s, 2: 45 s, 3: 60 s, 4: 120 s, 5: 150 s, 6: 75 s, 7: 90 s, 8–9: 120 s.
   Položka: správně jen tehdy, když odpověď přišla do limitu své úrovně (původní hodnota zůstává ve spravne_puvodni).
   Skóre: znovu se použije ukončení po 5 chybách v řadě – co by po novém ukončení už nebylo zadáno, se nepočítá.
   Opakované spuštění nic nemění (zpracované záznamy mají příznak prepocet). */
function kb_recode_dedukce() {
    global $wpdb;
    $CAP = array(1 => 30, 2 => 45, 3 => 60, 4 => 120, 5 => 150, 6 => 75, 7 => 90, 8 => 120, 9 => 120);
    $R = kb_table('rows'); $SC = kb_table('scores');
    $scores = $wpdb->get_results("SELECT id, session_id, raw_score, data FROM $SC WHERE test_key = 'dedukce' AND test_version IN ('DED-24-v1.0','DED-24-v1.1','DED-24-v1.2')", ARRAY_A);
    $nS = 0; $nR = 0; $changed = 0;
    foreach ($scores as $sc) {
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet'])) { continue; }
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $R WHERE session_id = %d AND test_key = 'dedukce' ORDER BY client_seq, id", $sc['session_id']), ARRAY_A);
        $raw = 0; $run = 0; $stopped = false; $konec = '';
        foreach ($rows as $r) {
            $d = json_decode((string) $r['data'], true);
            if (!is_array($d) || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
            if (!preg_match('/tier=(\d+)/', isset($d['facety']) ? $d['facety'] : '', $m)) { continue; }
            $tier = intval($m[1]); $cap = isset($CAP[$tier]) ? $CAP[$tier] : 120;
            $orig = isset($d['spravne']) ? intval($d['spravne']) : 0;
            $rt = isset($d['rt_ms']) ? floatval($d['rt_ms']) : 0;
            $ok = ($orig === 1 && $rt <= $cap * 1000) ? 1 : 0;
            if (empty($d['prepocet'])) {
                $d['spravne_puvodni'] = $orig; $d['spravne'] = $ok; $d['time_limit_ms_prepocet'] = $cap * 1000;
                $d['prepocet'] = 'casove-limity-DED-24-v1.3';
                if ($ok !== $orig) { $d['po_novem_limitu'] = 1; $changed++; }
                $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
            }
            if ($stopped) { continue; }
            if ($ok) { $raw++; $run = 0; } else { $run++; if ($run >= 5) { $stopped = true; $konec = 'ukončeno po 5 chybách v řadě (přepočet)'; } }
        }
        $sd['hruby_puvodni'] = $sc['raw_score']; $sd['hruby'] = $raw; $sd['prepocet'] = 'casove-limity-DED-24-v1.3';
        if ($konec) { $sd['konec_prepocet'] = $konec; }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    return array('scores' => $nS, 'rows' => $nR, 'changed' => $changed);
}

/* Tvarové klíče DED-24-v2.x: přepočet podle SOUČASNÝCH časových limitů (jediné místo, kde jsou limity pro přepočet).
   Počítá se vždy z původní správnosti (spravne_puvodni), takže při další změně limitů stačí upravit tabulku a značku –
   přepočet proběhne znovu sám. Odpověď za limitem své úrovně = chybná (příznak po_novem_limitu), přepočítá se i skore
   (export po položkách) a ukončení po 5 chybách v řadě. Původní hrubý skór zůstává v hruby_puvodni.
   Spouští se automaticky při prvním otevření administrace po aktualizaci (a tlačítkem v přehledu). */
function kb_ded_caps() { return array(1 => 30, 2 => 30, 3 => 60, 4 => 90, 5 => 90, 6 => 90, 7 => 90, 8 => 120, 9 => 120); }
define('KB_DED_CAPS_TAG', 'limity-DED-24-v2.3');
function kb_recode_dedukce_v2() {
    global $wpdb;
    $CAP = kb_ded_caps(); $TAG = KB_DED_CAPS_TAG;
    $R = kb_table('rows'); $SC = kb_table('scores');
    $scores = $wpdb->get_results("SELECT id, session_id, raw_score, data FROM $SC WHERE test_key = 'dedukce' AND test_version LIKE 'DED-24-v2.%'", ARRAY_A);
    $nS = 0; $nR = 0; $changed = 0; $diff = 0;
    foreach ($scores as $sc) {
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (isset($sd['prepocet']) && $sd['prepocet'] === $TAG) { continue; }
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $R WHERE session_id = %d AND test_key = 'dedukce' ORDER BY client_seq, id", $sc['session_id']), ARRAY_A);
        if (!$rows) { continue; }                       // bez uložených odpovědí (např. import) nelze přepočítat
        $raw = 0; $run = 0; $stopped = false; $konec = '';
        foreach ($rows as $r) {
            $d = json_decode((string) $r['data'], true);
            if (!is_array($d) || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
            if (!preg_match('/tier=(\d+)/', isset($d['facety']) ? $d['facety'] : '', $m)) { continue; }
            $cap = isset($CAP[intval($m[1])]) ? $CAP[intval($m[1])] : 100;
            $orig = isset($d['spravne_puvodni']) ? intval($d['spravne_puvodni']) : (isset($d['spravne']) ? intval($d['spravne']) : 0);
            $rt = isset($d['rt_ms']) ? floatval($d['rt_ms']) : 0;
            $ok = ($orig === 1 && $rt <= $cap * 1000) ? 1 : 0;
            if (!isset($d['prepocet']) || $d['prepocet'] !== $TAG) {
                $d['spravne_puvodni'] = $orig; $d['spravne'] = $ok; $d['skore'] = $ok; $d['time_limit_ms_prepocet'] = $cap * 1000;
                $d['prepocet'] = $TAG; $d['po_novem_limitu'] = ($ok !== $orig) ? 1 : 0;
                if ($ok !== $orig) { $changed++; }
                $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
            }
            if ($stopped) { continue; }
            if ($ok) { $raw++; $run = 0; } else { $run++; if ($run >= 5) { $stopped = true; $konec = 'ukončeno po 5 chybách v řadě (přepočet)'; } }
        }
        if (!isset($sd['hruby_puvodni'])) { $sd['hruby_puvodni'] = $sc['raw_score']; }
        if (intval($sc['raw_score']) !== $raw) { $diff++; }
        $sd['hruby'] = $raw; $sd['prepocet'] = $TAG; if ($konec) { $sd['konec_prepocet'] = $konec; } else { unset($sd['konec_prepocet']); }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    // oprava starého přepočtu v1.3: měnil jen „spravne“, export po položkách ale bere „skore“
    $old = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'dedukce' AND data LIKE '%casove-limity-DED-24-v1.3%' AND data LIKE '%po_novem_limitu%'", ARRAY_A);
    $fixed = 0;
    foreach ($old as $r) { $d = json_decode((string) $r['data'], true);
        if (is_array($d) && isset($d['spravne'], $d['skore']) && intval($d['skore']) !== intval($d['spravne'])) { $d['skore'] = intval($d['spravne']); $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $fixed++; } }
    $info = array('tag' => $TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'rows' => $nR, 'changed' => $changed, 'diff' => $diff, 'fixed_v13' => $fixed);
    update_option('kb_ded_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_ded_recode');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_DED_CAPS_TAG) && current_user_can('edit_posts')) { kb_recode_dedukce_v2(); }
});

/* ===== Časové limity 2026-10b (3.63.0): přepočet dřívějších výsledků podle nových stropů =====
   Běžné položky max 90 s, náročné bloky max 120 s: Matice úroveň 9–11 120 → 90 s; Hledání pravidla úroveň 5 150 → 120 s;
   Váhy blok K 180 → 120 s; Pohled na stavbu a Skládání tvarů nově 90 s; Mentální rotace 45 / 60 / 90 s podle empirické
   obtížnosti (dřívější MR-v5-50* a MR-v6-38t se převedou na škálu MR-v6-38h, 38 položek). Tvarové klíče řeší kb_recode_dedukce_v2.
   Správná odpověď za novým limitem = chybná (příznak po_novem_limitu). Hrubý skór = skór před úpravou − ztracené (bez dominového
   efektu pravidla ukončení). Skór před úpravou na současné škále zůstává v hruby_pred_upravou – aplikace ho ukáže jako druhou čáru.
   Počítá se vždy z původní správnosti (spravne_puvodni), takže opakované spuštění dá stejný výsledek. */
define('KB_CAPS2_TAG', 'limity-2026-10b');
function kb_caps2_rule($key, $d) {
    switch ($key) {
        case 'matice':   return (isset($d['uroven']) && intval($d['uroven']) >= 9) ? 90 : null;
        case 'pravidla': return (isset($d['uroven']) && intval($d['uroven']) === 5) ? 120 : null;
        case 'vahy':     return (isset($d['id']) && preg_match('/^V2_K/', (string) $d['id'])) ? 120 : null;
        case 'kostky': case 'skladani': return 90;
    }
    return null;
}
function kb_rot_v6() { return json_decode('{"order":["MR4_001","MR4_002","MR4_003","MR4_004","MR4_006","MR4_008","MR4_010","MR4_020","MR4_024","MR4_017","MR4_018","MR4_041","MR4_013","MR4_049","MR4_025","MR4_032","MR4_037","MR4_044","MR4_047","MR4_027","MR4_022","MR4_028","MR4_036","MR4_021","MR4_030","MR4_023","MR4_016","MR4_034","MR4_042","MR4_039","MR4_040","MR4_046","MR4_019","MR4_026","MR4_029","MR4_035","MR4_045","MR4_043"],"b":{"MR4_001":-1.23,"MR4_002":-1.23,"MR4_006":-2.75,"MR4_008":-2.75,"MR4_010":-2.75,"MR4_020":-2.45,"MR4_024":-2.4,"MR4_017":-1.06,"MR4_018":-0.33,"MR4_041":-0.07,"MR4_013":-0.05,"MR4_049":-0.05,"MR4_025":0.51,"MR4_032":0.76,"MR4_037":0.76,"MR4_044":0.77,"MR4_047":0.8,"MR4_027":0.95,"MR4_022":1.16,"MR4_028":1.18,"MR4_036":1.37,"MR4_021":1.49,"MR4_030":1.53,"MR4_023":1.69,"MR4_016":1.86,"MR4_034":1.89,"MR4_042":1.89,"MR4_039":2.37,"MR4_040":2.37,"MR4_046":2.47,"MR4_019":2.66,"MR4_026":2.7,"MR4_029":2.81,"MR4_035":2.83,"MR4_045":2.85,"MR4_043":3.32},"kids":["MR4_001","MR4_002","MR4_003","MR4_004","MR4_006","MR4_008","MR4_010"]}', true); }
function kb_rot_cap($id, $R) { if (!isset($R['b'][$id])) { return 45; } $b = floatval($R['b'][$id]); return $b < 0 ? 45 : ($b < 1.5 ? 60 : 90); }
function kb_recode_caps2() {
    global $wpdb;
    $TAG = KB_CAPS2_TAG; $RT = kb_table('rows'); $SC = kb_table('scores'); $ROT = kb_rot_v6();
    $scores = $wpdb->get_results("SELECT id, session_id, test_key, test_version, raw_score, age, data FROM $SC WHERE raw_score IS NOT NULL AND (test_key IN ('matice','pravidla','vahy','kostky','skladani') OR (test_key = 'rotace' AND (test_version LIKE 'MR-v5-50%' OR test_version IN ('MR-v6-38t','MR-v6-38h'))))", ARRAY_A);
    $nS = 0; $changed = 0; $diff = 0;
    foreach ($scores as $sc) {
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (isset($sd['prepocet_limity']) && $sd['prepocet_limity'] === $TAG) { continue; }
        $key = $sc['test_key'];
        if ($key === 'rotace' && $sc['test_version'] === 'MR-v6-38h' && !isset($sd['verze_puvodni'])) { continue; }   // nová data už mají nové limity
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $RT WHERE session_id = %d AND test_key = %s ORDER BY client_seq, id", $sc['session_id'], $key), ARRAY_A);
        if (!$rows) { continue; }
        $lost = 0; $seen = array(); $okv6 = array(); $orig6 = array();
        foreach ($rows as $r) {
            $d = json_decode((string) $r['data'], true);
            if (!is_array($d) || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
            $id = isset($d['id']) ? (string) $d['id'] : '';
            $cap = $key === 'rotace' ? kb_rot_cap($id, $ROT) : kb_caps2_rule($key, $d);
            if ($cap === null) { continue; }
            $orig = isset($d['spravne_puvodni']) ? intval($d['spravne_puvodni']) : (isset($d['spravne']) ? intval($d['spravne']) : 0);
            $rt = isset($d['rt_ms']) ? floatval($d['rt_ms']) : 0;
            $ok = ($orig === 1 && $rt <= $cap * 1000) ? 1 : 0;
            if ($key === 'rotace') { if (!isset($seen[$id])) { $seen[$id] = 1; $okv6[$id] = $ok; $orig6[$id] = $orig; } }
            elseif ($orig === 1 && !$ok) { $lost++; }
            if (!isset($d['prepocet_limity']) || $d['prepocet_limity'] !== $TAG) {
                $d['spravne_puvodni'] = $orig; $d['spravne'] = $ok; if (isset($d['skore']) && !$ok) { $d['skore'] = 0; }
                $d['time_limit_ms_prepocet'] = $cap * 1000; $d['po_novem_limitu'] = ($ok !== $orig) ? 1 : 0; $d['prepocet_limity'] = $TAG;
                if ($ok !== $orig) { $changed++; }
                $wpdb->update($RT, array('data' => wp_json_encode($d)), array('id' => $r['id']));
            }
        }
        $upd = array();
        if ($key === 'rotace') {                       // převod na škálu MR-v6-38h: položky, které v6 nemá, se nepočítají
            $adult = intval($sc['age']) >= 9; $pred = 0; $po = 0;
            foreach ($ROT['order'] as $id) {
                if (isset($okv6[$id])) { $pred += $orig6[$id]; $po += $okv6[$id]; }
                elseif ($adult && in_array($id, $ROT['kids'], true)) { $pred++; $po++; }   // úvod pro děti se dospělým připisuje
            }
            if (!isset($sd['verze_puvodni'])) { $sd['verze_puvodni'] = $sc['test_version']; $sd['hruby_puvodni'] = $sc['raw_score']; }
            $sd['hruby_pred_upravou'] = $pred; $new = $po; $upd['test_version'] = 'MR-v6-38h'; $sd['polozek'] = count($ROT['order']);
        } else {
            if (!isset($sd['hruby_pred_upravou'])) { $sd['hruby_pred_upravou'] = floatval($sc['raw_score']); }
            $new = max(0, floatval($sd['hruby_pred_upravou']) - $lost);
        }
        $sd['ztraceno_limitem'] = $key === 'rotace' ? ($sd['hruby_pred_upravou'] - $new) : $lost; $sd['hruby'] = $new; $sd['prepocet_limity'] = $TAG;
        if (floatval($sc['raw_score']) != $new) { $diff++; }
        $upd['raw_score'] = $new; $upd['data'] = wp_json_encode($sd);
        $wpdb->update($SC, $upd, array('id' => $sc['id'])); $nS++;
    }
    $info = array('tag' => $TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'changed_rows' => $changed, 'diff' => $diff);
    update_option('kb_caps2_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_caps2_recode');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_CAPS2_TAG) && current_user_can('edit_posts')) { kb_recode_caps2(); }
});

function kb_admin_overview() {
    global $wpdb;
    if (!current_user_can('edit_posts')) { return; }
    // smazání dat účastníka (GDPR)
    if (isset($_POST['kb_delete']) && check_admin_referer('kb_delete') && current_user_can('manage_options')) {
        $anon = sanitize_text_field(wp_unslash($_POST['kb_delete']));
        $n = kb_delete_participant($anon);
        echo '<div class="notice notice-success"><p>Smazáno záznamů účastníka: ' . intval($n) . '</p></div>';
    }
    $P = kb_table('participants'); $S = kb_table('sessions'); $SC = kb_table('scores');
    $np = (int) $wpdb->get_var("SELECT COUNT(*) FROM $P");
    $ns = (int) $wpdb->get_var("SELECT COUNT(*) FROM $S");
    $nr = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . kb_table('rows'));
    if (isset($_POST['kb_dedupe']) && check_admin_referer('kb_dedupe') && current_user_can('manage_options')) {
        // smaže jen přesné duplicity: stejný test a verze ve stejném sezení (ponechá první záznam)
        $d = $wpdb->query("DELETE a FROM $SC a JOIN $SC b ON a.session_id = b.session_id AND a.test_key = b.test_key AND a.test_version = b.test_version AND a.id > b.id");
        echo '<div class="notice notice-success"><p>Odstraněno duplicitních výsledků: ' . intval($d) . '</p></div>';
    }
    $per = $wpdb->get_results("SELECT test_key, test_version, COUNT(*) n, COUNT(DISTINCT session_id) ns, COUNT(DISTINCT participant_id) np, SUM(valid) nv, AVG(raw_score) m, MAX(created) last FROM $SC GROUP BY test_key, test_version ORDER BY test_key");
    $curv = array();                                   // současná verze testu = ta, ve které přišel nejnovější výsledek
    foreach ($per as $x) { if (!isset($curv[$x->test_key]) || strcmp($x->last, $curv[$x->test_key][1]) > 0) { $curv[$x->test_key] = array($x->test_version, $x->last); } }
    $dup = (int) $wpdb->get_var("SELECT COUNT(*) FROM $SC a JOIN $SC b ON a.session_id = b.session_id AND a.test_key = b.test_key AND a.test_version = b.test_version AND a.id > b.id");
    $recent = $wpdb->get_results("SELECT s.id, s.started, s.last_seen, p.code, p.mode, p.age, LEFT(p.anon_id, 8) a, p.anon_id full FROM $S s JOIN $P p ON p.id = s.participant_id ORDER BY s.id DESC LIMIT 50");
    $exp = function ($what) { return esc_url(wp_nonce_url(admin_url('admin-post.php?action=kb_export&what=' . $what), 'kb_export')); };
    echo '<div class="wrap"><h1>Kognitivní baterie</h1>';
    if (isset($_POST['kb_recode_ded']) && check_admin_referer('kb_recode_ded') && current_user_can('manage_options')) {
        $rr = kb_recode_dedukce();
        echo '<div class="notice notice-success"><p>Tvarové klíče přepočítány podle nových časových limitů: výsledků ' . intval($rr['scores']) . ', odpovědí ' . intval($rr['rows']) . ', z toho nově za limitem ' . intval($rr['changed']) . '.</p></div>';
    }
    if (isset($_POST['kb_recode_ded2']) && check_admin_referer('kb_recode_ded2') && current_user_can('manage_options')) { delete_option('kb_ded_recode'); kb_recode_dedukce_v2(); }
    $ri = get_option('kb_ded_recode');
    echo '<form method="post" style="margin:6px 0">'; wp_nonce_field('kb_recode_ded2');
    echo '<span class="description">Tvarové klíče DED-24-v2.x jsou přepočítané podle současných limitů (' . esc_html(is_array($ri) ? $ri['tag'] . ', ' . $ri['cas'] . ': výsledků ' . intval($ri['scores']) . ', změněný skór ' . intval($ri['diff']) . ', odpovědí nově za limitem ' . intval($ri['changed']) : 'zatím neproběhlo') . '). Přepočet běží automaticky po aktualizaci.</span> ';
    echo '<button class="button" name="kb_recode_ded2" value="1">Přepočítat znovu</button></form>';
    echo '<form method="post" style="margin:6px 0">'; wp_nonce_field('kb_recode_ded');
    echo '<button class="button" name="kb_recode_ded" value="1" onclick="return confirm(\'Přepočítat Tvarové klíče (DED-24 v1.0–v1.2) podle nových časových limitů? Původní hodnoty zůstanou uložené vedle.\')">Přepočítat Tvarové klíče podle nových limitů</button> <span class="description">Jednorázově pro data sebraná před verzí DED-24-v1.3. Opakované spuštění nic nemění.</span></form>';
    echo '<p>Účastníků: <b>' . $np . '</b> · sezení: <b>' . $ns . '</b> · uložených odpovědí: <b>' . $nr . '</b></p>';
    echo '<p><a class="button button-primary" href="' . $exp('rows') . '">Stáhnout všechny odpovědi (CSV)</a> ';
    echo '<a class="button" href="' . $exp('scores') . '">Stáhnout výsledky testů (CSV)</a></p>';
    $tests = $wpdb->get_col("SELECT DISTINCT test_key FROM " . kb_table('rows') . " ORDER BY test_key");
    echo '<form method="get" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:8px 0 16px"><input type="hidden" name="action" value="kb_export"><input type="hidden" name="what" value="items">';
    wp_nonce_field('kb_export', '_wpnonce', false);
    echo '<b>Položky po testech (HS za položku):</b> <select name="test">';
    foreach ($tests as $t) { echo '<option value="' . esc_attr($t) . '">' . esc_html($t) . '</option>'; }
    echo '</select> <label><input type="checkbox" name="sondy" value="1"> včetně sond</label> <button class="button">Stáhnout (CSV)</button>';
    echo ' <a class="button" href="' . esc_url(KB_URL . 'assets/codebook.csv') . '">Číselník položek (CSV)</a>';
    echo '<br><span class="description">Řádek = osoba (víc sezení téže osoby se sloučí; při opakování položky platí první pokus), sloupec = ID položky, hodnota = body (prázdné = nezadáno, T = vypršel čas a nic nebylo označeno). Jen ostré položky, bez nácviku. Znění položek je v číselníku.</span></form>';
    echo '<p>Vložení na stránku: <code>[kognitivni_baterie]</code> (veřejná verze), <code>[kognitivni_baterie_admin]</code> (vaše verze, jen po přihlášení).</p>';
    echo '<h2>Výsledky podle testů</h2>';
    if ($dup > 0) {
        echo '<form method="post" style="margin:6px 0"><span style="color:#b32d2e">V databázi je ' . $dup . ' duplicitních výsledků (stejný test odeslaný v jednom sezení vícekrát – chyba odesílání do verze 3.36.0).</span> ';
        wp_nonce_field('kb_dedupe'); echo '<button class="button" name="kb_dedupe" value="1" onclick="return confirm(\'Smazat duplicitní výsledky? Ponechá se vždy první záznam.\')">Odstranit duplicity</button></form>';
    }
    echo '<p class="description">Osob = různí účastníci s dokončeným testem (výsledkem). Export po položkách obsahuje i nedokončená vyplnění, proto v něm může být osob víc.</p>';
    $head = '<table class="widefat striped"><thead><tr><th>Test</th><th>Verze</th><th>Osob</th><th>Sezení</th><th>Záznamů</th><th>Platných záznamů</th><th>Průměr</th></tr></thead><tbody>';
    $line = function ($x) { return '<tr><td>' . esc_html(kb_test_label($x->test_key)) . ' <span style="color:#888">(' . esc_html($x->test_key) . ')</span></td><td>' . esc_html($x->test_version) . '</td><td><b>' . intval($x->np) . '</b></td><td>' . intval($x->ns) . '</td><td>' . intval($x->n) . '</td><td>' . intval($x->nv) . '</td><td>' . ($x->m === null ? '–' : esc_html(round((float) $x->m, 2))) . '</td></tr>'; };
    $cur = array(); $old = array();
    foreach ($per as $x) { if (kb_test_hidden($x->test_key)) { $old[] = $x; continue; } if ($curv[$x->test_key][0] === $x->test_version) { $cur[] = $x; } else { $old[] = $x; } }
    usort($cur, function ($a, $b) { return kb_test_rank($a->test_key) - kb_test_rank($b->test_key); });
    echo '<h3>Současné verze</h3>' . $head;
    foreach ($cur as $x) { echo $line($x); }
    echo '</tbody></table>';
    echo '<details style="margin-top:10px"><summary><b>Starší verze a odvozené údaje</b> (' . count($old) . ' řádků)</summary>' . $head;
    foreach ($old as $x) { echo $line($x); }
    echo '</tbody></table></details>';
    echo '<h2>Posledních 50 sezení</h2><table class="widefat striped"><thead><tr><th>Sezení</th><th>Začátek (UTC)</th><th>Naposledy</th><th>Kód</th><th>Verze</th><th>Věk</th><th>ID</th></tr></thead><tbody>';
    foreach ($recent as $x) { echo '<tr><td>' . intval($x->id) . '</td><td>' . esc_html($x->started) . '</td><td>' . esc_html($x->last_seen) . '</td><td>' . esc_html($x->code) . '</td><td>' . esc_html($x->mode) . '</td><td>' . esc_html($x->age) . '</td><td>' . esc_html($x->a) . '… <a href="' . esc_url(home_url('/?kognitivni-baterie=nahled&id=' . $x->full)) . '" target="_blank">náhled</a></td></tr>'; }
    echo '</tbody></table>';
    echo '<h2>Náhled výsledků účastníka</h2><form method="get" action="' . esc_url(home_url('/')) . '" target="_blank"><input type="hidden" name="kognitivni-baterie" value="nahled"><input name="id" placeholder="celý identifikátor účastníka" size="40" required> <button class="button">Zobrazit výsledky, jak je vidí účastník</button></form><p class="description">Jen pro čtení: nic se neukládá a data účastníka se nemění. Odkaz „náhled“ je i u posledních sezení výše.</p>';
    $m0 = kb_correlation_matrix(null, 10);
    // uspořádání: kognitivní testy po oblastech, pak školní dovednosti, pak škály; bez DSM počtů a starých klíčů
    $ord = array();
    foreach ($m0['keys'] as $i => $k) { if (kb_corr_hidden($k)) { continue; } $ord[] = $i; }
    usort($ord, function ($a, $b) use ($m0) { return kb_test_rank($m0['keys'][$a]) - kb_test_rank($m0['keys'][$b]); });
    $m = array('keys' => array(), 'r' => array(), 'n' => array(), 'min_n' => $m0['min_n']);
    foreach ($ord as $ii => $i) { $m['keys'][$ii] = $m0['keys'][$i]; foreach ($ord as $jj => $j) { $m['r'][$ii][$jj] = $m0['r'][$i][$j]; $m['n'][$ii][$jj] = $m0['n'][$i][$j]; } }
    echo '<h2>Korelace mezi testy</h2>';
    if (!$m['keys']) { echo '<p>Zatím málo dat (každý test potřebuje aspoň ' . intval($m['min_n']) . ' lidí).</p>'; }
    else {
        $grp = function ($k) { return kb_test_group($k); };
        echo '<table class="widefat" style="width:auto;border-collapse:collapse"><thead><tr><th></th>';
        $prev = '';
        foreach (array_slice($m['keys'], 0, -1) as $k) { $g = $grp($k); echo '<th style="font-size:11px;vertical-align:bottom;' . ($g !== $prev ? 'border-left:3px solid #333;' : '') . '"><span style="color:#666">' . esc_html($g !== $prev ? $g : '') . '</span><br>' . esc_html(kb_test_label($k)) . '</th>'; $prev = $g; }
        echo '</tr></thead><tbody>';
        $prevr = '';
        foreach ($m['keys'] as $i => $a) {
            if ($i === 0) { continue; }   // jen dolní trojúhelník (od 2026-10-27)
            $ga = $grp($a);
            echo '<tr' . ($ga !== $prevr ? ' style="border-top:3px solid #333"' : '') . '><th style="text-align:left;font-size:12px;white-space:nowrap">' . esc_html(kb_test_label($a)) . '</th>'; $prevr = $ga;
            $prevc = '';
            foreach (array_slice($m['keys'], 0, -1) as $j => $b) {
                $gb = $grp($b); $bl = $gb !== $prevc ? 'border-left:3px solid #333;' : ''; $prevc = $gb;
                $v = $m['r'][$i][$j];
                if ($j >= $i) { echo '<td style="' . $bl . '"></td>'; continue; }
                if ($v === null) { echo '<td style="' . $bl . 'text-align:center;color:#999">·</td>'; continue; }
                $al = min(1, abs($v)) * 0.85 + 0.05; $bg = $v >= 0 ? "rgba(33,102,172,$al)" : "rgba(178,24,43,$al)";
                echo '<td style="' . $bl . 'text-align:center;background:' . $bg . ';color:' . (abs($v) > 0.5 ? '#fff' : '#222') . '" title="n = ' . intval($m['n'][$i][$j]) . '">' . esc_html(number_format($v, 2)) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table><p class="description">Modrá = kladný vztah, červená = opačný; sytost = síla vztahu. Počítá se z prvního platného výsledku každé osoby, všechna její sezení dohromady (vaše verze se slučuje podle kódu osoby); zobrazují se testy s aspoň ' . intval($m['min_n']) . ' lidmi (u malých čísel jsou korelace velmi nestabilní – číslo n je v bublině po najetí myší). Skryto: počty DSM symptomů a starší odvozené skóry.</p>';
    }
    if (current_user_can('manage_options')) {
        echo '<h2>Smazat data účastníka (GDPR)</h2><form method="post">';
        wp_nonce_field('kb_delete');
        echo '<input name="kb_delete" placeholder="celý identifikátor účastníka" size="40" required> <button class="button">Smazat</button></form>';
    }
    echo '</div>';
}

function kb_delete_participant($anon) {
    global $wpdb;
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . kb_table('participants') . " WHERE anon_id = %s", $anon));
    if (!$pid) { return 0; }
    $sids = $wpdb->get_col($wpdb->prepare("SELECT id FROM " . kb_table('sessions') . " WHERE participant_id = %d", $pid));
    $n = 0;
    foreach ($sids as $sid) { $n += (int) $wpdb->delete(kb_table('rows'), array('session_id' => $sid)); }
    $n += (int) $wpdb->delete(kb_table('scores'), array('participant_id' => $pid));
    $n += (int) $wpdb->delete(kb_table('sessions'), array('participant_id' => $pid));
    $n += (int) $wpdb->delete(kb_table('participants'), array('id' => $pid));
    return $n;
}

function kb_admin_settings() {
    if (!current_user_can('manage_options')) { return; }
    $s = get_option('kb_settings', array());
    if (isset($_POST['kb_save']) && check_admin_referer('kb_settings')) {
        $s['notify_email']   = sanitize_email(wp_unslash($_POST['notify_email']));
        $s['notify']         = (isset($_POST['notify']) && $_POST['notify'] === 'finished') ? 'finished' : 'none';
        $s['min_n']          = max(1, intval($_POST['min_n']));
        $s['public_enabled'] = empty($_POST['public_enabled']) ? 0 : 1;
        $s['privacy_url']    = esc_url_raw(wp_unslash($_POST['privacy_url']));
        update_option('kb_settings', $s);
        echo '<div class="notice notice-success"><p>Uloženo.</p></div>';
    }
    echo '<div class="wrap"><h1>Nastavení baterie</h1><form method="post">';
    wp_nonce_field('kb_settings');
    echo '<table class="form-table">';
    echo '<tr><th>Veřejná verze zapnutá</th><td><input type="checkbox" name="public_enabled" value="1" ' . checked(!empty($s['public_enabled']), true, false) . '></td></tr>';
    echo '<tr><th>E-mail pro upozornění</th><td><input type="email" name="notify_email" value="' . esc_attr(isset($s['notify_email']) ? $s['notify_email'] : '') . '" size="40"></td></tr>';
    echo '<tr><th>Posílat e-mail</th><td><select name="notify"><option value="finished" ' . selected(isset($s['notify']) ? $s['notify'] : '', 'finished', false) . '>po každém dokončeném testu</option><option value="none" ' . selected(isset($s['notify']) ? $s['notify'] : '', 'none', false) . '>neposílat</option></select></td></tr>';
    echo '<tr><th>Odkaz na zásady ochrany osobních údajů</th><td><input type="url" name="privacy_url" value="' . esc_attr(isset($s['privacy_url']) ? $s['privacy_url'] : '') . '" size="60"><br><span class="description">Když zůstane prázdné, použije se stránka zásad nastavená ve WordPressu.</span></td></tr>';
    echo '<tr><th>Minimální počet lidí pro zobrazení rozložení</th><td><input type="number" name="min_n" min="1" value="' . esc_attr(isset($s['min_n']) ? $s['min_n'] : 30) . '"></td></tr>';
    echo '</table><p><button class="button button-primary" name="kb_save" value="1">Uložit</button></p></form>';
    echo '<p><b>Data se při aktualizaci pluginu nemažou.</b> Nová verze baterie jen přidá nové testy; stávající výsledky zůstávají.</p></div>';
}

/* Matice V12: položka V12-32 vyřazena ze skórování (od 4.2.0 / EN 1.63.0; úspěšnost 1/31, zavádějící 2. vzorový řádek).
   Přepočet historických výsledků na 39 skórovaných položek: hrubý skór − 1, pokud osoba V12-32 vyřešila správně
   (původní hodnota v hruby_puvodni_40). Odpověď se hledá v sezení výsledku, u převzatých výsledků i v dřívějších
   sezeních téže osoby. Řádky odpovědí na V12-32 dostanou neskorovano = 1 (zůstávají pro položkovou analýzu).
   Nová verze M12-40-pilot-r3 má místo ní opravenou pilotní V12-32_r (neskórovaná, kalibrace zvlášť).
   Spouští se jednou při otevření administrace; opakované spuštění nic nemění (příznak prepocet_v1232). */
define('KB_M12_32_TAG', 'm12-v1232-neskorovano');
function kb_recode_m12_32() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $nR = 0; $nS = 0; $minus = 0;
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'matice12' AND data LIKE '%\"V12-32\"%'", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        if (!is_array($d) || !isset($d['id']) || $d['id'] !== 'V12-32' || !empty($d['neskorovano'])) { continue; }
        $d['neskorovano'] = 1; $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_M12_32_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, raw_score, data, mode, created FROM $SC WHERE test_key = 'matice12' AND test_version NOT IN ('M12-40-pilot-r3', 'M12-40-pilot-r4')", ARRAY_A);
    foreach ($scores as $sc) {
        if ($p_skip = ('kb' === 'kben' && $sc['mode'] === 'cz')) { continue; }       // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_v1232'])) { continue; }
        $cand = $wpdb->get_results($wpdb->prepare(
            "SELECT r.session_id, r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = 'matice12' AND r.data LIKE %s AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
            $sc['participant_id'], '%"V12-32"%', $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
        $ok = null;
        foreach ($cand as $c) {
            $d = json_decode((string) $c['data'], true);
            if (!is_array($d) || !isset($d['id']) || $d['id'] !== 'V12-32' || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
            $ok = (isset($d['spravne']) && intval($d['spravne']) === 1) ? 1 : 0; break;
        }
        $sd['prepocet_v1232'] = 1; $sd['v1232_spravne'] = $ok === null ? 'nezadano' : $ok;
        $sd['hruby_puvodni_40'] = $sc['raw_score'];
        $raw = $sc['raw_score'];
        if ($ok === 1 && $raw !== null && $raw !== '') { $raw = floatval($raw) - 1; $minus++; }
        $sd['hruby'] = $raw;
        if (isset($sd['polozek']) && intval($sd['polozek']) === 40) { $sd['polozek'] = 39; }
        if ($ok !== null && isset($sd['administrovano']) && is_numeric($sd['administrovano'])) { $sd['administrovano_puvodni_40'] = $sd['administrovano']; $sd['administrovano'] = intval($sd['administrovano']) - 1; }
        if ($ok === 1 && isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) { $sd['spravne_administrovane'] = intval($sd['spravne_administrovane']) - 1; }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    $info = array('tag' => KB_M12_32_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'minus1' => $minus, 'rows' => $nR);
    update_option('kb_m12_32_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_m12_32_recode');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_M12_32_TAG) && current_user_can('edit_posts')) { kb_recode_m12_32(); }
});

/* Matice V12: u V12-34_r a V12-35_r2 je odpověď A obhajitelná (druhé pravidlo, které sedí na všechny vzory) → částečný kredit 0,5.
   (4.2.1 / EN 1.63.1 dávala za A plný bod; od 4.2.2 / EN 1.63.2 jen 0,5.) Přepočet historie: řádky s A dostanou spravne = 0, skore = 0,5,
   castecne = 1 (původní spravne ve spravne_puvodni_dvojklic); hrubý skór výsledku se upraví podle toho, co už obsahoval:
   A dosud za 0 → +0,5, A už za 1 (přepočet 4.2.1 nebo běh v 4.2.1) → −0,5, A už za 0,5 → beze změny (původní skór v hruby_pred_castecne).
   Odpověď se hledá jako u V12-32 (sezení výsledku, u převzatých výsledků i dřívější sezení). Verze testu se nemění. Spouští se jednou. */
define('KB_M12_PC_TAG', 'm12-castecne-34r-35r2');
function kb_recode_m12_castecne() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $IDS = array('V12-34_r', 'V12-35_r2');
    $isAlt = function ($d) use ($IDS) {
        return is_array($d) && isset($d['id']) && in_array($d['id'], $IDS, true) && isset($d['odpoved']) && $d['odpoved'] === 'A';
    };
    // 1) výsledky (před úpravou řádků – podle řádků se pozná, co skór dosud obsahoval)
    $nS = 0; $chg = 0;
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, raw_score, data, mode, created FROM $SC WHERE test_key = 'matice12'", ARRAY_A);
    foreach ($scores as $sc) {
        if ('kb' === 'kben' && $sc['mode'] === 'cz') { continue; }       // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_castecne'])) { continue; }
        $delta = 0.0; $found = array();
        foreach ($IDS as $iid) {
            $cand = $wpdb->get_results($wpdb->prepare(
                "SELECT r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = 'matice12' AND r.data LIKE %s AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
                $sc['participant_id'], '%"' . $iid . '"%', $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
            foreach ($cand as $c) {
                $d = json_decode((string) $c['data'], true);
                if (!is_array($d) || !isset($d['id']) || $d['id'] !== $iid || (isset($d['faze']) && $d['faze'] !== 'test')) { continue; }
                if ($isAlt($d)) {
                    if (!empty($d['castecne'])) { /* už 0,5 */ }
                    elseif (isset($d['spravne']) && intval($d['spravne']) === 1) { $delta -= 0.5; $found[] = $iid . ':1→0,5'; }
                    else { $delta += 0.5; $found[] = $iid . ':0→0,5'; }
                }
                break;
            }
        }
        $sd['prepocet_castecne'] = 1; $sd['castecne_polozky'] = implode(' ', $found);
        $raw = $sc['raw_score'];
        if ($delta != 0 && $raw !== null && $raw !== '') {
            $sd['hruby_pred_castecne'] = $raw; $raw = floatval($raw) + $delta; $chg++;
            $sd['hruby'] = $raw;
            if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) { $sd['spravne_administrovane'] = floatval($sd['spravne_administrovane']) + $delta; }
        }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    // 2) řádky odpovědí
    $nR = 0;
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'matice12' AND (data LIKE '%\"V12-34_r\"%' OR data LIKE '%\"V12-35_r2\"%')", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        if (!$isAlt($d) || !empty($d['castecne'])) { continue; }
        if (!isset($d['spravne_puvodni_dvojklic'])) { $d['spravne_puvodni_dvojklic'] = isset($d['spravne']) ? $d['spravne'] : ''; }
        $d['spravne'] = 0; $d['skore'] = 0.5; $d['castecne'] = 1; $d['alt_klic'] = 1;
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_M12_PC_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $info = array('tag' => KB_M12_PC_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'zmeneno' => $chg, 'rows' => $nR);
    update_option('kb_m12_pc_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_m12_pc_recode');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_M12_PC_TAG) && current_user_can('edit_posts')) { kb_recode_m12_castecne(); }
}, 20);

/* Matice V12: u staré V12-18_r je odpověď A („jen obrácené pořadí“) obhajitelná – barvy jdou číst jako prohození dvou pozic
   a ve vzorech chybělo právě prohození 1–3 (zjištěno 18. 10. 2026, r/cognitiveTesting; v datech nejčastější chyba).
   Od 4.5.8 / EN 1.65.7 / děti 1.3.8: přepočet historie jako u V12-34_r a V12-35_r2 – řádky s A dostanou spravne = 0, skore = 0,5,
   castecne = 1 (původní spravne ve spravne_puvodni_dvojklic), hrubý skór výsledku +0,5 (původní v hruby_pred_castecne18).
   Nová V12-18_r3 (od 4.5.9; r2 jen v 4.5.7–4.5.8) má třetí vzorový řádek a obhajitelnou druhou odpověď nemá. Verze testu se nemění. Spouští se jednou. */
define('KB_M12_PC18_TAG', 'm12-castecne-18r');
function kb_recode_m12_castecne18() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $iid = 'V12-18_r';
    $isAlt = function ($d) use ($iid) {
        return is_array($d) && isset($d['id']) && $d['id'] === $iid && isset($d['odpoved']) && $d['odpoved'] === 'A'
            && (!isset($d['chyba_typ']) || $d['chyba_typ'] === '' || $d['chyba_typ'] === 'reverse_only');
    };
    $nS = 0; $chg = 0;
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, raw_score, data, mode, created FROM $SC WHERE test_key = 'matice12'", ARRAY_A);
    foreach ($scores as $sc) {
        if ('kb' === 'kben' && $sc['mode'] === 'cz') { continue; }       // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_castecne18'])) { continue; }
        $cand = $wpdb->get_results($wpdb->prepare(
            "SELECT r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = 'matice12' AND r.data LIKE %s AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
            $sc['participant_id'], '%"' . $iid . '"%', $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
        $delta = 0.0; $found = '';
        foreach ($cand as $c) {
            $d = json_decode((string) $c['data'], true);
            if (!is_array($d) || !isset($d['id']) || $d['id'] !== $iid || (isset($d['faze']) && $d['faze'] !== 'test') || !empty($d['neskorovano'])) { continue; }
            if ($isAlt($d) && empty($d['castecne'])) {
                if (isset($d['spravne']) && intval($d['spravne']) === 1) { $delta -= 0.5; $found = $iid . ':1→0,5'; }
                else { $delta += 0.5; $found = $iid . ':0→0,5'; }
            }
            break;
        }
        $sd['prepocet_castecne18'] = 1; if ($found !== '') { $sd['castecne_polozky'] = trim((isset($sd['castecne_polozky']) ? $sd['castecne_polozky'] . ' ' : '') . $found); }
        $raw = $sc['raw_score'];
        if ($delta != 0 && $raw !== null && $raw !== '') {
            $sd['hruby_pred_castecne18'] = $raw; $raw = floatval($raw) + $delta; $chg++;
            $sd['hruby'] = $raw;
            if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) { $sd['spravne_administrovane'] = floatval($sd['spravne_administrovane']) + $delta; }
            $sd['castecne'] = (isset($sd['castecne']) && is_numeric($sd['castecne']) ? intval($sd['castecne']) : 0) + 1;
        }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    $nR = 0;
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'matice12' AND data LIKE '%\"V12-18_r\"%'", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        if (!$isAlt($d) || !empty($d['castecne'])) { continue; }
        if (!isset($d['spravne_puvodni_dvojklic'])) { $d['spravne_puvodni_dvojklic'] = isset($d['spravne']) ? $d['spravne'] : ''; }
        $d['spravne'] = 0; $d['skore'] = 0.5; $d['castecne'] = 1; $d['alt_klic'] = 1;
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_M12_PC18_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $info = array('tag' => KB_M12_PC18_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'zmeneno' => $chg, 'rows' => $nR);
    update_option('kb_m12_pc18_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_m12_pc18_recode');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_M12_PC18_TAG) && current_user_can('edit_posts')) { kb_recode_m12_castecne18(); }
}, 21);

/* Škála ADHD: 4.2.3 omylem vyřadila IMP_10, EXE_16, HYP_12 a přepočítala vyplnění v13. Od 4.2.4 je škála zase v13 se 120 položkami.
   Pokud přepočet z 4.2.3 proběhl, vrátí se původní hodnoty (pred_vyrazenim_v14 / hruby_pred_v14). Případná vyplnění označená ADHD-v14
   (117 položek) zůstávají ve stejné skupině srovnání. Spouští se jednou při otevření administrace. */
define('KB_ADHD14_UNDO_TAG', 'adhd-v14-vraceno');
function kb_adhd_v14_undo() {
    global $wpdb;
    $SC = kb_table('scores'); $n = 0;
    $rows = $wpdb->get_results("SELECT id, raw_score, data FROM $SC WHERE data LIKE '%prepocet_v14%'", ARRAY_A);
    foreach ($rows as $x) {
        $d = json_decode((string) $x['data'], true); if (!is_array($d) || empty($d['prepocet_v14'])) { continue; }
        $raw = $x['raw_score'];
        if (isset($d['pred_vyrazenim_v14']) && is_array($d['pred_vyrazenim_v14'])) { foreach ($d['pred_vyrazenim_v14'] as $k => $v) { $d[$k] = $v; } }
        if (array_key_exists('hruby_pred_v14', $d)) { $raw = $d['hruby_pred_v14']; }
        unset($d['pred_vyrazenim_v14'], $d['hruby_pred_v14'], $d['prepocet_v14']);
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($d)), array('id' => $x['id'])); $n++;
    }
    $info = array('tag' => KB_ADHD14_UNDO_TAG, 'cas' => current_time('mysql'), 'vraceno' => $n);
    update_option('kb_adhd14_undo', $info);
    return $info;
}
add_action('admin_init', function () {
    $i = get_option('kb_adhd14_undo');
    if ((!is_array($i) || !isset($i['tag']) || $i['tag'] !== KB_ADHD14_UNDO_TAG) && current_user_can('edit_posts')) { kb_adhd_v14_undo(); }
}, 20);

/* Matice V12 – banka M12-34-r13 (od CZ 4.8.0 / EN 1.69.0 / děti 1.6.0 / gifted 1.2.0): skórovaná sada 34 položek.
   Ze skóre vyřazeny V12-37_r2, V12-36_r, V12-35_r3 (r položka–test 0,24–0,28; obtížnost z navazujících kroků a podmínek),
   do skóre zařazeny dřívější funkční piloty V12-41, V12-47, V12-42, V12-57 (a 1,6–1,9; už v r10 se počítaly do ukončení).
   Přepočet výsledků M12-33-r10 až r12 na skórování r13: hrubý skór − body za vyřazené + body za zařazené položky
   (body z řádků odpovědí: správně = 1, částečný kredit = skore; nezadaná položka = 0). Odpovědi se hledají v sezení výsledku,
   u převzatých výsledků i v dřívějších sezeních téže osoby. Původní hodnoty zůstávají v datech (hruby_pred_r13 aj.).
   Řádky vyřazených položek dostanou neskorovano = 1, u zařazených se příznak neskorovano zruší (zůstávají pro položkovou analýzu).
   Běží při každém otevření administrace, ale zpracuje jen dosud nepřepočítané výsledky (příznak prepocet_r13) – zachytí
   i výsledky odeslané později ze starší, v prohlížeči uložené verze aplikace. */
define('KB_M12_R13_TAG', 'm12-r13-skorovani');
function kb_recode_m12_r13() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $OUT = array('V12-37_r2', 'V12-36_r', 'V12-35_r3'); $IN = array('V12-41', 'V12-47', 'V12-42', 'V12-57');
    $ALL = array_merge($OUT, $IN);
    $nS = 0; $nR = 0;
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, raw_score, data, mode, created FROM $SC WHERE test_key = 'matice12' AND test_version IN ('M12-33-r10', 'M12-33-r11', 'M12-33-r12') AND (data IS NULL OR data NOT LIKE '%prepocet_r13%')", ARRAY_A);
    foreach ($scores as $sc) {
        if (false && $sc['mode'] === 'cz') { continue; }      // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_r13'])) { continue; }
        $cand = $wpdb->get_results($wpdb->prepare(
            "SELECT r.session_id, r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = 'matice12' AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
            $sc['participant_id'], $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
        $pts = array(); $ok = array();
        foreach ($cand as $c) {
            $d = json_decode((string) $c['data'], true);
            if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }
            $id = isset($d['polozka']) ? (string) $d['polozka'] : (isset($d['id']) ? (string) $d['id'] : '');
            if (!in_array($id, $ALL, true) || array_key_exists($id, $pts)) { continue; }
            if (!isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
            $pts[$id] = intval($d['spravne']) ? 1 : ((!empty($d['castecne']) && isset($d['skore']) && is_numeric($d['skore'])) ? floatval($d['skore']) : 0);
            $ok[$id] = intval($d['spravne']) ? 1 : 0;
        }
        $minus = 0; $plus = 0;
        foreach ($OUT as $id) { if (isset($pts[$id])) { $minus += $pts[$id]; } }
        foreach ($IN as $id) { if (isset($pts[$id])) { $plus += $pts[$id]; } }
        $raw = $sc['raw_score'];
        $sd['prepocet_r13'] = 1; $sd['hruby_pred_r13'] = $raw; $sd['r13_odecteno'] = $minus; $sd['r13_pricteno'] = $plus;
        $sd['r13_polozky'] = (object) $pts; $sd['verze_puvodni_r13'] = isset($sd['verze']) ? $sd['verze'] : '';
        if ($raw !== null && $raw !== '') { $raw = round(floatval($raw) - $minus + $plus, 2); }
        $sd['hruby'] = $raw;
        if (isset($sd['polozek']) && intval($sd['polozek']) === 33) { $sd['polozek'] = 34; }
        if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) {
            $sd['spravne_administrovane_pred_r13'] = $sd['spravne_administrovane'];
            $sd['spravne_administrovane'] = intval($sd['spravne_administrovane']) - array_sum(array_intersect_key($ok, array_flip($OUT))) + array_sum(array_intersect_key($ok, array_flip($IN)));
        }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    /* příznaky v řádcích (jednou; dál jen nové řádky) */
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'matice12' AND data NOT LIKE '%" . KB_M12_R13_TAG . "%' AND (data LIKE '%\"V12-37_r2\"%' OR data LIKE '%\"V12-36_r\"%' OR data LIKE '%\"V12-35_r3\"%' OR data LIKE '%\"V12-41\"%' OR data LIKE '%\"V12-47\"%' OR data LIKE '%\"V12-42\"%' OR data LIKE '%\"V12-57\"%')", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        $id = is_array($d) ? (isset($d['polozka']) ? (string) $d['polozka'] : (isset($d['id']) ? (string) $d['id'] : '')) : '';
        if (!in_array($id, $ALL, true)) { continue; }
        if (in_array($id, $OUT, true)) { $d['neskorovano'] = 1; } else { $d['neskorovano'] = ''; $d['skorovano_od_r13'] = 1; }
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_M12_R13_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $prev = get_option('kb_m12_r13_recode'); $tot = is_array($prev) && isset($prev['scores_celkem']) ? intval($prev['scores_celkem']) : 0;
    $info = array('tag' => KB_M12_R13_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'scores_celkem' => $tot + $nS, 'rows' => $nR);
    if ($nS || $nR || !is_array($prev)) { update_option('kb_m12_r13_recode', $info); }
    return $info;
}
add_action('admin_init', function () {
    if (current_user_can('edit_posts')) { kb_recode_m12_r13(); }
}, 22);

/* Matice V12 – banka M12-35-r15 (od CZ 4.9.0 / EN 1.70.0 / děti 1.7.0 / gifted 1.3.0): skórovaná sada 35 položek.
   Do skóre zařazena dřívější funkční pilotní položka V12-53 (a 1,44; od r10 se počítala do ukončení, takže pravidlo ukončení
   se nemění). Pilot V12-38_r4 vyřazen z banky (neskórovaný, skóre se nemění).
   Přepočet výsledků M12-33-r10 až M12-34-r14 na skórování r15: hrubý skór + body za V12-53 (z řádků odpovědí; nezadaná = 0).
   Výsledky r10–r12 se přepočítají až po přepočtu r13 (příznak prepocet_r13), aby se oba kroky nesčítaly špatně.
   Původní hodnoty zůstávají v datech (hruby_pred_r15 aj.); řádky V12-53 dostanou skorovano_od_r15 = 1 a neskorovano = ''.
   Běží při každém otevření administrace, ale zpracuje jen dosud nepřepočítané výsledky (příznak prepocet_r15). */
define('KB_M12_R15_TAG', 'm12-r15-skorovani');
function kb_recode_m12_r15() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $OUT = array(); $IN = array('V12-53');
    $ALL = array_merge($OUT, $IN);
    $nS = 0; $nR = 0;
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, raw_score, data, mode, created, test_version FROM $SC WHERE test_key = 'matice12' AND test_version IN ('M12-33-r10', 'M12-33-r11', 'M12-33-r12', 'M12-34-r13', 'M12-34-r14') AND (data IS NULL OR data NOT LIKE '%prepocet_r15%')", ARRAY_A);
    foreach ($scores as $sc) {
        if (false && $sc['mode'] === 'cz') { continue; }      // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_r15'])) { continue; }
        if (strpos((string) $sc['data'], 'prepocet_r13') === false && !in_array($sc['test_version'], array('M12-34-r13', 'M12-34-r14'), true)) { continue; }   // nejdřív přepočet r13
        $cand = $wpdb->get_results($wpdb->prepare(
            "SELECT r.session_id, r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = 'matice12' AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
            $sc['participant_id'], $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
        $pts = array(); $ok = array();
        foreach ($cand as $c) {
            $d = json_decode((string) $c['data'], true);
            if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }
            $id = isset($d['polozka']) ? (string) $d['polozka'] : (isset($d['id']) ? (string) $d['id'] : '');
            if (!in_array($id, $ALL, true) || array_key_exists($id, $pts)) { continue; }
            if (!isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
            $pts[$id] = intval($d['spravne']) ? 1 : ((!empty($d['castecne']) && isset($d['skore']) && is_numeric($d['skore'])) ? floatval($d['skore']) : 0);
            $ok[$id] = intval($d['spravne']) ? 1 : 0;
        }
        $minus = 0; $plus = 0;
        foreach ($OUT as $id) { if (isset($pts[$id])) { $minus += $pts[$id]; } }
        foreach ($IN as $id) { if (isset($pts[$id])) { $plus += $pts[$id]; } }
        $raw = $sc['raw_score'];
        $sd['prepocet_r15'] = 1; $sd['hruby_pred_r15'] = $raw; $sd['r15_odecteno'] = $minus; $sd['r15_pricteno'] = $plus;
        $sd['r15_polozky'] = (object) $pts; $sd['verze_puvodni_r15'] = isset($sd['verze']) ? $sd['verze'] : '';
        if ($raw !== null && $raw !== '') { $raw = round(floatval($raw) - $minus + $plus, 2); }
        $sd['hruby'] = $raw;
        if (isset($sd['polozek']) && intval($sd['polozek']) === 34) { $sd['polozek'] = 35; }
        if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) {
            $sd['spravne_administrovane_pred_r15'] = $sd['spravne_administrovane'];
            $sd['spravne_administrovane'] = intval($sd['spravne_administrovane']) - array_sum(array_intersect_key($ok, array_flip($OUT))) + array_sum(array_intersect_key($ok, array_flip($IN)));
        }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    /* příznaky v řádcích (jednou; dál jen nové řádky) */
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key = 'matice12' AND data NOT LIKE '%" . KB_M12_R15_TAG . "%' AND data LIKE '%\"V12-53\"%'", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        $id = is_array($d) ? (isset($d['polozka']) ? (string) $d['polozka'] : (isset($d['id']) ? (string) $d['id'] : '')) : '';
        if (!in_array($id, $ALL, true)) { continue; }
        if (in_array($id, $OUT, true)) { $d['neskorovano'] = 1; } else { $d['neskorovano'] = ''; $d['skorovano_od_r15'] = 1; }
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_M12_R15_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $prev = get_option('kb_m12_r15_recode'); $tot = is_array($prev) && isset($prev['scores_celkem']) ? intval($prev['scores_celkem']) : 0;
    $info = array('tag' => KB_M12_R15_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'scores_celkem' => $tot + $nS, 'rows' => $nR);
    if ($nS || $nR || !is_array($prev)) { update_option('kb_m12_r15_recode', $info); }
    return $info;
}
add_action('admin_init', function () {
    if (current_user_can('edit_posts')) { kb_recode_m12_r15(); }
}, 23);

/* Gc (Jak se to nazývá, Všeobecné znalosti) – klíč GCS-55-v3 / GCZ-50-v3 (od CZ 4.9.4 / EN 1.70.4 / děti 1.7.4 / gifted 1.3.4):
   nově se uznávají slovenské ekvivalenty klíčového slova (nožnice, žubrienka, štrajk, slnko) a překlepy / zjevné varianty
   (pendemie, insektologie, anektace, Boží hod, 24. 12., 0sm, kořenem, kaler IV, 45, Anstein, Spojené národy, romanovovci).
   Odpovědi s více možnostmi, z nichž některá je chybná, se dál neuznávají; SZ15 dál jen „tlumočník“.
   Přepočet výsledků GCS-55-v1/v2 a GCZ-50-v1/v2: + 1 bod za každou dřív chybnou odpověď, kterou nový klíč uznává
   (seznam normalizovaných odpovědí vznikl z dat: nový klíč puštěný na všechny uložené chybné odpovědi). Řádky se opraví
   (spravne = 1, prepocet gc3-klic). Pravidlo ukončení se zpětně nemění. Původní hodnoty v hruby_pred_gc3.
   Verze 40 se nepřepočítávají (jiné přiřazení čísel položek). Běží při otevření administrace, jen pro dosud nepřepočítané. */
define('KB_GC3_TAG', 'gc3-klic');
function kb_gc3_norm($s) {
    $s = mb_strtolower((string) $s, 'UTF-8');
    if (class_exists('Normalizer')) { $s = preg_replace('/\p{Mn}+/u', '', Normalizer::normalize($s, Normalizer::FORM_D)); }
    elseif (function_exists('remove_accents')) { $s = remove_accents($s); }
    $s = preg_replace('/[„“”"\'’‚`´.,:!?()\[\]°–—-]/u', ' ', $s);
    $s = trim(preg_replace('/\s+/u', ' ', $s));
    $ord = array('iv' => '4', 'ctvrty' => '4', 'ctvrteho' => '4', 'iii' => '3', 'treti' => '3', 'ii' => '2');
    return implode(' ', array_map(function ($w) use ($ord) { return isset($ord[$w]) ? $ord[$w] : $w; }, explode(' ', $s)));
}
function kb_gc3_flip() { return array('SZ04' => array('niznice', 'noznice'), 'SZ06' => array('zubrienka'), 'SZ19' => array('strajk'), 'SZ22' => array('pendemie'), 'SZ31' => array('insectologie', 'insektologie', 'insektomologie'), 'SZ36' => array('anektace'), 'ZN04' => array('24 12', 'bozi hod'), 'ZN06' => array('0sm'), 'ZN07' => array('korem', 'korenem'), 'ZN09' => array('slnko'), 'ZN14' => array('kaler 4'), 'ZN15' => array('45'), 'ZN17' => array('anstein'), 'ZN27' => array('spojene narody'), 'ZN47' => array('romanovovci')); }
function kb_recode_gc3() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores'); $SE = kb_table('sessions');
    $FL = kb_gc3_flip(); $OLD = array('GCS-55-v1', 'GCS-55-v2', 'GCZ-50-v1', 'GCZ-50-v2'); $IND = array('gcslovni' => 'slovni', 'gcznalosti' => 'znalosti');
    $nS = 0; $nR = 0;
    $hit = function ($d) use ($FL, $OLD) {     // řádek s odpovědí, kterou nový klíč uznává (a starý ne)
        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { return ''; }
        if (!in_array(isset($d['forma']) ? $d['forma'] : '', $OLD, true)) { return ''; }
        $id = isset($d['polozka']) ? (string) $d['polozka'] : (isset($d['id']) ? (string) $d['id'] : '');
        if (!isset($FL[$id]) || !isset($d['odpoved'])) { return ''; }
        $was0 = (isset($d['spravne']) && intval($d['spravne']) === 0) || (isset($d['prepocet']) && strpos($d['prepocet'], KB_GC3_TAG) !== false);
        return ($was0 && in_array(kb_gc3_norm($d['odpoved']), $FL[$id], true)) ? $id : '';
    };
    $scores = $wpdb->get_results("SELECT id, session_id, participant_id, test_key, raw_score, data, mode, created FROM $SC WHERE test_key IN ('gcslovni', 'gcznalosti') AND test_version IN ('GCS-55-v1', 'GCS-55-v2', 'GCZ-50-v1', 'GCZ-50-v2') AND (data IS NULL OR data NOT LIKE '%prepocet_gc3%')", ARRAY_A);
    foreach ($scores as $sc) {
        if (false && $sc['mode'] === 'cz') { continue; }      // importované české výsledky: obnoví je nový import
        $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
        if (!empty($sd['prepocet_gc3'])) { continue; }
        $cand = $wpdb->get_results($wpdb->prepare(
            "SELECT r.session_id, r.data FROM $R r JOIN $SE s ON s.id = r.session_id WHERE s.participant_id = %d AND r.test_key = %s AND (r.session_id = %d OR r.created <= %s) ORDER BY (r.session_id = %d) DESC, r.id DESC",
            $sc['participant_id'], $sc['test_key'], $sc['session_id'], $sc['created'] ? $sc['created'] : current_time('mysql', true), $sc['session_id']), ARRAY_A);
        $got = array();
        foreach ($cand as $c) { $id = $hit(json_decode((string) $c['data'], true)); if ($id !== '') { $got[$id] = 1; } }
        $plus = count($got); $raw = $sc['raw_score'];
        $sd['prepocet_gc3'] = 1; $sd['hruby_pred_gc3'] = $raw; $sd['gc3_pricteno'] = $plus; $sd['gc3_polozky'] = implode(' ', array_keys($got));
        if ($plus) {
            if ($raw !== null && $raw !== '') { $raw = round(floatval($raw) + $plus, 2); }
            $sd['hruby'] = $raw;
            if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) { $sd['spravne_administrovane'] = intval($sd['spravne_administrovane']) + $plus; }
            $k = $IND[$sc['test_key']];
            if (isset($sd['indikatory'][$k]) && is_array($sd['indikatory'][$k])) {
                foreach (array('hruby', 'spravne') as $f) { if (isset($sd['indikatory'][$k][$f]) && is_numeric($sd['indikatory'][$k][$f])) { $sd['indikatory'][$k][$f] += $plus; } }
            }
            if (isset($sd['korelace'][$sc['test_key'] . '_' . $k]) && is_numeric($sd['korelace'][$sc['test_key'] . '_' . $k])) { $sd['korelace'][$sc['test_key'] . '_' . $k] += $plus; }
        }
        $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
    }
    $like = implode(' OR ', array_map(function ($id) { return "data LIKE '%\"" . $id . "\"%'"; }, array_keys($FL)));
    $rows = $wpdb->get_results("SELECT id, data FROM $R WHERE test_key IN ('gcslovni', 'gcznalosti') AND data NOT LIKE '%" . KB_GC3_TAG . "%' AND ($like)", ARRAY_A);
    foreach ($rows as $r) {
        $d = json_decode((string) $r['data'], true);
        if ($hit($d) === '') { continue; }
        $d['spravne'] = 1; $d['skore'] = 1; $d['chyby'] = 'varianta (klíč v3)';
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_GC3_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $prev = get_option('kb_gc3_recode'); $tot = is_array($prev) && isset($prev['scores_celkem']) ? intval($prev['scores_celkem']) : 0;
    $info = array('tag' => KB_GC3_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'scores_celkem' => $tot + $nS, 'rows' => $nR);
    if ($nS || $nR || !is_array($prev)) { update_option('kb_gc3_recode', $info); }
    return $info;
}
add_action('admin_init', function () {
    if (current_user_can('edit_posts')) { kb_recode_gc3(); }
}, 24);


/* Přetahovaná: celé správné pořadí, které člověk při vypršení 45 s nepotvrdil, se od CZ 4.18.2 / EN 1.76.2 počítá jako správné.
   Přepočet historie (spouští se v administraci, přírůstkově – zachytí i odpovědi ze starých otevřených stránek, které se odešlou až po aktualizaci):
   1) výsledky: k hrubému skóru se přičtou dosud neuznané úlohy (fáze test, timeout = 1, celé pořadí = řešení, spravne = 0) z běhu, ke kterému výsledek patří
      (běh v sezení výsledku se stejnou verzí testu a se stejným počtem administrovaných a správných úloh); sondy_spravne obdobně.
      Původní skór zůstává v hruby_pred_limitem. ukonceni_mozna_predcasne = 1, když mezi posledními 4 „chybami“, po kterých test skončil, byla teď uznaná úloha
      (s novým pravidlem by člověk pokračoval – skór je pak spíš podhodnocený).
   2) řádky: spravne = 1, skore = 1, nepotvrzeno = 1, uznano_po_limitu = 1, původní hodnota ve spravne_puvodni_limit, značka v prepocet.
   Verze testu se nemění (stejná skupina srovnání). */
define('KB_PT_LIMIT_TAG', 'pt-limit-uznano');
function kb_pt_rescue($d) {   // nepotvrzené, ale celé správné pořadí, zatím neuznané
    return is_array($d) && !empty($d['timeout']) && empty($d['preskoceno']) && isset($d['odpoved'], $d['reseni']) && $d['odpoved'] !== '' && $d['odpoved'] === $d['reseni']
        && !(isset($d['spravne']) && is_numeric($d['spravne']) && floatval($d['spravne']) >= 1);
}
function kb_recode_pt_limit() {
    global $wpdb;
    $R = kb_table('rows'); $SC = kb_table('scores');
    $rescue = 'kb_pt_rescue';
    /* zpracují se všechny dosud neoznačené výsledky (napoprvé celá historie, pak jen nové) a jejich sezení. Úloha se přičte, když ji uznává
       nové pravidlo, ale výsledek ji ještě nemá: řádek dosud neuznaný, nebo už přepočítaný tímto přepočtem (spravne_puvodni_limit) – to je případ
       výsledku ze staré otevřené stránky, který dorazil až po přepočtu řádků. Výsledky z nové verze aplikace mají uznané úlohy už v hrubém skóru. */
    $cand = $wpdb->get_results("SELECT id, session_id, data FROM $R WHERE test_key = 'pretahovana' AND data LIKE '%\"timeout\":1%' AND data NOT LIKE '%" . KB_PT_LIMIT_TAG . "%'", ARRAY_A);
    $SCL = $wpdb->get_results($wpdb->prepare("SELECT id, session_id, raw_score, data, test_version, mode FROM $SC WHERE test_key = 'pretahovana' AND (data IS NULL OR data NOT LIKE %s) ORDER BY id ASC",
        '%' . $wpdb->esc_like(KB_PT_LIMIT_TAG) . '%'), ARRAY_A);
    $bySess = array(); foreach ($SCL as $sc) { $bySess[intval($sc['session_id'])][] = $sc; }
    $nS = 0; $plus = 0; $nf = 0;
    foreach ($bySess as $sid => $scores) {
        /* běhy v sezení: nový běh při značce novy_pokus / znovu_po_neresenem nebo při opakování položky */
        $rows = $wpdb->get_results($wpdb->prepare("SELECT id, data FROM $R WHERE session_id = %d AND test_key = 'pretahovana' ORDER BY client_seq ASC, id ASC", $sid), ARRAY_A);
        $runs = array(); $cur = null;
        foreach ($rows as $r) {
            $d = json_decode((string) $r['data'], true); if (!is_array($d)) { continue; }
            if (isset($d['polozka']) && in_array($d['polozka'], array('novy_pokus', 'znovu_po_neresenem'), true)) { $cur = null; continue; }
            if (!isset($d['faze']) || !in_array($d['faze'], array('test', 'sonda'), true)) { continue; }
            if (!empty($d['pilot'])) { continue; }                           // od CZ 4.22.0 / EN 1.81.0: neskórovaný pilotní blok PN do skóre nepatří
            $f = isset($d['forma']) ? (string) $d['forma'] : ''; $id = isset($d['id']) ? (string) $d['id'] : '';
            if ($d['faze'] === 'test' && ($cur === null || $runs[$cur]['f'] !== $f || isset($runs[$cur]['ids'][$id]) || $runs[$cur]['sondy'])) {
                $runs[] = array('f' => $f, 'ids' => array(), 'n' => 0, 'ok' => 0, 'plus' => 0, 'seq' => array(), 'sondy' => 0, 'sondy_plus' => 0, 'used' => 0); $cur = count($runs) - 1; }
            if ($cur === null) { continue; }
            $was = isset($d['spravne_puvodni_limit']);                        // uznané tímto přepočtem (výsledek ho ještě nemusí mít)
            $res = $rescue($d) || $was;
            if ($d['faze'] === 'sonda') { $runs[$cur]['sondy']++; if ($res) { $runs[$cur]['sondy_plus']++; } continue; }
            $runs[$cur]['ids'][$id] = 1; $runs[$cur]['n']++;
            $okNow = !$was && isset($d['spravne']) && is_numeric($d['spravne']) && floatval($d['spravne']) >= 1;   // správně už v původním skóru
            if ($okNow) { $runs[$cur]['ok']++; }
            if ($res) { $runs[$cur]['plus']++; }
            $runs[$cur]['seq'][] = $res ? 'u' : ($okNow ? 'c' : 'w');
        }
        foreach ($scores as $sc) {
            $sd = json_decode((string) $sc['data'], true); if (!is_array($sd)) { $sd = array(); }
            if (isset($sd['prevzato']) || isset($sd['prevzato_z']) || ('kb' === 'kben' && $sc['mode'] === 'cz')) {   // importy: přepočítá je zdrojová verze a nový import
                $sd['prepocet_pt_limit'] = KB_PT_LIMIT_TAG; $sd['pt_limit_beh'] = 'import'; $wpdb->update($SC, array('data' => wp_json_encode($sd)), array('id' => $sc['id'])); continue; }
            $adm = isset($sd['administrovano']) && is_numeric($sd['administrovano']) ? intval($sd['administrovano']) : null; $raw = $sc['raw_score'];
            $hit = null;
            foreach ($runs as $i => $ru) { if ($ru['used'] || $ru['f'] !== (string) $sc['test_version']) { continue; }
                if (($adm === null || $ru['n'] === $adm) && $raw !== null && $raw !== '' && intval(round(floatval($raw))) === $ru['ok']) { $hit = $i; } }
            if ($hit === null) { $same = array_keys(array_filter($runs, function ($ru) use ($sc) { return !$ru['used'] && $ru['f'] === (string) $sc['test_version']; })); if (count($same) === 1) { $hit = $same[0]; } }
            $sd['prepocet_pt_limit'] = KB_PT_LIMIT_TAG;
            if ($hit === null) { $sd['pt_limit_beh'] = 'nenalezen'; $nf++; }
            else {
                $ru = $runs[$hit]; $runs[$hit]['used'] = 1;
                if ($ru['plus'] && $raw !== null && $raw !== '') {
                    $sd['hruby_pred_limitem'] = $raw; $raw = floatval($raw) + $ru['plus']; $sd['hruby'] = $raw; $sd['uznano_po_limitu'] = $ru['plus']; $plus += $ru['plus'];
                    if (isset($sd['spravne_administrovane']) && is_numeric($sd['spravne_administrovane'])) { $sd['spravne_administrovane'] = floatval($sd['spravne_administrovane']) + $ru['plus']; }
                    $last = array_slice($ru['seq'], -4); if (count($last) === 4 && !in_array('c', $last, true) && in_array('u', $last, true) && isset($sd['konec']) && strpos((string) $sd['konec'], 'chyb') !== false) { $sd['ukonceni_mozna_predcasne'] = 1; }
                }
                if ($ru['sondy_plus'] && isset($sd['sondy_spravne']) && is_numeric($sd['sondy_spravne'])) { $sd['sondy_spravne'] = intval($sd['sondy_spravne']) + $ru['sondy_plus']; }
            }
            $wpdb->update($SC, array('raw_score' => $raw, 'data' => wp_json_encode($sd)), array('id' => $sc['id'])); $nS++;
        }
    }
    /* 2) řádky odpovědí */
    $nR = 0;
    foreach ($cand as $r) {
        $d = json_decode((string) $r['data'], true); if (!$rescue($d)) { continue; }
        $d['spravne_puvodni_limit'] = isset($d['spravne']) ? $d['spravne'] : ''; $d['spravne'] = 1; $d['skore'] = 1; $d['nepotvrzeno'] = 1; $d['uznano_po_limitu'] = 1;
        $d['prepocet'] = trim((isset($d['prepocet']) ? $d['prepocet'] . ' ' : '') . KB_PT_LIMIT_TAG);
        $wpdb->update($R, array('data' => wp_json_encode($d)), array('id' => $r['id'])); $nR++;
    }
    $prev = get_option('kb_pt_limit_recode');
    $info = array('tag' => KB_PT_LIMIT_TAG, 'cas' => current_time('mysql'), 'scores' => $nS, 'plus_bodu' => $plus, 'beh_nenalezen' => $nf, 'rows' => $nR,
        'rows_celkem' => (is_array($prev) && isset($prev['rows_celkem']) ? intval($prev['rows_celkem']) : 0) + $nR);
    update_option('kb_pt_limit_recode', $info);
    return $info;
}
add_action('admin_init', function () {
    if (current_user_can('edit_posts')) { kb_recode_pt_limit(); }
}, 25);
