/* ===== Gv: Oblouky (OB-17-v1) – skládání vzoru z kostek s čtvrtkruhovými oblouky (obdoba Kostek / Block Design s neznámým materiálem) =====
   Kostky: W bílá, R červená; q+roh = vypouklá čtvrtkruhová výseč se středem v rohu (poloměr = strana kostky); k+roh = červená kostka
   s vykousnutou výsečí; A–D = kostka půlená úhlopříčkou (jen poslední dvě položky). Rohy a = levý horní, b = pravý horní, c = pravý dolní, d = levý dolní.
   Vzor se staví klepáním: vybrat kostku v paletě, klepnout na políčko. Položka končí sama, jakmile stavba odpovídá vzoru (i posunutá), nebo po limitu.
   Postup: 2×2 (první s hranicemi kostek) → 3×3 → 4×4 → volná plocha 6×6 (vzor není čtverec, bílá splývá s pozadím) → smíšené kostky.
   Skór = počet správně složených vzorů (bez bonusu za rychlost); čas, tahy a typy chyb se ukládají do řádků. */
const BANK_OB = __BANK__;
const OB_TX = __TX__;
function mod_oblouky(root, B, TX){
  const K = 'oblouky', VERSION = B.verze, show = (id) => showIn(root, id), $ = (s) => root.querySelector(s);
  const tx = (a) => Array.isArray(a) ? (formalAddress() ? a[0] : a[1]) : a;
  const RED = '#C8102E', TRI = {A:[[0,0],[1,0],[0,1]], B:[[0,0],[1,0],[1,1]], C:[[1,0],[1,1],[0,1]], D:[[0,0],[1,1],[0,1]]};
  const CORN = {a:[0,0], b:[1,0], c:[1,1], d:[0,1]}, SWEEP = {a:1, b:0, c:1, d:0}, ARC = ['qa', 'qb', 'qc', 'qd', 'ka', 'kb', 'kc', 'kd'];
  function shape(code, x, y, s, attr){
    if (code === 'R') return `<rect x="${x}" y="${y}" width="${s}" height="${s}" ${attr}/>`;
    if (TRI[code]) return `<polygon points="${TRI[code].map(([a, b]) => (x + a * s) + ',' + (y + b * s)).join(' ')}" ${attr}/>`;
    if (!code || code === 'W') return '';
    const [cx, cy] = CORN[code[1]], X = x + cx * s, Y = y + cy * s, p1 = [x + (1 - cx) * s, y + cy * s], p2 = [x + cx * s, y + (1 - cy) * s], sw = SWEEP[code[1]];
    if (code[0] === 'q') return `<path d="M${X},${Y} L${p1} A${s},${s} 0 0 ${sw} ${p2} Z" ${attr}/>`;
    return `<path d="M${p1} A${s},${s} 0 0 ${sw} ${p2} L${x + (1 - cx) * s},${y + (1 - cy) * s} Z" ${attr}/>`;
  }
  const tileSvg = (code) => `<svg viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" fill="#fff"/>${shape(code, 0, 0, 40, 'fill="' + RED + '"')}<rect width="40" height="40" fill="none" stroke="#9aa1a9" stroke-width="1.5"/></svg>`;
  const cellsOf = (it) => { const o = []; it.grid.forEach((row, i) => row.split(' ').forEach((c, j) => { if (c !== 'W' || !it.free) o.push([i, j, c]); })); return o; };
  const tilesFor = (it) => ['W', 'R'].concat(ARC, it.mix ? ['A', 'B', 'C', 'D'] : []);
  function modelSvg(it, px){
    const C = cellsOf(it), R = Math.max(...C.map(c => c[0])) + 1, Kc = Math.max(...C.map(c => c[1])) + 1, s = Math.min(px / Math.max(R, Kc), 60);
    let x = `<svg width="${Kc * s + 4}" height="${R * s + 4}" viewBox="0 0 ${Kc * s + 4} ${R * s + 4}" aria-hidden="true"><g transform="translate(2,2)">`;
    C.forEach(([i, j, c]) => { x += shape(c, j * s, i * s, s, 'fill="' + RED + '" stroke="' + RED + '" stroke-width="1"');   // obrys stejnou barvou: mezi kostkami nejsou světlé spáry
      if (it.lines) x += `<rect x="${j * s}" y="${i * s}" width="${s}" height="${s}" fill="none" stroke="#8a929c" stroke-width="1"/>`; });
    if (!it.free) x += `<rect width="${Kc * s}" height="${R * s}" fill="none" stroke="#c9ced5" stroke-width="1"/>`;
    return x + '</g></svg>';
  }
  /* shoda nezávislá na posunu: každý kód má jinou červenou plochu, takže shoda kódů = shoda vzoru */
  function redSet(cells){ const q = cells.filter(c => c[2] && c[2] !== 'W'); if (!q.length) return '';
    const mi = Math.min(...q.map(a => a[0])), mj = Math.min(...q.map(a => a[1])); return q.map(([i, j, k]) => (i - mi) + ',' + (j - mj) + ':' + k).sort().join(' '); }
  function boardCells(){ const o = []; U.board.forEach((row, a) => row.forEach((c, b) => { if (c) o.push([a, b, c]); })); return o; }
  function diagnose(it){   // nejlepší posun stavby vůči vzoru a typy chyb
    const M = cellsOf(it).filter(c => c[2] !== 'W'), Bc = boardCells().filter(c => c[2] !== 'W'); let best = null;
    for (let di = -6; di <= 6; di++) for (let dj = -6; dj <= 6; dj++) {
      const map = new Map(Bc.map(([i, j, c]) => [(i - di) + ',' + (j - dj), c])); let hit = 0;
      M.forEach(([i, j, c]) => { if (map.get(i + ',' + j) === c) hit++; });
      if (!best || hit > best.hit) best = {hit, map}; }
    let rot = 0, inv = 0, oth = 0, miss = 0; const fam = (c) => TRI[c] ? 'd' : c.length === 2 ? c[0] : c, used = new Set();
    M.forEach(([i, j, c]) => { const p = best.map.get(i + ',' + j); used.add(i + ',' + j);
      if (!p) miss++; else if (p !== c) { if (fam(p) === fam(c)) rot++; else if (c.length === 2 && p.length === 2 && c[1] === p[1]) inv++; else oth++; } });
    return {hit:best.hit, n:M.length, rot, inv, oth, miss, extra:[...best.map.keys()].filter(k => !used.has(k)).length};
  }
  root.innerHTML = `
<section class="screen" id="${K}-instr"><div class="wrap" style="max-width:920px">
  <div class="instr"><h1 data-heading>${TX.name}</h1><button class="speak" data-say="instr">${TX.read}</button></div>
  <p style="font-size:21px" id="${K}-intro"></p>
  <div id="${K}-demo" class="ob-demo"></div>
  <div class="actions"><button class="btn ghost" data-back>${TX.back}</button><button class="btn" id="${K}-go">${TX.tryIt}</button></div>
</div></section>
<section class="screen" id="${K}-item"><div class="wrap" style="max-width:1020px">
  <div class="progress" aria-hidden="true"><i id="${K}-prog" style="width:0%"></i></div>
  <div class="ob-timebar" id="${K}-timebar" aria-hidden="true"></div>
  <p class="pill" id="${K}-pill" hidden>${TX.practice}</p>
  <div class="ob-lay">
    <div class="ob-card"><p class="gv-lbl">${TX.model}</p><div class="ob-model" id="${K}-model"></div><p class="muted ob-cnt" id="${K}-cnt"></p></div>
    <div class="ob-card"><p class="gv-lbl" id="${K}-blbl"></p><div class="ob-board" id="${K}-board"></div>
      <div class="ob-pal" id="${K}-pal"></div>
      <div class="feedback" id="${K}-fb" role="status" aria-live="polite"></div></div>
  </div>
  <div class="actions"><button class="btn ghost" id="${K}-skip"></button></div>
</div></section>
<section class="screen" id="${K}-ready"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${TX.readyH}</h1><p style="font-size:22px" id="${K}-readytxt"></p>
  <div class="actions"><button class="btn" id="${K}-start">${TX.start}</button></div>
</div></section>
<section class="screen" id="${K}-done-s"><div class="wrap" style="max-width:820px">
  <h1 data-heading>${TX.doneH}</h1><p style="font-size:20px" id="${K}-done-text"></p>
  <div class="actions"><button class="btn" data-back>${TX.back}</button></div>
</div></section>`;
  bindSpeak(root, {get instr(){ return tx(TX.intro); }});
  root.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', backToMenu));
  const ST = {list:[], i:0, phase:'', run:0, correct:0, admin:0}; let U = null, timer = null;
  root._state = ST;   // pro automatické testy
  const capOf = (it) => (ST.phase === 'run' && !S.untimed) ? (it.cap || 60) : 0;
  const stopN = () => (S.stop === 0 ? 0 : 3);
  function stopTimer(){ if (timer) { clearInterval(timer); timer = null; } $('#' + K + '-timebar').style.display = 'none'; }
  function load(){
    const it = ST.list[ST.i], n = it.free ? 6 : it.grid.length, wide = innerWidth >= 900, side = Math.min(wide ? 380 : innerWidth - 56, 380), cs = Math.floor(side / n);
    U = {it, n, board:Array.from({length:n}, () => Array(n).fill(null)), sel:'R', t0:performance.now(), first:null, moves:[], done:false, cap:capOf(it)};
    root._u = U;
    $('#' + K + '-prog').style.width = (ST.phase === 'run' ? ST.i / ST.list.length * 100 : 0) + '%';
    $('#' + K + '-model').innerHTML = modelSvg(it, wide ? 240 : Math.min(170, innerWidth - 80));
    $('#' + K + '-cnt').textContent = it.free ? tx(TX.count).replace('{n}', cellsOf(it).length) : '';
    $('#' + K + '-blbl').textContent = tx(it.free ? TX.boardFree : TX.board);
    const bd = $('#' + K + '-board'); bd.style.gridTemplateColumns = `repeat(${n},${cs}px)`; bd.style.gridAutoRows = cs + 'px';
    $('#' + K + '-pal').innerHTML = tilesFor(it).map(t => `<button type="button" data-t="${t}" aria-label="${TX.tile} ${t}">${tileSvg(t)}</button>`).join('') + `<button type="button" data-t="" aria-label="${TX.erase}" class="ob-erase">⌫</button>`;
    $('#' + K + '-pal').querySelectorAll('button').forEach(b => b.addEventListener('click', () => { if (U.done) return; U.sel = b.dataset.t; drawPal(); }));
    $('#' + K + '-skip').textContent = tx(ST.phase === 'prac' ? TX.showMe : TX.skip); $('#' + K + '-skip').hidden = false;
    $('#' + K + '-fb').innerHTML = '';
    drawBoard(); drawPal(); stopTimer();
    if (U.cap) { const bar = $('#' + K + '-timebar'), end = U.t0 + U.cap * 1000;
      timer = setInterval(() => { if (!KB_ALIVE(K)) return stopTimer(); const left = (end - performance.now()) / 1000;
        if (left <= 20) { bar.style.display = 'block'; bar.style.transform = `scaleX(${Math.max(0, left / 20)})`; }
        if (left <= 0) finishItem(false, 'timeout'); }, 200); }
  }
  function drawPal(){ $('#' + K + '-pal').querySelectorAll('button').forEach(b => b.classList.toggle('sel', b.dataset.t === U.sel)); }
  function drawBoard(){
    const el = $('#' + K + '-board'); el.innerHTML = '';
    U.board.forEach((row, i) => row.forEach((c, j) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'ob-cell' + (c ? ' on' : '');
      b.innerHTML = c ? tileSvg(c).replace('stroke="#9aa1a9"', 'stroke="#d0d4da"') : ''; b.setAttribute('aria-label', TX.cell + ' ' + (i + 1) + ',' + (j + 1));
      b.addEventListener('click', () => place(i, j)); el.appendChild(b); }));
  }
  function place(i, j){
    if (!U || U.done) return; const t = performance.now() - U.t0; if (U.first === null) U.first = t;
    U.board[i][j] = U.sel || null; U.moves.push(Math.round(t) + ':' + i + ',' + j + ':' + (U.sel || '-')); drawBoard();
    if (redSet(boardCells()) === redSet(cellsOf(U.it))) finishItem(true, 'slozeno');
  }
  function finishItem(ok, how){
    if (!U || U.done) return; U.done = true; stopTimer();
    const it = U.it, rt = Math.round(performance.now() - U.t0), dg = diagnose(it);
    S.rows.push({test:K, forma:VERSION, faze:S.mode, poradi:ST.i + 1, polozka:it.id, id:it.id, format:K + '-' + (it.free ? 'volne' : it.grid.length + 'x' + it.grid.length) + (it.mix ? '-smis' : ''),
      typ:'úroveň ' + (it.level || 'nácvik'), reseni:it.grid.join(' / '), odpoved:redSet(boardCells()), spravne:ok ? 1 : 0, skore:dg.hit, max_skore:dg.n,
      chyby_natoceni:dg.rot, chyby_vypoukla_vyduta:dg.inv, chyby_jine:dg.oth, chybejici:dg.miss, navic:dg.extra, konec_polozky:how,
      rt_ms:rt, prvni_akce_ms:U.first === null ? '' : Math.round(U.first), upravy:U.moves.length, tahy:U.moves.join(' ').slice(0, 1500),
      timeout:how === 'timeout' ? 1 : 0, preskoceno:how === 'skip' ? 1 : 0, time_limit_ms:U.cap ? U.cap * 1000 : '', cas:new Date().toISOString()});
    save(); $('#' + K + '-skip').hidden = true;
    const fb = $('#' + K + '-fb');
    if (ST.phase === 'prac') {
      if (!ok) { cellsOf(it).forEach(([i, j, c]) => { U.board[i][j] = c; }); drawBoard(); }
      fb.innerHTML = (ok ? '<span class="mark ok">' + CHECK + '</span> ' + tx(TX.pracOk) : tx(TX.pracShown)) + '<div><button class="btn" id="' + K + '-next" style="margin-top:10px">' + TX.cont + '</button></div>';
      $('#' + K + '-next').addEventListener('click', () => { ST.i++; if (ST.i >= ST.list.length) { $('#' + K + '-readytxt').textContent = tx(TX.ready); return show(K + '-ready'); } load(); });
      return;
    }
    if (ok) fb.innerHTML = '<span class="mark ok">' + CHECK + '</span> ' + TX.built;
    setTimeout(() => { if (KB_ALIVE(K)) advance(ok); }, ok ? 700 : 350);
  }
  function advance(ok){
    ST.done.add(ST.i); ST.admin++; if (ok) { ST.correct++; ST.run = 0; ST.times.push(S.rows[S.rows.length - 1].rt_ms); } else ST.run++;
    /* start podle věku: chyba v jedné z prvních dvou položek → návrat k lehčím položkám */
    if (ST.start > 0 && !ST.checked) { ST.first.push(ok ? 1 : 0);
      if (!ok || ST.first.length === 2) { ST.checked = true; if (!ok) { ST.back = true; ST.resume = ST.i + 1; ST.i = -1; ST.run = 0; } else ST.credit = ST.start; } }
    ST.i++;
    if (ST.back && ST.i >= ST.start) { ST.back = false; ST.i = ST.resume; }
    while (ST.done.has(ST.i)) ST.i++;
    const sn = stopN();
    if (sn && ST.run >= sn) return finish('ukončeno po ' + sn + ' chybách v řadě');
    if (ST.i >= ST.list.length) return finish('všechny položky');
    if (typeof ckSave === 'function') ckSave(K, {i:ST.i, run:ST.run, correct:ST.correct, admin:ST.admin, start:ST.start, first:ST.first, checked:ST.checked,
      back:ST.back, resume:ST.resume, done:[...ST.done], credit:ST.credit, times:ST.times, n:ST.admin, of:ST.list.length});
    load();
  }
  function finish(reason){
    if (typeof ckClear === 'function') ckClear(K); stopTimer();
    const tm = ST.times.slice().sort((a, b) => a - b), med = tm.length ? tm[Math.floor((tm.length - 1) / 2)] : '';
    S.scores[K] = {hruby:ST.correct + (ST.credit || 0), spravne_administrovane:ST.correct, pripsane:ST.credit || 0, administrovano:ST.admin, start:(ST.start || 0) + 1,
      navrat:ST.first && ST.first.some(x => !x) ? 1 : 0, polozek:ST.list.length, konec:reason, forma:VERSION, cas_spravnych_median_ms:med, ukonceni_po:stopN()};
    save(); $('#' + K + '-done-text').textContent = TX.doneTxt.replace('{a}', ST.correct).replace('{b}', ST.admin); show(K + '-done-s');
  }
  function startRun(){
    S.mode = 'test'; ST.phase = 'run'; ST.list = B.items; ST.run = 0; ST.correct = 0; ST.admin = 0; ST.times = [];
    const age = +S.vek || 30; ST.start = (S.startRule !== 'vek' || age <= 8) ? 0 : Math.max(0, ST.list.findIndex(x => x.id === B.start_od_9));
    ST.i = ST.start; ST.first = []; ST.checked = false; ST.back = false; ST.resume = null; ST.done = new Set(); ST.credit = 0;
    $('#' + K + '-pill').hidden = true; show(K + '-item'); load();
  }
  $('#' + K + '-go').addEventListener('click', () => { S.mode = 'nacvik'; ST.phase = 'prac'; ST.list = B.practice; ST.i = 0; $('#' + K + '-pill').hidden = false; show(K + '-item'); load(); });
  $('#' + K + '-start').addEventListener('click', startRun);
  $('#' + K + '-skip').addEventListener('click', () => finishItem(false, ST.phase === 'prac' ? 'ukazano' : 'skip'));
  return {key:K, name:TX.name, blurb:TX.blurb, group:'gv', version:VERSION, show,
    icon:'<svg viewBox="0 0 48 48"><rect x="6" y="6" width="36" height="36" rx="3" fill="#fff" stroke="#2B3440" stroke-width="2"/><path d="M24 6A18 18 0 0 0 6 24H24Z" fill="#C8102E"/><path d="M24 42A18 18 0 0 0 42 24H24Z" fill="#C8102E"/><path d="M24 6v36M6 24h36" stroke="#2B3440" stroke-width="1.5"/></svg>',
    prepare(){ CUR.formLabel = VERSION; $('#' + K + '-intro').textContent = tx(TX.intro);
      $('#' + K + '-demo').innerHTML = '<div class="ob-demo-row">' + ['R', 'qc', 'kc'].map(t => '<span class="ob-demo-t">' + tileSvg(t) + '</span>').join('') + '<span class="gv-demo-arrow">→</span>' + modelSvg(B.practice[0], 110) + '</div><p class="muted">' + tx(TX.demo) + '</p>'; },
    resume(ck){ CUR.formLabel = VERSION; S.mode = 'test'; ST.phase = 'run'; ST.list = B.items;
      Object.assign(ST, {i:ck.i, run:ck.run, correct:ck.correct, admin:ck.admin, start:ck.start, first:ck.first || [], checked:ck.checked, back:ck.back, resume:ck.resume,
        done:new Set(ck.done || []), credit:ck.credit || 0, times:ck.times || []});
      $('#' + K + '-pill').hidden = true; show(K + '-item'); load(); },
    runSelf(){ if (S.nacvik) show(K + '-instr'); else { $('#' + K + '-readytxt').textContent = tx(TX.ready); show(K + '-ready'); } }, formLabel:''};
}
