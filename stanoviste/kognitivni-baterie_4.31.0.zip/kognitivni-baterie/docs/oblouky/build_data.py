import json
G = [('hvezda', ['ka kb', 'kd kc'], 1, 45, dict(lines=True)), ('okenko', ['kc kd', 'kb ka'], 1, 45, {}), ('polstar', ['qa qb', 'qd qc'], 1, 45, {}), ('list', ['qc kd', 'kb qa'], 1, 45, {}),
     ('obly ctverec', ['qc R qd', 'R R R', 'qb R qa'], 2, 75, {}), ('vykousnuty ctverec', ['ka R kb', 'R R R', 'kd R kc'], 2, 75, {}), ('oval', ['qc R qd', 'qb R qa', 'W W W'], 2, 75, {}),
     ('dvojkruh', ['W qc qd', 'qc R qa', 'qb qa W'], 2, 75, {}), ('esko', ['qc qd W', 'qb kb kd', 'W qb qa'], 2, 75, {}),
     ('kvet', ['W qc qd W', 'qc kc kd qd', 'qb kb ka qa', 'W qb qa W'], 3, 120, {}), ('kolo', ['kc qd qc kd', 'qa kb ka qb', 'qd kc kd qc', 'kb qa qb ka'], 3, 120, {}),
     ('srp', ['W qc R', 'qc kc W', 'R W W'], 4, 120, dict(free=True)), ('osmicka', ['qc qd', 'qb qa', 'qc qd', 'qb qa'], 4, 120, dict(free=True)),
     ('had', ['qc qd W W', 'qb kb kd W', 'W W qb qa'], 4, 120, dict(free=True)), ('cinka', ['qc qd W W qc qd', 'qb qa R R qb qa'], 4, 120, dict(free=True)),
     ('kapka s hrotem', ['qc qd', 'qb A'], 5, 120, dict(free=True, mix=True)), ('list s hrotem', ['W C qd', 'C R qa', 'qb qa W'], 5, 120, dict(free=True, mix=True))]
items = [dict({'id': 'OB%02d' % (k + 1), 'nazev': n, 'level': lv, 'cap': cap, 'grid': g}, **ex) for k, (n, g, lv, cap, ex) in enumerate(G)]
bank = {'verze': 'OB-17-v1', 'start_od_9': 'OB05',
        'practice': [{'id': 'OB_N1', 'nazev': 'kruh', 'level': 0, 'grid': ['qc qd', 'qb qa'], 'lines': True}, {'id': 'OB_N2', 'nazev': 'okno', 'level': 0, 'grid': ['qc qd', 'R R'], 'lines': True}], 'items': items}
json.dump(bank, open('BANK_OB.json', 'w'), ensure_ascii=False, indent=1)
TX = {'cz': {'name': 'Oblouky', 'blurb': 'Poskládej vzor z kostek s oblouky', 'read': 'Přečíst', 'back': 'Zpět do menu', 'tryIt': 'Vyzkoušet', 'practice': 'Zácvik', 'model': 'Vzor',
  'intro': ['Nahoře uvidíte vzor. Poskládejte ho z kostek: dole vyberte kostku a klepněte na políčko, kam ji chcete dát. Kostky jsou bílá, červená, kostka s červenou čtvrtkruhovou výsečí a červená kostka s vykousnutou výsečí – obojí ve čtyřech natočeních. Kostku přepíšete tak, že na políčko klepnete s jinou kostkou; ⌫ políčko vymaže. Jakmile stavba odpovídá vzoru, úloha sama skončí. Nejdřív dvě cvičné úlohy.',
            'Nahoře uvidíš vzor. Poskládej ho z kostek: dole vyber kostku a klepni na políčko, kam ji chceš dát. Kostky jsou bílá, červená, kostka s červenou čtvrtkruhovou výsečí a červená kostka s vykousnutou výsečí – obojí ve čtyřech natočeních. Kostku přepíšeš tak, že na políčko klepneš s jinou kostkou; ⌫ políčko vymaže. Jakmile stavba odpovídá vzoru, úloha sama skončí. Nejdřív dvě cvičné úlohy.'],
  'demo': ['Z těchto kostek se skládají vzory – například kruh ze čtyř výsečí.', 'Z těchto kostek se skládají vzory – například kruh ze čtyř výsečí.'],
  'board': ['Vaše stavba', 'Tvoje stavba'], 'boardFree': ['Postavte vzor kdekoliv na ploše', 'Postav vzor kdekoliv na ploše'], 'count': ['Na stavbu je potřeba {n} kostek.', 'Na stavbu je potřeba {n} kostek.'],
  'tile': 'kostka', 'erase': 'smazat políčko', 'cell': 'políčko', 'skip': ['Nevím, další úloha', 'Nevím, další úloha'], 'showMe': ['Ukázat řešení', 'Ukázat řešení'],
  'pracOk': ['Správně, vzor je složený.', 'Správně, vzor je složený.'], 'pracShown': ['Takhle se vzor skládá.', 'Takhle se vzor skládá.'], 'cont': 'Pokračovat', 'built': 'Složeno',
  'readyH': 'Teď naostro', 'start': 'Začít',
  'ready': ['Každý vzor má časový limit; když se čas krátí, objeví se nahoře pruh. Pracujte hlavně přesně. Později vzory nebudou čtvercové – postavíte je kdekoliv na větší ploše a bílé části vzoru splynou s pozadím. U posledních dvou přibudou kostky půlené úhlopříčkou. Když si nevíte rady, můžete úlohu přeskočit.',
            'Každý vzor má časový limit; když se čas krátí, objeví se nahoře pruh. Pracuj hlavně přesně. Později vzory nebudou čtvercové – postavíš je kdekoliv na větší ploše a bílé části vzoru splynou s pozadím. U posledních dvou přibudou kostky půlené úhlopříčkou. Když si nevíš rady, můžeš úlohu přeskočit.'],
  'doneH': 'Hotovo', 'doneTxt': 'Hotovo. Složeno {a} z {b} vzorů.'},
 'en': {'name': 'Arcs', 'blurb': 'Build the pattern from arc blocks', 'read': 'Read aloud', 'back': 'Back to menu', 'tryIt': 'Try it', 'practice': 'Practice', 'model': 'Pattern',
  'intro': 'At the top you will see a pattern. Build it from blocks: pick a block below and tap the square where you want to put it. The blocks are white, red, a block with a red quarter-circle, and a red block with a quarter-circle bitten out – each in four rotations. To replace a block, tap its square with another block; ⌫ clears a square. As soon as your construction matches the pattern, the item ends by itself. First two practice items.',
  'demo': 'Patterns are built from these blocks – for example a circle from four quarter-circles.',
  'board': 'Your construction', 'boardFree': 'Build the pattern anywhere on the board', 'count': 'The construction needs {n} blocks.',
  'tile': 'block', 'erase': 'clear square', 'cell': 'square', 'skip': "I don't know, next item", 'showMe': 'Show the solution',
  'pracOk': 'Correct, the pattern is built.', 'pracShown': 'This is how the pattern is built.', 'cont': 'Continue', 'built': 'Built',
  'readyH': 'Now for real', 'start': 'Start',
  'ready': 'Each pattern has a time limit; a bar appears at the top when time is running out. Above all, work accurately. Later the patterns will not be square – you build them anywhere on a larger board, and the white parts of the pattern blend into the background. The last two add blocks split along the diagonal. If you are stuck, you can skip the item.',
  'doneH': 'Done', 'doneTxt': 'Done. You built {a} of {b} patterns.'}}
json.dump(TX, open('OB_TX.json', 'w'), ensure_ascii=False, indent=1)
print(len(items))
