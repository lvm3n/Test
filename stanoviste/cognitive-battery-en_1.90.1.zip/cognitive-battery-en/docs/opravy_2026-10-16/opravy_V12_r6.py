# Opravy V12-12_r2, 17_r, 31_r, 37_r2, 38_r3 (2026-10-16). Potřebuje vedle sebe gen.py (= nove_polozky_V12-46_55.py) a bank.json (BANK_M12 verze r5).
import itertools, json, copy
exec(open('gen.py').read().split("ITEMS = []")[0])
B = json.load(open('bank.json', encoding='utf-8'))
byid = {it['id']: it for it in B['items']}
REV = {}
# ---------- 38_r3 ----------
FR = ['keep', 'tog', '=s', '=m', '=b', '!s', '!m', '!b', 'S', 'H']
def fr(rule, own, s, m, b):
    S_ = lambda v: v == 'solid'; inv = lambda v: 'hollow' if v == 'solid' else 'solid'
    return {'keep': own, 'tog': inv(own), '=s': s, '=m': m, '=b': b, '!s': inv(s), '!m': inv(m), '!b': inv(b), 'S': 'solid', 'H': 'hollow'}[rule]
def mk38(order, rs):
    def f(parts):
        srt = sorted(parts, key=lambda p: p[1]); s, m, b = [p[2] for p in srt]
        out = [[p[0], p[1], fr(rs[k], p[2], s, m, b)] for k, p in enumerate(srt)]
        if order == 'desc': out = out[::-1]
        if order == 'none':  # keep input positions
            out = [next(o for o in out if o[0] == p[0]) for p in parts]
        return tuple(tuple(o) for o in out)
    return f
H38 = {(o, rs): mk38(o, rs) for o in ('asc', 'desc', 'none') for rs in itertools.product(FR, repeat=3)}
rule38 = mk38('asc', ('keep', 'tog', 'keep'))
P = lambda *a: tuple(tuple(x) for x in a)
d38 = [P(['square', 2, 'hollow'], ['triangle', 3, 'solid'], ['circle', 1, 'hollow']),
       P(['hex', 3, 'hollow'], ['diamond', 2, 'hollow'], ['star', 1, 'solid']),
       P(['hex', 2, 'solid'], ['square', 3, 'hollow'], ['triangle', 1, 'hollow'])]
t38 = P(['circle', 2, 'hollow'], ['triangle', 3, 'solid'], ['square', 1, 'solid'])
it = byid['V12-38_r2']; opts = [tuple(tuple(x) for x in o['parts']) for o in it['options']]
dis38 = [(m, o) for m, o in zip(it['option_models'], opts) if m != 'correct']
ans, outs = check('V12-38_r3', d38, t38, rule38, H38, dis38)
assert ans == opts[it['correct_index']]
n = copy.deepcopy(it); n['id'] = 'V12-38_r3'
n['stem'] = [[{'parts': [list(x) for x in d]}, {'parts': [list(x) for x in o]}] for d, o in zip(d38, outs)] + [[{'parts': [list(x) for x in t38]}, None]]
n['notes'] = 'r3 (2026-10-16): ve r2 měly ve dvou ukázkách nejmenší a prostřední objekt vždy stejnou výplň a nejmenší s největším opačnou → stejně dobře sedělo „prostřední dostane opak výplně nejmenšího“ (→ A) nebo „prostřední = největší“. Tři ukázky teď tato pravidla (i „prostřední vždy plný/prázdný“) vylučují; vstup ve 3. ukázce není předem seřazený. Ověřeno proti 3 řazením × 10³ pravidlům výplně.'
REV['V12-38_r2'] = n

# ---------- 31_r: test in SAME branch ----------
OPS = {'shapes': lambda x: {**x, 'outer': x['inner'], 'inner': x['outer']}, 'colors': lambda x: {**x, 'oc': x['ic'], 'ic': x['oc']},
       'both': lambda x: {'outer': x['inner'], 'oc': x['ic'], 'inner': x['outer'], 'ic': x['oc']}, 'none': lambda x: dict(x)}
def key(x): return (x['outer'], x['oc'], x['inner'], x['ic'])
H31 = {}
for a in OPS:
    for b in OPS:
        H31[('cond', a, b)] = (lambda a, b: lambda x: key(OPS[a](x) if x['oc'] == x['ic'] else OPS[b](x)))(a, b)
        H31[('altern', a, b)] = (lambda a, b: lambda x: key(OPS[a](x) if x['_k'] % 2 == 0 else OPS[b](x)))(a, b)
    H31[('always', a)] = (lambda a: lambda x: key(OPS[a](x)))(a)
def strip(x): return {k: v for k, v in x.items() if k != '_k'}
it = byid['V12-31']; st = it['stem']
demos31 = [dict(st[0], _k=0), dict(st[2], _k=1), dict(st[4], _k=2)]
test31 = {'outer': 'star', 'oc': 'yellow', 'inner': 'hex', 'ic': 'yellow', '_k': 3}
rule31 = H31[('cond', 'shapes', 'colors')]
for d, o in zip(demos31, [st[1], st[3], st[5]]): assert rule31(d) == key(o)
K = lambda o, oc, i, ic: (o, oc, i, ic)
dis31 = [('other_branch_no_visible_change', K('star', 'yellow', 'hex', 'yellow')), ('outer_shape_only', K('hex', 'yellow', 'hex', 'yellow')),
         ('inner_shape_only', K('star', 'yellow', 'star', 'yellow')), ('swap_plus_outer_recoloured', K('hex', 'blue', 'star', 'yellow')),
         ('swap_plus_inner_recoloured', K('hex', 'yellow', 'star', 'blue'))]
# check: hypotheses take dict with _k
H31w = {k: (lambda f: lambda x: f(dict(x)))(f) for k, f in H31.items()}
REPORT_before = len(REPORT)
outs = [rule31(d) for d in demos31]; ans = rule31(test31)
fit = {k: f(test31) for k, f in H31.items() if all(f(d) == o for d, o in zip(demos31, outs))}
bad = {k: v for k, v in fit.items() if v != ans}
REPORT.append(('V12-31_r', not bad and len(set([ans] + [o for _, o in dis31])) == 6, len(H31), len(fit), [('AMBIG', bad)] if bad else []))
n = copy.deepcopy(it); n['id'] = 'V12-31_r'
n['stem'] = st[:6] + [strip(test31), None]
opts = [ans] + [o for _, o in dis31]; mods = ['correct'] + [m for m, _ in dis31]
order = [1, 0, 2, 3, 4, 5]  # correct at B
n['options'] = [dict(zip(('outer', 'oc', 'inner', 'ic'), opts[i])) for i in order]; n['option_models'] = [mods[i] for i in order]; n['correct_index'] = 1
n['principle'] = 'Řada je tvořena čtyřmi dvojicemi vstup→výstup. Jsou-li barvy vnější a vnitřní části stejné, prohodí se jejich tvary (barvy zůstanou). Jsou-li různé, tvary zůstanou a prohodí se barvy. Hledaná dvojice patří do vzácnější větve (stejné barvy).'
n['notes'] = 'r (2026-10-16): v původní verzi patřil test do větve „různé barvy“, kterou ukazovaly dvě ze tří ukázek → šlo odpovědět prostým „prohoď barvy“ bez pochopení podmínky (p = .68, r_it = .04). Teď je test ve větvi „stejné barvy“; „prohoď barvy“ vede k nezměněnému obrázku (distraktor). Ověřeno proti podmíněným, střídavým a stálým kombinacím operací.'
REV['V12-31'] = n

# ---------- 37_r2: red rotates 45° left per count ----------
it = byid['V12-37_r']; st = copy.deepcopy(it['stem'])
st[1]['dir'] = 6; st[5]['dir'] = 4; st[7]['dir'] = 3
blue = {1: 0, 2: 2, 3: 4, 4: 6}
Hs = {}
for k in range(-3, 5):
    for c in range(8): Hs[('lin', k, c)] = (lambda k, c: lambda n: (c + k * n) % 8)(k, c)
for s in (1, -1):
    for c in range(8): Hs[('rel_blue', s, c)] = (lambda s, c: lambda n: (s * blue[n] + c) % 8)(s, c)
red = {1: 6, 3: 4, 4: 3}
fit = {k: f(2) for k, f in Hs.items() if all(f(nn) == v for nn, v in red.items())}
REPORT.append(('V12-37_r2', set(fit.values()) == {5}, len(Hs), len(fit), [] if set(fit.values()) == {5} else [fit]))
n = copy.deepcopy(it); n['id'] = 'V12-37_r2'; n['stem'] = st
n['options'] = [{'n': 2, 'color': 'red', 'dir': 5}, {'n': 2, 'color': 'red', 'dir': 0}, {'n': 2, 'color': 'red', 'dir': 4},
                {'n': 2, 'color': 'red', 'dir': 7}, {'n': 2, 'color': 'blue', 'dir': 5}, {'n': 1, 'color': 'red', 'dir': 5}]
n['option_models'] = ['correct', 'use_blue_step', 'red_step_90', 'red_turns_right', 'wrong_color', 'wrong_count']; n['correct_index'] = 0
assert len(set(json.dumps(o, sort_keys=True) for o in n['options'])) == 6
n['principle'] = 'Dvojice podle počtu (modrá, červená). Modrá šipka se s každým dalším počtem otočí o 90° doprava, červená o 45° doleva. Chybí červená dvojka.'
n['notes'] = 'r2 (2026-10-16): v r se obě barvy otáčely o 90°, takže každá barva prošla všemi čtyřmi úhlopříčkami → chybějící šipku šlo doplnit jako „ten směr, který u červené ještě není“, bez pochopení rotace (p = .79, r_it = .04). Červená se teď otáčí o 45° (jiný krok i směr než modrá), doplnění podle chybějícího směru nefunguje.'
REV['V12-37_r'] = n

# ---------- 12_r2 ----------
it = byid['V12-12_r']; n = copy.deepcopy(it); n['id'] = 'V12-12_r2'
top = [1, 0, 2]; bot = [0, 2]
# reading 1: cyclic continuation of positions; reading 2: step sequence phase-shifted; reading 3: same set of corners
r1 = top[(top.index(bot[0]) + 2) % 3]
steps = [(top[1] - top[0]) % 4, (top[2] - top[1]) % 4]; r2 = (bot[1] + steps[0]) % 4
r3 = (set(top) - set(bot)).pop()
REPORT.append(('V12-12_r2', r1 == r2 == r3 == 1 and bot[1] - bot[0] == steps[1] % 4 or (bot[1] - bot[0]) % 4 == steps[1], 3, 3, [r1, r2, r3]))
n['stem'] = [[{'pos': p, 'color': 'red'} for p in top], [{'pos': 0, 'color': 'blue'}, {'pos': 2, 'color': 'blue'}, None]]
n['options'] = [{'pos': 2, 'color': 'blue'}, {'pos': 1, 'color': 'blue'}, {'pos': 3, 'color': 'blue'}, {'pos': 1, 'color': 'red'}, {'pos': 0, 'color': 'blue'}, {'pos': 2, 'color': 'red'}]
n['option_models'] = ['no_phase_shift', 'correct', 'unused_corner', 'wrong_color', 'repeat_earlier', 'copy_top']; n['correct_index'] = 1
n['notes'] = 'r2 (2026-10-16): v r šly obhájit dvě odpovědi – „stejné tři rohy posunuté o fázi“ (B) i „stejné kroky posunuté o fázi“ (+2, −1 → levý dolní roh, C). Nové pořadí rohů je zvolené tak, že posun poloh, posun kroků i „chybějící roh z horní řady“ dávají stejnou odpověď.'
REV['V12-12_r'] = n

# ---------- 17_r: bigger size contrast (new scene swap_tiles_v2) ----------
it = byid['V12-17']; n = copy.deepcopy(it); n['id'] = 'V12-17_r'; n['scene'] = 'swap_tiles_v2'
n['notes'] = 'r (2026-10-16): logika beze změny; stupně velikosti byly blízko sebe (poloměr 14/19/24) a u různých tvarů (hvězda vs. šestiúhelník) šly v možnostech těžko porovnat se zadáním (C vs. F se lišily jen o jeden stupeň hvězdy). Nová scéna má stupně 11/18/26.'
REV['V12-17'] = n

if __name__ == '__main__':
    for r in REPORT: print(r[0], 'OK' if r[1] else 'FAIL', 'hyps=%d fitting=%d' % (r[2], r[3]), r[4])
    json.dump(REV, open('rev_items.json', 'w'), ensure_ascii=False, indent=1)
