# Generátor a kontrola jednoznačnosti nových položek V12-46..55 (2026-10-16). Spuštění: python3 nove_polozky_V12-46_55.py (vypíše kontrolu a uloží new_items.json).
import itertools, json, random
REPORT = []
def check(iid, demos, test, rule, hyps, distractors, min_alt=0):
    """demos: list of inputs; rule(inp)->out; hyps: dict name->fn; distractors: list of (model, out)"""
    ok = True; msgs = []
    outs = [rule(d) for d in demos]; ans = rule(test)
    fit = {}
    for n, f in hyps.items():
        try:
            if all(f(d) == o for d, o in zip(demos, outs)): fit[n] = f(test)
        except Exception: pass
    bad = {n: a for n, a in fit.items() if a != ans}
    if bad: ok = False; msgs.append('AMBIGUOUS: %d alternative rules fit demos but give a different answer, e.g. %s' % (len(bad), list(bad.items())[:4]))
    if ans in outs: ok = False; msgs.append('test answer equals a demo output (copy shortcut)')
    if test in demos: ok = False; msgs.append('test input equals a demo input')
    allopts = [ans] + [o for _, o in distractors]
    if len(set(json.dumps(o, sort_keys=True) for o in allopts)) != 6: ok = False; msgs.append('options not 6 distinct: %s' % allopts)
    REPORT.append((iid, ok, len(hyps), len(fit), msgs))
    return ans, outs

def finish_item(base, demos, outs, test, ans, distractors, correct_pos, wrap):
    """build triples stem + options; correct placed at correct_pos"""
    opts = [o for _, o in distractors]; models = [m for m, _ in distractors]
    opts.insert(correct_pos, ans); models.insert(correct_pos, 'correct')
    base['stem'] = [[wrap(d, 'in'), wrap(o, 'out')] for d, o in zip(demos, outs)] + [[wrap(test, 'in'), None]]
    base['options'] = [wrap(o, 'out') for o in opts]; base['option_models'] = models; base['correct_index'] = correct_pos
    return base

ITEMS = []
def item(**kw):
    d = dict(tier='ceiling', format='triples_3x2', pilot=1, randomize_options_in_deployment=True, source='v12-2026-10-16', **kw); return d

# ---------- 46 tile_strips: (A − B) shifted right by 1, 5 cells cyclic ----------
def bf(k): return lambda a, b: (k >> (a * 2 + b)) & 1
def shift(v, k): n = len(v); return tuple(v[(i - k) % n] for i in range(n))
def T46(v, t): return shift(v[::-1] if t[0] else v, t[1])
def mk46(fk, t): return lambda d: T46(tuple(bf(fk)(a, b) for a, b in zip(*d)), t)
TR = [(r, k) for r in (0, 1) for k in range(5)]
H46 = {('f%d' % fk, t): mk46(fk, t) for fk in range(16) for t in TR}
DIFF = 0b0100  # a=1,b=0 -> index 2 -> bit 2
assert bf(DIFF)(1, 0) == 1 and bf(DIFF)(1, 1) == 0 and bf(DIFF)(0, 0) == 0 and bf(DIFF)(0, 1) == 0
XOR, AND, OR, BMA = 0b0110, 0b1000, 0b1110, 0b0010
rule46 = mk46(DIFF, (0, 1))
demos46 = [((1, 1, 0, 1, 0), (0, 1, 0, 0, 1)), ((0, 1, 1, 1, 0), (1, 0, 1, 0, 0)), ((1, 0, 1, 1, 1), (0, 0, 1, 1, 0))]
test46 = ((1, 1, 1, 0, 0), (0, 1, 0, 1, 1))
dis46 = [('difference_no_shift', mk46(DIFF, (0, 0))(test46)), ('xor_shifted', mk46(XOR, (0, 1))(test46)),
         ('reverse_difference_shifted', mk46(BMA, (0, 1))(test46)), ('difference_shift_left', mk46(DIFF, (0, 4))(test46)),
         ('intersection_shifted', mk46(AND, (0, 1))(test46))]
ans, outs = check('V12-46', demos46, test46, rule46, H46, dis46)
ITEMS.append(finish_item(item(id='V12-46', scene='tile_strips', relation_family='set_difference_plus_shift', strategy_superfamily='set_algebra',
    principle='Ve výsledném pásu jsou políčka, která jsou plná v horním (modrém) pásu a zároveň prázdná v dolním (oranžovém) – rozdíl A − B. Výsledek se pak posune o jedno políčko doprava; políčko, které vypadne vpravo, se vrátí vlevo.',
    active_dimensions=['množiny', 'rozdíl', 'cyklický posun'], complexity={'integration': 'composition', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): asymetrická množinová operace + cyklický posun. Distraktory = dílčí řešení (bez posunu, XOR, opačný rozdíl, posun doleva, průnik).'),
    demos46, outs, test46, ans, dis46, 2, lambda v, k: {'A': list(v[0]), 'B': list(v[1])} if k == 'in' else {'S': list(v)}))

# ---------- 47 hex_edges: union, rotated one edge clockwise, shared edges red ----------
def mk47(fg, fr, rot, refl):
    def f(d):
        A, B = d; g = [bf(fg)(a, b) for a, b in zip(A, B)]; r = [bf(fr)(a, b) for a, b in zip(A, B)]
        v = [2 if r[i] else 1 if g[i] else 0 for i in range(6)]
        if refl: v = v[::-1]
        return tuple(v[(i - rot) % 6] for i in range(6))
    return f
H47 = {(fg, fr, rot, refl): mk47(fg, fr, rot, refl) for fg in range(16) for fr in range(16) for rot in range(6) for refl in (0, 1)}
rule47 = mk47(OR, AND, 1, 0)
demos47 = [((1, 1, 0, 0, 0, 0), (0, 1, 1, 0, 0, 0)), ((1, 0, 0, 1, 1, 0), (0, 0, 0, 1, 0, 0)), ((0, 0, 1, 0, 1, 1), (1, 0, 1, 0, 0, 0))]
test47 = ((1, 1, 0, 1, 0, 0), (0, 1, 0, 0, 0, 1))
dis47 = [('no_rotation', mk47(OR, AND, 0, 0)(test47)), ('rotate_left', mk47(OR, AND, 5, 0)(test47)),
         ('shared_not_marked', mk47(OR, 0, 1, 0)(test47)), ('xor_marked_red', mk47(OR, XOR, 1, 0)(test47)), ('rotate_two_edges', mk47(OR, AND, 2, 0)(test47))]
ans, outs = check('V12-47', demos47, test47, rule47, H47, dis47)
ITEMS.append(finish_item(item(id='V12-47', scene='hex_edges', relation_family='union_rotation_shared_mark', strategy_superfamily='set_algebra',
    principle='Výsledek obsahuje všechny hrany, které jsou alespoň v jednom ze dvou šestiúhelníků (sjednocení). Hrany, které byly v obou, jsou červené, ostatní modré. Celý výsledek se otočí o jednu hranu po směru hodinových ručiček.',
    active_dimensions=['množiny', 'sjednocení + průnik', 'rotace'], complexity={'integration': 'composition', 'rule_depth': 4, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop): tři současná pravidla (sjednocení, označení průniku, rotace o 60°).'),
    demos47, outs, test47, ans, dis47, 4, lambda v, k: {'A': list(v[0]), 'B': list(v[1])} if k == 'in' else {'E': list(v)}))

# ---------- 48 domino: top' = bottom, bottom' = top + bottom ----------
F48 = {'t': lambda t, b: t, 'b': lambda t, b: b, 't+b': lambda t, b: t + b, '|t-b|': lambda t, b: abs(t - b), 't+1': lambda t, b: t + 1,
       'b+1': lambda t, b: b + 1, 't-1': lambda t, b: t - 1, 'b-1': lambda t, b: b - 1, '2t': lambda t, b: 2 * t, '2b': lambda t, b: 2 * b,
       'max': lambda t, b: max(t, b), 'min': lambda t, b: min(t, b), '6-t': lambda t, b: 6 - t, '6-b': lambda t, b: 6 - b,
       't+b+1': lambda t, b: t + b + 1, 't+b-1': lambda t, b: t + b - 1, 'b+2': lambda t, b: b + 2, 't+2': lambda t, b: t + 2, '2t+b': lambda t, b: 2 * t + b, 't+2b': lambda t, b: t + 2 * b}
for c in range(7): F48['c%d' % c] = (lambda c: lambda t, b: c)(c)
H48 = {(x, y): (lambda fx, fy: lambda d: (fx(*d), fy(*d)))(F48[x], F48[y]) for x in F48 for y in F48}
rule48 = H48[('b', 't+b')]
demos48 = [(1, 2), (3, 1), (2, 4)]
test48 = (4, 1)
dis48 = [('swap_only', (1, 4)), ('sum_without_swap', (4, 5)), ('sum_on_top', (5, 1)), ('difference_instead_of_sum', (1, 3)), ('sum_on_top_and_swap', (5, 4))]
ans, outs = check('V12-48', demos48, test48, rule48, H48, dis48)
ITEMS.append(finish_item(item(id='V12-48', scene='domino_pips', relation_family='swap_plus_sum', strategy_superfamily='quantitative_transform',
    principle='Horní polovina výsledku má tolik ok, kolik měla dolní polovina. Dolní polovina výsledku má součet obou polovin.',
    active_dimensions=['počet', 'přesun', 'součet'], complexity={'integration': 'composition', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): kvantitativní rekurence (jako Fibonacci). Ověřeno proti 27×27 jednoduchým funkcím (kopie, součet, rozdíl, ±1, ×2, max/min, doplněk do 6, konstanty).'),
    demos48, outs, test48, ans, dis48, 1, lambda v, k: {'t': v[0], 'b': v[1]}))

# ---------- 49 clock_hands: long' = old short position, short' = short + 90° cw ----------
LIN = [(a, c, d) for a in (-1, 0, 1) for c in (-1, 0, 1) for d in range(8)]
H49 = {(p, q): (lambda p, q: lambda x: ((p[0] * x[0] + p[1] * x[1] + p[2]) % 8, (q[0] * x[0] + q[1] * x[1] + q[2]) % 8))(p, q) for p in LIN for q in LIN}
rule49 = lambda x: ((x[0] + 2) % 8, x[0])           # x = (short h, long m)
demos49 = [(3, 2), (5, 7), (1, 0)]
test49 = (7, 4)
dis49 = [('long_not_moved', ((7 + 2) % 8, 4)), ('wrong_direction', ((7 - 2) % 8, 7)), ('both_rotate', ((7 + 2) % 8, (4 + 2) % 8)),
         ('short_45_only', ((7 + 1) % 8, 7)), ('hands_swapped', (4, 7))]
ans, outs = check('V12-49', demos49, test49, rule49, H49, dis49)
ITEMS.append(finish_item(item(id='V12-49', scene='clock_hands', relation_family='hand_routing_plus_rotation', strategy_superfamily='source_routing',
    principle='Dlouhá ručička se přesune tam, kde byla krátká. Krátká ručička se otočí o 90° po směru hodinových ručiček.',
    active_dimensions=['poloha', 'přenos mezi objekty', 'rotace'], complexity={'integration': 'relational', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): přenos polohy mezi dvěma objekty + rotace. Ověřeno proti všem lineárním pravidlům (a·krátká + c·dlouhá + d, mod 8) pro obě ručičky.'),
    demos49, outs, test49, ans, dis49, 3, lambda v, k: {'h': v[0], 'm': v[1]}))

# ---------- 50 bar_trio: bars rotate left by one, the bar that moved to the end grows by one ----------
def mk50(perm, sel, dl):
    def f(x):
        y = [x[p] for p in perm]
        idx = {'none': [], 'all': [0, 1, 2], 0: [0], 1: [1], 2: [2], 'tallest': [y.index(max(y))] if y.count(max(y)) == 1 else None,
               'shortest': [y.index(min(y))] if y.count(min(y)) == 1 else None}[sel]
        if idx is None: raise ValueError
        for i in idx: y[i] += dl
        return tuple(y)
    return f
H50 = {(perm, sel, dl): mk50(perm, sel, dl) for perm in itertools.permutations(range(3)) for sel in ('none', 'all', 0, 1, 2, 'tallest', 'shortest') for dl in (1, -1, 2)}
rule50 = mk50((1, 2, 0), 2, 1)
demos50 = [(2, 4, 1), (3, 1, 2), (1, 2, 3)]
test50 = (4, 3, 1)
dis50 = [('shift_only', (3, 1, 4)), ('grow_without_shift', (5, 3, 1)), ('shift_right_and_grow', (2, 4, 3)), ('wrong_bar_grows', (4, 1, 4)), ('shift_and_shrink', (3, 1, 3))]
ans, outs = check('V12-50', demos50, test50, rule50, H50, dis50)
ITEMS.append(finish_item(item(id='V12-50', scene='bar_trio', relation_family='rotation_plus_subset_increment', strategy_superfamily='role_permutation',
    principle='Sloupce se posunou o jedno místo doleva; první sloupec přejde na konec. Jen ten sloupec, který přešel na konec, vyroste o jeden dílek.',
    active_dimensions=['pořadí', 'výška', 'pravidlo jen pro část'], complexity={'integration': 'composition', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): permutace + změna jen u podmnožiny (přesunutý prvek). Ověřeno proti 6 permutacím × výběru sloupce (žádný, všechny, pozice, nejvyšší, nejnižší) × změně (+1, −1, +2).'),
    demos50, outs, test50, ans, dis50, 0, lambda v, k: {'h': list(v)}))

# ---------- 51 banner: if top == bottom: colours of middle and outer stripes swap; otherwise stripes move down by one ----------
G51 = {}
for p in itertools.permutations(range(3)): G51['perm%s' % ''.join(map(str, p))] = (lambda p: lambda x: tuple(x[i] for i in p))(p)
G51['mtm'] = lambda x: (x[1], x[0], x[1]); G51['mbm'] = lambda x: (x[1], x[2], x[1]); G51['tmt'] = lambda x: (x[0], x[1], x[0])
G51['mmm'] = lambda x: (x[1],) * 3; G51['ttt'] = lambda x: (x[0],) * 3
CND = {'t==b': lambda x: x[0] == x[2], 't==m': lambda x: x[0] == x[1], 'm==b': lambda x: x[1] == x[2], 'always': lambda x: True}
H51 = {(c, g1, g2): (lambda c, g1, g2: lambda x: G51[g1](x) if CND[c](x) else G51[g2](x))(c, g1, g2) for c in CND for g1 in G51 for g2 in G51}
rule51 = H51[('t==b', 'mtm', 'perm201')]
demos51 = [('red', 'blue', 'red'), ('yellow', 'green', 'purple'), ('blue', 'purple', 'red')]
test51 = ('green', 'yellow', 'green')
dis51 = [('move_down_branch', ('green', 'green', 'yellow')), ('no_change', ('green', 'yellow', 'green')), ('move_up', ('yellow', 'green', 'green')),
         ('outer_only_recoloured', ('yellow', 'yellow', 'yellow')), ('middle_only_recoloured', ('green', 'green', 'green'))]
ans, outs = check('V12-51', demos51, test51, rule51, H51, dis51)
ITEMS.append(finish_item(item(id='V12-51', scene='stripe_banner', relation_family='conditional_permutation', strategy_superfamily='conditional_rule',
    principle='Mají-li horní a dolní pruh stejnou barvu, prostřední pruh a okrajové pruhy si barvy vymění. Jinak se všechny pruhy posunou o jeden dolů a dolní přejde nahoru. Testovaná vlajka patří do méně častého případu (stejné okraje), takže prosté „posuň dolů“ nestačí.',
    active_dimensions=['barva', 'pořadí', 'podmínka'], complexity={'integration': 'conditional', 'rule_depth': 4, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): podmíněné pravidlo, test ve vzácnější větvi (oprava zkratky z V12-31). Ověřeno proti 4 podmínkám × 11 × 11 operacím (permutace, přebarvení).'),
    demos51, outs, test51, ans, dis51, 5, lambda v, k: {'s': list(v)}))

# ---------- 52 pointer_dots: needle jumps to the next dot clockwise and that dot disappears ----------
def nxt(d, D, s):
    for k in range(1, 8):
        if (d + s * k) % 8 in D: return (d + s * k) % 8
def far(d, D):
    dist = lambda p: min((p - d) % 8, (d - p) % 8); m = max(dist(p) for p in D); c = [p for p in D if dist(p) == m]
    if len(c) > 1: raise ValueError
    return c[0]
def near(d, D):
    dist = lambda p: min((p - d) % 8, (d - p) % 8); m = min(dist(p) for p in D); c = [p for p in D if dist(p) == m]
    if len(c) > 1: raise ValueError
    return c[0]
TGT = {'cw': lambda d, D: nxt(d, D, 1), 'ccw': lambda d, D: nxt(d, D, -1), 'far': far, 'near': near, 'opp': lambda d, D: (d + 4) % 8,
       'stay': lambda d, D: d, '+1': lambda d, D: (d + 1) % 8, '+2': lambda d, D: (d + 2) % 8, '-1': lambda d, D: (d - 1) % 8, '-2': lambda d, D: (d - 2) % 8}
REM = {'target': lambda d, D, t: D - {t}, 'none': lambda d, D, t: D, 'others': lambda d, D, t: D & {t}, 'add_old': lambda d, D, t: (D - {t}) | {d},
       'rotate1': lambda d, D, t: frozenset((p + 1) % 8 for p in D), 'cwnext': lambda d, D, t: D - {nxt(d, D, 1)}, 'ccwnext': lambda d, D, t: D - {nxt(d, D, -1)}}
def mk52(tg, rm):
    def f(x):
        d, D = x; D = frozenset(D); t = TGT[tg](d, D); return (t, tuple(sorted(REM[rm](d, D, t))))
    return f
H52 = {(tg, rm): mk52(tg, rm) for tg in TGT for rm in REM}
rule52 = mk52('cw', 'target')
demos52 = [(0, (3, 6)), (5, (1, 4, 7)), (2, (0, 3, 5))]
test52 = (6, (1, 2, 4))
dis52 = [('ccw_dot', mk52('ccw', 'target')(test52)), ('dot_not_removed', mk52('cw', 'none')(test52)), ('opposite_dot', (2, (1, 4))),
         ('needle_stays_dot_removed', (6, (2, 4))), ('wrong_dot_removed', (1, (1, 2)))]
assert dis52[2][1] != rule52(test52)
ans, outs = check('V12-52', demos52, test52, rule52, H52, dis52)
ITEMS.append(finish_item(item(id='V12-52', scene='pointer_dots', relation_family='pointer_next_target_consume', strategy_superfamily='spatial_search',
    principle='Ručička se otočí k nejbližší tečce po směru hodinových ručiček a tato tečka zmizí. Ostatní tečky zůstanou.',
    active_dimensions=['směr', 'výběr cíle', 'odebrání'], complexity={'integration': 'relational', 'rule_depth': 3, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop): výběr cíle podle směru + odebrání. Ověřeno proti 10 pravidlům výběru (po/proti směru, nejbližší, nejvzdálenější, protější, pevný krok) × 7 pravidlům pro tečky.'),
    demos52, outs, test52, ans, dis52, 2, lambda v, k: {'d': v[0], 'D': list(v[1])}))

# ---------- 53 window_grid: the 2×2 block inside the frame rotates 90° clockwise, the rest stays ----------
CORN = {'TL': (0, 0), 'TR': (0, 1), 'BL': (1, 0), 'BR': (1, 1)}
D4 = {'id': lambda r, c, n: (r, c), 'cw': lambda r, c, n: (c, n - 1 - r), 'ccw': lambda r, c, n: (n - 1 - c, r), '180': lambda r, c, n: (n - 1 - r, n - 1 - c),
      'fh': lambda r, c, n: (r, n - 1 - c), 'fv': lambda r, c, n: (n - 1 - r, c), 'tr': lambda r, c, n: (c, r), 'atr': lambda r, c, n: (n - 1 - c, n - 1 - r)}
def tf(g, t, n, r0, c0):
    out = [row[:] for row in g]
    for r in range(n):
        for c in range(n):
            rr, cc = D4[t](r, c, n); out[r0 + rr][c0 + cc] = g[r0 + r][c0 + c]
    return out
def mk53(tin, tall, comp):
    def f(x):
        g, w = [list(r) for r in x[0]], x[1]; r0, c0 = CORN[w]
        g = tf(g, tin, 2, r0, c0); g = tf(g, tall, 3, 0, 0)
        if comp:
            for r in range(3):
                for c in range(3):
                    if not (r0 <= r < r0 + 2 and c0 <= c < c0 + 2): g[r][c] ^= 1
        return (tuple(tuple(r) for r in g), w)
    return f
H53 = {(a, b, c): mk53(a, b, c) for a in D4 for b in D4 for c in (0, 1)}
rule53 = mk53('cw', 'id', 0)
G = lambda s: tuple(tuple(int(ch) for ch in s[i:i + 3]) for i in (0, 3, 6))
demos53 = [(G('100110001'), 'TL'), (G('010001111'), 'BR'), (G('101010110'), 'TR')]
test53 = (G('011001110'), 'BL')
def flat(x): return x
dis53 = [('rotate_ccw_inside', mk53('ccw', 'id', 0)(test53)), ('whole_grid_rotated', mk53('id', 'cw', 0)(test53)), ('no_change', test53),
         ('inside_180', mk53('180', 'id', 0)(test53)), ('wrong_window_rotated', (tuple(tuple(r) for r in tf([list(r) for r in test53[0]], 'cw', 2, 0, 0)), test53[1]))]
ans, outs = check('V12-53', demos53, test53, rule53, H53, dis53)
ITEMS.append(finish_item(item(id='V12-53', scene='window_grid', relation_family='local_rotation_in_window', strategy_superfamily='spatial_transform',
    principle='Jen čtyři tečky uvnitř oranžového rámečku se otočí o 90° po směru hodinových ručiček (každá se posune o jedno místo dokola). Tečky mimo rámeček zůstanou, rámeček zůstane na místě.',
    active_dimensions=['poloha', 'rotace', 'pravidlo jen pro část'], complexity={'integration': 'local_transform', 'rule_depth': 3, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop): transformace jen uvnitř vyznačené oblasti, oblast se mezi řádky mění. Ověřeno proti 8 × 8 symetriím (uvnitř okna × celé mřížky) × inverzi okolí.'),
    demos53, outs, test53, ans, dis53, 1, lambda v, k: {'g': [list(r) for r in v[0]], 'w': v[1]}))

# ---------- 54 coin_stacks: |a − b| coins in the colour of the taller stack ----------
N54 = {'a+b': lambda a, b: a + b, '|a-b|': lambda a, b: abs(a - b), 'max': max, 'min': min, 'a': lambda a, b: a, 'b': lambda a, b: b,
       'max+1': lambda a, b: max(a, b) + 1, 'min+1': lambda a, b: min(a, b) + 1, '|a-b|+1': lambda a, b: abs(a - b) + 1, 'a-1': lambda a, b: a - 1, 'b-1': lambda a, b: b - 1}
C54 = {'larger': lambda a, b: 'blue' if a > b else 'red', 'smaller': lambda a, b: 'red' if a > b else 'blue', 'left': lambda a, b: 'blue', 'right': lambda a, b: 'red'}
H54 = {(n, c): (lambda n, c: lambda x: (N54[n](*x), C54[c](*x)))(n, c) for n in N54 for c in C54}
rule54 = H54[('|a-b|', 'larger')]
demos54 = [(5, 2), (1, 3), (4, 5)]
test54 = (6, 2)
dis54 = [('sum_larger_colour', (8, 'blue')), ('difference_smaller_colour', (4, 'red')), ('taller_stack_copied', (6, 'blue')),
         ('smaller_stack_copied', (2, 'red')), ('difference_plus_one', (5, 'blue'))]
ans, outs = check('V12-54', demos54, test54, rule54, H54, dis54)
ITEMS.append(finish_item(item(id='V12-54', scene='coin_stacks', relation_family='difference_plus_winner_colour', strategy_superfamily='quantitative_transform',
    principle='Výsledný sloupek má tolik mincí, o kolik je vyšší sloupek větší než nižší (rozdíl). Mince mají barvu vyššího sloupku.',
    active_dimensions=['počet', 'rozdíl', 'barva podle vztahu'], complexity={'integration': 'relational', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop): kvantitativní vztah + výběr atributu podle porovnání. Ověřeno proti 11 početním × 4 barevným pravidlům.'),
    demos54, outs, test54, ans, dis54, 4, lambda v, k: {'a': v[0], 'b': v[1]} if k == 'in' else {'n': v[0], 'color': v[1]}))

# ---------- 55 layered_cards: colours move one place right (last to first), stacking order by place reverses ----------
# x = (colours by place L,M,R; rank by place 0 = front)
def mk55(cp, mode, zp, inv):
    def f(x):
        c, r = x; c2 = tuple(c[i] for i in cp)
        if mode == 'pos': r2 = tuple(r[i] for i in zp)
        else:  # rank travels with the colour
            r2 = tuple(r[c.index(col)] for col in c2)
        if inv: r2 = tuple(2 - v for v in r2)
        return (c2, r2)
    return f
PERM = list(itertools.permutations(range(3)))
H55 = {}
for cp in PERM:
    for inv in (0, 1):
        for zp in PERM: H55[(cp, 'pos', zp, inv)] = mk55(cp, 'pos', zp, inv)
        H55[(cp, 'col', None, inv)] = mk55(cp, 'col', None, inv)
rule55 = mk55((2, 0, 1), 'pos', (0, 1, 2), 1)
demos55 = [(('red', 'yellow', 'blue'), (0, 1, 2)), (('green', 'purple', 'red'), (1, 0, 2)), (('blue', 'green', 'yellow'), (1, 2, 0))]
test55 = (('yellow', 'red', 'green'), (2, 1, 0))
dis55 = [('colours_only', (('green', 'yellow', 'red'), (2, 1, 0))), ('stacking_only', (('yellow', 'red', 'green'), (0, 1, 2))),
         ('colours_left', (('red', 'green', 'yellow'), (0, 1, 2))), ('stacking_moves_with_colour', mk55((2, 0, 1), 'col', None, 0)(test55)),
         ('stacking_moves_with_colour_reversed', mk55((2, 0, 1), 'col', None, 1)(test55))]
def vis55(x): c, r = x; return (tuple(c), r[0] < r[1], r[1] < r[2])
FB = {'a': lambda a, b: a, '!a': lambda a, b: not a, 'b': lambda a, b: b, '!b': lambda a, b: not b, 'T': lambda a, b: True, 'F': lambda a, b: False}
HV55 = {(cp, f1, f2): (lambda cp, f1, f2: lambda x: (tuple(vis55(x)[0][i] for i in cp), FB[f1](*vis55(x)[1:]), FB[f2](*vis55(x)[1:])))(cp, f1, f2) for cp in PERM for f1 in FB for f2 in FB}
check('V12-55-visible', demos55, test55, lambda x: vis55(rule55(x)), HV55, [(m, vis55(o)) for m, o in dis55])
ans, outs = check('V12-55', demos55, test55, rule55, H55, dis55)
ITEMS.append(finish_item(item(id='V12-55', scene='layered_cards', relation_family='colour_shift_plus_depth_reversal', strategy_superfamily='role_permutation',
    principle='Barvy karet se posunou o jedno místo doprava (pravá barva přejde vlevo). Pořadí vrstev zůstává vázané na místo a obrátí se: karta na místě, které bylo vpředu, je teď vzadu, a naopak; prostřední zůstane prostřední.',
    active_dimensions=['barva', 'poloha', 'překrývání (hloubka)'], complexity={'integration': 'independent_attributes', 'rule_depth': 4, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop): dva atributy se mění nezávisle (barva po místech, hloubka podle místa). Ověřeno proti 6 permutacím barev × (hloubka podle místa: 6 permutací × obrácení; hloubka putuje s barvou × obrácení).'),
    demos55, outs, test55, ans, dis55, 3, lambda v, k: {'c': list(v[0]), 'r': list(v[1])}))

if __name__ == '__main__':
    for r in REPORT: print(r[0], 'OK' if r[1] else 'FAIL', 'hyps=%d fitting=%d' % (r[2], r[3]), r[4])
    json.dump(ITEMS, open('new_items.json', 'w'), ensure_ascii=False, indent=1)
