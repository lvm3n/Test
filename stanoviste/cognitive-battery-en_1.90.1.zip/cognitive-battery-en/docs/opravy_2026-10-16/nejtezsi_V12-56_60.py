# Nejtěžší pilotní položky V12-56..60 (2026-10-16). Potřebuje vedle sebe gen.py (= nove_polozky_V12-46_55.py).
import itertools, json
exec(open('gen.py').read().split("ITEMS = []")[0])
ITEMS = []
def item(**kw): return dict(tier='ceiling', format='triples_3x2', pilot=1, randomize_options_in_deployment=True, source='v12-2026-10-16b', **kw)

# ---------- 56 abacus: each rod = sum of the other two rods; the fullest rod is red ----------
COMB = [c for c in itertools.product((0, 1), repeat=3) if any(c)] + [(1, 1, 1)]
def lin(cf, x, k=0): return sum(a * b for a, b in zip(cf, x)) + k
NUMF = {}
for cf in set(COMB):
    for k in (-1, 0, 1): NUMF[(cf, k)] = (lambda cf, k: lambda x: lin(cf, x, k))(cf, k)
NUMF[('T-x', 0)] = None
SEL = ['max_out', 'min_out', 'max_in', 'min_in', 0, 1, 2]
def red(sel, x, y):
    if isinstance(sel, int): return sel
    v = y if sel.endswith('out') else x; m = max(v) if sel.startswith('max') else min(v)
    if v.count(m) != 1: raise ValueError
    return v.index(m)
keys = [k for k in NUMF if NUMF[k]]
# hypothesis: per output rod one numeric function (shared structure is a special case) -> too many combos (49^3); restrict to "same structural rule shifted":
H56 = {}
for k in keys:
    for sh in range(3):
        for rev in (0, 1):
            for sel in SEL:
                def f(x, k=k, sh=sh, rev=rev, sel=sel):
                    cf, kk = k
                    y = []
                    for i in range(3):
                        j = (i + sh) % 3; xs = x[j:] + x[:j]       # rotate inputs so that "own" rod is first
                        y.append(lin(cf, xs, kk))
                    if rev: y = y[::-1]
                    y = tuple(y); return (y, red(sel, x, y))
                H56[(k, sh, rev, sel)] = f
# plus independent per-rod linear functions (no colour variation) checked separately below
rule56 = lambda x: (lambda y: (y, y.index(max(y))))(tuple(sum(x) - v for v in x))
demos56 = [(1, 3, 2), (4, 1, 0), (2, 0, 3)]
test56 = (0, 3, 2)
dis56 = [('sum_with_neighbour', ((3, 5, 2), 1)), ('red_on_smallest', ((5, 2, 3), 1)), ('red_on_last', ((5, 2, 3), 2)),
         ('difference_of_others', ((1, 2, 3), 2)), ('sum_of_all_no_red', ((5, 5, 5), -1))]
ans, outs = check('V12-56', demos56, test56, rule56, H56, dis56)
# extra: every per-rod combination of linear functions consistent with numeric demos must give the same numbers
numout = [o[0] for o in outs]; per = []
for i in range(3):
    ok = {lin(cf, test56, k) for (cf, k) in keys if all(lin(cf, d, k) == o[i] for d, o in zip(demos56, numout))}
    per.append(ok)
REPORT.append(('V12-56-per-rod', all(len(s) == 1 for s in per), len(keys) ** 3, 0, [per]))
ITEMS.append(finish_item(item(id='V12-56', scene='abacus_rods', relation_family='sum_of_others_plus_max_mark', strategy_superfamily='quantitative_transform',
    principle='Každá tyč výsledku má tolik korálků, kolik mají dohromady dvě zbývající tyče vstupu. Tyč s nejvíce korálky je červená, ostatní modré.',
    active_dimensions=['počet', 'součet ostatních', 'označení podle vztahu'], complexity={'integration': 'composition', 'rule_depth': 4, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop, cíl b > +2,5): početní pravidlo, které není „součet sousedů“, + označení podle vztahu. Ověřeno proti 7 lineárním kombinacím (±1) × posunům × obrácení × 7 pravidlům barvy a navíc po tyčích zvlášť.'),
    demos56, outs, test56, ans, dis56, 3, lambda v, k: {'n': list(v)} if k == 'in' else {'n': list(v[0]), 'red': v[1]}))

# ---------- 57 lamp_panel: odd number of lit lamps -> rotate 90° cw; even -> mirror left-right ----------
def g9(s): return tuple(tuple(int(c) for c in s[i:i + 3]) for i in (0, 3, 6))
D4 = {'id': lambda r, c, n: (r, c), 'cw': lambda r, c, n: (c, n - 1 - r), 'ccw': lambda r, c, n: (n - 1 - c, r), '180': lambda r, c, n: (n - 1 - r, n - 1 - c),
      'fh': lambda r, c, n: (r, n - 1 - c), 'fv': lambda r, c, n: (n - 1 - r, c), 'tr': lambda r, c, n: (c, r), 'atr': lambda r, c, n: (n - 1 - c, n - 1 - r)}
def tf9(g, t):
    out = [[0] * 3 for _ in range(3)]
    for r in range(3):
        for c in range(3):
            r2, c2 = D4[t](r, c, 3); out[r2][c2] = g[r][c]
    return tuple(tuple(r) for r in out)
CND57 = {'odd': lambda g: sum(map(sum, g)) % 2 == 1, 'gt4': lambda g: sum(map(sum, g)) > 4, 'center': lambda g: g[1][1] == 1,
         'tl': lambda g: g[0][0] == 1, 'top3': lambda g: sum(g[0]) >= 2, 'always': lambda g: True, 'lt4': lambda g: sum(map(sum, g)) < 4}
H57 = {}
for cn in CND57:
    for t1 in D4:
        for t2 in D4:
            for inv in (0, 1):
                H57[(cn, t1, t2, inv)] = (lambda cn, t1, t2, inv: lambda g: (lambda gg: tuple(tuple(1 - v for v in r) for r in gg) if inv else gg)(tf9(g, t1) if CND57[cn](g) else tf9(g, t2)))(cn, t1, t2, inv)
rule57 = H57[('odd', 'cw', 'fh', 0)]
demos57 = [g9('011001111'), g9('110010101'), g9('101110000')]
test57 = g9('011010101')
print('57 counts', [sum(map(sum, d)) for d in demos57], sum(map(sum, test57)))
dis57 = [('even_branch_applied', tf9(test57, 'fh')), ('mirror_up_down', tf9(test57, 'fv')), ('no_change', test57),
         ('rotate_ccw', tf9(test57, 'ccw')), ('rotate_180', tf9(test57, '180'))]
ans, outs = check('V12-57', demos57, test57, rule57, H57, dis57)
ITEMS.append(finish_item(item(id='V12-57', scene='lamp_panel', relation_family='parity_conditional_transform', strategy_superfamily='conditional_rule',
    principle='Svítí-li lichý počet lamp, celý panel se otočí o 90° po směru hodinových ručiček. Svítí-li sudý počet, panel se zrcadlí zleva doprava.',
    active_dimensions=['počet', 'podmínka', 'prostorová transformace'], complexity={'integration': 'conditional', 'rule_depth': 4, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop, cíl b > +2,5): podmínku je nutné objevit (parita počtu), test patří do větve ukázané jen jednou. Ověřeno proti 7 podmínkám × 8 × 8 symetriím × inverzi.'),
    demos57, outs, test57, ans, dis57, 0, lambda v, k: {'g': [list(r) for r in v]}))

# ---------- 58 turn_gauge: output arrow shows the turn that carries the left arrow onto the right one ----------
LIN2 = [(a, c, d) for a in (-2, -1, 0, 1, 2) for c in (-2, -1, 0, 1, 2) for d in range(8)]
H58 = {p: (lambda p: lambda x: (p[0] * x[0] + p[1] * x[1] + p[2]) % 8)(p) for p in LIN2}
rule58 = lambda x: (x[1] - x[0]) % 8
demos58 = [(1, 3), (6, 3), (7, 2)]
test58 = (3, 2)
dis58 = [('sum_of_turns', (test58[0] + test58[1]) % 8), ('turn_wrong_direction', (test58[0] - test58[1]) % 8), ('copy_right', test58[1]), ('copy_left', test58[0]), ('double_turn', (2 * (test58[1] - test58[0])) % 8)]
print('58 dis', [d[1] for d in dis58], rule58(test58))
ans, outs = check('V12-58', demos58, test58, rule58, H58, dis58)
ITEMS.append(finish_item(item(id='V12-58', scene='turn_gauge', relation_family='transformation_as_object', strategy_superfamily='relational_abstraction',
    principle='Výsledná šipka (měřeno od značky nahoře) ukazuje, o kolik a kterým směrem je potřeba otočit levou šipku, aby mířila jako pravá.',
    active_dimensions=['směr', 'rozdíl úhlů', 'transformace jako objekt'], complexity={'integration': 'relational', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop, cíl b > +2,5): výstupem není objekt, ale vztah mezi vstupy (o kolik se otočil). Ověřeno proti všem lineárním pravidlům a·L + c·P + d (mod 8), a, c ∈ −2…2.'),
    demos58, outs, test58, ans, dis58, 2, lambda v, k: {'L': v[0], 'R': v[1]} if k == 'in' else {'S': v}))

# ---------- 59 bounce_track: ball moves 3 cells in arrow direction, bounces off the ends; each bounce flips the arrow ----------
def sim(p, d, n, mode, amode):
    b = 0
    for _ in range(n):
        q = p + d
        if 0 <= q <= 4: p = q
        elif mode == 'bounce': d = -d; p = p + d; b += 1
        elif mode == 'wrap': p = q % 5
        else: pass
    dd = {'keep': d if mode == 'bounce' else d, 'orig': None, 'flip_always': None}
    return p, d, b
def mk59(n, mode, amode):
    def f(x):
        p, d = x; p2, d2, b = sim(p, d, n, mode, amode)
        if amode == 'final': dout = d2
        elif amode == 'orig': dout = d
        elif amode == 'flip': dout = -d
        else: dout = d if b == 0 else -d   # 'flip_if_bounced'
        return (p2, dout)
    return f
H59 = {(n, m, a): mk59(n, m, a) for n in (1, 2, 3, 4, 5) for m in ('bounce', 'wrap', 'clamp') for a in ('final', 'orig', 'flip', 'flip_if_bounced')}
rule59 = mk59(3, 'bounce', 'final')
demos59 = [(0, 1), (3, 1), (1, -1)]
test59 = (2, 1)
dis59 = [('no_bounce_wrap', mk59(3, 'wrap', 'orig')(test59)), ('arrow_not_flipped', (3, 1)), ('stops_at_end', (4, 1)), ('five_steps', mk59(5, 'bounce', 'final')(test59)), ('four_steps', mk59(4, 'bounce', 'final')(test59))]
print('59', [rule59(d) for d in demos59], rule59(test59), [d[1] for d in dis59])
ans, outs = check('V12-59', demos59, test59, rule59, H59, dis59)
ITEMS.append(finish_item(item(id='V12-59', scene='bounce_track', relation_family='motion_with_reflection', strategy_superfamily='spatial_simulation',
    principle='Kulička se posune o tři políčka ve směru šipky. Když narazí na konec dráhy, odrazí se a pokračuje zpět; šipka pak ukazuje nový směr pohybu.',
    active_dimensions=['poloha', 'počet kroků', 'odraz + směr'], complexity={'integration': 'simulation', 'rule_depth': 3, 'sensory_load': 'low'},
    notes='Pilot 2026-10-16 (strop, cíl b > +2,5): mentální simulace s odrazem. Ověřeno proti 1–5 krokům × (odraz, přetečení, zastavení) × 4 pravidlům pro šipku.'),
    demos59, outs, test59, ans, dis59, 4, lambda v, k: {'p': v[0], 'd': v[1]}))

# ---------- 60 crate_box: box turns 90° clockwise, then the crates fall down ----------
def fallc(g, dirn):
    g = [list(r) for r in g]
    if dirn == 'none': return tuple(tuple(r) for r in g)
    if dirn in ('D', 'U'):
        for c in range(3):
            col = [g[r][c] for r in range(3) if g[r][c]]
            col = [0] * (3 - len(col)) + col if dirn == 'D' else col + [0] * (3 - len(col))
            for r in range(3): g[r][c] = col[r]
    else:
        for r in range(3):
            row = [v for v in g[r] if v]; g[r] = [0] * (3 - len(row)) + row if dirn == 'R' else row + [0] * (3 - len(row))
    return tuple(tuple(r) for r in g)
HC = {}
for t in D4:
    for fd in ('none', 'D', 'U', 'L', 'R'):
        for order in ('tf', 'ft'):
            HC[(t, fd, order)] = (lambda t, fd, order: lambda g: fallc(tf9(g, t), fd) if order == 'tf' else tf9(fallc(g, fd), t))(t, fd, order)
rule60 = HC[('cw', 'D', 'tf')]
Y, B_, R_, G_ = 'yellow', 'blue', 'red', 'green'
demos60 = [((0, 0, 0), (Y, 0, B_), (R_, 0, G_)), ((0, G_, 0), (0, R_, 0), (Y, B_, 0)), ((0, Y, 0), (0, R_, 0), (0, G_, B_))]
test60 = ((R_, 0, 0), (B_, 0, 0), (Y, G_, 0))
dis60 = [('rotated_no_fall', tf9(test60, 'cw')), ('rotate_ccw_fall', fallc(tf9(test60, 'ccw'), 'D')), ('no_change', test60),
         ('mirror_fall', fallc(tf9(test60, 'fh'), 'D')), ('rotate_180_fall', fallc(tf9(test60, '180'), 'D'))]
ans, outs = check('V12-60', demos60, test60, rule60, HC, dis60)
ITEMS.append(finish_item(item(id='V12-60', scene='crate_box', relation_family='rotation_plus_gravity', strategy_superfamily='spatial_simulation',
    principle='Krabice se otočí o 90° po směru hodinových ručiček (dno se stane levou stěnou) a bedýnky pak spadnou dolů na nové dno; pořadí bedýnek nad sebou se při pádu nemění.',
    active_dimensions=['rotace', 'gravitace', 'pořadí kroků'], complexity={'integration': 'simulation', 'rule_depth': 3, 'sensory_load': 'medium'},
    notes='Pilot 2026-10-16 (strop, cíl b > +2,5): rotace + fyzikální krok (pád). Ověřeno proti 8 symetriím × 5 směrům pádu × pořadí kroků.'),
    demos60, outs, test60, ans, dis60, 1, lambda v, k: {'g': [list(r) for r in v]}))

if __name__ == '__main__':
    for r in REPORT: print(r[0], 'OK' if r[1] else 'FAIL', 'hyps=%d fitting=%d' % (r[2], r[3]), r[4])
    json.dump(ITEMS, open('new_items2.json', 'w'), ensure_ascii=False, indent=1)
