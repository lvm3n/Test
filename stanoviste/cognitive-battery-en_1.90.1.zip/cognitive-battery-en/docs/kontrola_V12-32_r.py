import itertools
P=['top','BL','BR']; C=['red','yellow','blue']
def row(objs): return {o[0]:(o[1],o[2]) for o in objs}  # shape -> (pos,color)
R1i=[('circle','top','red'),('triangle','BL','yellow'),('square','BR','blue')]
R1o=[('square','top','yellow'),('circle','BL','blue'),('triangle','BR','red')]
NEW=True
R2i=[('diamond','top','yellow'),('star','BL','red'),('hex','BR','blue')]
R2o=[('hex','top','yellow'),('star','BL','red'),('diamond','BR','blue')]
OLD2i=[('diamond','top','yellow'),('star','BL','blue'),('hex','BR','red')]
OLD2o=[('star','top','red'),('hex','BL','yellow'),('diamond','BR','blue')]
R3i=[('square','top','blue'),('circle','BL','yellow'),('triangle','BR','red')]
opts={'A':[('square','top','blue'),('triangle','BL','yellow'),('circle','BR','red')],
 'B':[('square','top','blue'),('circle','BL','yellow'),('triangle','BR','red')],
 'C':[('square','top','blue'),('triangle','BL','red'),('circle','BR','yellow')],
 'D':[('circle','top','blue'),('triangle','BL','yellow'),('square','BR','red')],
 'E':[('triangle','top','yellow'),('square','BL','blue'),('circle','BR','red')],
 'F':[('square','top','red'),('triangle','BL','blue'),('circle','BR','yellow')]}
perms=lambda xs:[dict(zip(xs,p)) for p in itertools.permutations(xs)]
# position rules: f(pos,color) ; color rules: g(pos,color,newpos)
posrules=[]
for m in perms(P): posrules.append(('posperm'+str(list(m.values())), lambda p,c,m=m: m[p]))
for m in perms(P): posrules.append(('bycolor'+str(list(m.values())), lambda p,c,m=m: m[c] if False else None))
posrules=[r for r in posrules if not r[0].startswith('bycolor')]
for vals in itertools.permutations(P):
    m=dict(zip(C,vals)); posrules.append(('colorTo'+str(vals), lambda p,c,m=m: m[c]))
colrules=[]
for m in perms(C): colrules.append(('colperm'+str(list(m.values())), lambda p,c,q,m=m: m[c]))
for vals in itertools.permutations(C):
    m=dict(zip(P,vals)); colrules.append(('fromOldPos'+str(vals), lambda p,c,q,m=m: m[p]))
    colrules.append(('fromNewPos'+str(vals), lambda p,c,q,m=m: m[q]))
def apply(objs,pr,cr):
    out=[]
    for s,p,c in objs:
        q=pr(p,c); out.append((s,q,cr(p,c,q)))
    if len({o[1] for o in out})<3: return None
    return sorted(out)
def test(r2i,r2o,label):
    preds={}
    for pn,pr in posrules:
        for cn,cr in colrules:
            if apply(R1i,pr,cr)==sorted(R1o) and apply(r2i,pr,cr)==sorted(r2o):
                a=apply(R3i,pr,cr); k=[x for x,o in opts.items() if sorted(o)==a]
                preds[(pn,cn)]=k[0] if k else 'jiné'
    print(label, 'konzistentních pravidel:', len(preds), '→ předpovědi:', sorted(set(preds.values())))
    for k,v in preds.items(): print('   ',k,v)
    # single-row heuristics: rules consistent with row1 only / row2 only
    for lab,ri,ro in (('jen 1. řádek',R1i,R1o),('jen 2. řádek',r2i,r2o)):
        s=set()
        for pn,pr in posrules:
            for cn,cr in colrules:
                if apply(ri,pr,cr)==sorted(ro):
                    a=apply(R3i,pr,cr); k=[x for x,o in opts.items() if sorted(o)==a]; s.add(k[0] if k else 'jiné')
        print('   ',lab,'→ možnosti:',sorted(s))
test(OLD2i,OLD2o,'PŮVODNÍ')
test(R2i,R2o,'NOVÁ')
# "všechno se změní" (barva i pozice) splňuje:
for lab,ri,ro in (('původní',OLD2i,OLD2o),('nová',R2i,R2o)):
    allch=lambda i,o: all(dict((s,(p,c)) for s,p,c in i)[s][0]!=p and dict((s,(p,c)) for s,p,c in i)[s][1]!=c for s,p,c in o)
    print(lab,'2. řádek: vše se mění =',allch(ri,ro),'| možnosti se vším změněným:',[k for k,o in opts.items() if allch(R3i,o)])
