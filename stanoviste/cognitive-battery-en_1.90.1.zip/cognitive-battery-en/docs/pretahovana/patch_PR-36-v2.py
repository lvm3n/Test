"""Přetahovaná PR-36-v1 -> PR-36-v2: pořadí podle b z položkové analýzy 2026-11-12 (bloky 3/4/5 figurek,
uvnitř bloku vzestupně podle b), úlohy s 5 figurkami limit 60 s (ostatní 45 s).
Použití: python3 -I patch_pt.py <plugin_dir> <cz|en> <analyza.csv>"""
import sys, json, re, csv

root, lang, csv_path = sys.argv[1], sys.argv[2], sys.argv[3]
app = root + '/assets/app.html'
s = open(app, encoding='utf-8').read()

b = {r['item']: float(r['b']) for r in csv.DictReader(open(csv_path, encoding='utf-8'))}

# 1) banka
m = re.search(r'const BANK_PT = (\{.*?\});\n', s)
bank = json.loads(m.group(1))
assert bank['verze'] == 'PR-36-v1' and len(bank['items']) == 36
old = [it['id'] for it in bank['items']]
items = sorted(bank['items'], key=lambda it: (it['n_shapes'], round(b[it['id']], 3), old.index(it['id'])))
for it in items:
    it['limit_s'] = 60 if it['n_shapes'] >= 5 else 45
    it['b_pilot'] = round(b[it['id']], 2)
bank['items'] = items
bank['verze'] = 'PR-36-v2'
bank['limit_s'] = 45
bank['limit_s_5_figurek'] = 60
s = s[:m.start(1)] + json.dumps(bank, ensure_ascii=False, separators=(',', ':')) + s[m.end(1):]
new = [it['id'] for it in items]

def rep(a, c, n=1):
    global s
    assert s.count(a) == n, (a[:80], s.count(a))
    s = s.replace(a, c)

# 2) modul: limit podle položky
rep("PRAC = B.practice, LIMIT = 45, STOPN",
    "PRAC = B.practice, LIMIT = 45, LIM = (x) => x.limit_s || LIMIT, STOPN")
rep("startTimer(phase === 'tut' || S.untimed ? null : LIMIT);",
    "startTimer(phase === 'tut' || S.untimed ? null : LIM(item));   // od CZ 4.19.0 / EN 1.77.0: limit podle položky (5 figurek 60 s, jinak 45 s)")
rep("limit_s:S.untimed ? 0 : LIMIT,",
    "limit_s:S.untimed ? 0 : LIMIT, limit_s_max:S.untimed ? 0 : Math.max(...ITEMS.map(LIM)),")

# 3) instrukce
if lang == 'cz':
    rep("Na každou úlohu máte 45 sekund;", "Na každou úlohu máte 45 sekund, na úlohy s pěti figurkami 60 sekund;")
    rep("Na každou úlohu máš 45 sekund;", "Na každou úlohu máš 45 sekund, na úlohy s pěti figurkami 60 sekund;")
else:
    rep("You have 45 seconds for each item;", "You have 45 seconds for each item, 60 seconds for items with five figures;", 2)

# 4) skupiny srovnání, značka řazení
rep("pretahovana:[['PR-50-v1'], ['PR-36-v1']],   // 36 = jiný počet položek → samostatná skupina",
    "pretahovana:[['PR-50-v1'], ['PR-36-v1'], ['PR-36-v2']],   // 36 = jiný počet položek → samostatná skupina; v2 = jiné pořadí + 60 s u 5 figurek → samostatná")
rep("const BANK_ORDER_TAG = {",
    "const BANK_ORDER_TAG = {pretahovana:'b-2026-11-12 (N=45, PR-36-v1); bloky 3/4/5 figurek, uvnitr bloku podle b; 5 figurek 60 s', ")

# 5) komentář u modulu
rep("   ukončení po 4 chybách za sebou (vypršení i přeskočení = chyba), pak sondy.\n",
    "   ukončení po 4 chybách za sebou (vypršení i přeskočení = chyba), pak sondy.\n"
    "   Od CZ 4.19.0 / EN 1.77.0 PR-36-v2: stejné položky, pořadí podle b z pilotu PR-36-v1 (N = 45, 2026-11-12) – bloky 3 / 4 / 5 figurek,\n"
    "   uvnitř bloku vzestupně podle b; úlohy s 5 figurkami mají limit 60 s (pole limit_s u položky), ostatní 45 s.\n")
open(app, 'w', encoding='utf-8').write(s)

# 6) codebook: přidat řádky v2
cb = root + '/assets/codebook.csv'
rows = open(cb, encoding='utf-8-sig').read().splitlines()
v1 = {r.split(';')[3]: r for r in rows if r.startswith('pretahovana;PR-36-v1;')}
add = []
lim = {i['id']: i['limit_s'] for i in items}
for k, iid in enumerate(new, 1):
    r = v1[iid].replace('pretahovana;PR-36-v1;', 'pretahovana;PR-36-v2;', 1)
    r = re.sub(r'^(pretahovana;PR-36-v2;)\d+;', lambda mm: mm.group(1) + str(k) + ';', r)
    r, n = re.subn(r'(plán z [^;]*?, složitost [0-9.]+)', lambda mm: mm.group(1) + f', b pilot {b[iid]:.2f}, limit {lim[iid]} s', r, count=1)
    assert n == 1, iid
    add.append(r)
last = max(i for i, r in enumerate(rows) if r.startswith('pretahovana;PR-36-v1;'))
rows[last + 1:last + 1] = add
open(cb, 'w', encoding='utf-8-sig').write('\n'.join(rows) + '\n')

# 7) banka do docs
json.dump(bank, open(root + '/docs/pretahovana/pretahovana_PR-36-v2.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(lang, 'OK', ' '.join(new))
