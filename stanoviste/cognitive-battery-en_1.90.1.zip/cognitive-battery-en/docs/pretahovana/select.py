"""Výběr 50 položek Přetahované z poolů a sestavení banky PR-50-v1 (seřazeno podle konstrukční obtížnosti)."""
import json, glob, itertools, collections, random
import numpy as np

QUOTA = {-3: 4, -2: 5, -1: 7, 0: 9, 1: 9, 2: 8, 3: 8}
KEYMAP = {'red_circle': 'circle', 'blue_square': 'square', 'green_triangle': 'triangle', 'gold_diamond': 'diamond', 'violet_pentagon': 'pentagon'}

pool = []
for f in sorted(glob.glob('pool_*.json')):
    pool += json.load(open(f))

def canon(it):
    rank = {f: r for r, f in enumerate(it['answer_index_order'])}
    out = []
    for c in it['clues']:
        L = tuple(sorted(r for f, n in enumerate(c['left']) for r in [rank[f]] * n))
        R = tuple(sorted(r for f, n in enumerate(c['right']) for r in [rank[f]] * n))
        res = c['result']
        if L > R:
            L, R = R, L; res = {'left': 'right', 'right': 'left', 'tie': 'tie'}[res]
        out.append((L, R, res))
    return (it['n_shapes'], tuple(sorted(out)))

def score(it):
    return (1.0 * (it['n_shapes'] - 3) + 0.6 * (it['n_clues'] - 2) + 1.2 * it['pairs_needing_combination']
            + 0.6 * (it['max_clues_combined'] - 1) + 0.15 * it['figures_shown'] + 0.3 * it['misleading_matches'])

seen, uniq = set(), []
for it in sorted(pool, key=lambda x: x['target_z']):
    k = canon(it)
    if k in seen:
        continue
    seen.add(k); it['complexity'] = round(score(it), 2); uniq.append(it)

rng = random.Random(7)
chosen = []
for z, q in QUOTA.items():
    cand = sorted([it for it in uniq if it['target_z'] == z], key=lambda x: (x['complexity'], x['figures_shown']))
    assert len(cand) >= q, (z, len(cand))
    if len(cand) == q:
        pick = cand
    else:
        # rovnoměrné pokrytí složitosti v pásmu; u stejného kvantilu méně figurek na obrazovce (rychlejší)
        idx = sorted(set(int(round(x)) for x in np.linspace(0, len(cand) - 1, q)))
        while len(idx) < q:
            extra = [i for i in range(len(cand)) if i not in idx]
            idx = sorted(idx + [extra[len(extra) // 2]])
        pick = [cand[i] for i in idx]
    chosen += pick
    print(z, 'pool', len(cand), 'vybráno', len(pick), 'složitost', [p['complexity'] for p in pick])

chosen.sort(key=lambda x: (x['target_z'], x['complexity'], x['figures_shown']))
# vyvážení figurek: která figurka je nejsilnější / uprostřed / nejslabší (jinak by šlo hádat podle tvaru)
ALL = ['circle', 'square', 'triangle', 'diamond', 'pentagon']
cnt = collections.Counter(); prev = None
for it in chosen:
    n = it['n_shapes']; best = None
    for _ in range(300):
        g = rng.sample(ALL, n)
        mp = {old: new for old, new in zip([KEYMAP[f] for f in it['figures']], g)}
        order = [mp[KEYMAP[f]] for f in it['answer_order']]
        keys = [(order[0], 'top'), (order[-1], 'bottom')] + [(f, 'mid') for f in order[1:-1]] + [(f, 'use') for f in order]
        cost = sum((cnt[k] + 1) ** 2 - cnt[k] ** 2 for k in keys) + (25 if prev and order[0] == prev[0] else 0) + (10 if prev and order[-1] == prev[-1] else 0)
        if best is None or cost < best[0]: best = (cost, g, order, keys)
    _, g, order, keys = best
    for k in keys: cnt[k] += 1
    it['_figs'] = g; it['_order'] = order; prev = order
items = []
for k, it in enumerate(chosen, 1):
    figs = it['_figs']
    items.append({'id': f'PR{k:02d}', 'target_z': it['target_z'], 'n_shapes': it['n_shapes'], 'n_clues': it['n_clues'],
                  'figures': figs, 'clues': it['clues'], 'answer_order': it['_order'],
                  'complexity': it['complexity'], 'pairs_needing_combination': it['pairs_needing_combination'],
                  'max_clues_combined': it['max_clues_combined'], 'tie_matches': it['tie_matches'],
                  'misleading_matches': it['misleading_matches'], 'figures_shown': it['figures_shown'],
                  'guess_p': it['guess_p'], 'example_weights': it['example_weights']})

# nezávislá kontrola hrubou silou (celočíselná mřížka): jediné ostré pořadí, každý zápas nezbytný
G = {3: 30, 4: 20, 5: 12}
GR = {n: np.array(list(itertools.product(range(1, G[n] + 1), repeat=n)), dtype=np.int32) for n in G}
def orders(clues, n):
    X = GR[n]; m = np.ones(len(X), bool)
    for c in clues:
        s = X @ (np.array(c['left']) - np.array(c['right']))
        m &= (s == 0) if c['result'] == 'tie' else (s > 0) if c['result'] == 'left' else (s < 0)
    Y = X[m]
    if len(Y) == 0: return None
    if (np.diff(np.sort(Y, 1), 1) == 0).any(): return 'eq'
    return {tuple(r) for r in np.argsort(-Y, 1)}
for it in items:
    n = it['n_shapes']; o = orders(it['clues'], n)
    assert o not in (None, 'eq') and len(o) == 1, it['id']
    assert [it['figures'][i] for i in next(iter(o))] == it['answer_order'], it['id']
    for m in range(len(it['clues'])):
        r = orders(it['clues'][:m] + it['clues'][m + 1:], n)
        assert r == 'eq' or (r is not None and len(r) > 1), (it['id'], m)
print('ověřeno', len(items))

practice = [
    {'id': 'PR_N1', 'n_shapes': 3, 'figures': ['circle', 'square', 'triangle'],
     'clues': [{'left': [1, 0, 0], 'right': [0, 1, 0], 'result': 'left'}, {'left': [0, 0, 1], 'right': [0, 1, 0], 'result': 'right'}],
     'answer_order': ['circle', 'square', 'triangle']},
    {'id': 'PR_N2', 'n_shapes': 3, 'figures': ['diamond', 'pentagon', 'square'],
     'clues': [{'left': [0, 1, 0], 'right': [0, 0, 2], 'result': 'tie'}, {'left': [0, 1, 1], 'right': [1, 0, 0], 'result': 'tie'}],
     'answer_order': ['diamond', 'pentagon', 'square']}]
bank = {'verze': 'PR-50-v1', 'limit_s': 45, 'ukonceni_po': 5, 'practice': practice, 'items': items}
json.dump(bank, open('/home/claude/pretahovana_PR-50-v1.json', 'w'), ensure_ascii=False, indent=1)
print(collections.Counter(i['target_z'] for i in items))
print('nejsilnější', collections.Counter(i['answer_order'][0] for i in items)); print('nejslabší', collections.Counter(i['answer_order'][-1] for i in items))
