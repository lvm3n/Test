"""Přetahovaná v0.2 – generátor položek s odpovědí 'seřaď figurky'.
Každá položka: n figurek, k zápasů (levý tým vs pravý tým, výsledek L/R/remíza).
Požadavky: z kladných sil vyplývá jednoznačné ostré pořadí všech figurek;
každý zápas je nezbytný; obtížnost z kombinování zápasů (nerovnosti, krácení),
ne z velkých čísel (síly 1–6, tým max 3 figurky, max 2 stejné na straně).
"""
import itertools, json, random, sys, collections
import numpy as np
from scipy.optimize import linprog

rng = random.Random(20261111 + (int(sys.argv[3].split(",")[0]) * 7919 if len(sys.argv) > 3 else 0))
FIGS = ["red_circle", "blue_square", "green_triangle", "gold_diamond", "violet_pentagon"]

def diff(c):
    return np.array(c["left"], float) - np.array(c["right"], float)

def feasible(clues, n, extra_ge=()):
    """Kladné síly w>=1; výhra = rozdíl >=1 (homogenní -> škálování), remíza = 0.
    extra_ge: vektory e s požadavkem e.w >= 0."""
    A_ub, b_ub, A_eq, b_eq = [], [], [], []
    for c in clues:
        d = diff(c)
        if c["result"] == "tie":
            A_eq.append(d); b_eq.append(0)
        elif c["result"] == "left":
            A_ub.append(-d); b_ub.append(-1)
        else:
            A_ub.append(d); b_ub.append(-1)
    for e in extra_ge:
        A_ub.append(-np.array(e, float)); b_ub.append(0)
    r = linprog(np.zeros(n), A_ub=A_ub or None, b_ub=b_ub or None,
                A_eq=A_eq or None, b_eq=b_eq or None, bounds=[(1, None)] * n, method="highs")
    return r.status == 0

def forced(clues, n, i, j):
    """True, pokud ze zápasů nutně plyne w_i > w_j (tj. w_j >= w_i je nemožné)."""
    e = np.zeros(n); e[j] = 1; e[i] = -1
    return not feasible(clues, n, [e])

def order_if_unique(clues, n):
    if not feasible(clues, n):
        return None
    above = {i: 0 for i in range(n)}
    for i, j in itertools.combinations(range(n), 2):
        fij, fji = forced(clues, n, i, j), forced(clues, n, j, i)
        if fij == fji:
            return None
        above[j if fij else i] += 1
    return sorted(range(n), key=lambda k: above[k])  # 0 nad sebou = nejsilnější

GRIDS = {}
def grid(n):
    if n not in GRIDS:
        G = {3: 15, 4: 12, 5: 9, 6: 7}[n]
        GRIDS[n] = np.array(list(itertools.product(range(1, G + 1), repeat=n)), dtype=np.int32)
    return GRIDS[n]

GRIDMETA = {}
def gridmeta(n):
    if n not in GRIDMETA:
        X = grid(n)
        srt = np.sort(X, axis=1)
        distinct = ~(np.diff(srt, axis=1) == 0).any(axis=1)
        perms = {p: i for i, p in enumerate(itertools.permutations(range(n)))}
        oid = np.array([perms[tuple(r)] for r in np.argsort(-X, axis=1)])
        GRIDMETA[n] = (distinct, oid)
    return GRIDMETA[n]

def mask_for(clues, n):
    X = grid(n); m = np.ones(len(X), bool)
    for c in clues:
        s = X @ diff(c).astype(np.int32)
        m &= (s == 0) if c["result"] == "tie" else ((s > 0) if c["result"] == "left" else (s < 0))
    return m

def n_orders(clues, n):
    distinct, oid = gridmeta(n)
    m = mask_for(clues, n)
    m = m
    return len(np.unique(oid[m & distinct]))

def grid_orders(clues, n):
    X = grid(n); m = np.ones(len(X), bool)
    for c in clues:
        s = X @ diff(c).astype(np.int32)
        m &= (s == 0) if c["result"] == "tie" else ((s > 0) if c["result"] == "left" else (s < 0))
    Y = X[m]
    if len(Y) == 0:
        return 0
    srt = np.sort(Y, axis=1)
    if (np.diff(srt, axis=1) == 0).any():
        return 2  # rovnost sil je přípustná -> pořadí není ostré
    return len({tuple(r) for r in np.argsort(-Y, axis=1)})

def random_side(n, maxsize, exclude):
    pool = [k for k in range(n) if k not in exclude]
    size = rng.randint(1, maxsize)
    v = [0] * n
    for _ in range(size):
        k = rng.choice(pool)
        if v[k] < 2:
            v[k] += 1
    return v

def make_clue(w, n, maxsize, tie_bias):
    for _ in range(400):
        L = random_side(n, maxsize, [])
        R = random_side(n, maxsize, [k for k in range(n) if L[k]])
        if sum(R) == 0:
            continue
        sl = sum(a * b for a, b in zip(L, w)); sr = sum(a * b for a, b in zip(R, w))
        if sl == sr or rng.random() > tie_bias:
            res = "tie" if sl == sr else ("left" if sl > sr else "right")
            return {"left": L, "right": R, "result": res}
    return None

def single_clue_facts(clues, n):
    facts = set()
    for c in clues:
        for i, j in itertools.permutations(range(n), 2):
            if forced([c], n, i, j):
                facts.add((i, j))
    # tranzitivní uzávěr
    changed = True
    while changed:
        changed = False
        for (a, b), (c, d) in itertools.product(list(facts), list(facts)):
            if b == c and (a, d) not in facts:
                facts.add((a, d)); changed = True
    return facts

def min_subset(clues, n, i, j):
    for s in range(1, len(clues) + 1):
        for sub in itertools.combinations(clues, s):
            if forced(list(sub), n, i, j):
                return s
    return len(clues)

def analyse(clues, n, order):
    facts = single_clue_facts(clues, n)
    adj = list(zip(order, order[1:]))
    algebraic = [(i, j) for i, j in adj if (i, j) not in facts]
    comb = [min_subset(clues, n, i, j) for i, j in algebraic]
    # zavádějící zápasy: vyhraje/remizuje tým s méně figurkami
    misleading = sum(1 for c in clues if (c["result"] == "left" and sum(c["left"]) < sum(c["right"]))
                     or (c["result"] == "right" and sum(c["right"]) < sum(c["left"]))
                     or (c["result"] == "tie" and sum(c["left"]) != sum(c["right"])))
    figures_shown = sum(sum(c["left"]) + sum(c["right"]) for c in clues)
    return {
        "algebraic_pairs": len(algebraic),
        "max_combination": max(comb) if comb else 1,
        "sum_combination": sum(comb),
        "ties": sum(c["result"] == "tie" for c in clues),
        "misleading": misleading,
        "figures_shown": figures_shown,
    }

def canon(clues, order):
    rank = {f: r for r, f in enumerate(order)}
    out = []
    for c in clues:
        L = tuple(sorted(r for f, cnt in enumerate(c["left"]) for r in [rank[f]] * cnt))
        R = tuple(sorted(r for f, cnt in enumerate(c["right"]) for r in [rank[f]] * cnt))
        res = c["result"]
        if (L, ) > (R, ):
            L, R = R, L
            res = {"left": "right", "right": "left", "tie": "tie"}[res]
        out.append((L, R, res))
    return tuple(sorted(out))

# ---- specifikace pásem (konstrukční záměr, ne kalibrace) ----
BANDS = {
    -3: dict(n=3, k=2, maxsize=2, tie=0.0, wmax=4, need=lambda a: a["algebraic_pairs"] == 0 and a["figures_shown"] <= 5),
    -2: dict(n=3, k=2, maxsize=2, tie=0.5, wmax=5, need=lambda a: a["algebraic_pairs"] == 0 and a["figures_shown"] >= 5),
    -1: dict(n=4, k=3, maxsize=2, tie=0.3, wmax=5, need=lambda a: a["algebraic_pairs"] == 0),
     0: dict(n=4, k=3, maxsize=2, tie=0.4, wmax=5, need=lambda a: a["algebraic_pairs"] == 1 and a["max_combination"] == 2),
     1: dict(n=4, k=3, maxsize=3, tie=0.4, wmax=6, need=lambda a: a["algebraic_pairs"] >= 2 or a["max_combination"] >= 3),
     2: dict(n=5, k=4, maxsize=3, tie=0.4, wmax=6, need=lambda a: 1 <= a["algebraic_pairs"] <= 2 and a["max_combination"] <= 2),
     3: dict(n=5, k=4, maxsize=3, tie=0.4, wmax=6, need=lambda a: a["algebraic_pairs"] >= 2 and a["max_combination"] >= 2 and a["misleading"] >= 1),
}
PER_BAND = int(sys.argv[1]) if len(sys.argv) > 1 else 8
NCAND = int(sys.argv[4]) if len(sys.argv) > 4 else 60
BUDGET = float(sys.argv[2]) if len(sys.argv) > 2 else 60
ONLY = [int(x) for x in sys.argv[3].split(',')] if len(sys.argv) > 3 else None
CAP = {-3: 5, -2: 6, -1: 8, 0: 10, 1: 11, 2: 13, 3: 14}
COUNT = {-3: 4, -2: 5, -1: 7, 0: 9, 1: 9, 2: 8, 3: 8}
TIME = {-3: 15, -2: 20, -1: 25, 0: 30, 1: 35, 2: 40, 3: 40}
LABEL = {-3: "velmi lehká", -2: "lehká", -1: "nižší střední", 0: "střední", 1: "vyšší střední", 2: "těžká", 3: "velmi těžká"}

items = []
for z, spec in BANDS.items():
    if ONLY and z not in ONLY: continue
    n, k = spec["n"], spec["k"]
    seen, pool = set(), []
    tries = 0
    import time; t0=time.time(); stats=collections.Counter()
    while len(pool) < COUNT[z] * 5 and time.time()-t0 < BUDGET:
        tries += 1
        w = rng.sample(range(1, spec["wmax"] + 1), n)
        clues = []; cur = n_orders([], n); ok = True
        for step in range(k):
            cands = []
            for _ in range(NCAND):
                c = make_clue(w, n, spec["maxsize"], spec["tie"])
                if c is None: continue
                no = n_orders(clues + [c], n)
                if no < cur and (no > 1 or step == k - 1):
                    cands.append((no, c))
            if not cands: ok = False; break
            cands.sort(key=lambda t: t[0])
            no, c = rng.choice(cands[:max(1, len(cands) // 3)]); clues.append(c); cur = no
        if not ok or cur != 1:
            stats['greedy_fail'] += 1; continue
        if grid_orders(clues, n) != 1:
            stats['notunique'] += 1; continue
        # každý zápas nezbytný (mřížka najde dvě různá pořadí => nezbytný s jistotou)
        if any(grid_orders(clues[:m] + clues[m + 1:], n) < 2 for m in range(k)):
            stats['redundant'] += 1; continue
        order = order_if_unique(clues, n)
        if order is None:
            continue
        key = canon(clues, order)
        if key in seen:
            continue
        a = analyse(clues, n, order)
        if any(np.gcd.reduce(np.array(c["left"] + c["right"])) > 1 for c in clues):
            stats['gcd'] += 1; continue
        if not spec["need"](a) or a["figures_shown"] > CAP[z]:
            stats['band'] += 1; continue
        seen.add(key)
        pool.append((clues, order, w, a))
    print(z, "pool", len(pool), "tries", tries, dict(stats), round(time.time()-t0), file=sys.stderr, flush=True)
    # výběr: různé struktury, rozmanité pořadí odpovědí, vyvážit remízy
    rng.shuffle(pool)
    pool.sort(key=lambda p: (p[3]["sum_combination"], p[3]["figures_shown"]))
    chosen = pool   # v0.3: ukládá se celý pool, výběr dělá select.py
    for clues, order, w, a in chosen:
        figs = rng.sample(FIGS, n)
        # náhodně prohodit strany zápasů a pořadí zápasů
        cl = []
        for c in clues:
            if rng.random() < 0.5:
                c = {"left": c["right"], "right": c["left"],
                     "result": {"left": "right", "right": "left", "tie": "tie"}[c["result"]]}
            cl.append(c)
        rng.shuffle(cl)
        items.append({
            "target_z": z, "n_shapes": n, "n_clues": k, "format": "rank",
            "figures": figs, "clues": cl,
            "answer_order": [figs[i] for i in order],
            "answer_index_order": order,
            "example_weights": w,
            "single_clue_solvable": a["algebraic_pairs"] == 0,
            "pairs_needing_combination": a["algebraic_pairs"],
            "max_clues_combined": a["max_combination"],
            "tie_matches": a["ties"],
            "misleading_matches": a["misleading"],
            "figures_shown": a["figures_shown"],
            "guess_p": round(1 / len(list(itertools.permutations(range(n)))), 4),
            "intended_time_s": TIME[z],
            "difficulty_label": LABEL[z],
        })

for idx, it in enumerate(items, 1):
    it["id"] = f"PR{idx:03d}"
    items[idx - 1] = {"id": it.pop("id"), **it}

json.dump(items, open("pool_" + (sys.argv[3] if len(sys.argv) > 3 else "all") + ".json", "w"), ensure_ascii=False, indent=1)
print(len(items), file=sys.stderr)
