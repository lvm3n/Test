import json, numpy as np, collections
b = json.load(open('/home/claude/pretahovana_PR-50-v1.json'))
Q = {-3: 2, -2: 3, -1: 5, 0: 7, 1: 7, 2: 6, 3: 6}
def feat(it): return np.array([it['complexity'], it['figures_shown'] / 3, it['tie_matches'], it['misleading_matches'], it['pairs_needing_combination']], float)
keep = []
for z, q in Q.items():
    band = [it for it in b['items'] if it['target_z'] == z]
    sel = [band[0], band[-1]] if q >= 2 else [band[0]]
    while len(sel) < q:   # nejvzdálenější od už vybraných (rozptyl složitosti i typu zápasů)
        rest = [it for it in band if it not in sel]
        sel.append(max(rest, key=lambda it: min(np.abs(feat(it) - feat(s)).sum() for s in sel)))
    keep += sorted(sel, key=lambda it: band.index(it))
    print(z, [it['id'] for it in keep if it['target_z'] == z])
nb = dict(b); nb['verze'] = 'PR-36-v1'; nb['ukonceni_po'] = 4; nb['items'] = keep
json.dump(nb, open('/home/claude/pretahovana_PR-36-v1.json', 'w'), ensure_ascii=False, indent=1)
print(len(keep), 'nejsilnější', collections.Counter(i['answer_order'][0] for i in keep), 'nejslabší', collections.Counter(i['answer_order'][-1] for i in keep))
