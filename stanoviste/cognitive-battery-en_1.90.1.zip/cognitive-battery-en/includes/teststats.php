<?php
if (!defined('ABSPATH')) { exit; }
/* od EN 1.89.0: GET /teststats – průběžné údaje k testům pro menu (cache 6 h).
   Doba: medián (a kvartily) čistého času testu (viz níže), jen platné výsledky
   nejpodobnějších verzí (allow v pořadí podobnosti: současná, má-li ≥ 5 výsledků, jinak se přibírají další do 15), bez výsledků vyřazených screeningem a bez sezení, kde osoba dělala týž test víckrát; 20 s – 3 h.
   Reliabilita (položkové testy): empirická marginální reliabilita EAP théty var(θ) / (var(θ) + průměr SE²) z uložených výsledků
   (théta a SE se ukládají s výsledkem; bere se nejnovější verze IRT parametrů, které má aspoň 50 výsledků). */
add_action('rest_api_init', function () {
    register_rest_route('kben/v1', '/teststats', array('methods' => 'GET', 'callback' => 'kben_rest_teststats', 'permission_callback' => '__return_true'));
});
function kben_rest_teststats(WP_REST_Request $r) {
    $allow = array(); $raw = $r->get_param('allow');
    if (is_string($raw) && $raw !== '') {
        $dec = json_decode(wp_unslash($raw), true);
        if (is_array($dec)) { foreach (array_slice($dec, 0, 60, true) as $k => $vs) { $k = sanitize_key($k); if ($k === '' || !is_array($vs)) { continue; }
            $allow[$k] = array_slice(array_map('sanitize_text_field', array_map('strval', $vs)), 0, 60); } }
    }
    $ck = 'kben_tstats_' . md5(wp_json_encode($allow) . '|v6');
    $c = get_transient($ck); if ($c !== false) { return $c; }
    $out = array();
    foreach ($allow as $k => $vs) { $s = kben_teststats_one($k, $vs); if ($s) { $out[$k] = $s; } }
    $res = array('tests' => $out, 'generated' => gmdate('c'));
    set_transient($ck, $res, 6 * HOUR_IN_SECONDS);
    return $res;
}
function kben_tstats_q($a, $p) {   // kvantil seřazeného pole
    $n = count($a); if (!$n) { return null; } $h = ($n - 1) * $p; $lo = floor($h); $hi = ceil($h);
    return $a[$lo] + ($h - $lo) * ($a[$hi] - $a[$lo]);
}
function kben_teststats_one($key, $vs) {
    global $wpdb;
    $S = kben_table('scores'); $R = kben_table('rows');
    $vin = $vs ? ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')' : '';
    $args = array_merge(array($key), $vs);
    $scr = function_exists('kben_scr_ids') ? (array) kben_scr_ids(substr($S, 0, -6), $key) : array();
    /* doba */
    $rows = (array) $wpdb->get_results($wpdb->prepare(
        "SELECT sc.id, sc.session_id, sc.test_version, UNIX_TIMESTAMP(sc.created) AS te
           FROM $S sc WHERE sc.test_key = %s AND sc.valid = 1 AND sc.raw_score IS NOT NULL AND sc.mode <> 'cz'$vin", $args));
    /* čistý čas: u úlohových testů a škál součet časů řešení jednotlivých úloh (rt_ms, včetně nácviku; každá úloha nejvýš 3 min –
       v prohlížeči na pozadí se časovač úlohy zastaví a RT pak může být nesmyslně dlouhé); instrukce a obrazovky mezi úlohami se nepočítají.
       U ostatních testů (rychlost, paměť, reakce – pevná délka nebo předvádění podnětů, které v rt_ms není) součet mezer mezi záznamy,
       každá mezera nejvýš 3 minuty. */
    $net = in_array($key, array('matice12', 'ceiling', 'vahy', 'pravidla', 'stanoviste', 'dedukce', 'papir', 'skladani', 'oblouky', 'pretahovana', 'ptvyvoj', 'ptvyvoj2', 'pretah2', 'pretah2b',
        'gcslovni', 'gcznalosti', 'gcanalogie', 'zasoba2', 'znalosti2', 'cteni2', 'rychly', 'pocitani', 'ulohy', 'adhd', 'adhd_inf', 'masking'), true);
    $ts = array(); $rs = array(); $lastR = 0;
    do {
        $ch = (array) $wpdb->get_results($wpdb->prepare("SELECT id, session_id, UNIX_TIMESTAMP(created) AS t" . ($net ? ", data" : "") . " FROM $R WHERE test_key = %s AND id > %d ORDER BY id ASC LIMIT 20000", $key, $lastR));
        foreach ($ch as $x) {
            $lastR = intval($x->id); $sid = intval($x->session_id); $ts[$sid][] = intval($x->t);
            if ($net && preg_match('/"rt_ms":"?(\d+)/', (string) $x->data, $mm)) { $rs[$sid] = (isset($rs[$sid]) ? $rs[$sid] : 0) + min(180000, intval($mm[1])); }
        }
        $cnt = count($ch); unset($ch);
    } while ($cnt === 20000);
    foreach ($rows as $x) {
        $sid = intval($x->session_id);
        if ($net) { $x->dur = isset($rs[$sid]) ? round($rs[$sid] / 1000) : -1; continue; }
        $L = isset($ts[$sid]) ? $ts[$sid] : array(); if (!$L) { $x->dur = -1; continue; }
        $L[] = intval($x->te); sort($L); $sum = 0;
        for ($i = 1; $i < count($L); $i++) { $sum += min(180, max(0, $L[$i] - $L[$i - 1])); }
        $x->dur = $sum;
    }
    /* sezení, kde test nezačal od začátku: převzaté odpovědi z dřívější verze, doplnění nových úloh, navázání na rozpracovaný test,
       opakování, nový pokus – doba by byla jen zbytek testu (nebo by zahrnovala dřívější pokus) */
    $mk = array('prevzato', 'rozsireni', 'navazani', 'opakovani', 'nova_pravidla', 'novy_pokus', 'znovu_po_neresenem');
    $lk = array(); $la = array($key); foreach ($mk as $m) { $lk[] = 'data LIKE %s'; $la[] = '%"polozka":"' . $m . '"%'; }
    $skipS = array(); foreach ((array) $wpdb->get_col($wpdb->prepare("SELECT DISTINCT session_id FROM $R WHERE test_key = %s AND (" . implode(' OR ', $lk) . ")", $la)) as $sid) { $skipS[intval($sid)] = 1; }
    $perS = array(); foreach ($rows as $x) { $perS[$x->session_id] = isset($perS[$x->session_id]) ? $perS[$x->session_id] + 1 : 1; }
    $byVer = array();
    foreach ($rows as $x) {
        if (isset($scr[intval($x->id)]) || $perS[$x->session_id] > 1 || isset($skipS[intval($x->session_id)])) { continue; }
        $v = intval($x->dur); if ($v >= 20 && $v <= 10800) { $byVer[(string) $x->test_version][] = $v; }
    }
    /* verze v pořadí podobnosti (od klienta: současná, pak téže skupiny od nejnovější): současná sama, má-li ≥ 5 výsledků,
       jinak se přibírají další, dokud jich není 15 – aby dobu neurčovaly staré, delší verze */
    $d = array(); $used = array();
    foreach (($vs ? $vs : array_keys($byVer)) as $i => $ver) {
        if (empty($byVer[$ver])) { continue; }
        $d = array_merge($d, $byVer[$ver]); $used[] = $ver;
        if (($i === 0 && count($d) >= 5) || count($d) >= 15) { break; }
    }
    sort($d); $o = array('n_t' => count($d), 'v_t' => $used);
    if (count($d) >= (count($used) === 1 && $used[0] === ($vs ? $vs[0] : '') ? 5 : 10)) { $o['med_s'] = round(kben_tstats_q($d, .5)); $o['q1_s'] = round(kben_tstats_q($d, .25)); $o['q3_s'] = round(kben_tstats_q($d, .75)); }
    /* marginální reliabilita (jen výsledky s uloženou thétou) */
    $byV = array(); $last = 0;
    do {
        $ch = (array) $wpdb->get_results($wpdb->prepare("SELECT sc.id, sc.data FROM $S sc WHERE sc.test_key = %s AND sc.valid = 1 AND sc.raw_score IS NOT NULL AND sc.mode <> 'cz'$vin AND sc.id > %d ORDER BY sc.id ASC LIMIT 2000",
            array_merge($args, array($last))));
        foreach ($ch as $x) {
            $last = intval($x->id); if (isset($scr[$last]) || strpos((string) $x->data, 'theta_se') === false) { continue; }
            $j = json_decode((string) $x->data, true);
            if (!is_array($j) || !isset($j['theta'], $j['theta_se']) || !is_numeric($j['theta']) || !is_numeric($j['theta_se'])) { continue; }
            $tv = isset($j['theta_v']) ? (string) $j['theta_v'] : ''; $byV[$tv][] = array(floatval($j['theta']), floatval($j['theta_se']));
        }
        $cnt = count($ch); unset($ch);
    } while ($cnt === 2000);
    if ($byV) {
        krsort($byV); $use = null;
        foreach ($byV as $tv => $L) { if (count($L) >= 50) { $use = $L; break; } }
        if ($use) {
            $n = count($use); $m = 0; foreach ($use as $p) { $m += $p[0]; } $m /= $n;
            $var = 0; $se2 = 0; foreach ($use as $p) { $var += ($p[0] - $m) * ($p[0] - $m); $se2 += $p[1] * $p[1]; }
            $var /= ($n - 1); $se2 /= $n;
            if ($var > 0) { $o['rel'] = round($var / ($var + $se2), 3); $o['n_rel'] = $n; }
        }
    }
    return $o;
}
