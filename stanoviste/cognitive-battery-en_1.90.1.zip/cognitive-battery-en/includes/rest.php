<?php
if (!defined('ABSPATH')) { exit; }

add_action('rest_api_init', function () {
    $ns = 'kben/v1';
    register_rest_route($ns, '/session', array('methods' => 'POST', 'callback' => 'kben_rest_session', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/rows', array('methods' => 'POST', 'callback' => 'kben_rest_rows', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/score', array('methods' => 'POST', 'callback' => 'kben_rest_score', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/profile', array('methods' => 'POST', 'callback' => 'kben_rest_profile', 'permission_callback' => '__return_true'));   // od 1.86.0: doplnění údajů o zkušenosti s testy
    register_rest_route($ns, '/distribution', array('methods' => 'GET', 'callback' => 'kben_rest_distribution', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/progress', array('methods' => 'GET', 'callback' => 'kben_rest_progress', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/correlations', array('methods' => 'GET', 'callback' => 'kben_rest_correlations', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/external', array('methods' => 'GET', 'callback' => 'kben_rest_external_get', 'permission_callback' => '__return_true'));
    register_rest_route($ns, '/external', array('methods' => 'POST', 'callback' => 'kben_rest_external_save', 'permission_callback' => '__return_true'));
});

function kben_now() { return current_time('mysql', true); }
function kben_valid_uuid($s) { return is_string($s) && preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $s); }
function kben_clean_key($s) { return substr(preg_replace('/[^a-z0-9_\-]/i', '', (string) $s), 0, 40); }
function kben_err($msg, $code = 400) { return new WP_Error('kben_error', $msg, array('status' => $code)); }

/* jednoduché omezení frekvence bez ukládání IP (jen krátkodobý hash v transientu) */
function kben_rate_ok($bucket, $limit, $seconds) {
    $ip  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $key = 'kben_rl_' . $bucket . '_' . substr(hash('sha256', $ip . wp_salt('nonce')), 0, 20);
    $n   = (int) get_transient($key);
    if ($n >= $limit) { return false; }
    set_transient($key, $n + 1, $seconds);
    return true;
}

function kben_session_by_token($sid, $token) {
    global $wpdb;
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kben_table('sessions') . " WHERE id = %d", $sid));
    if (!$row || !hash_equals($row->token, (string) $token)) { return null; }
    return $row;
}

/* POST /session – založí (nebo najde) účastníka a nové sezení */
function kben_rest_session(WP_REST_Request $r) {
    global $wpdb;
    if (!kben_rate_ok('sess', 30, HOUR_IN_SECONDS)) { return kben_err('Příliš mnoho požadavků.', 429); }
    $p    = $r->get_json_params();
    $mode = (isset($p['mode']) && $p['mode'] === 'admin') ? 'admin' : 'public';
    if ($mode === 'admin' && !current_user_can('edit_posts')) { return kben_err('Nepřihlášený uživatel.', 403); }
    $anon = isset($p['anon_id']) ? $p['anon_id'] : '';
    if (!kben_valid_uuid($anon)) { return kben_err('Neplatný identifikátor.'); }
    if ($mode === 'public' && empty($p['consent']['gdpr'])) { return kben_err('Chybí souhlas se zpracováním údajů.'); }

    $pt  = kben_table('participants');
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM $pt WHERE anon_id = %s", $anon));
    $age = isset($p['age']) ? max(0, min(120, intval($p['age']))) : null;
    $demo = isset($p['demographics']) ? wp_json_encode($p['demographics']) : null;
    $cons = isset($p['consent']) ? wp_json_encode($p['consent']) : null;
    $code = isset($p['code']) ? sanitize_text_field(substr($p['code'], 0, 60)) : '';
    if (!$pid) {
        $wpdb->insert($pt, array('anon_id' => $anon, 'created' => kben_now(), 'mode' => $mode, 'code' => $code,
            'age' => $age, 'demographics' => $demo, 'consent' => $cons));
        $pid = $wpdb->insert_id;
    } else {
        $wpdb->update($pt, array('age' => $age, 'demographics' => $demo, 'consent' => $cons, 'code' => $code), array('id' => $pid));
    }
    $token = wp_generate_password(40, false, false);
    $wpdb->insert(kben_table('sessions'), array(
        'participant_id' => $pid, 'token' => $token, 'started' => kben_now(), 'last_seen' => kben_now(),
        'battery_version' => sanitize_text_field(isset($p['battery_version']) ? $p['battery_version'] : ''),
        'settings' => isset($p['settings']) ? wp_json_encode($p['settings']) : null,
        'device'   => isset($p['device']) ? wp_json_encode($p['device']) : null));
    return array('session_id' => (int) $wpdb->insert_id, 'token' => $token);
}

/* od 1.86.0: POST /profile – doplní k demografii účastníka údaje z dotazníku o zkušenosti s testy (bez nového sezení).
   Jen povolené klíče a krátké hodnoty; ostatní demografie zůstává. */
function kben_profile_keys() { return array('zeme', 'testy_2r', 'priprava', 'vysetreni_rok', 'zk_v', 'zk_cas'); }
function kben_rest_profile(WP_REST_Request $r) {
    global $wpdb;
    if (!kben_rate_ok('prof', 30, HOUR_IN_SECONDS)) { return kben_err('Příliš mnoho požadavků.', 429); }
    $p = $r->get_json_params();
    $s = kben_session_by_token(isset($p['session_id']) ? intval($p['session_id']) : 0, isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kben_err('Neplatné sezení.', 403); }
    $in = isset($p['demographics']) && is_array($p['demographics']) ? $p['demographics'] : array();
    $pt = kben_table('participants');
    $cur = json_decode((string) $wpdb->get_var($wpdb->prepare("SELECT demographics FROM $pt WHERE id = %d", $s->participant_id)), true); if (!is_array($cur)) { $cur = array(); }
    foreach (kben_profile_keys() as $k) { if (array_key_exists($k, $in) && is_scalar($in[$k])) { $cur[$k] = sanitize_text_field(substr((string) $in[$k], 0, 40)); } }
    $wpdb->update($pt, array('demographics' => wp_json_encode($cur)), array('id' => $s->participant_id));
    return array('ok' => 1);
}

/* POST /rows – dávka řádků (každá odpověď s časy v ms) */
function kben_rest_rows(WP_REST_Request $r) {
    global $wpdb;
    if (!kben_rate_ok('rows', 3000, HOUR_IN_SECONDS)) { return kben_err('Příliš mnoho požadavků.', 429); }
    $p = $r->get_json_params();
    $s = kben_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kben_err('Neplatné sezení.', 403); }
    $rows = isset($p['rows']) && is_array($p['rows']) ? array_slice($p['rows'], 0, 500) : array();
    $saved = 0;
    foreach ($rows as $row) {
        if (!is_array($row)) { continue; }
        $json = wp_json_encode($row);
        if (strlen($json) > 30000) { continue; }
        $seq = isset($row['_seq']) ? intval($row['_seq']) : 0;
        // INSERT IGNORE: opakované odeslání téže dávky nevytvoří duplicitu
        $ok = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO " . kben_table('rows') . " (session_id, test_key, client_seq, created, data) VALUES (%d, %s, %d, %s, %s)",
            $s->id, kben_clean_key(isset($row['test']) ? $row['test'] : ''), $seq, kben_now(), $json));
        if ($ok) { $saved++; }
    }
    $wpdb->update(kben_table('sessions'), array('last_seen' => kben_now()), array('id' => $s->id));
    return array('saved' => $saved);
}

/* POST /score – výsledek jednoho testu (pro rozložení a e-mail) */
function kben_rest_score(WP_REST_Request $r) {
    global $wpdb;
    $p = $r->get_json_params();
    $s = kben_session_by_token(intval(isset($p['session_id']) ? $p['session_id'] : 0), isset($p['token']) ? $p['token'] : '');
    if (!$s) { return kben_err('Neplatné sezení.', 403); }
    $pt  = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . kben_table('participants') . " WHERE id = %d", $s->participant_id));
    $key = kben_clean_key(isset($p['test_key']) ? $p['test_key'] : '');
    if ($key === '') { return kben_err('Chybí test.'); }
    $raw = (isset($p['raw_score']) && is_numeric($p['raw_score'])) ? floatval($p['raw_score']) : null;
    $ver = sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : '');
    // pojistka proti duplicitám: aplikace posílá výsledek testu v jednom sezení jen jednou; opakované odeslání se ignoruje
    $rep = (isset($p['score']) && is_array($p['score']) && isset($p['score']['opakovani'])) ? intval($p['score']['opakovani']) : 0;   // opakování testu (retest)
    foreach ($wpdb->get_col($wpdb->prepare("SELECT data FROM " . kben_table('scores') . " WHERE session_id = %d AND test_key = %s AND test_version = %s", $s->id, $key, $ver)) as $dj) {
        $dd = json_decode((string) $dj, true);
        if ((is_array($dd) && isset($dd['opakovani']) ? intval($dd['opakovani']) : 0) === $rep) { return array('ok' => true, 'duplicate' => true); }
    }
    $ins = $wpdb->insert(kben_table('scores'), array(
        'session_id' => $s->id, 'participant_id' => $s->participant_id, 'test_key' => $key,
        'test_version' => sanitize_text_field(isset($p['test_version']) ? substr($p['test_version'], 0, 40) : ''),
        'raw_score' => $raw, 'valid' => empty($p['valid']) ? 0 : 1, 'age' => $pt ? $pt->age : null,
        'mode' => $pt ? $pt->mode : 'public', 'created' => kben_now(),
        'data' => wp_json_encode(isset($p['score']) ? $p['score'] : null)));
    if ($ins === false) { return kben_err('Výsledek se nepodařilo uložit.', 500); }   // od 2026-11-03: aplikace to zkusí znovu (dřív se ztratil)
    if (function_exists('kben_ner_last') && $raw !== null && !in_array($key, array('gcslovni', 'gcznalosti'), true) && kben_ner_last($s->id, $key, isset($p['score']['administrovano']) && is_numeric($p['score']['administrovano']) ? intval($p['score']['administrovano']) : 0)) {   // od 2026-10-28: test jen otevřený → neplatný, další pokus bude první
        $nid = $wpdb->insert_id; $dd = isset($p['score']) && is_array($p['score']) ? $p['score'] : array();
        $dd['neresil'] = 1; $dd['ner_v'] = 2; $dd['valid_puvodni'] = empty($p['valid']) ? 0 : 1;
        $wpdb->update(kben_table('scores'), array('valid' => 0, 'data' => wp_json_encode($dd)), array('id' => $nid));
    }
    kben_maybe_notify($s, $pt, $key, $raw);
    return array('ok' => true);
}

/* Výběr výsledku osoby pro srovnání a korelace (od 3.85.0): v rámci skupiny verzí platí PRVNÍ výsledek NEJNOVĚJŠÍ verze,
   kterou osoba dělala. Opakování téže verze se nepočítá (člověk úlohy zná); když se ale test mezitím změnil (opravené
   úlohy, nové úrovně, jiné časové limity) a člověk udělal novou verzi, počítá se první výsledek nové verze. */
function kben_ceil_rules() { return array(); }   // (dřívější seznam testů s rozšířeným stropem – už se nepoužívá)
function kben_ceil_pick($rows, $rule = null) {      // řádky seřazené podle id → jeden řádek na osobu
    $pick = array(); $seen = array();
    foreach ($rows as $x) {
        $pid = $x->participant_id; $v = (string) $x->test_version;
        if (!isset($pick[$pid])) { $pick[$pid] = $x; $seen[$pid] = array($v => 1); continue; }
        if (!isset($seen[$pid][$v])) { $seen[$pid][$v] = 1; $pick[$pid] = $x; }   // první výsledek nové verze nahradí starší
    }
    return array_values($pick);
}

/* zaklad=puvodni: srovnání výsledků přepočtených po zkrácení časových limitů – PŮVODNÍ výsledek (před přepočtem) jen mezi
   výsledky, které vznikly za původních podmínek (mají příznak přepočtu). Vrací null, když řádek do tohoto srovnání nepatří. */
function kben_orig_value($data) {
    $d = json_decode((string) $data, true);
    if (!is_array($d) || !(isset($d['prepocet_limity']) || isset($d['prepocet']))) { return null; }
    $pv = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : (isset($d['hruby_puvodni']) ? $d['hruby_puvodni'] : null);
    return is_numeric($pv) ? floatval($pv) : null;
}

/* GET /distribution?test=...&version=...&age_min=&age_max= – jen souhrnné údaje, nikdy data jednotlivců */
/* jazykově nezávislé testy – u nich se srovnává i s výsledky z české verze (tabulky wp_kb_*) */
function kben_pool_keys() { return array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka'); }
function kben_cz_live() { global $wpdb; $t = $wpdb->prefix . 'kb_scores'; return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t; }
function kben_rest_distribution(WP_REST_Request $r) {
    global $wpdb;
    if ($r->get_param('zaklad') === 'theta') { return kben_theta_distribution($r); }   // théta (od 2026-10-27)
    $key = kben_clean_key($r->get_param('test'));
    $ver = sanitize_text_field((string) $r->get_param('version'));
    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));
    $orig = $r->get_param('zaklad') === 'puvodni';      // srovnání za původních časových limitů
    $pool = in_array($key, kben_pool_keys(), true) && kben_cz_live();
    $par = in_array($key, kben_pool_keys(), true) && kben_kbd_live();
    $enOnly = $r->get_param('vzorek') === 'en';          // od 1.71.0: jen EN + gifted (přepínač ve výsledcích)
    $czOnly = $r->get_param('vzorek') === 'cz';          // od 1.70.44: srovnání jen s českým vzorkem (CZ verze + dospělí rodiče z dětské verze)
    $xl = $key === 'srce' && kben_cz_live();            // od 2026-11-03: Efektivita čtení – srovnání s českou verzí (stejný úkol a skórování: správně − chybně za 120 s, české věty)
    if ($czOnly && !$xl && !in_array($key, kben_pool_keys(), true)) { return array('n' => 0, 'min_n' => 30, 'bins' => array()); }   // + živá česká data (od EN 1.70.22); importované řádky mode = cz se pak vynechají
    $ck = 'kben_dist_' . md5(wp_json_encode(array($key, $ver, $amin, $amax, $orig, $pool, $par, $czOnly, $enOnly, 'gf3', 'scr1')));
    $cached = get_transient($ck);
    if ($cached !== false) { return $cached; }
    $vs = array();
    if ($ver !== '') { $vs = array_slice(array_values(array_filter(array_map('trim', explode('|', $ver)), 'strlen')), 0, 20); }
    /* jedna hodnota na osobu: bez verze první platný výsledek, s verzí první výsledek nejnovější verze (viz *_ceil_pick) */
    $fetch = function ($ST, $skipCz, $vsOv = null) use ($wpdb, $key, $vs, $amin, $amax) {
        if ($vsOv !== null) { $vs = $vsOv; }   // jiné názvy verzí (česká verze)
        $args = array($key);
        $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $ST sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL";
        if ($skipCz) { $sql .= $skipCz === 2 ? " AND sc.mode NOT IN ('cz', 'en')" : " AND sc.mode <> 'cz'"; }
        if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }
        if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
        if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
        $rows = (array) $wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args));
        if (function_exists('kben_scr_filter')) { $rows = kben_scr_filter($rows, $ST, $key); }   // od 1.80.0: bez výsledků „nechaný běžet“ (pak platí další pokus)
        if ($vs) { return kben_ceil_pick($rows); }
        $first = array(); foreach ($rows as $x) { if (!isset($first[$x->participant_id])) { $first[$x->participant_id] = $x; } }
        return array_values($first);
    };
    if ($czOnly) {
        $res = $xl ? $fetch($wpdb->prefix . 'kb_scores', false, array('SRCE-v06', 'SRCE-v07', 'SRCE-v08', 'SRCE-v09', 'SRCE-v10')) : ($pool ? $fetch($wpdb->prefix . 'kb_scores', false) : array());
    } elseif ($enOnly) {
        $res = $fetch(kben_table('scores'), true);
        $gt = $wpdb->prefix . 'kbgf_scores';
        if (in_array($key, kben_pool_keys(), true) && $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $gt)) === $gt) { $res = array_merge($res, $fetch($gt, 2)); }   // gifted bez importů z CZ a EN
    } else {
        $res = $fetch(kben_table('scores'), $pool);
        if ($pool) { $res = array_merge($res, $fetch($wpdb->prefix . 'kb_scores', false)); }
    }
    $vals = array();
    foreach ($res as $x) {
        $v = floatval($x->raw_score);
        if ($orig) { $ov = kben_orig_value($x->data); if ($ov !== null) { $vals[] = $ov; } continue; }
        // SRCE: hlavní skór je „správně − chybně“; jen verze v08 ukládala jako hlavní skór počet správně → přepočet
        if ($key === 'srce' && $x->test_version === 'SRCE-v08') {
            $d = json_decode((string) $x->data, true);
            if (is_array($d) && isset($d['spravne_minus_chybne']) && is_numeric($d['spravne_minus_chybne'])) { $v = floatval($d['spravne_minus_chybne']); }
            elseif (is_array($d) && isset($d['spravne_administrovane'], $d['chybne'])) { $v = floatval($d['spravne_administrovane']) - floatval($d['chybne']); }
        }
        $vals[] = $v;
    }
    if (!$enOnly) $vals = array_merge($vals, kben_parent_values($key, $vs, $amin, $amax, $orig, 13));   // od 1.70.64 i v celkovém srovnání celá dětská verze od 13 let   // + rodiče z dětské verze (český vzorek: celá dětská verze od 13 let)
    $set  = get_option('kben_settings', array());
    $minn = isset($set['min_n']) ? intval($set['min_n']) : 30;
    $n = count($vals);
    if ($n === 0) { return array('n' => 0, 'min_n' => $minn, 'bins' => array()); }
    // zaokrouhlené hodnoty s četnostmi (dostatečné pro graf, neidentifikují jednotlivce)
    $counts = array();
    foreach ($vals as $v) { $k = (string) round($v, 1); $counts[$k] = isset($counts[$k]) ? $counts[$k] + 1 : 1; }
    ksort($counts, SORT_NUMERIC);
    $bins = array();
    foreach ($counts as $k => $c) { $bins[] = array('x' => floatval($k), 'n' => $c); }
    $out = array('n' => $n, 'min_n' => $minn, 'bins' => $bins);
    set_transient($ck, $out, 5 * MINUTE_IN_SECONDS);
    return $out;
}

/* GET /progress?anon_id=... – co už účastník dokončil (pro návrat do baterie) */
function kben_rest_progress(WP_REST_Request $r) {
    global $wpdb;
    $anon = $r->get_param('anon_id');
    if (!kben_valid_uuid($anon)) { return kben_err('Neplatný identifikátor.'); }
    $pid = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . kben_table('participants') . " WHERE anon_id = %s", $anon));
    if (!$pid) { return array('tests' => array()); }
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT test_key, test_version, raw_score, valid, created, data FROM " . kben_table('scores') . " WHERE participant_id = %d ORDER BY created ASC", $pid));
    $out = array();
    foreach ($rows as $x) {
        if ($x->raw_score === null && (int) $x->valid === 0) { continue; }   // přerušený test – lze zopakovat
        $d = json_decode((string) $x->data, true);
        if ((int) $x->valid === 0 && is_array($d) && !empty($d['neresil'])) { continue; }   // od 2026-10-28: test jen otevřený – jako by nebyl, další pokus je první
        $pok = isset($out[$x->test_key]['pokusy']) ? $out[$x->test_key]['pokusy'] : 0;
        $his = isset($out[$x->test_key]['historie']) ? $out[$x->test_key]['historie'] : array();   // všechny pokusy s časy (od 1.70.7)
        if ($x->raw_score !== null) {
            $his[] = array('version' => $x->test_version, 'raw_score' => floatval($x->raw_score), 'valid' => (int) $x->valid, 'date' => $x->created,
                           'zahajeno' => is_array($d) && isset($d['zahajeno']) ? (string) $d['zahajeno'] : '', 'dokonceno' => is_array($d) && isset($d['dokonceno']) ? (string) $d['dokonceno'] : '');
        }
        $out[$x->test_key] = array('pokusy' => $x->raw_score === null ? $pok : $pok + 1, 'version' => $x->test_version, 'raw_score' => $x->raw_score === null ? null : floatval($x->raw_score),
                                   'valid' => (int) $x->valid, 'date' => $x->created, 'konec' => is_array($d) && isset($d['konec']) ? (string) $d['konec'] : '',
                                   'dokonceno' => is_array($d) && isset($d['dokonceno']) ? (string) $d['dokonceno'] : '',   // čas dokončení z prohlížeče (od 1.68.0)
                                   'historie' => $his);
        if (is_array($d) && !empty($d['opakovani'])) {   // opakování testu → popisek v grafu výsledku
            $out[$x->test_key]['opakovani'] = intval($d['opakovani']);
            if (isset($d['predchozi_skore']) && is_numeric($d['predchozi_skore'])) { $out[$x->test_key]['predchozi'] = floatval($d['predchozi_skore']); }
            if (isset($d['predchozi_verze'])) { $out[$x->test_key]['predchozi_verze'] = (string) $d['predchozi_verze']; }
        }
        if (is_array($d) && (isset($d['hruby_pred_upravou']) || isset($d['hruby_puvodni'])) && (isset($d['prepocet_limity']) || isset($d['prepocet']))) {   // přepočet podle časových limitů
            $pred = isset($d['hruby_pred_upravou']) ? $d['hruby_pred_upravou'] : $d['hruby_puvodni'];
            if (is_numeric($pred) && $x->raw_score !== null && floatval($pred) != floatval($x->raw_score)) { $out[$x->test_key]['raw_pred'] = floatval($pred); }
        }
    }
    /* položkové testy: odpovědi na jednotlivé položky (ID → 0/1) ze všech dokončených běhů – aplikace podle nich
       nabídne doplnit jen nové / opravené položky (převzetí odpovědí) */
    /* historie pokusů (datum, body) a théta spočítaná živě ze všech odpovědí osoby (od 2026-10-27) */
    foreach ($rows as $x) {
        if ($x->raw_score === null || !isset($out[$x->test_key])) { continue; }
        $d = json_decode((string) $x->data, true);
        $out[$x->test_key]['hist'][] = array('version' => $x->test_version, 'raw_score' => floatval($x->raw_score), 'valid' => (int) $x->valid, 'date' => $x->created,
                                             'dokonceno' => is_array($d) && isset($d['dokonceno']) ? (string) $d['dokonceno'] : '');
    }
    foreach (kben_irt_keys() as $k) {
        if (!isset($out[$k]) || $out[$k]['raw_score'] === null) { continue; }
        $e = kben_irt_eap($k, kben_irt_resp($pid, $k));
        if ($e) { $out[$k]['theta'] = $e['theta']; $out[$k]['theta_se'] = $e['se']; $out[$k]['theta_n'] = $e['n']; $out[$k]['theta_v'] = kben_irt()['version']; }
    }
    foreach (array('matice12', 'dedukce', 'papir', 'stanoviste', 'pravidla', 'vahy', 'skladani', 'gcslovni', 'gcznalosti', 'ceiling') as $k) {
        if (isset($out[$k])) { $out[$k]['items'] = kben_answered_items($pid, $k); }
    }
    /* odvozené výsledky (théta bez dokončeného testu) se od 4.12.1 / 1.71.1 lidem nevracejí – slouží jen k normám (*_theta_pool) */
    $res = array('tests' => $out);
    $res['age'] = ($ag = $wpdb->get_var($wpdb->prepare("SELECT age FROM " . kben_table('participants') . " WHERE id = %d", $pid))) !== null ? intval($ag) : null;
    return $res;
}

function kben_answered_items($pid, $key) {
    global $wpdb;
    $sids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT session_id FROM " . kben_table('scores') . " WHERE participant_id = %d AND test_key = %s AND raw_score IS NOT NULL", $pid, $key));
    $items = array();
    if (!$sids) { return (object) $items; }
    $in = implode(',', array_map('intval', $sids));
    $rows = $wpdb->get_results($wpdb->prepare("SELECT session_id, test_key, data FROM " . kben_table('rows') . " WHERE session_id IN ($in) AND test_key = %s ORDER BY id ASC", $key));
    $ner = function_exists('kben_ner_sessions') ? kben_ner_sessions($rows) : array(); $RK = function_exists('kben_runs') ? kben_runs($rows) : array();   // od 2026-10-28: test jen otevřený se nepřebírá
    foreach ($rows as $ri => $x) {
        if (isset($RK[$ri]) && isset($ner[$RK[$ri]])) { continue; }
        $d = json_decode((string) $x->data, true);
        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }      // jen ostré odpovědi (ne nácvik, ne sondy)
        $id = isset($d['polozka']) ? (string) $d['polozka'] : '';
        if ($id === '' || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
        $items[$id] = intval($d['spravne']) ? 1 : ((!empty($d['castecne']) && isset($d['skore']) && is_numeric($d['skore'])) ? floatval($d['skore']) : 0);   // pozdější odpověď přepíše dřívější; částečný kredit (Matice V12)
    }
    return (object) $items;
}

function kben_maybe_notify($s, $pt, $key, $raw) {
    $set = get_option('kben_settings', array());
    if (empty($set['notify']) || $set['notify'] === 'none' || empty($set['notify_email'])) { return; }
    $who = $pt ? (($pt->code !== '' ? $pt->code : substr($pt->anon_id, 0, 8)) . ', věk ' . $pt->age . ', ' . $pt->mode) : '?';
    wp_mail($set['notify_email'], 'Kognitivní baterie: dokončen test ' . $key,
        "Účastník: $who\nTest: $key\nHrubý skór: " . ($raw === null ? '-' : $raw) . "\nSezení: " . $s->id . "\n");
}

/* GET /correlations – Pearsonovy korelace mezi testy (poslední platný výsledek každého účastníka); jen souhrn, žádná data jednotlivců */
function kben_correlation_matrix($allow = null, $minOverride = null) {
    global $wpdb;
    $seenV = array();
    $rows = $wpdb->get_results("SELECT sc.id, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, sc.valid, sc.data, p.mode, p.code, p.anon_id FROM " . kben_table('scores') . " sc JOIN " . kben_table('participants') . " p ON p.id = sc.participant_id WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) ORDER BY sc.id ASC");
    $by = array();
    $FKEYS = array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka');
    $FT = $wpdb->prefix . 'kb_scores'; $FP = $wpdb->prefix . 'kb_participants';
    $czLive = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $FT)) === $FT;
    $scrT = array();   // od 1.80.0: screening – výsledky „nechaný běžet“ se do korelací nepočítají
    $isScr = function ($r, $ST) use (&$scrT) { if (!function_exists('kben_scr_ids') || !isset($r->id) || intval($r->valid) === 2) { return false; }
        if (!isset($scrT[$ST][$r->test_key])) { $scrT[$ST][$r->test_key] = kben_scr_ids(substr($ST, 0, -6), $r->test_key); } return isset($scrT[$ST][$r->test_key][intval($r->id)]); };
    $add = function ($r, $pk) use (&$by, &$seenV, $allow) {
        // jen testy a verze, které aplikace posílá jako současné (starší verze a zrušené testy se vynechají)
        if (is_array($allow)) {
            if (!isset($allow[$r->test_key]) || !in_array($r->test_version, (array) $allow[$r->test_key], true)) { return; }
        }
        // u opakovaného testu platí PRVNÍ dokončený výsledek (resp. první výsledek nové verze)
        if (!isset($by[$pk][$r->test_key])) { $by[$pk][$r->test_key] = floatval($r->raw_score); $seenV[$pk][$r->test_key] = array($r->test_version => 1); }
        elseif (!isset($seenV[$pk][$r->test_key][$r->test_version])) { $seenV[$pk][$r->test_key][$r->test_version] = 1; $by[$pk][$r->test_key] = floatval($r->raw_score); }
    };
    foreach ($rows as $r) {
        if ($czLive && $r->mode === 'cz') { continue; }   // importované české výsledky: místo nich se berou živá česká data níže
        if ($isScr($r, kben_table('scores'))) { continue; }
        // osoba = všechna její sezení dohromady (vaše verze podle kódu)
        $add($r, function_exists('kben_person_key') ? kben_person_key($r->mode, $r->code, $r->anon_id) : $r->participant_id);
    }
    /* + výsledky z české verze (tabulky wp_kb_*), živě – jen jazykově nezávislé testy (od 3.98.0 / EN 1.59.0) */
    if ($czLive) {
        $fin = "'" . implode("','", $FKEYS) . "'";
        $fr = $wpdb->get_results("SELECT sc.id, sc.valid, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score, fp.mode, fp.code, fp.anon_id FROM $FT sc JOIN $FP fp ON fp.id = sc.participant_id WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) AND sc.test_key IN ($fin) AND 1=1 ORDER BY sc.id ASC");
        foreach ((array) $fr as $r) { if ($isScr($r, $FT)) { continue; } $add($r, 'cz:' . (function_exists('kben_person_key') ? kben_person_key($r->mode, $r->code, $r->anon_id) : $r->participant_id)); }
    }
    /* + rodiče z dětské verze (wp_kbd_*; jen výsledky s věkem 18+) – jazykově nezávislé testy (od CZ 4.10.21 / EN 1.70.28) */
    if (kben_kbd_live()) {
        $KT = $wpdb->prefix . 'kbd_scores'; $kin = "'" . implode("','", $FKEYS) . "'";
        $kr = $wpdb->get_results("SELECT sc.id, sc.valid, sc.participant_id, sc.test_key, sc.test_version, sc.raw_score FROM $KT sc WHERE sc.raw_score IS NOT NULL AND sc.valid IN (1,2) AND sc.age >= 18 AND sc.test_key IN ($kin) ORDER BY sc.id ASC");
        foreach ((array) $kr as $r) { if ($isScr($r, $KT)) { continue; } $add($r, 'kbd:' . $r->participant_id); }
    }
    $set = get_option('kben_settings', array());
    $minn = $minOverride !== null ? intval($minOverride) : (isset($set['min_n']) ? intval($set['min_n']) : 30);
    $count = array();
    foreach ($by as $pid => $t) { foreach ($t as $k => $v) { $count[$k] = isset($count[$k]) ? $count[$k] + 1 : 1; } }
    $keys = array();
    foreach ($count as $k => $c) { if ($c >= $minn) { $keys[] = $k; } }
    sort($keys);
    $R = array(); $N = array();
    foreach ($keys as $i => $a) {
        foreach ($keys as $j => $b) {
            $x = array(); $y = array();
            foreach ($by as $t) { if (isset($t[$a]) && isset($t[$b])) { $x[] = $t[$a]; $y[] = $t[$b]; } }
            $n = count($x); $N[$i][$j] = $n; $R[$i][$j] = null;
            if ($i === $j || $n < $minn) { continue; }
            $mx = array_sum($x) / $n; $my = array_sum($y) / $n; $sxy = 0; $sxx = 0; $syy = 0;
            for ($q = 0; $q < $n; $q++) { $dx = $x[$q] - $mx; $dy = $y[$q] - $my; $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy; }
            $R[$i][$j] = ($sxx > 0 && $syy > 0) ? round($sxy / sqrt($sxx * $syy), 3) : null;
        }
    }
    return array('keys' => $keys, 'r' => $R, 'n' => $N, 'min_n' => $minn);
}
/* Rodiče z dětské verze (tabulky wp_kbd_*) – dospělí se stejnými verzemi testů; jen výsledky, u kterých je uložený věk 18+
   (podle věku u výsledku, ne podle role v profilu: rodič a dítě můžou sdílet zařízení a tedy i anonymní ID). Jen čtení, živě. */
function kben_kbd_live() { global $wpdb; $t = $wpdb->prefix . 'kbd_scores'; return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t; }
function kben_parent_values($key, $vs, $amin, $amax, $orig = false, $minAge = 18) {
    global $wpdb;
    if (!in_array($key, array('matice', 'matice12', 'vahy', 'dedukce', 'pravidla', 'pretahovana', 'stanoviste', 'papir', 'rotace', 'skladani', 'oblouky', 'rds', 'zpetna', 'por', 'corsi', 'symboly', 'rady', 'prohozene', 'dvojice', 'reakce', 'volba', 'kolecka'), true) || !kben_kbd_live()) { return array(); }
    $T = $wpdb->prefix . 'kbd_scores'; $args = array($key);
    $sql = "SELECT sc.id, sc.participant_id, sc.raw_score, sc.test_version, sc.data FROM $T sc WHERE sc.test_key = %s AND sc.valid >= 1 AND sc.raw_score IS NOT NULL AND sc.age >= " . intval($minAge);
    if ($vs) { $sql .= ' AND sc.test_version IN (' . implode(',', array_fill(0, count($vs), '%s')) . ')'; foreach ($vs as $v) { $args[] = $v; } }
    if ($amin > 0) { $sql .= " AND sc.age >= %d"; $args[] = $amin; }
    if ($amax > 0) { $sql .= " AND sc.age <= %d"; $args[] = $amax; }
    $rows = (array) $wpdb->get_results($wpdb->prepare($sql . ' ORDER BY sc.id ASC', $args));
    if (function_exists('kben_scr_filter')) { $rows = kben_scr_filter($rows, $T, $key); }   // od 1.80.0: screening
    if ($vs) { $rows = kben_ceil_pick($rows); }
    else { $f = array(); foreach ($rows as $x) { if (!isset($f[$x->participant_id])) { $f[$x->participant_id] = $x; } } $rows = array_values($f); }
    $out = array();
    foreach ($rows as $x) { if ($orig) { $ov = kben_orig_value($x->data); if ($ov !== null) { $out[] = $ov; } } else { $out[] = floatval($x->raw_score); } }
    return $out;
}
function kben_rest_correlations(WP_REST_Request $r) {
    $allow = null; $raw = $r->get_param('allow');
    if (is_string($raw) && $raw !== '') {
        $dec = json_decode(wp_unslash($raw), true);
        if (is_array($dec)) {
            $allow = array();
            foreach ($dec as $k => $vs) { $k = sanitize_key($k); if ($k === '' || !is_array($vs)) { continue; }
                $allow[$k] = array_slice(array_map('sanitize_text_field', array_map('strval', $vs)), 0, 20); }
        }
    }
    $ck = 'kben_corr_' . md5(wp_json_encode($allow) . '|scr1');
    $cached = get_transient($ck);
    if ($cached) { return $cached; }
    $m = kben_correlation_matrix($allow);
    set_transient($ck, $m, 10 * MINUTE_IN_SECONDS);
    return $m;
}

/* GET/POST /external – výsledky z jiných testů, které účastník sám zadá (nepovinné; sběr dat o validitě).
   Klíčem je anonymní ID (jako u /progress); ukládá se jen u existujícího účastníka. */
function kben_ext_lists() {
    return array('test' => array('wais4', 'wais5', 'wais3', 'wisc5', 'sb5', 'core', 'riot', 'cait', 'rapm', 'mensa', 'other'),
                 'admin' => array('pro', 'group', 'online', ''), 'source' => array('report', 'memory', ''));
}
function kben_ext_pid($anon) {
    global $wpdb;
    if (!kben_valid_uuid($anon)) { return 0; }
    return intval($wpdb->get_var($wpdb->prepare("SELECT id FROM " . kben_table('participants') . " WHERE anon_id = %s", $anon)));
}
function kben_rest_external_get(WP_REST_Request $r) {
    global $wpdb;
    $pid = kben_ext_pid($r->get_param('anon_id'));
    if (!$pid) { return array('entries' => array()); }
    $d = $wpdb->get_var($wpdb->prepare("SELECT data FROM " . kben_table('external') . " WHERE participant_id = %d", $pid));
    $e = json_decode((string) $d, true);
    return array('entries' => is_array($e) ? $e : array());
}
function kben_rest_external_save(WP_REST_Request $r) {
    global $wpdb;
    if (!kben_rate_ok('ext', 60, HOUR_IN_SECONDS)) { return kben_err('Too many requests.', 429); }
    $p = $r->get_json_params();
    $pid = kben_ext_pid(isset($p['anon_id']) ? $p['anon_id'] : '');
    if (!$pid) { return kben_err('Unknown participant.', 403); }
    $L = kben_ext_lists(); $out = array(); $yNow = intval(gmdate('Y'));
    foreach (array_slice(isset($p['entries']) && is_array($p['entries']) ? $p['entries'] : array(), 0, 6) as $e) {
        if (!is_array($e)) { continue; }
        $g = function ($k) use ($e) { return isset($e[$k]) && is_scalar($e[$k]) ? (string) $e[$k] : ''; };
        $test = $g('test'); if (!in_array($test, $L['test'], true)) { continue; }
        $sc = array();
        foreach ((isset($e['scores']) && is_array($e['scores']) ? array_slice($e['scores'], 0, 12, true) : array()) as $k => $v) {
            $k = substr(preg_replace('/[^a-z0-9]/', '', strtolower((string) $k)), 0, 8);
            if ($k === '' || !is_numeric($v) || floatval($v) <= 0 || floatval($v) > 250) { continue; }
            $sc[$k] = floatval($v);
        }
        if (!$sc) { continue; }
        $oth = array();
        foreach (array('o1_name', 'o2_name') as $k) { if (isset($e['other'][$k]) && is_scalar($e['other'][$k])) { $oth[$k] = mb_substr(sanitize_text_field((string) $e['other'][$k]), 0, 30); } }
        $year = intval($g('year')); $sd = intval($g('sd'));
        $out[] = array('test' => $test, 'test_other' => mb_substr(sanitize_text_field($g('test_other')), 0, 60), 'scores' => $sc, 'other' => $oth,
                       'sd' => in_array($sd, array(15, 16, 24), true) ? $sd : null, 'year' => ($year >= 1950 && $year <= $yNow) ? $year : null,
                       'admin' => in_array($g('admin'), $L['admin'], true) ? $g('admin') : '', 'source' => in_array($g('source'), $L['source'], true) ? $g('source') : '');
    }
    $T = kben_table('external'); $now = kben_now();
    $id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $T WHERE participant_id = %d", $pid));
    if ($id) { $wpdb->update($T, array('updated' => $now, 'data' => wp_json_encode($out)), array('id' => $id)); }
    else { $wpdb->insert($T, array('participant_id' => $pid, 'created' => $now, 'updated' => $now, 'data' => wp_json_encode($out))); }
    return array('saved' => count($out));
}
