<?php
if (!defined('ABSPATH')) { exit; }

function kben_table($name) { global $wpdb; return $wpdb->prefix . 'kben_' . $name; }

/**
 * Obecné schéma: každý řádek odpovědi je uložený jako JSON s klíčem testu.
 * Nový test tedy nevyžaduje změnu databáze a stávající data zůstanou beze změny.
 */
function kben_install_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE " . kben_table('participants') . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        anon_id CHAR(36) NOT NULL,
        created DATETIME NOT NULL,
        mode VARCHAR(10) NOT NULL DEFAULT 'public',
        code VARCHAR(60) NOT NULL DEFAULT '',
        age SMALLINT NULL,
        demographics LONGTEXT NULL,
        consent LONGTEXT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY anon_id (anon_id)
    ) $c;");
    dbDelta("CREATE TABLE " . kben_table('sessions') . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        participant_id BIGINT UNSIGNED NOT NULL,
        token CHAR(40) NOT NULL,
        started DATETIME NOT NULL,
        last_seen DATETIME NOT NULL,
        battery_version VARCHAR(30) NOT NULL DEFAULT '',
        settings LONGTEXT NULL,
        device LONGTEXT NULL,
        PRIMARY KEY  (id),
        KEY participant_id (participant_id)
    ) $c;");
    dbDelta("CREATE TABLE " . kben_table('rows') . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id BIGINT UNSIGNED NOT NULL,
        test_key VARCHAR(40) NOT NULL,
        client_seq INT UNSIGNED NOT NULL DEFAULT 0,
        created DATETIME NOT NULL,
        data LONGTEXT NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY session_seq (session_id, client_seq),
        KEY test_key (test_key)
    ) $c;");
    dbDelta("CREATE TABLE " . kben_table('scores') . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id BIGINT UNSIGNED NOT NULL,
        participant_id BIGINT UNSIGNED NOT NULL,
        test_key VARCHAR(40) NOT NULL,
        test_version VARCHAR(40) NOT NULL DEFAULT '',
        raw_score DOUBLE NULL,
        valid TINYINT(1) NOT NULL DEFAULT 1,
        age SMALLINT NULL,
        mode VARCHAR(10) NOT NULL DEFAULT 'public',
        created DATETIME NOT NULL,
        data LONGTEXT NULL,
        PRIMARY KEY  (id),
        KEY test_key (test_key, test_version),
        KEY participant_id (participant_id)
    ) $c;");
    /* výsledky z jiných testů (WAIS, RIOT…) zadané účastníkem – jeden řádek na osobu, data = JSON seznam (od 1.70.23) */
    dbDelta("CREATE TABLE " . kben_table('external') . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        participant_id BIGINT UNSIGNED NOT NULL,
        created DATETIME NOT NULL,
        updated DATETIME NOT NULL,
        data LONGTEXT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY participant_id (participant_id)
    ) $c;");
    update_option('kben_db_version', KBEN_DB_VERSION);
}
