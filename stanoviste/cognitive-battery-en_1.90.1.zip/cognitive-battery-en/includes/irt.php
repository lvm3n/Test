<?php
if (!defined('ABSPATH')) { exit; }
/* od 2026-11-13 (IRT-2026-11-13): + Přetahovaná – Rasch (a = 1), b z kalibrace 13. 11. 2026 (N = 67, téměř jen EN vzorek), prior N(0,1).
   Skórování théta (od 2026-10-27): položkové testy se skórují odhadem schopnosti (EAP, 1PL se společnou diskriminací
   pro test, prior N(0,1)) z PRVNÍ odpovědi osoby na každou kalibrovanou položku – ve všech sezeních a verzích testu.
   Parametry jsou z kalibrace na datech všech čtyř verzí baterie; stejné parametry má aplikace (KB_IRT).
   Théta se ukládá k výsledku (data.theta, theta_v = verze parametrů); starší výsledky server dopočítá postupně sám. */
function kben_irt() {
    static $p = null;
    if ($p === null) { $p = json_decode(<<<'JSON'
{"version":"IRT-2026-11-13","tests":{"matice12":{"a":1.4,"src":["matice12","ceiling"],"b":{"V12-212":-0.77,"V12-122":-0.7,"V12-113":-0.225,"V12-114":-0.29,"V12-01":-3.846,"V12-02":-3.255,"V12-03":-3.053,"V12-04":-3.027,"V12-05":-3.12,"V12-06":-1.293,"V12-07":-1.956,"V12-08":-2.298,"V12-09":-2.713,"V12-10":-1.195,"V12-11":0.707,"V12-11_r":0.025,"V12-12_r":0.652,"V12-13":-1.377,"V12-14":-1.066,"V12-15":-1.34,"V12-16":-0.715,"V12-16_r2":-1.361,"V12-17":-0.102,"V12-17_r":0.037,"V12-18":2.188,"V12-19":-0.006,"V12-20":-1.69,"V12-21":-1.183,"V12-22":-1.046,"V12-22_r":-0.341,"V12-23":-0.545,"V12-24":-0.405,"V12-24_r":-0.366,"V12-25":-0.46,"V12-26":0.064,"V12-26_r":-0.501,"V12-27":-0.277,"V12-28":0.363,"V12-28_r":-0.694,"V12-29":-0.113,"V12-30":-0.776,"V12-31_r":-0.769,"V12-32_r":1.737,"V12-33_r":1.617,"V12-33_r2":-0.329,"V12-34_r":0.288,"V12-34_r2":-0.226,"V12-35_r2":0.966,"V12-35_r3":0.685,"V12-36_r":0.544,"V12-37":-0.745,"V12-37_r":-1.029,"V12-38_r3":1.381,"V12-39_r":2.086,"V12-39_r2":1.119,"V12-40":-1.287,"V12-41":0.692,"V12-42":-0.629,"V12-46":1.285,"V12-47":0.049,"V12-48":-0.362,"V12-49":0.98,"V12-50":0.944,"V12-51":-1.038,"V12-52":0.263,"V12-53":-0.089,"V12-55":0.812,"V12-56":-0.22,"V12-57":-0.223,"V12-58":1.271,"V12-60":-0.244,"V12-61":1.486,"V12-63":-0.793,"V12-64":-0.607,"V12-65_r2":1.737,"V12-66":-0.623,"V12-67":2.03,"V12-69":-1.0,"V12-71":-0.69,"V12-72":-1.922,"V12-73":-1.899,"V12-74":-1.096,"V12-75":-0.533,"V12-76":0.312,"V12-78":1.165,"V12-79":-0.17,"V12-80":1.913,"V12-93":-0.291,"V12-97":0.404,"V12-98":-0.212,"V12-70_r":0.978,"V12-181":-0.538}},"vahy":{"a":1.905,"src":["vahy"],"b":{"V2_A3":-1.683,"V2_B1":-1.687,"V2_C1":-1.88,"V2_C2":-1.63,"V2_C3":-1.226,"V2_D1":-1.729,"V2_D2":-1.589,"V2_D3":-2.428,"V2_D4":-2.076,"V2_E1":-1.944,"V2_E2":-1.45,"V2_F1":-2.576,"V2_F2":-1.074,"V2_F3":-1.673,"V2_F4":-1.58,"V2_G1":-1.679,"V2_G2":-1.161,"V2_G3":-1.228,"V2_H1":-1.323,"V2_H2":-0.843,"V2_J1":-0.441,"V2_J2":-0.295,"V2_K1":-0.425,"V2_K10":1.356,"V2_K11":-0.051,"V2_K12":0.744,"V2_K13":1.283,"V2_K14":1.291,"V2_K15":1.434,"V2_K2":0.51,"V2_K3":1.272,"V2_K4":-0.424,"V2_K5":-0.469,"V2_K6":1.497,"V2_K7":0.037,"V2_K8":-0.028,"V2_K9":0.869,"V2_L2":0.105}},"papir":{"a":2.657,"src":["papir"],"b":{"PAP_001":-1.274,"PAP_002":-1.252,"PAP_003":-1.499,"PAP_004":-0.667,"PAP_006":-1.013,"PAP_008":-0.965,"PAP_011":-0.606,"PAP_013":-0.729,"PAP_016":-0.809,"PAP_017":-0.593,"PAP_018":-0.791,"PAP_019":-1.21,"PAP_020":-0.162,"PAP_021":-0.327,"PAP_022":-0.71,"PAP_023":-0.561,"PAP_024":-1.046,"PAP_025":-0.45,"PAP_026":-0.053,"PAP_027":0.518,"PAP_028":0.333,"PAP_029":0.139,"PAP_030":0.236,"PAP_032":-1.277,"PAP_033":-0.616,"PAP_034":-0.568,"PAP_035":-0.886,"PAP_036":-0.117,"PAP_037":-0.484,"PAP_039":-0.351,"PAP_040":-0.269,"PAP_041":-0.617,"PAP_042":-0.264,"PAP_043":0.343,"PAP_044":0.403,"PAP_045":-1.097,"PAP_046":0.514,"PAP_048":1.053,"PAP_049":-0.431,"PAP_050":0.729,"PAP_051":0.738,"PAP_052":0.488,"PAP_053":1.558,"PAP_054":0.303,"PAP_055":-0.023,"PAP_056":0.738,"PAP_057":-0.016,"PAP_058":0.533,"PAP_059":0.347,"PAP_060":1.405,"PAP_061":0.824,"PAP_062":0.075,"PAP_063":0.854,"PAP_064":0.786,"PAP_071_r":0.216,"PAP_072":0.616,"PAP_072_r":0.699,"PAP_073":-0.476,"PAP_074":0.329,"PAP_075":-0.296,"PAP_076_r":0.857,"PAP_077_r":0.961,"PAP_078_r":1.891}},"dedukce":{"a":1.697,"src":["dedukce"],"b":{"D01":-2.11,"D02":-1.227,"D03":-1.579,"D04":-2.366,"D05":-1.579,"D06":-1.687,"D07":-1.054,"D08":-1.274,"D09":-1.14,"D12":-1.475,"D13":-1.421,"D14":-1.475,"D16":-0.706,"D18":-0.835,"D20":-1.459,"D21":-1.459,"D23":-1.321,"D26":0.595,"D27":-0.871,"D28":-0.333,"D29":-0.52,"D30":-0.52,"D31":-0.136,"D32":0.022,"D33":-0.304,"D34":-0.432,"D35":0.732,"D36":1.641,"D37":1.195,"D38":1.646,"D39":0.568,"D41":-0.294,"D42":-1.204,"D43":-0.366,"D44":-0.524,"D45":-0.094,"D46":-0.666,"D47":-0.358,"D48":-0.167,"D49":0.242,"D54":-0.306,"D55":0.552,"D56":-0.583,"D57":1.235,"D58":1.123,"D59":0.957,"D60":0.686,"D61":0.43,"D62":0.132,"D63":0.188,"D64":0.567,"D65":0.56,"D66":0.58,"D67":-0.609,"D68":0.181}},"pravidla":{"a":2.583,"src":["pravidla"],"b":{"A1":-1.576,"A2":-1.011,"A3":-1.413,"A4":-1.058,"A4R":-0.939,"A5":-1.31,"A5R":0.159,"A6":-1.454,"B1":-0.924,"B2":-0.426,"B3R":-0.47,"B4":0.167,"B5":-0.173,"B6":-0.645,"B7":-0.738,"B7R":-0.077,"C1":-0.299,"C2":-0.936,"C3":-0.137,"C4":-0.27,"C5R":0.202,"C6":-0.291,"C7":-0.618,"C7R":1.57,"C8":-0.618,"C8R":1.553,"D1R":-0.225,"D2":0.159,"D3":-0.614,"D4":-0.103,"D5":1.765,"D5R":0.921,"D6":-0.127,"D7":-0.543,"D8":-0.579,"E1":0.218,"E2":1.429,"E3":0.078,"E3R":-0.02,"E4":0.533,"E5":-0.7,"E5R":1.004,"E6":0.601,"E7":0.907}},"stanoviste":{"a":2.031,"src":["stanoviste"],"b":{"S01":-2.35,"S02":-2.35,"S06":-1.435,"S08":-1.128,"S11":-0.078,"S12b":-1.08,"S13":-0.943,"S15b":-1.358,"S16b":-1.052,"S17":-0.642,"S18":-0.864,"S19":-0.749,"S20b":-0.557,"S21b":-0.314,"S22b":-0.292,"S23":-0.776,"S24":-0.077,"S25":-0.331,"S27":0.277,"S28":-1.03,"S30":-0.582,"S31":-0.776,"S32":-0.776,"S33":-0.776,"S33b_r":-0.732,"S34":-0.331,"S34b_r":0.046,"S35":0.534,"S35b_r":-0.307,"S36b_r":-0.049,"S37_r":-0.311,"S38_r":0.185,"S39_r":-0.406,"S40_r":0.151,"S41_r":0.074,"S42_r":0.626,"S43_r":0.41,"S44_r":0.524,"S45_r":1.326,"S46_r":0.993,"S50_r":0.442,"S52_r":0.503,"S53":-0.796,"S54_r":-0.771,"S55_r":0.969,"S56_r":1.886,"S57_r":1.829}},"skladani":{"a":2.202,"src":["skladani"],"b":{"SK48_40":0.204,"SK48_44":0.915,"SKB_1":1.59,"SKB_4":2.134,"SKL_2":0.86,"SKO_1":-0.113,"SKS_02":0.185,"SKS_03":-0.349,"SKS_04":-0.133,"SKS_05":-0.433,"SKS_06":-0.252,"SKS_07":0.551,"SKW_01":-2.808,"SKW_02":-2.444,"SKW_06":0.544,"SKW_06_r":-0.694,"SKW_06_r2":-0.413,"SKW_07":-1.361,"SKW_07_r":-0.02,"SKW_08":-1.019,"SKW_08_r":-1.063,"SKW_09":-0.794,"SKW_09_r":-0.237,"SKW_09_r2":0.222,"SKW_10":-1.033,"SKW_10_r":1.299,"SKW_11":-0.121,"SKW_12":-1.694,"SKW_12_r":-0.267,"SKW_13":0.507,"SKW_13_r":0.312,"SKW_14":-0.203,"SKW_14_r":-0.144,"SKW_15":-2.017,"SKW_16":-0.371,"SKW_16_r":0.543,"SKW_17":-0.491,"SKW_17_r":0.188,"SKX_1":1.675,"SKX_2":1.207,"SKX_3":1.547,"SKX_4":0.532,"SK_E1":-2.005,"SK_E2":-2.005,"SK_E3":-2.005,"SK_E4":-2.005}},"gcslovni":{"a":1.839,"src":["gcslovni"],"b":{"SZ05":-2.315,"SZ06":-1.988,"SZ08":-1.498,"SZ09":-1.75,"SZ10":-1.75,"SZ11":-1.325,"SZ12":-1.414,"SZ13":-1.356,"SZ14":-1.356,"SZ15":-0.077,"SZ16":-1.971,"SZ17":-1.646,"SZ18":-1.943,"SZ19":-1.541,"SZ20":-0.576,"SZ21":0.253,"SZ22":-0.359,"SZ23":-1.232,"SZ25":-0.443,"SZ26":-1.153,"SZ27":-0.722,"SZ28":1.011,"SZ29":-1.511,"SZ30":-0.531,"SZ31":0.336,"SZ32":0.964,"SZ33":0.326,"SZ34":-1.23,"SZ35":-0.783,"SZ36":0.042,"SZ37":0.298,"SZ38":1.765,"SZ39":-0.302,"SZ40":1.002,"SZ41":1.243,"SZ42":0.012,"SZ43":0.532,"SZ44":0.152,"SZ45":1.06,"SZ46":0.27,"SZ47":0.061,"SZ48":1.339,"SZ49":0.509,"SZ50":1.762,"SZ51":0.213,"SZ52":1.76,"SZ53":1.415,"SZ54":1.377}},"gcznalosti":{"a":1.649,"src":["gcznalosti"],"b":{"ZN06":-1.725,"ZN08":-0.431,"ZN09":-0.511,"ZN10":-2.145,"ZN11":-1.725,"ZN12":-0.392,"ZN13":-1.478,"ZN15":-1.066,"ZN16":-0.569,"ZN17":-1.564,"ZN18":-1.679,"ZN19":-1.153,"ZN20":0.043,"ZN22":-0.697,"ZN23":-1.349,"ZN24":-1.862,"ZN26":-0.632,"ZN27":-0.448,"ZN28":0.909,"ZN29":-0.908,"ZN30":-0.908,"ZN31":-0.16,"ZN32":0.181,"ZN33":-0.357,"ZN34":1.167,"ZN36":-0.49,"ZN37":1.234,"ZN38":-0.009,"ZN39":-0.344,"ZN40":-0.308,"ZN41":1.029,"ZN42":0.445,"ZN43":1.619,"ZN44":0.399,"ZN45":0.459,"ZN46":-0.373,"ZN47":0.944,"ZN48":1.35,"ZN49":1.466,"ZN50":2.083}},"pretahovana":{"a":1.0,"src":["pretahovana"],"b":{"PR01":-2.971,"PR04":-3.546,"PR05":-2.554,"PR06":-3.534,"PR09":-5.584,"PR10":-1.94,"PR11":-2.225,"PR12":-2.594,"PR13":-1.931,"PR16":-1.61,"PR17":-0.849,"PR18":-0.662,"PR19":-0.495,"PR21":-0.222,"PR22":0.42,"PR23":0.211,"PR25":-0.573,"PR26":0.09,"PR28":-0.601,"PR29":0.569,"PR31":1.052,"PR32":0.469,"PR33":0.687,"PR34":0.776,"PR35":1.166,"PR36":1.327,"PR37":0.387,"PR38":0.478,"PR40":1.611,"PR42":2.263,"PR43":1.713,"PR44":2.448,"PR45":0.696,"PR47":3.212,"PR49":2.951,"PR50":4.058}}}}
JSON
, true); }
    return $p;
}
function kben_irt_keys() { $P = kben_irt(); return array_keys($P['tests']); }
function kben_irt_pool_keys() { return array_values(array_diff(kben_irt_keys(), array('gcslovni', 'gcznalosti'))); }   // jazykově nezávislé
function kben_irt_eap($t, $resp) {
    $P = kben_irt(); if (!isset($P['tests'][$t])) { return null; }
    $a = floatval($P['tests'][$t]['a']); $B = $P['tests'][$t]['b']; $n = 0; $L = array_fill(0, 61, 0.0);
    foreach ($resp as $id => $y) {
        if (!isset($B[$id])) { continue; }
        $n++; $b = floatval($B[$id]);
        for ($q = 0; $q < 61; $q++) { $z = $a * ((-5 + $q / 6) - $b); $L[$q] += $y ? -log(1 + exp(-$z)) : -log(1 + exp($z)); }
    }
    if (!$n) { return null; }
    $mx = -INF; $lp = array();
    for ($q = 0; $q < 61; $q++) { $th = -5 + $q / 6; $lp[$q] = $L[$q] - $th * $th / 2; if ($lp[$q] > $mx) { $mx = $lp[$q]; } }
    $s = 0; $m = 0; $m2 = 0;
    for ($q = 0; $q < 61; $q++) { $th = -5 + $q / 6; $w = exp($lp[$q] - $mx); $s += $w; $m += $w * $th; $m2 += $w * $th * $th; }
    $m /= $s;
    return array('theta' => round($m, 3), 'se' => round(sqrt(max(0, $m2 / $s - $m * $m)), 3), 'n' => $n);
}
/* od 2026-10-28: sezení, ve kterém člověk test jen otevřel a nechal běžet – aspoň 3 ostré úlohy a u poloviny a víc z nich
   žádná akce (prvni_akce_ms je uložené a prázdné, odpověď nesprávná). Takové odpovědi se nepočítají do théty ani do převzetí
   a výsledek se označí jako neplatný (nepočítá se do norem). Gc (psaní odpovědí) se neposuzuje. Vrací množinu "session_id|test_key". */
function kben_runs($rows) {                  // klíč běhu pro každý řádek: sezení|test|pořadí běhu (nový běh začíná řádkem novy_pokus / znovu_po_neresenem)
    $run = array(); $keys = array();
    foreach ((array) $rows as $i => $x) {
        $b = intval($x->session_id) . '|' . $x->test_key; if (!isset($run[$b])) { $run[$b] = 0; }
        if (strpos((string) $x->data, 'novy_pokus') !== false || strpos((string) $x->data, 'znovu_po_neresenem') !== false) {
            $d = json_decode((string) $x->data, true);
            if (is_array($d) && isset($d['polozka']) && in_array($d['polozka'], array('novy_pokus', 'znovu_po_neresenem'), true)) { $run[$b]++; }
        }
        $keys[$i] = $b . '|' . $run[$b];
    }
    return $keys;
}
function kben_ner_sessions($rows) {          // množina klíčů běhů bez snahy (viz výše)
    $n = array(); $na = array(); $K = kben_runs($rows);
    foreach ((array) $rows as $i => $x) {
        if (in_array($x->test_key, array('gcslovni', 'gcznalosti'), true)) { continue; }
        $d = json_decode((string) $x->data, true);
        if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }
        $k = $K[$i]; $n[$k] = (isset($n[$k]) ? $n[$k] : 0) + 1;
        if (array_key_exists('prvni_akce_ms', $d) && ($d['prvni_akce_ms'] === '' || $d['prvni_akce_ms'] === null) && !(isset($d['spravne']) && is_numeric($d['spravne']) && floatval($d['spravne']) >= 1)) { $na[$k] = (isset($na[$k]) ? $na[$k] : 0) + 1; }
    }
    /* od 2026-11-03 (ner_v 2): navíc nejvýš 2 úlohy s akcí – kdo část úloh vyřešil a pak nechal test doběhnout (konec po chybách), test dokončil */
    $out = array(); foreach ($n as $k => $c) { if ($c >= 3 && isset($na[$k]) && $na[$k] * 2 >= $c && $c - $na[$k] <= 2) { $out[$k] = 1; } }
    return $out;
}
/* od 2026-10-28: je POSLEDNÍ běh testu v sezení bez snahy? (při uložení výsledku) */
function kben_ner_last($sid, $key, $expect = 0) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare("SELECT session_id, test_key, data FROM " . kben_table('rows') . " WHERE session_id = %d AND test_key = %s ORDER BY id ASC", $sid, $key));
    if (!$rows) { return false; }
    $K = kben_runs($rows); $ner = kben_ner_sessions($rows); $last = end($K);
    if ($expect > 0) {                                             // řádky posledního běhu musí odpovídat výsledku (jinak ještě nedorazily – nerozhodovat)
        $c = 0; foreach ($rows as $i => $x) { if ($K[$i] === $last && strpos((string) $x->data, '"faze":"test"') !== false) { $c++; } }
        if ($c * 2 < $expect) { return false; }
    }
    return isset($ner[$last]);
}
/* od 1.80.0: SCREENING norem – výsledky, kde člověk test pustil a nechal běžet, se do srovnání nepočítají
   (stejná pravidla jako Přehled baterie 1.8.0). Posuzuje se POSLEDNÍ běh testu v sezení, ke kterému se výsledek uložil:
   – jen otevřený: kben_ner_sessions (beze změny);
   – konec bez akce: běh končí aspoň kben_scr_set()['n'] úlohami za sebou bez jakékoli akce (vypršel čas, nic neoznačeno);
   – Gs nečinnost: nejdelší úsek bez odpovědi (jedna úloha, nebo zbytek limitu po poslední odpovědi) aspoň 'gs' s;
   – Rychlý test: jedna úloha aspoň 'rq' s.
   Gc s psaním a reakční testy (vlastní validita) se neposuzují. V thétě se úlohy z konce bez akce (a sondy bez akce) berou jako
   nezadané, ne jako chyby; vyřazený výsledek se nepočítá jako „má výsledek“ (pak platí ≥ 10 úloh a SE ≤ 0,5). */
function kben_scr_set() { return array('n' => 3, 'gs' => 20, 'rq' => 180); }
function kben_scr_skip($tk) { return in_array($tk, array('gcslovni', 'gcznalosti', 'reakce', 'volba', 'kolecka'), true); }
function kben_noact($d) {
    return is_array($d) && array_key_exists('prvni_akce_ms', $d) && ($d['prvni_akce_ms'] === '' || $d['prvni_akce_ms'] === null) && !(isset($d['spravne']) && is_numeric($d['spravne']) && floatval($d['spravne']) >= 1);
}
function kben_ms($iso) {
    if (!is_string($iso) || $iso === '') { return null; } $t = strtotime($iso); if ($t === false) { return null; }
    return $t * 1000 + (preg_match('/\.(\d{1,3})/', $iso, $m) ? intval(str_pad($m[1], 3, '0')) : 0);
}
function kben_rm_row(&$A, $sid, $tk, $d) {      // metriky běhu (viz výše); vrací klíč běhu sezení|test|pořadí
    $b = intval($sid) . '|' . $tk; if (!isset($A['run'][$b])) { $A['run'][$b] = 0; }
    if (is_array($d) && isset($d['polozka']) && in_array($d['polozka'], array('novy_pokus', 'znovu_po_neresenem'), true)) { $A['run'][$b]++; }
    $k = $b . '|' . $A['run'][$b]; $A['last'][$b] = $k;
    if (!is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test' || kben_scr_skip($tk)) { return $k; }
    if (!isset($A['m'][$k])) { $A['m'][$k] = array('n' => 0, 'na' => 0, 'st' => 0, 'g' => 0, 'sp' => 0, 'rq' => 0, 'c0' => null, 'r0' => 0, 'c1' => null, 'lim' => 0, 'el' => 0, 'T' => 0); }
    $M = &$A['m'][$k]; $M['n']++;
    $rt = isset($d['rt_ms']) && is_numeric($d['rt_ms']) ? floatval($d['rt_ms']) : null;
    if ($tk === 'rychly') {
        $M['rq'] = 1; $M['lim'] = isset($d['time_limit_ms']) && is_numeric($d['time_limit_ms']) ? floatval($d['time_limit_ms']) : 600000;
        if ($rt !== null) { $M['g'] = max($M['g'], $rt); } if (isset($d['elapsed_ms']) && is_numeric($d['elapsed_ms'])) { $M['el'] = max($M['el'], floatval($d['elapsed_ms'])); }
        if (isset($d['stav']) && $d['stav'] === 'T') { $M['T'] = 1; }
    } elseif (array_key_exists('prvni_akce_ms', $d)) {
        if (kben_noact($d)) { $M['na']++; $M['st']++; } else { $M['st'] = 0; }
    } elseif (isset($d['time_limit_ms']) && is_numeric($d['time_limit_ms']) && floatval($d['time_limit_ms']) > 0) {
        $M['sp'] = 1; $M['lim'] = floatval($d['time_limit_ms']); $c = kben_ms(isset($d['cas']) ? $d['cas'] : '');
        if ($rt !== null) { $M['g'] = max($M['g'], $rt); }
        if ($c !== null) { if ($M['c0'] === null) { $M['c0'] = $c; $M['r0'] = $rt === null ? 0 : $rt; } $M['c1'] = $c; }
    }
    unset($M); return $k;
}
function kben_scr_reason($M) {
    if (!$M) { return null; } $S = kben_scr_set();
    if ($M['n'] >= 3 && $M['na'] * 2 >= $M['n'] && $M['n'] - $M['na'] <= 2) { return 'ot'; }
    if ($M['st'] >= $S['n']) { return 'kon'; }
    if ($M['sp']) { $idle = $M['g']; if ($M['c0'] !== null && $M['lim'] > 0) { $idle = max($idle, $M['lim'] - ($M['c1'] - $M['c0'] + $M['r0'])); } if ($idle >= $S['gs'] * 1000) { return 'gs'; } }
    if ($M['rq']) { $idle = $M['g']; if ($M['T'] && $M['lim'] > 0 && $M['el'] > 0) { $idle = max($idle, $M['lim'] - $M['el']); } if ($idle >= $S['rq'] * 1000) { return 'rq'; } }
    return null;
}
/* id výsledků testu $key v tabulkách s předponou $T (např. wp_kb_), které screening vyřadil; cache 30 min */
function kben_scr_ids($T, $key) {
    global $wpdb; static $mem = array();
    $ck = 'kben_scr_' . md5($T . '|' . $key . '|' . wp_json_encode(kben_scr_set()) . '|s2');   // s2 = + vlastní výpověď po testu
    if (isset($mem[$ck])) { return $mem[$ck]; }
    $c = get_transient($ck); if ($c !== false) { return $mem[$ck] = $c; }
    foreach (array('rows', 'scores') as $tb) { if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $T . $tb)) !== $T . $tb) { return array(); } }
    $A = array('run' => array(), 'last' => array(), 'm' => array()); $last = 0;
    if (!kben_scr_skip($key)) { do {
        $rs = $wpdb->get_results($wpdb->prepare("SELECT id, session_id, data FROM {$T}rows WHERE test_key = %s AND id > %d AND (data LIKE %s OR data LIKE %s OR data LIKE %s) ORDER BY id ASC LIMIT 20000",
            $key, $last, '%"faze":"test"%', '%novy_pokus%', '%znovu_po_neresenem%'));
        foreach ((array) $rs as $x) { $last = intval($x->id); kben_rm_row($A, $x->session_id, $key, json_decode((string) $x->data, true)); }
        $cnt = count((array) $rs); unset($rs);
    } while ($cnt === 20000); }
    $out = array(); $PO = function_exists('kbnf_self_all') ? kbnf_self_all($T, array($key)) : array('s' => array());   // od 1.86.0: po testu uvedl(a), že se nesnažil(a) / test už dělal(a)
    foreach ((array) $wpdb->get_results($wpdb->prepare("SELECT id, session_id FROM {$T}scores WHERE test_key = %s AND raw_score IS NOT NULL", $key)) as $x) {
        $lk = intval($x->session_id) . '|' . $key;
        if (isset($PO['s'][$lk])) { $out[intval($x->id)] = 1; continue; }
        if (isset($A['last'][$lk], $A['m'][$A['last'][$lk]]) && kben_scr_reason($A['m'][$A['last'][$lk]])) { $out[intval($x->id)] = 1; }
    }
    set_transient($ck, $out, 30 * MINUTE_IN_SECONDS);
    return $mem[$ck] = $out;
}
function kben_scr_filter($rows, $ST, $key) {    // výsledky (objekty s id) bez vyřazených screeningem; $ST = tabulka *_scores
    $ids = kben_scr_ids(substr($ST, 0, -6), $key); if (!$ids) { return $rows; }
    return array_values(array_filter((array) $rows, function ($x) use ($ids) { return !isset($x->id) || !isset($ids[intval($x->id)]); }));
}
/* první odpověď osoby na každou položku testu (všechna sezení do $maxSid včetně; 0 = všechna) */
function kben_irt_resp($pid, $t, $maxSid = 0) {
    global $wpdb;
    $P = kben_irt(); if (!isset($P['tests'][$t])) { return array(); }
    $sids = $wpdb->get_col($wpdb->prepare("SELECT id FROM " . kben_table('sessions') . " WHERE participant_id = %d" . ($maxSid ? " AND id <= " . intval($maxSid) : ''), $pid));
    if (!$sids) { return array(); }
    $src = "'" . implode("','", array_map('esc_sql', $P['tests'][$t]['src'])) . "'";
    $rows = $wpdb->get_results("SELECT session_id, test_key, data FROM " . kben_table('rows') . " WHERE session_id IN (" . implode(',', array_map('intval', $sids)) . ") AND test_key IN ($src) ORDER BY id ASC");
    $ner = kben_ner_sessions($rows); $RK = kben_runs($rows);   // od 2026-10-28: běhy bez snahy se vynechají
    $r = array();
    foreach ((array) $rows as $ri => $xr) {
        if (isset($ner[$RK[$ri]])) { continue; }
        $d = json_decode((string) $xr->data, true);
        if (!is_array($d) || !isset($d['faze']) || !in_array($d['faze'], array('test', 'sonda'), true)) { continue; }
        $id = isset($d['id']) && $d['id'] !== '' && $d['id'] !== null ? (string) $d['id'] : (isset($d['polozka']) ? (string) $d['polozka'] : '');
        if ($id === '' || isset($r[$id]) || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
        $r[$id] = floatval($d['spravne']) >= 1 ? 1 : 0;
    }
    return $r;
}
/* zpětný přepočet: výsledky položkových testů bez théty (nebo se starší verzí parametrů) */
function kben_irt_backfill($limit = 150) {
    global $wpdb;
    $P = kben_irt(); $V = $P['version']; $T = kben_table('scores');
    $in = "'" . implode("','", array_map('esc_sql', kben_irt_keys())) . "'";
    $rows = $wpdb->get_results($wpdb->prepare("SELECT id, participant_id, session_id, test_key, valid, data FROM $T WHERE test_key IN ($in) AND raw_score IS NOT NULL AND (data IS NULL OR data NOT LIKE %s OR data NOT LIKE %s) ORDER BY id ASC LIMIT " . intval($limit), '%"theta_v":"' . $wpdb->esc_like($V) . '"%', '%"ner_v":2%'));
    $done = 0;
    foreach ((array) $rows as $x) {
        $e = kben_irt_eap($x->test_key, kben_irt_resp($x->participant_id, $x->test_key, $x->session_id));
        $d = json_decode((string) $x->data, true); if (!is_array($d)) { $d = array(); }
        $d['theta'] = $e ? $e['theta'] : null; $d['theta_se'] = $e ? $e['se'] : null; $d['theta_n'] = $e ? $e['n'] : 0; $d['theta_v'] = $V; $d['theta_server'] = 1;
        $upd = array();
        if (empty($d['ner_v']) || intval($d['ner_v']) < 2) {                                          // od 2026-10-28: test jen otevřený (viz kben_ner_sessions) → neplatný výsledek
            $brs = $wpdb->get_results($wpdb->prepare("SELECT session_id, test_key, data FROM " . kben_table('rows') . " WHERE session_id = %d AND test_key = %s ORDER BY id ASC", $x->session_id, $x->test_key));
            $ner = kben_ner_sessions($brs); $BK = kben_runs($brs);
            if (!empty($d['neresil'])) {                                   // od 2026-11-03: dřív označený jako „jen otevřený“ – podle nového pravidla znovu posoudit poslední běh
                if ($brs && !isset($ner[end($BK)])) { $upd['valid'] = isset($d['valid_puvodni']) ? intval($d['valid_puvodni']) : 1; unset($d['neresil']); $d['neresil_zruseno'] = 1; }
            }
            /* starší data: jeden běh v sezení (víc běhů řeší kontrola při uložení) */ elseif (empty($d['ner_v']) && $brs && count(array_unique($BK)) === 1 && isset($ner[$BK[0]])) { $d['neresil'] = 1; $d['valid_puvodni'] = isset($x->valid) ? intval($x->valid) : 1; $upd['valid'] = 0; }
            $d['ner_v'] = 2;
        }
        $upd['data'] = wp_json_encode($d);
        $wpdb->update($T, $upd, array('id' => $x->id)); $done++;
    }
    return $done;
}
add_action('init', function () {
    if (get_transient('kben_irt_bf')) { return; }
    set_transient('kben_irt_bf', 1, 5 * MINUTE_IN_SECONDS);
    kben_irt_backfill(is_admin() ? 600 : 150);
});
/* od 2026-11-03: théta pro normy ze VŠECH použitelných odpovědí – i od lidí, kterým se výsledek testu neuložil
   (zavřeli stránku, test ukončili dřív, sezení spadlo). Použitelná théta = osoba má uložený platný výsledek testu, nebo aspoň
   kben_th_min_n() kalibrovaných úloh a SE ≤ kben_th_max_se(). Běhy „jen otevřený“ se vynechají. Jedna hodnota na osobu:
   první odpověď na každou úlohu ze všech sezení (stejně jako u vlastního výsledku). Výsledek se drží 30 minut v transientu. */
function kben_th_min_n() { return 10; }
function kben_th_max_se() { return 0.5; }
function kben_theta_pool($T, $key) {          // $T = předpona tabulek dané verze (např. wp_kb_); vrací [théta, věk, režim, má výsledek, participant_id]
    global $wpdb;
    $P = kben_irt(); if (!isset($P['tests'][$key])) { return array(); }
    foreach (array('rows', 'sessions', 'participants', 'scores') as $tb) { if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $T . $tb)) !== $T . $tb) { return array(); } }
    $ck = 'kben_thp_' . md5($T . '|' . $key . '|' . $P['version'] . '|p3|' . wp_json_encode(kben_scr_set()) . '|' . (function_exists('kbnf_defaults') ? KBNF_VERSION . wp_json_encode(kbnf_defaults()) : ''));   // p2 = se screeningem (od 1.80.0), p3 = + čištění norem (od 1.86.0)
    $c = get_transient($ck); if ($c !== false) { return $c; }
    $src = "'" . implode("','", array_map('esc_sql', $P['tests'][$key]['src'])) . "'";
    $rows = $wpdb->get_results("SELECT r.session_id, r.test_key, r.data, s.participant_id FROM {$T}rows r JOIN {$T}sessions s ON s.id = r.session_id WHERE r.test_key IN ($src)" .
        " AND (r.data LIKE '%\"faze\":\"test\"%' OR r.data LIKE '%\"faze\":\"sonda\"%' OR r.data LIKE '%novy_pokus%' OR r.data LIKE '%znovu_po_neresenem%') ORDER BY r.id ASC");
    $ner = kben_ner_sessions($rows); $RK = kben_runs($rows); $resp = array();
    /* od 1.80.0: konec běhu bez akce → úlohy jako nezadané (ne chyby), i sondy bez akce v takovém běhu */
    $DD = array(); $tail = array(); $SN = kben_scr_set();
    foreach ((array) $rows as $i => $x) { $d = json_decode((string) $x->data, true); $DD[$i] = $d;
        if (kben_scr_skip($x->test_key) || !is_array($d) || !isset($d['faze']) || $d['faze'] !== 'test') { continue; }
        if (kben_noact($d)) { $tail[$RK[$i]][] = $i; } else { $tail[$RK[$i]] = array(); } }
    $drop = array(); $tailRun = array(); foreach ($tail as $k => $ix) { if (count($ix) >= $SN['n']) { $tailRun[$k] = 1; foreach ($ix as $j) { $drop[$j] = 1; } } }
    foreach ((array) $rows as $i => $x) {
        if (isset($ner[$RK[$i]]) || isset($drop[$i])) { continue; }
        $d = $DD[$i];
        if (!is_array($d) || !isset($d['faze']) || !in_array($d['faze'], array('test', 'sonda'), true)) { continue; }
        if ($d['faze'] === 'sonda' && isset($tailRun[$RK[$i]]) && kben_noact($d)) { continue; }
        $id = isset($d['id']) && $d['id'] !== '' && $d['id'] !== null ? (string) $d['id'] : (isset($d['polozka']) ? (string) $d['polozka'] : '');
        $pid = intval($x->participant_id);
        if ($id === '' || isset($resp[$pid][$id]) || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
        $resp[$pid][$id] = floatval($d['spravne']) >= 1 ? 1 : 0;
    }
    $ok = array(); $scr = kben_scr_ids($T, $key);   // od 1.80.0: výsledek vyřazený screeningem se nepočítá jako uložený
    foreach ((array) $wpdb->get_results("SELECT id, participant_id FROM {$T}scores WHERE test_key IN ($src) AND valid >= 1 AND raw_score IS NOT NULL") as $x) { if (!isset($scr[intval($x->id)])) { $ok[intval($x->participant_id)] = 1; } }
    /* od 1.86.0: čištění norem (includes/norm-filter.php) – nedokončení, rychlé hádání, samé T, misfit, pravděpodobná opakování */
    $NF = array();
    if (function_exists('kbnf_eval')) { $skip = $drop; foreach ($RK as $i => $k) { if (isset($ner[$k])) { $skip[$i] = 1; } } $NF = kbnf_eval($rows, $DD, $RK, $skip, $P['tests'][$key], $ok, $T); }
    unset($rows, $DD);
    $pp = array();
    foreach ((array) $wpdb->get_results("SELECT * FROM {$T}participants") as $x) { $pp[intval($x->id)] = array(!isset($x->age) || $x->age === null ? null : intval($x->age), isset($x->mode) ? (string) $x->mode : ''); }
    $out = array();
    foreach ($resp as $pid => $r) {
        $e = kben_irt_eap($key, $r); if (!$e) { continue; }
        $has = isset($ok[$pid]);
        if (!$has && ($e['n'] < kben_th_min_n() || $e['se'] > kben_th_max_se())) { continue; }
        if (isset($NF[$pid]) && $NF[$pid][0] !== '') { continue; }   // od 1.86.0: vyřazeno čištěním norem
        $p = isset($pp[$pid]) ? $pp[$pid] : array(null, '');
        $out[] = array(round(floatval($e['theta']), 2), $p[0], $p[1], $has ? 1 : 0, $pid);
    }
    set_transient($ck, $out, 30 * MINUTE_IN_SECONDS);
    return $out;
}
/* théta pro srovnání – jedna hodnota na osobu (viz kben_theta_pool); $ST = tabulka výsledků dané verze */
function kben_theta_values($ST, $key, $amin, $amax, $skipCz, $adults) {
    $T = substr($ST, 0, -6); $gf = substr($ST, -11) === 'kbgf_scores'; $minA = $adults ? ($adults === 13 ? 13 : 18) : 0;
    $vals = array();
    foreach (kben_theta_pool($T, $key) as $v) {
        $age = $v[1]; $mode = $v[2];
        if ($skipCz && $mode === 'cz') { continue; }
        if ($gf && in_array($mode, array('cz', 'en'), true)) { continue; }   // gifted bez importovaných kopií z CZ a EN
        if ($minA && ($age === null || $age < $minA)) { continue; }
        if ($amin > 0 && ($age === null || $age < $amin)) { continue; }
        if ($amax > 0 && ($age === null || $age > $amax)) { continue; }
        $vals[] = $v[0];
    }
    return $vals;
}
/* od 1.70.65: český vzorek vážený podle vzdělání k populaci ČR (SLDB 2021, 15+: bez maturity ≈ 50 %, s maturitou ≈ 31,3 %, VŠ 18,7 %).
   Váží se jen dospělí (18+) se známým vzděláním; ostatní váha 1. Jen když má každá skupina aspoň 15 lidí; váhy omezené na 0,25–4 a pak přepočtené, aby součet vah dospělých = jejich počet (konečná váha může být o trochu nad 4).
   Vrací hodnoty jako {x, n} s n = 10× váha (celá čísla), aby klient mohl počítat percentil beze změny; skutečné N zvlášť. */
function kben_cz_weighted_theta($key, $amin, $amax) {
    global $wpdb; $pre = $wpdb->prefix; $P = kben_irt();
    $rows = array();
    foreach (array(array($pre . 'kb_', 0), array($pre . 'kbd_', 13)) as $T) {      // od 2026-11-03: všechny použitelné théty (viz kben_theta_pool)
        list($TP, $minAge) = $T; $PT = $TP . 'participants';
        $pool = kben_theta_pool($TP, $key); if (!$pool) { continue; }
        $dem = array();
        foreach ((array) $wpdb->get_results("SELECT id, demographics FROM $PT") as $x) { $dem[intval($x->id)] = (string) $x->demographics; }
        $by = array();
        foreach ($pool as $v) {
            $age = $v[1]; $pid = $v[4];
            if ($minAge && ($age === null || $age < $minAge)) { continue; }
            if ($amin > 0 && ($age === null || $age < $amin)) { continue; }
            if ($amax > 0 && ($age === null || $age > $amax)) { continue; }
            $dm = json_decode(isset($dem[$pid]) ? $dem[$pid] : '', true); $e = is_array($dm) && isset($dm['vzdelani']) ? (string) $dm['vzdelani'] : '';
            $g = in_array($e, array('zs', 'ss_bez_mat'), true) ? 'n' : (in_array($e, array('ss_mat', 'ss_studuji', 'vs_studuji'), true) ? 's' : (in_array($e, array('vos_bc', 'mgr', 'phd'), true) ? 'v' : ''));
            if ($age === null || $age < 18) { $g = ''; }
            $by[$TP . ':' . $pid] = array($v[0], $g);
        }
        $rows = array_merge($rows, array_values($by));
    }
    $TGT = array('n' => 0.50, 's' => 0.313, 'v' => 0.187);
    $cnt = array('n' => 0, 's' => 0, 'v' => 0); foreach ($rows as $r) { if ($r[1] !== '') { $cnt[$r[1]]++; } }
    $known = array_sum($cnt); $ok = $known > 0 && min($cnt) >= 15;
    $w = array('n' => 1, 's' => 1, 'v' => 1);
    if ($ok) {
        foreach ($TGT as $g => $t) { $w[$g] = max(0.25, min(4, $t * $known / $cnt[$g])); }
        $mass = 0; foreach ($cnt as $g => $c) { $mass += $w[$g] * $c; } foreach ($w as $g => $v) { $w[$g] = $v * $known / $mass; }   // součet vah dospělých = jejich počet
    }
    $counts = array(); $sw = 0; $sw2 = 0;
    foreach ($rows as $r) { $wi = $r[1] === '' ? 1 : $w[$r[1]]; $sw += $wi; $sw2 += $wi * $wi;
        $k = number_format($r[0], 2, '.', ''); $counts[$k] = (isset($counts[$k]) ? $counts[$k] : 0) + max(1, intval(round(10 * $wi))); }
    ksort($counts, SORT_NUMERIC); $bins = array(); foreach ($counts as $k => $n) { $bins[] = array('x' => floatval($k), 'n' => $n); }
    return array('n' => count($rows), 'bins' => $bins, 'vazeno' => $ok ? 1 : 0, 'n_ef' => $sw2 > 0 ? round($sw * $sw / $sw2) : 0, 'skupiny' => $cnt, 'vahy' => $ok ? array_map(function ($v) { return round($v, 2); }, $w) : null);
}
/* GET /distribution?zaklad=theta – rozložení théty (všechny verze testu dohromady) */
function kben_theta_distribution($r) {
    global $wpdb;
    $key = kben_clean_key($r->get_param('test'));
    $amin = intval($r->get_param('age_min')); $amax = intval($r->get_param('age_max'));
    $set = get_option('kben_settings', array()); $minn = isset($set['min_n']) ? intval($set['min_n']) : 30;
    if (!in_array($key, kben_irt_keys(), true)) { return array('n' => 0, 'min_n' => $minn, 'bins' => array(), 'theta' => 1); }
    $czOnly = $r->get_param('vzorek') === 'cz';          // od 1.70.44: jen český vzorek
    $enOnly = $r->get_param('vzorek') === 'en';          // od 1.71.0: jen anglicky mluvící vzorek (EN + gifted), přepínač ve výsledcích
    $ck = 'kben_thd_' . md5(wp_json_encode(array($key, $amin, $amax, kben_irt()['version'], $czOnly, $enOnly, 'gf4')));
    $c = get_transient($ck); if ($c !== false) { return $c; }
    $pre = $wpdb->prefix; $pool = in_array($key, kben_irt_pool_keys(), true) && true;
    $cz = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $pre . 'kb_scores')) === $pre . 'kb_scores';
    if ($czOnly) {
        if (!($pool && $cz)) { return array('n' => 0, 'min_n' => $minn, 'bins' => array(), 'theta' => 1); }
        $W = kben_cz_weighted_theta($key, $amin, $amax);
        $out = array('n' => $W['n'], 'min_n' => $minn, 'bins' => $W['bins'], 'theta' => 1, 'vazeno' => $W['vazeno'], 'n_ef' => $W['n_ef'], 'skupiny' => $W['skupiny'], 'vahy' => $W['vahy']);
        set_transient($ck, $out, 5 * MINUTE_IN_SECONDS); return $out;
    } elseif ($enOnly) {
        $vals = kben_theta_values(kben_table('scores'), $key, $amin, $amax, true, false);
        if ($pool) { $vals = array_merge($vals, kben_theta_values($pre . 'kbgf_scores', $key, $amin, $amax, false, false)); }   // gifted bez importů z CZ a EN
    } else {
    $vals = kben_theta_values(kben_table('scores'), $key, $amin, $amax, 'kben' === 'kben' && $cz, false);
    }
    if ($pool && !$enOnly) {
        if ('kben' === 'kb') { $vals = array_merge($vals, kben_theta_values($pre . 'kben_scores', $key, $amin, $amax, true, false)); }
        if ('kben' === 'kben') { $vals = array_merge($vals, kben_theta_values($pre . 'kb_scores', $key, $amin, $amax, false, false)); }
        $vals = array_merge($vals, kben_theta_values($pre . 'kbd_scores', $key, $amin, $amax, false, 13));   // dětská verze od 13 let (od 1.70.64; dřív jen rodiče 18+)
    }
    $counts = array();
    foreach ($vals as $v) { $k = number_format($v, 2, '.', ''); $counts[$k] = isset($counts[$k]) ? $counts[$k] + 1 : 1; }
    ksort($counts, SORT_NUMERIC); $bins = array();
    foreach ($counts as $k => $n) { $bins[] = array('x' => floatval($k), 'n' => $n); }
    $out = array('n' => count($vals), 'min_n' => $minn, 'bins' => $bins, 'theta' => 1);
    set_transient($ck, $out, 5 * MINUTE_IN_SECONDS);
    return $out;
}
