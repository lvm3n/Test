<?php
/* Čištění théty pro normy (KBNF 1.0, 2026-11-15) – SPOLEČNÝ soubor: stejná kopie je v Přehledu baterie (kb-prehled/norm-filter.php),
   v české baterii (kognitivni-baterie/includes/norm-filter.php) a v anglické baterii (cognitive-battery-en/includes/norm-filter.php).
   Když je aktivních víc pluginů, funkce se načtou jen jednou (function_exists) – při úpravě je třeba změnit všechny kopie.

   Do norem (srovnávacího souboru théty) nejde člověk, u kterého platí aspoň jedno z pravidel (kódy):
   – ned  nedokončený: nemá uložený platný výsledek a žádný jeho běh neskončil přirozeně – ani pravidlem ukončení (posledních
          'stop' skórovaných úloh chybně), ani koncem testu (tolik skórovaných úloh jako nejdelší běh stejné verze testu, s tolerancí 1),
          ani přechodem do sond. Typicky otevřel test, zkusil pár (nebo i 20) úloh a odešel, dokud se mu ještě dařilo – théta je pak
          stažená dolů a k průměru.
   – rg   rychlé hádání: aspoň 'rg_min' odpovědí rychlejších než práh úlohy (10 % mediánu času úlohy, 1–10 s; Wise & Ma, 2012),
          podíl odpovědí s úsilím RTE < 'rg_rte' (Wise & Kong, 2005) a z rychlých odpovědí správně méně než 'rg_acc' (rychlé a správné
          = úloha byla pro člověka snadná, to se nepočítá).
   – nt   samé „T“: aspoň 'nt_share' úloh skončilo vypršením času bez jakékoli akce (mimo konec běhu bez akce, ten řeší screening).
   – mf   misfit: standardizovaná věrohodnost odpovědí lz < 'lz' (Drasgow, Levine & Williams, 1985), jen od 10 kalibrovaných úloh –
          např. chyby v lehkých úlohách a správně v těžkých (náhodné klikání, nepozornost, nápověda).
   – rep  pravděpodobné opakování (např. v anonymním okně = nové anonymní id): v téže verzi baterie dřívější člověk se stejným věkem,
          pohlavím a vzděláním, nejvýš 'rep_days' dní předtím, aspoň 8 úloh vyřešených oběma a na nich medián poměru časů
          ≤ e^'rep_speed' (výchozí −0,9 ≈ 2,5× rychleji), a ne horší théta (o víc než 0,3). Vyřazuje se pozdější pokus, první zůstává.
   – sam  vlastní výpověď (od 1.2, otázky po dokončení testu v baterii CZ 4.27.0 / EN 1.86.0): u tohoto testu uvedl, že se nesnažil
          (snaha = ne), nebo že test či jeho úlohy dělal už dříve (drive = ano). Řádek odpovědí faze 'po_testu'.
   Pravidla se týkají jen norem; vlastní výsledek člověka se nemění. */
if (!function_exists('kbnf_defaults')) {
define('KBNF_VERSION', '1.2');
function kbnf_defaults() { return array('on' => 1, 'stop' => 3, 'rg_min' => 3, 'rg_rte' => 0.90, 'rg_acc' => 0.5, 'nt_share' => 0.25, 'lz' => -3.0, 'rep' => 1, 'rep_days' => 14, 'rep_speed' => -0.9); }
function kbnf_names() { return array('sam' => 'vlastní výpověď', 'ned' => 'nedokončený', 'rg' => 'rychlé hádání', 'nt' => 'samé T (čas bez akce)', 'mf' => 'misfit', 'rep' => 'pravděpodobné opakování'); }
function kbnf_noact($d) {
    return is_array($d) && array_key_exists('prvni_akce_ms', $d) && ($d['prvni_akce_ms'] === '' || $d['prvni_akce_ms'] === null) && !(isset($d['spravne']) && is_numeric($d['spravne']) && floatval($d['spravne']) >= 1);
}
/* od 1.2: odpovědi po dokončení testu (řádky faze 'po_testu'): participant_id => popis, když uvedl snaha = ne nebo drive = ano.
   $keys = klíče testů; vrací i podle sezení: ['p' => [pid => popis], 's' => ['session_id|test' => popis]] přes kbnf_self_all */
function kbnf_self_all($T, $keys) {
    global $wpdb; $out = array('p' => array(), 's' => array());
    if (!$keys) { return $out; }
    $in = "'" . implode("','", array_map('esc_sql', $keys)) . "'";
    foreach ((array) $wpdb->get_results("SELECT r.session_id, r.test_key, r.data, s.participant_id FROM {$T}rows r JOIN {$T}sessions s ON s.id = r.session_id WHERE r.test_key IN ($in) AND r.data LIKE '%\"faze\":\"po_testu\"%' ORDER BY r.id ASC") as $x) {
        $d = json_decode((string) $x->data, true); if (!is_array($d)) { continue; } $w = array();
        if (isset($d['snaha']) && $d['snaha'] === 'ne') { $w[] = 'nesnažil(a) se'; } if (isset($d['drive']) && $d['drive'] === 'ano') { $w[] = 'test dělal(a) už dříve'; }
        if (!$w) { continue; } $why = implode(', ', $w);
        $out['p'][intval($x->participant_id)] = $why; $out['s'][intval($x->session_id) . '|' . $x->test_key] = $why; }
    return $out;
}
function kbnf_self($T, $keys) { $a = kbnf_self_all($T, $keys); return $a['p']; }
function kbnf_med($a) { $n = count($a); if (!$n) { return null; } sort($a); return $n % 2 ? $a[($n - 1) / 2] : ($a[$n / 2 - 1] + $a[$n / 2]) / 2; }
function kbnf_eap($a, $B, $resp) {
    $n = 0; $L = array_fill(0, 61, 0.0);
    foreach ($resp as $id => $y) { if (!isset($B[$id])) { continue; } $n++; $b = floatval($B[$id]);
        for ($q = 0; $q < 61; $q++) { $z = $a * ((-5 + $q / 6) - $b); $L[$q] += $y ? -log(1 + exp(-$z)) : -log(1 + exp($z)); } }
    if (!$n) { return null; }
    $mx = -INF; $lp = array(); for ($q = 0; $q < 61; $q++) { $th = -5 + $q / 6; $lp[$q] = $L[$q] - $th * $th / 2; if ($lp[$q] > $mx) { $mx = $lp[$q]; } }
    $s = 0; $m = 0; for ($q = 0; $q < 61; $q++) { $th = -5 + $q / 6; $w = exp($lp[$q] - $mx); $s += $w; $m += $w * $th; }
    return $m / $s;
}
/* $rows = řádky odpovědí (objekty session_id, test_key, data, participant_id) v pořadí id; $DD = dekódovaná data řádků (stejné indexy);
   $RK = klíč běhu každého řádku; $skip = indexy řádků, které théta nepoužívá (běhy „jen otevřený“, konec bez akce);
   $TP = parametry IRT testu (a, b); $ok = participant_id => 1 (má uložený platný výsledek); $T = předpona tabulek (kvůli demografii).
   Vrací participant_id => array(kód nebo '', popis, ukazatele). Kód '' = do norem jde. */
function kbnf_eval($rows, $DD, $RK, $skip, $TP, $ok, $T, $S = null) {
    global $wpdb;
    $S = is_array($S) ? array_merge(kbnf_defaults(), $S) : kbnf_defaults();
    $a = floatval($TP['a']); $B = $TP['b'];
    $run = array(); $forMax = array(); $first = array(); $seen = array(); $t0 = array(); $rtAll = array(); $tks = array();
    foreach ((array) $rows as $i => $x) { $tks[$x->test_key] = 1;
        if (isset($skip[$i])) { continue; } $d = isset($DD[$i]) ? $DD[$i] : null;
        if (!is_array($d) || !isset($d['faze']) || !in_array($d['faze'], array('test', 'sonda'), true)) { continue; }
        $pid = intval($x->participant_id); $k = $RK[$i];
        if (!isset($run[$pid][$k])) { $run[$pid][$k] = array('e' => array(), 'n' => 0, 'f' => isset($d['forma']) ? (string) $d['forma'] : '', 'sonda' => 0); }
        if (!empty($d['cas'])) { $c = strtotime((string) $d['cas']); if ($c && (!isset($t0[$pid]) || $c < $t0[$pid])) { $t0[$pid] = $c; } }
        if ($d['faze'] === 'sonda') { $run[$pid][$k]['sonda'] = 1; }
        $pil = !empty($d['pilot']) || !empty($d['neskorovano']) || !empty($d['podlaha']);
        if ($d['faze'] === 'test' && !$pil && isset($d['spravne']) && $d['spravne'] !== '' && $d['spravne'] !== null) {
            $err = floatval($d['spravne']) < 1 && !(isset($d['skore']) && is_numeric($d['skore']) && floatval($d['skore']) > 0);   // částečný kredit není chyba (jako v baterii)
            $run[$pid][$k]['e'][] = $err ? 1 : 0; $run[$pid][$k]['n']++;
        }
        $id = isset($d['id']) && $d['id'] !== '' && $d['id'] !== null ? (string) $d['id'] : (isset($d['polozka']) ? (string) $d['polozka'] : '');
        if ($id === '' || isset($seen[$pid][$id]) || !isset($d['spravne']) || $d['spravne'] === '' || $d['spravne'] === null) { continue; }
        $seen[$pid][$id] = 1;
        $y = floatval($d['spravne']) >= 1 || ($x->test_key === 'pretahovana' && !empty($d['timeout']) && empty($d['preskoceno']) && isset($d['odpoved'], $d['reseni']) && $d['odpoved'] !== '' && $d['odpoved'] === $d['reseni']) ? 1 : 0;
        $na = kbnf_noact($d); $rt = isset($d['rt_ms']) && is_numeric($d['rt_ms']) ? floatval($d['rt_ms']) : null;
        $first[$pid][$id] = array($y, $rt, $na);
        if (!$na && $rt !== null && isset($B[$id])) { $rtAll[$id][] = $rt; }
    }
    foreach ($run as $pid => $rr) { foreach ($rr as $k => $r) { $f = $r['f']; if (!isset($forMax[$f]) || $r['n'] > $forMax[$f]) { $forMax[$f] = $r['n']; } } }
    $thr = array(); foreach ($rtAll as $id => $v) { if (count($v) >= 10) { $thr[$id] = max(1000, min(10000, 0.1 * kbnf_med($v))); } }
    /* demografie (opakování) */
    $self = kbnf_self($T, array_keys($tks));   // od 1.2: vlastní výpověď po testu
    $dem = array();
    foreach ((array) $wpdb->get_results("SELECT * FROM {$T}participants") as $p) {
        $j = isset($p->demographics) ? json_decode((string) $p->demographics, true) : null;
        if (empty($S['rep'])) { continue; } $sx = is_array($j) && isset($j['pohlavi']) ? (string) $j['pohlavi'] : ''; $ed = is_array($j) && isset($j['vzdelani']) ? (string) $j['vzdelani'] : '';
        if (isset($p->age) && $p->age !== null && $sx !== '' && $ed !== '' && $sx !== 'neuvedeno' && $ed !== 'neuvedeno') { $dem[intval($p->id)] = intval($p->age) . '|' . $sx . '|' . $ed; } }
    $out = array(); $th = array();
    foreach ($first as $pid => $F) {
        $resp = array(); $n = 0; $na = 0; $rap = 0; $rapOk = 0; $act = 0;
        foreach ($F as $id => $v) { $n++; if ($v[2]) { $na++; } else { $act++; if ($v[1] !== null && isset($thr[$id]) && $v[1] < $thr[$id]) { $rap++; $rapOk += $v[0]; } }
            if (isset($B[$id])) { $resp[$id] = $v[0]; } }
        $t = kbnf_eap($a, $B, $resp); $th[$pid] = $t;
        $lz = null; if ($t !== null && count($resp) >= 10) { $l0 = 0; $E = 0; $V = 0;
            foreach ($resp as $id => $y) { $p = 1 / (1 + exp(-$a * ($t - floatval($B[$id])))); $p = max(1e-6, min(1 - 1e-6, $p)); $l0 += $y ? log($p) : log(1 - $p); $E += $p * log($p) + (1 - $p) * log(1 - $p); $V += $p * (1 - $p) * pow(log($p / (1 - $p)), 2); }
            if ($V > 0) { $lz = ($l0 - $E) / sqrt($V); } }
        $rte = $act ? 1 - $rap / $act : null;
        $done = false;
        foreach ((isset($run[$pid]) ? $run[$pid] : array()) as $r) { $e = $r['e']; $m = count($e);
            if ($r['sonda'] || ($m >= $S['stop'] && array_sum(array_slice($e, -$S['stop'])) == $S['stop']) || ($m > 0 && isset($forMax[$r['f']]) && $m >= $forMax[$r['f']] - 1)) { $done = true; break; } }
        $code = ''; $why = '';
        if (isset($self[$pid])) { $code = 'sam'; $why = 'po testu uvedl(a): ' . $self[$pid]; }
        elseif (!isset($ok[$pid]) && !$done) { $code = 'ned'; $why = 'nedokončený (' . $n . ' úloh, bez přirozeného konce)'; }
        elseif ($rap >= $S['rg_min'] && $rte !== null && $rte < $S['rg_rte'] && $rapOk / $rap < $S['rg_acc']) { $code = 'rg'; $why = 'rychlé hádání (' . $rap . ' z ' . $act . ' rychle, z nich správně ' . $rapOk . ')'; }
        elseif ($n >= 4 && $na / $n >= $S['nt_share']) { $code = 'nt'; $why = 'čas bez akce u ' . $na . ' z ' . $n . ' úloh'; }
        elseif ($lz !== null && $lz < $S['lz']) { $code = 'mf'; $why = 'misfit lz = ' . number_format($lz, 2, ',', ''); }
        $out[$pid] = array($code, $why, array('n' => $n, 'rte' => $rte === null ? '' : round($rte, 3), 'rychle' => $rap, 'bez_akce' => $na, 'lz' => $lz === null ? '' : round($lz, 2), 'dokoncen' => $done ? 1 : 0, 'opak_z' => ''));
    }
    /* opakování: pozdější pokus stejné demografie, výrazně rychlejší na společně vyřešených úlohách */
    if (!empty($S['rep']) && $dem) {
        $G = array(); foreach ($out as $pid => $o) { if (isset($dem[$pid], $t0[$pid])) { $G[$dem[$pid]][] = $pid; } }
        foreach ($G as $g) { if (count($g) < 2) { continue; } usort($g, function ($p, $q) use ($t0) { return $t0[$p] - $t0[$q]; });
            foreach ($g as $bi => $pb) { if ($out[$pb][0] !== '') { continue; }
                for ($ai = 0; $ai < $bi; $ai++) { $pa = $g[$ai]; if ($t0[$pb] - $t0[$pa] > $S['rep_days'] * 86400 || $t0[$pb] <= $t0[$pa]) { continue; }
                    $lr = array(); foreach ($first[$pb] as $id => $v) { if ($v[0] && $v[1] && isset($first[$pa][$id]) && $first[$pa][$id][0] && $first[$pa][$id][1]) { $lr[] = log($v[1] / $first[$pa][$id][1]); } }
                    if (count($lr) < 8) { continue; } $md = kbnf_med($lr);
                    if ($md <= $S['rep_speed'] && $th[$pb] !== null && $th[$pa] !== null && $th[$pb] >= $th[$pa] - 0.3) {
                        $out[$pb][0] = 'rep'; $out[$pb][1] = 'opakování? ' . round(exp(-$md), 1) . '× rychleji než id ' . $pa . ' (' . count($lr) . ' úloh)'; $out[$pb][2]['opak_z'] = $pa; break; } } } }
    }
    return $out;
}
}
